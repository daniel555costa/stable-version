CREATE FUNCTION funct_disable_user ("idUser" character varying, "idAgencia" numeric, "idUserDisable" character varying, "disableModo" character varying) RETURNS "Result"
	LANGUAGE plpgsql
AS $$

DECLARE
  -- disableModo  (Force user to change password), B (Block user access)
  res "Result";

BEGIN
  
  res."RESULT" := 'false';
  
  update "user"
    set user_access = (case
                          when "disableModo" = 'B' then 0
                          when "disableModo" = 'F' then 2
                          else user_access
                       end),
       user_pwd = (case 
                      when "disableModo" = 'F' then md5(user_id)
                      else user_pwd
                   end)
    where user_id = "idUserDisable";


  res."RESULT" := 'true';
  res."MESSAGE" := 'Sucesso';

  return res;
END;
$$
