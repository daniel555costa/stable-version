CREATE FUNCTION ln () RETURNS character varying
	LANGUAGE plpgsql
AS $$

  DECLARE
    nl character varying;
  BEGIN
    nl := '
';
    return nl;
  END;
$$
