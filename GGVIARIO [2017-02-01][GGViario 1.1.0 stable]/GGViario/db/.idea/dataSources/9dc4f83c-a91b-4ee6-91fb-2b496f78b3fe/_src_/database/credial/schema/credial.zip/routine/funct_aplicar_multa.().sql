CREATE FUNCTION funct_aplicar_multa () RETURNS result
	LANGUAGE plpgsql
AS $$

  BEGIN
    PERFORM rule.funct_aplicar_multa();
    RETURN '(true,success)'::credial.result;
  end;
$$
