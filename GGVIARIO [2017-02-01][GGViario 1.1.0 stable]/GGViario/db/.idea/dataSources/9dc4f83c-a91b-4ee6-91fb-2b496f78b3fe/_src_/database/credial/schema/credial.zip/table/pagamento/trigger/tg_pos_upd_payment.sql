CREATE TRIGGER tg_pos_upd_payment
AFTER UPDATE ON pagamento
FOR EACH ROW EXECUTE PROCEDURE functg_pos_upd_payment()