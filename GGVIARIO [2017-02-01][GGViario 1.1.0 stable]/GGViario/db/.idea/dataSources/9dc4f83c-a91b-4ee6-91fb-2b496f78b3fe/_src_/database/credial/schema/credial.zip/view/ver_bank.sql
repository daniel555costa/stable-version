CREATE VIEW ver_bank AS
SELECT banco.banco_name AS "NAME",
    banco.banco_id AS "ID",
    banco.banco_sigla AS "SIGLA",
    lib.money(banco.banco_saldo) AS "SALDO",
    banco.banco_saldominimo,
    banco.banco_saldo
   FROM banco
  WHERE (banco.banco_state = (1)::numeric)
  ORDER BY banco.banco_name