CREATE VIEW ver_cheques_disponiveis AS
SELECT ch.cheq_id AS "ID",
    ag.age_name AS "AGENCIA",
    ct.banco_sigla AS "BANCO",
    ch.cheq_sequenceinicio AS "INICIO",
    ch.cheq_sequencefim AS "FIM",
    ch.cheq_total AS "TOTAL",
    ch.cheq_distribuido AS "DESTRIBUIDO",
        CASE
            WHEN ((ch.cheq_total > (0)::numeric) AND (((100)::numeric - ((ch.cheq_distribuido * (100)::numeric) / ch.cheq_total)) < (0)::numeric)) THEN '100%'::text
            WHEN (ch.cheq_total > (0)::numeric) THEN (to_char(((100)::numeric - ((ch.cheq_distribuido * (100)::numeric) / ch.cheq_total)), 'FM900'::text) || '%'::text)
            ELSE '0%'::text
        END AS "RESTANTE",
        CASE
            WHEN ((ch.cheq_total > (0)::numeric) AND (((100)::numeric - ((ch.cheq_distribuido * (100)::numeric) / ch.cheq_total)) < (0)::numeric)) THEN (100)::numeric
            WHEN (ch.cheq_total > (0)::numeric) THEN ((100)::numeric - ((ch.cheq_distribuido * (100)::numeric) / ch.cheq_total))
            ELSE NULL::numeric
        END AS "RESTANTE_NUMBER"
   FROM ((chequempresa ch
     JOIN agencia ag ON ((ch.cheq_age_owner = ag.age_id)))
     JOIN banco ct ON ((ch.cheq_banco_id = ct.banco_id)))
  WHERE (ch.cheq_state = (1)::numeric)
  ORDER BY
        CASE
            WHEN ((ch.cheq_total > (0)::numeric) AND (((100)::numeric - ((ch.cheq_distribuido * (100)::numeric) / ch.cheq_total)) < (0)::numeric)) THEN (100)::numeric
            WHEN (ch.cheq_total > (0)::numeric) THEN ((100)::numeric - ((ch.cheq_distribuido * (100)::numeric) / ch.cheq_total))
            ELSE NULL::numeric
        END