CREATE FUNCTION funct_cheque_restore (iduser integer, idagencia integer, idchequeanular integer, idchequeresrtore integer) RETURNS result
	LANGUAGE plpgsql
AS $$

    DECLARE
      vResult result;
      i RECORD;
    BEGIN
      vResult := '(false,"Nenum cheque para restaurar")'::result;
      for i in(
        SELECT *
          from funct_cheque_restore_effect() ef
          ORDER BY ef."OPR" ASC
      ) loop
        CASE

          WHEN i."OPR" = -1 THEN
            UPDATE  chequempresa
              set cheq_state = -1
              where cheq_id = i."ID";
            vResult := '(true,"Ultimo cheque restaurado!")'::result;

          WHEN i."OPR" = 1 THEN
            UPDATE chequempresa
              set cheq_state = 1
              where cheq_id = i."ID";
            vResult := '(true,"Cheque restaurado")'::result;
        END CASE;
      END LOOP;

      RETURN vResult;

    END;
$$
