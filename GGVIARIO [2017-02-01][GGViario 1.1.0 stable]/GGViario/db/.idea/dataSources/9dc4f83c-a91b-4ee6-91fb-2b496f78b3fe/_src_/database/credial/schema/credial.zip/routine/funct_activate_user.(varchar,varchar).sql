CREATE FUNCTION funct_activate_user (userid character varying, userpwd character varying) RETURNS TABLE("RESULT" character varying, "MESSAGE" text)
	LANGUAGE plpgsql
AS $$

   declare
      pwdMd5 character varying(32);
      userData record;
   begin
	  pwdMd5 := md5(userPwd);
	  "RESULT" := 'false';
	  
	  select * into userData
	     from "user" us
	     where us.user_id = userId;
	     
	  if userData.user_access != 2 then
	     "MESSAGE" := 'O utilizador não esta no estado preativo';
	  else 
	     update "user"
	        set user_pwd = pwdMd5,
	            user_access = 1
	        where user_id = userId;
	        
	     "RESULT" := 'true';
	     "MESSAGE" := 'Utilizador ativo';
	  end if;
	  
	  return next;
   end 
$$
