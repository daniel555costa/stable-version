CREATE FUNCTION funct_load_bancomovimentation ("idUser" character varying, "idAgencia" numeric, "idBanco" numeric) RETURNS TABLE("ID" numeric, "DEBITO" character varying, "CREDITO" character varying, "LIBELE" character varying, "DATA" character varying)
	LANGUAGE sql
AS $$


  select bm.bancomov_id,
        lib.money(bm.bancomov_debito),
        lib.money(bm.bancomov_credito),
        bm.bancomov_libele,
        to_char(bm.bancomov_dtreg, 'DD-MM-YYYY')
    from bancomovimento bm
    where bm.bancomov_banco_id = "idBanco"

$$
