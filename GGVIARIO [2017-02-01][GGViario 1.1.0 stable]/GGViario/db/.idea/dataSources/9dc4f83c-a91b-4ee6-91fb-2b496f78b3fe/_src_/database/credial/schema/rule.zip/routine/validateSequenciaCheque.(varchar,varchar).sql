CREATE FUNCTION validateSequenciaCheque ("sequenciaInicio" character varying, "sequenciaFim" character varying) RETURNS "ValidateResult"
	LANGUAGE plpgsql
AS $$

  DECLARE
    tt numeric;
    inicio numeric := to_number("sequenciaInicio", '000000000000000000000000000000');
    fim numeric := to_number("sequenciaFim", '000000000000000000000000000000');
    res "ValidateResult";
    che chequempresa;
  BEGIN
    select count(*) into tt
      from chequempresa ch
        where inicio BETWEEN  (ch.cheq_sequenceinicio::numeric) and (ch.cheq_sequencefim::numeric)
          or fim BETWEEN  (ch.cheq_sequenceinicio::numeric) and (ch.cheq_sequencefim::numeric)
          or (ch.cheq_sequenceinicio::numeric) between inicio and fim
          or (ch.cheq_sequencefim::numeric) between inicio and fim
          or "sequenciaInicio" = ch.cheq_sequenceinicio
          or "sequenciaInicio" = ch.cheq_sequencefim
          or "sequenciaFim" = ch.cheq_sequenceinicio
          or "sequenciaFim" = ch.cheq_sequencefim;

      if tt != 0 then
        res."RESULT" := false;
        res."MESSAGE" := message('CHEQUE.RANGE.INTERCALE');
      elsif length("sequenciaFim") not in(28)
        or length("sequenciaInicio") not in(28) then
        res."RESULT" := false;
        res."MESSAGE" := message('CHEQUE.INVALID.SEQUENCE.NUMBER');
      else
        res."RESULT" := true ;
        res."MESSAGE" := 'Sucesso';
      end if;

      return res;
   END;
$$
