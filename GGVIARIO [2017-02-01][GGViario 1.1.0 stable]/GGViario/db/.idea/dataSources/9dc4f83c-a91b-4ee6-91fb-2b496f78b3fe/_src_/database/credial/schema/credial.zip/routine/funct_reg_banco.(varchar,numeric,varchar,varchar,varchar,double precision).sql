CREATE FUNCTION funct_reg_banco ("idUser" character varying, "idAgencia" numeric, "siglaBanco" character varying, "nomeBanco" character varying, "codBanco" character varying, "saldoMinimo" double precision) RETURNS result
	LANGUAGE plpgsql
AS $$

DECLARE
  tt numeric; -- verificador da quantidade de sigla
  res result;
BEGIN
  res.result := FALSE;

  -- contabilizar a quantidade dos bancos com essa sigla
  select count(*) into tt
  from banco bc
  where upper(bc.banco_sigla) = upper("siglaBanco");

  -- se houver mais de zero banco com a mese sigla então
  if tt>0 then
    res.message:= message('SIGLA OF BANK ALERED EXIST');
    return res;
  END IF;

  insert into banco (
    banco_age_id,
    banco_user_id,
    banco_sigla,
    banco_name,
    banco_cod,
    banco_saldominimo
  ) values (
    "idAgencia",
    "idUser",
    "siglaBanco",
    "nomeBanco",
    "codBanco",
    "saldoMinimo"
  );

  res.result := TRUE ;
  res.message := 'Sucesso';
  return res;
END;
$$
