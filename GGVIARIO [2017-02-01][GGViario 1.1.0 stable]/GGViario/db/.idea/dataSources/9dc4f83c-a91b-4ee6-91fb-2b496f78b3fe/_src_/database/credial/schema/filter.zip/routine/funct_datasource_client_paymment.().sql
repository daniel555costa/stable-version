CREATE FUNCTION funct_datasource_client_paymment () RETURNS TABLE("NIF" character varying, "NAME" character varying, "SURNAME" character varying, "DOSSIER" character varying, "TELE" character varying, "ID AGENCIA" integer, "QUANTIDADE DE CREDITO" integer, name_noaccent character varying, surname_noaccent character varying, "CREDITO CHEQUE NUMBER" character varying, "CREDITO NUMNER" character varying, "PAGAMENTO DOCUMENTO PREVISTO" character varying, "PAGAMENTO DOCUMENTO REAL" character varying)
	LANGUAGE sql
AS $$


  SELECT DISTINCT
    mcs."NIF",
    mcs."NAME",
    mcs."SURNAME",
    mcs."DOSSIER",
    mcs."TELE",
    mcs."ID AGENCIA",
    mcs."QUANTIDADE DE CREDITO",
    mcs.name_noaccent,
    mcs.surname_noaccent,
    ct.credi_numcheque AS "CREDITO CHEQUE NUMBER",
    ct.credi_numcredito AS "CREDITO NUMBER",
    pay.paga_numdocumentopagamento AS "PAGAMENTO DOCUMENTO PREVISTO",
    pay.paga_numdocumentopagamentoreal AS "PAGAMENTO DOCUMENTO REAL"
   FROM filter.funct_datasource_client_simple() mcs("NIF", "NAME", "SURNAME", "DOSSIER", "TELE", "ID AGENCIA", "QUANTIDADE DE CREDITO", name_noaccent, surname_noaccent)
     JOIN credial.credito ct ON mcs."NIF" = ct.credi_dos_nif
     JOIN credial.pagamento pay ON ct.credi_id = pay.paga_credi_id

$$
