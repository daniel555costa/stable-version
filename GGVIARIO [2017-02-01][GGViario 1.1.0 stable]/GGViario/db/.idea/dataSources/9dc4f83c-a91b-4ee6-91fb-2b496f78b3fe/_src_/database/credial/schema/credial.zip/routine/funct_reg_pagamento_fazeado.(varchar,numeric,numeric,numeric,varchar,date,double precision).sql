CREATE FUNCTION funct_reg_pagamento_fazeado ("idUser" character varying, "idAgencia" numeric, "idPagamento" numeric, "idBanco" numeric, "numeroDocumentoPagamento" character varying, "dataDocumentoPagamento" date, "valorPagamento" double precision) RETURNS "Result"
	LANGUAGE sql
AS $$

  insert into pagamentofazeado(
    pagafaze_paga_id, 
    pagafaze_banco_id,
    pagafaze_age_id,
    pagafaze_user_id,
    pagafaze_numdocumentopagamento,
    pagafaze_dtdocumentopagamento,
    pagafaze_value
  ) values (
      "idPagamento",
        "idBanco",
        "idAgencia",
        "idUser",
        "numeroDocumentoPagamento",
        "dataDocumentoPagamento",
        "valorPagamento"
  );
  
  select '(true,Sucesso)'::"Result";
$$
