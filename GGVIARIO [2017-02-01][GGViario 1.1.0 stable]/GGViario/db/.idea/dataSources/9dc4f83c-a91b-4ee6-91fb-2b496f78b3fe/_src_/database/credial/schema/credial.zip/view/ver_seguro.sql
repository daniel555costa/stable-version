CREATE VIEW ver_seguro AS
SELECT se.seg_id AS "ID",
    se.seg_value AS "SEGURO",
    to_char(se.seg_dtreg, 'DD-MM-YYYY'::text) AS "DATA",
        CASE
            WHEN (se.seg_state = (1)::numeric) THEN 'Ativo'::text
            ELSE 'Inativo'::text
        END AS "ESTADO"
   FROM seguro se
  ORDER BY se.seg_dtreg DESC