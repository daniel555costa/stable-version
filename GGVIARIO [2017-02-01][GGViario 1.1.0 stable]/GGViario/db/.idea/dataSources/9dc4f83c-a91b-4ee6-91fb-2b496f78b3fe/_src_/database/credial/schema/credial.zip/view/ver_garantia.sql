CREATE VIEW ver_garantia AS
SELECT objecto.obj_id AS "ID",
    objecto.obj_desc AS "DESC"
   FROM objecto
  WHERE ((objecto.obj_tobj_id = (6)::numeric) AND (objecto.obj_state = (1)::numeric))