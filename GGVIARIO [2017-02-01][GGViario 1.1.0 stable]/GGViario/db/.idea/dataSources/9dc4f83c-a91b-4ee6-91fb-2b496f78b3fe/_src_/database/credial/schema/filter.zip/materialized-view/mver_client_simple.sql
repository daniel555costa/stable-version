CREATE MATERIALIZED VIEW mver_client_simple AS
SELECT funct_datasource_client_simple."NIF",
    funct_datasource_client_simple."NAME",
    funct_datasource_client_simple."SURNAME",
    funct_datasource_client_simple."DOSSIER",
    funct_datasource_client_simple."TELE",
    funct_datasource_client_simple."ID AGENCIA",
    funct_datasource_client_simple."QUANTIDADE DE CREDITO",
    funct_datasource_client_simple.name_noaccent,
    funct_datasource_client_simple.surname_noaccent
   FROM filter.funct_datasource_client_simple() funct_datasource_client_simple("NIF", "NAME", "SURNAME", "DOSSIER", "TELE", "ID AGENCIA", "QUANTIDADE DE CREDITO", name_noaccent, surname_noaccent)