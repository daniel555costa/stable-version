CREATE FUNCTION hasUserNif ("userNif" character varying) RETURNS boolean
	LANGUAGE plpgsql
AS $$

  declare
    tt numeric;
  begin 
    -- Verificar se ja existe algum utilizador portando esse numero de NIF
    select count(*)  into tt
      from "user" 
      where "user".user_id = "userNif";
    
    return tt > 0;
  END;
$$
