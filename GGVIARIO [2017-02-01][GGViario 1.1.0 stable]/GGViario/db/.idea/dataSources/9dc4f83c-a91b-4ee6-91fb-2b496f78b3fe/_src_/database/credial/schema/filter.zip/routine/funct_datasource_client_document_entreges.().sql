CREATE FUNCTION funct_datasource_client_document_entreges () RETURNS TABLE("NIF" character varying, "NAME" character varying, "SURNAME" character varying, "DOSSIER" character varying, "TELE" character varying, "ID AGENCIA" integer, "QUANTIDADE DE CREDITO" integer, name_noaccent character varying, surname_noaccent character varying, "DOCUMENT" character varying, "TYPE DOCUMENT" character varying, typedocument_noaccent character varying, document_noaccent character varying)
	LANGUAGE sql
AS $$

  SELECT mcs."NIF",
    mcs."NAME",
    mcs."SURNAME",
    mcs."DOSSIER",
    mcs."TELE",
    mcs."ID AGENCIA",
    mcs."QUANTIDADE DE CREDITO",
    mcs.name_noaccent,
    mcs.surname_noaccent,
    doc.docentre_desc AS "DOCUMENT",
    tpgar.obj_desc as "TYPE DOCUMENT",
    upper(lib.funaccent(tpgar.obj_desc)) AS typedocument_noaccent,
    upper(lib.funaccent(doc.docentre_desc)) AS document_noaccent
   FROM filter.funct_datasource_client_simple() mcs("NIF", "NAME", "SURNAME", "DOSSIER", "TELE", "ID AGENCIA", "QUANTIDADE DE CREDITO", name_noaccent, surname_noaccent)
     JOIN credial.credito ce ON mcs."NIF"  = ce.credi_dos_nif
     JOIN credial.documentoentregue doc ON ce.credi_id = doc.docentre_credi_id
     JOIN credial.objecto tpgar ON ce.credi_obj_fonte = tpgar.obj_id
$$
