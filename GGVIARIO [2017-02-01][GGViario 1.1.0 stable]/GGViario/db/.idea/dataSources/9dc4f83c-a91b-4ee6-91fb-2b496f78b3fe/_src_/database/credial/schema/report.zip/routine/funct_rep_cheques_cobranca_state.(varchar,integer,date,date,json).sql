CREATE FUNCTION funct_rep_cheques_cobranca_state ("idUser" character varying, "idAgencia" integer, "dataInicio" date, "dataFim" date, filter json) RETURNS TABLE("ID" integer, "NIF" character varying, "NAME" character varying, "SURNAME" character varying, "PAGAMENTO NUM DOCUMENTO" character varying, "VALOR CHEQUE REEMBOLSO" character varying, "DATA DOCUMENTO PAGAMENTO PREVISTO DEPOSITO" date, "BANCO SIGLA" character varying, "PAGAMENTO DATA ENDOSSADO" date)
	LANGUAGE plpgsql
AS $$

  DECLARE
    
    stateReport integer DEFAULT filter->'state' ;
    idAgenciaReport integer DEFAULT filter-> 'agencia';
    idBancoReport integer DEFAULT filter->'banco';
    idLocalTrabalhoReport integer DEFAULT filter -> 'localTrabalho';
    idTipoCreditoReport integer DEFAULT filter-> 'tipoCredito';



    sumTotalValorReembolso FLOAT DEFAULT 0;
    i RECORD;
  BEGIN
    -- Essa funcao corrosponde ao visualizaçao do cheq
    -- Carregar os dados das cobrancas do cheque em um dado intervalo de tempo
    -- Efetuara o somatorio dos valores recoperados
    -- Quando a agentia ou o tipo do credito equals -1 then siginifica que se pretende carregar todas as informacoes

    FOR i IN (
      SELECT
        pay.paga_id as id,
        dos.dos_nif as nif,
        dos.dos_name as name,
        dos.dos_surname as surname,
        pay.paga_numdocumentopagamento as numDocumentoPagamento,
        pay.paga_reembolso as valorChequeReembolso,
        pay.paga_dtdocumentopagamento as dataDocumentoPagamentoPrevisto,
        bc.banco_sigla as bancoSigla,
        pay.paga_dtendossado as dataPagamentoEndossado
      FROM credial.dossiercliente dos
        INNER JOIN credial.historicocliente his ON dos.dos_nif = his.hisdos_dos_nif
        INNER JOIN credial.credito ce on dos.dos_nif = ce.credi_dos_nif
        INNER JOIN credial.taxa tx ON ce.credi_taxa_id = tx.taxa_id
        INNER JOIN credial.pagamento pay ON ce.credi_id = pay.paga_credi_id
        INNER JOIN credial.banco bc on pay.paga_banco_id = bc.banco_id
      WHERE his.hisdos_state = 1
        and dos.dos_state = 1
        and (pay.paga_state = stateReport OR stateReport IS NULL)
        and (pay.paga_dtdocumentopagamento BETWEEN "dataInicio" AND  "dataFim")
        and (his.hisdos_obj_localtrabalho = idLocalTrabalhoReport or idLocalTrabalhoReport IS NULL)
        and (pay.paga_banco_id = idBancoReport OR idBancoReport IS NULL)
        and (pay.paga_age_id = idAgenciaReport OR idAgenciaReport IS NULL)
        and (tx.taxa_obj_tipocredito = idTipoCreditoReport OR idTipoCreditoReport IS NULL)
    )
    LOOP
      "ID" := i.id;
      "NIF" := i.nif;
      "NAME" := i.name;
      "SURNAME" := i.surname;
      "PAGAMENTO NUM DOCUMENTO" := i.numDocumentoPagamento;
      "VALOR CHEQUE REEMBOLSO" := i.valorChequeReembolso;
      "DATA DOCUMENTO PAGAMENTO PREVISTO DEPOSITO" := i.dataDocumentoPagamentoPrevisto;
      "BANCO SIGLA" := i.bancoSigla;
      "PAGAMENTO DATA ENDOSSADO" := i.dataPagamentoEndossado;

      sumTotalValorReembolso := sumTotalValorReembolso + i.valorChequeReembolso;

      RETURN NEXT;

    END LOOP;

    "ID" := null;
    "NIF" := 'TOTAL';
    "NAME" := NULL;
    "SURNAME" := NULL;
    "PAGAMENTO NUM DOCUMENTO" := NULL;
    "VALOR CHEQUE REEMBOLSO" := sumTotalValorReembolso;
    "DATA DOCUMENTO PAGAMENTO PREVISTO DEPOSITO" := NULL;
    "BANCO SIGLA" := NULL;
    "PAGAMENTO DATA ENDOSSADO" := NULL;


  END;
$$
