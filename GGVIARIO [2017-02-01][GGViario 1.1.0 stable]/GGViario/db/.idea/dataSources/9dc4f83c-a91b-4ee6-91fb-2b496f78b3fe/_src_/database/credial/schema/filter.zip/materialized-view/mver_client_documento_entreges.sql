CREATE MATERIALIZED VIEW mver_client_documento_entreges AS
SELECT funct_datasource_client_document_entreges."NIF",
    funct_datasource_client_document_entreges."NAME",
    funct_datasource_client_document_entreges."SURNAME",
    funct_datasource_client_document_entreges."DOSSIER",
    funct_datasource_client_document_entreges."TELE",
    funct_datasource_client_document_entreges."ID AGENCIA",
    funct_datasource_client_document_entreges."QUANTIDADE DE CREDITO",
    funct_datasource_client_document_entreges.name_noaccent,
    funct_datasource_client_document_entreges.surname_noaccent,
    funct_datasource_client_document_entreges."DOCUMENT",
    funct_datasource_client_document_entreges."TYPE DOCUMENT",
    funct_datasource_client_document_entreges.typedocument_noaccent,
    funct_datasource_client_document_entreges.document_noaccent
   FROM filter.funct_datasource_client_document_entreges() funct_datasource_client_document_entreges("NIF", "NAME", "SURNAME", "DOSSIER", "TELE", "ID AGENCIA", "QUANTIDADE DE CREDITO", name_noaccent, surname_noaccent, "DOCUMENT", "TYPE DOCUMENT", typedocument_noaccent, document_noaccent)