CREATE FUNCTION funct_change_menuser ("idUser" character varying, "idAgencia" integer, "idUserMenuOwner" character varying, "arrayListMenusSelected" integer[]) RETURNS result
	LANGUAGE plpgsql
AS $$


  DECLARE
    i RECORD;
    iMenu NUMERIC;
  BEGIN

    -- Carregar os menus do utilizador que nao aparecem na lista dos menus 
      -- selecionados
    FOR i IN (
      select *
        from menuser mu
        where mu.muser_user_user = "idUserMenuOwner"
          and mu.muser_state = 1
          and mu.muser_menu_id not in (
            SELECT *
              FROM unnest("arrayListMenusSelected")
        )
    ) LOOP

      -- Dessativar todos esses menus
      UPDATE menuser
        set muser_state = 0,
            muser_dtfim = now()
        where muser_id = i.muser_id;

    END LOOP;

    
    -- selecionar na lista dos menus selecionados
      -- os menus em que o utilizador nao tem atual acesso ao mesmo
    FOR iMenu IN (
      SELECT menu_id
        from unnest("arrayListMenusSelected") menu_id
        WHERE menu_id not in (
          select m.muser_menu_id
            from menuser m
            where m.muser_user_user = "idUserMenuOwner"
              and m.muser_state = 1
        )
    ) LOOP

      PERFORM funct_reg_menuser_grant(
          "idUser",
          "idAgencia"::numeric,
          "idUserMenuOwner",
          iMenu,
          null
      );

    END LOOP ;
    
    -- 
    RETURN '(true,Sucesso)'::result;
  END;
$$
