CREATE FUNCTION funct_reg_credito_import_simulacao ("idUser" character varying, "idAgencia" numeric, "idClientNif" character varying, "valorCredito" double precision, "totalPagar" double precision, "numeroPrestacao" numeric, "dataInicio" date, "dataFinalizar" date, "idTaxa" numeric, "numeroCheque" character varying, "objectoFontePagamento" numeric, "idCheque" numeric, "valorDesconto" double precision, "objectoTipoCredito" numeric, taeg double precision) RETURNS TABLE("RESULT" character varying, "MESSAGE" character varying, "ID CREDITO" numeric, "NUMERO CREDITO" character varying)
	LANGUAGE plpgsql
AS $$

  DECLARE
    numeroCredito character varying(12);
    randomNumCredito "Result";
    tt numeric;
    resValidator result;
    vSeguro record;
    idCredito numeric;
  BEGIN

    -- criar um numero de credito aleatoriamente
    randomNumCredito := rule."generateNumCredit"("idUser", "idAgencia", "idClientNif", "numeroCheque");

    --se nao consegir criar o numero de credito entao retornar o resultado da criacao do numero de credito
    if randomNumCredito."RESULT" = 'false' then
      "RESULT" :='false';
      "MESSAGE" := randomNumCredito."RESULT"."MESSAGE";
      RETURN next;
    END IF;

    numeroCredito := randomNumCredito."MESSAGE";


    -- verificar a desponibilidade de saldo no banco
    resValidator := rule.check_saldo_bank("idCheque", "valorCredito", 'C');
    if not resValidator.result then
      "RESULT" := 'false';
      "MESSAGE" := resValidator.message;
      return next;
    end if;

    select * into vSeguro
      from seguro
      where seg_state = 1
      limit 1;

    insert into credito(
      credi_dos_nif,
      credi_age_id,
      credi_obj_tipopagamento,
      credi_cheq_id,
      credi_obj_fonte,
      credi_user_id,
      credi_taxa_id,
      credi_seg_id,
      credi_valuecredito,
      credi_totalpagar,
      credi_numprestacao,
      credi_dtinicio,
      credi_dtfinalizar,
      credi_numcredito,
      credi_numcheque,
      credi_desconto,
      credi_taeg
    ) values (
      "idClientNif",
      "idAgencia",
      "objectoTipoCredito",
      "idCheque",
      "objectoFontePagamento",
      "idUser",
      "idTaxa",
      vSeguro.seg_id,
      "valorCredito",
      "totalPagar",
      "numeroPrestacao",
      "dataInicio",
      "dataFinalizar",
      numeroCredito,
      "numeroCheque",
      "valorDesconto",
      taeg
    ) returning credi_id into idCredito;

    "RESULT" := 'true';
    "MESSAGE" := 'Sucessso';
    "ID CREDITO" := idCredito;
    "NUMERO CREDITO" := numeroCredito;

    return next;
  END;
$$
