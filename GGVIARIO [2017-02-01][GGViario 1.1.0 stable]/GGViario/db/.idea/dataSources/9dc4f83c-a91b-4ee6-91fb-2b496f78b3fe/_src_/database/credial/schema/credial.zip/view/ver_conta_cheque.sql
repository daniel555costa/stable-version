CREATE VIEW ver_conta_cheque AS
SELECT ct.conta_id AS "ID",
    (((bc.banco_sigla)::text || ' - '::text) || (ct.conta_desc)::text) AS "CONTA"
   FROM (conta ct
     JOIN banco bc ON ((ct.conta_banco_id = bc.banco_id)))