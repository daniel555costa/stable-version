CREATE FUNCTION funct_add_menuperfil ("idUser" character varying, "idAgencia" numeric, "idPerfil" numeric, "idMenu" numeric) RETURNS "Result"
	LANGUAGE plpgsql
AS $$

  DECLARE
    res "Result";
    hasMenuInPerfil numeric;
  BEGIN
    res."RESULT" := 'false';

    select count(*) into hasMenuInPerfil
      from menuperfil mf
      where mf.menuperf_menu_id = "idMenu"
        and mf.menuperf_tperf_id = "idPerfil"
        and mf.menuperf_state = 1;

    if hasMenuInPerfil != 0 then
      res."MESSAGE" := message('MENUPERF.MENU.EXIST');
      return res;
    END IF;
    
    insert into menuperfil(
      menuperf_menu_id,
      menuperf_tperf_id, 
      menuperf_user_id, 
      menuperf_age_id
    ) values (
      "idMenu",
      "idPerfil",
      "idUser",
      "idAgencia"
    );
    
    res."RESULT" := 'true';
    res."MESSAGE" := 'Sucesso';
    
    return res;

  END;
$$
