CREATE FUNCTION funct_load_user_by_agency ("idUser" character varying, "idAgencia" numeric, "idAgenciaLoad" numeric) RETURNS TABLE("ID" character varying, "NAME" character varying, "SURNAME" character varying, "PHOTO" bytea)
	LANGUAGE sql
AS $$

  select "user".user_id,
      "user".user_name,
      "user".user_surname,
      "user".user_photo
    from "user" 
      inner join trabalha tr on "user".user_id = tr.trab_user_user
    where tr.trab_age_agencia = "idAgenciaLoad";
$$
