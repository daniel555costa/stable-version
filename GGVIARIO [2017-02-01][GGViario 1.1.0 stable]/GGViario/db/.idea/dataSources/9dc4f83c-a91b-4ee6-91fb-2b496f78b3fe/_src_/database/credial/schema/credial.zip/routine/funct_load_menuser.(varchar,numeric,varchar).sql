CREATE FUNCTION funct_load_menuser ("idUser" character varying, "idAgencia" numeric, "idUserLoad" character varying) RETURNS SETOF ver_menu_active
	LANGUAGE sql
AS $$

  select mactive.*
    from ver_menu_active  mactive
      inner join menuser muser on mactive."ID" = muser.muser_menu_id
    where muser.muser_user_user = "idUserLoad"
      and muser.muser_state = 1
  ;
$$
