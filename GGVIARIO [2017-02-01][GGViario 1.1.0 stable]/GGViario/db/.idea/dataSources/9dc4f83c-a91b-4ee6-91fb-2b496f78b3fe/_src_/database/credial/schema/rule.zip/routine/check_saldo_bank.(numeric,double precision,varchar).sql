CREATE FUNCTION check_saldo_bank (id numeric, "ammountRequire" double precision, "idOfEntity" character varying DEFAULT 'B'::character varying) RETURNS result
	LANGUAGE plpgsql
AS $$

  DECLARE
  -- idOfEntity indica que entidade deve o id pertencte {C - cheque | B - Banco}
    idBanco numeric;
    res credial.result;
    tt numeric;
  BEGIN
    res.result := false;

    -- carregar o veridadeiro id do banco
    if "idOfEntity" = 'B' then
      idBanco := id;
    elsif "idOfEntity" = 'C' then

      select ct.conta_banco_id into idBanco
        from credial.chequempresa ce
          INNER JOIN credial.conta ct on ce.cheq_conta_id = ct.conta_id
        WHERE  ce.cheq_id = id;
    END IF;

    -- verificar o baco possui o saldo soficiente para cobrir a requisisa
    select count(*) into tt
      from  credial.banco bc
      where bc.banco_saldo >= "ammountRequire"
        and bc.banco_id = idBanco;

    if tt = 0 then
      res.message := credial.message('SALDO INSUFICIENTE');
    else
      res.result := true;
      res.message := credial.message('EXISTE SALDO');
    END IF;

    return res;
  END;
$$
