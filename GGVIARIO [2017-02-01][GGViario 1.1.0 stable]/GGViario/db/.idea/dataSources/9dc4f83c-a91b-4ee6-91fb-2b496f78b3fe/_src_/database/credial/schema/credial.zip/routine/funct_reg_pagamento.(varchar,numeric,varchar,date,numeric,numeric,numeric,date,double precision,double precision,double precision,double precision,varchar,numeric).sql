CREATE FUNCTION funct_reg_pagamento ("idUser" character varying, "idAgencia" numeric, "numeroDOcumnetoPagamento" character varying, "dataDocumentoPagamento" date, "idObjectoTipoPagamneto" numeric, "idCredito" numeric, periodo numeric, "dataSaque" date, taxa double precision, reembolso double precision, desconto double precision, "valorReal" double precision, conta character varying, "idBanco" numeric) RETURNS "Result"
	LANGUAGE plpgsql
AS $$

DECLARE
  res "Result";
BEGIN
  res."RESULT" := 'true';
  INSERT INTO pagamento (
    paga_user_id,
    paga_obj_tipopagamento,
    paga_credi_id,
    paga_banco_id,
    paga_age_id,
    paga_numdocumentopagamento,
    paga_dtdocumentopagamento,
    paga_taxa,
    paga_periodo,
    paga_reembolso,
    paga_valoreal,
    paga_conta,
    paga_desconto,
    paga_dtsaque
  ) VALUES (
    "idUser",
    "idObjectoTipoPagamneto",
    "idCredito",
    "idBanco",
    "idAgencia",
    "numeroDOcumnetoPagamento",
    "dataDocumentoPagamento",
    taxa,
    periodo,
    reembolso,
    "valorReal",
    conta,
    desconto,
    "dataSaque"
  );

  res."RESULT" := 'true';
  res."MESSAGE" := 'Sucesso';
  RETURN res;
END;
$$
