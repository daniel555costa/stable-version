CREATE FUNCTION funct_filter_client_by_nif ("idUser" character varying, "idAgencia" integer, "nifClinet" character varying) RETURNS TABLE("NIF" character varying, "NAME" character varying, "SURNAME" character varying, "DOSSIER" character varying, "TELE" character varying, "ID AGENCIA" integer, "QUANTIDADE DE CREDITO" integer)
	LANGUAGE sql
AS $$

    SELECT mcs."NIF",
          mcs."NAME",
          mcs."SURNAME",
          mcs."DOSSIER",
          mcs."TELE",
          mcs."ID AGENCIA",
          mcs."QUANTIDADE DE CREDITO"
      from filter.mver_client_simple mcs
      where  mcs."NIF" LIKE  '%'||"nifClinet"||'%'
$$
