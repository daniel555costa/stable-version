CREATE FUNCTION funct_anular_credito (iduser integer, idagancia integer, idcredito integer, observacao integer) RETURNS result
	LANGUAGE plpgsql
AS $$


  DECLARE
    res result;
    ttPagamentoRembolso integer;
    vCredito credial.credito;
  BEGIN

    res.result = FALSE;

    -- load data credito
    SELECT * into vCredito
      from credial.credito ce
      where ce.credi_id = idcredito;

    -- Verificar a quantidade dos ppagamentos que ja foram ou estao a ser remblsados
    select count(*) into ttPagamentoRembolso
      from pagamento pa
      where pa.paga_credi_id= vCredito.credi_id
        and pa.paga_prestacao != 0; -- as prestacao que estao pagas ou em pagamento

    -- Garantir que somente creditos em que não tiverm nem reemboso seja anulado
    if vCredito.credi_state = 1
      and vCredito.credi_valuepago = 0
      and vCredito.credi_numprestacao = 0
      and ttPagamentoRembolso = 0
    THEN

      UPDATE  credito
        set credi_state = 0,
            credi_state = -1,
            cred_anulateobs = observacao
      WHERE credi_id = vCredito.credi_id;

      res.result := TRUE;
      RETURN res;

    ELSE
      res.message := message('credito-anular-reembolso');
      RETURN res;
    END IF;

  END;
$$
