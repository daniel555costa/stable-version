CREATE TRIGGER tg_pre_upd_payment
BEFORE UPDATE ON pagamento
FOR EACH ROW EXECUTE PROCEDURE functg_pre_upd_payment()