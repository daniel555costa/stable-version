CREATE VIEW ver_menu AS
SELECT m.menu_id AS "ID",
    m.menu_name AS "NAME",
    m.menu_link AS "LINK",
    ms.menu_icon AS "ICON",
    ms.menu_id AS "SUPER ID",
    ms.menu_name AS "SUPER NAME",
    ms.menu_link AS "SUPER LINK",
    m.menu_state AS "STATE",
    m.menu_raiz AS "RAIZ"
   FROM (menu m
     LEFT JOIN menu ms ON ((m.menu_menu_id = ms.menu_id)))