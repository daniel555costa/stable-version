CREATE VIEW ver_typeobjecto AS
SELECT typeobjecto.tobj_id AS "ID",
    typeobjecto.tobj_desc AS "NAME"
   FROM typeobjecto