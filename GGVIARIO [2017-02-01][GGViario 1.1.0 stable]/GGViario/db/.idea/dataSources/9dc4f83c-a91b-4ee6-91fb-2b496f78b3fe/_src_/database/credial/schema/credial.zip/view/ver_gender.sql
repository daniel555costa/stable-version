CREATE VIEW ver_gender AS
SELECT gender.gen_id AS "ID",
    gender.gen_desc AS "DESC"
   FROM gender