CREATE FUNCTION funct_load_status_cliente ("idUser" character varying, "idAgencia" numeric, "nifClinete" character varying) RETURNS TABLE("DATA REGISTRO" character varying, "IDADE NA EMPRESA" numeric, "TOTAL CREDITO" numeric, "PAGOS" numeric, "POR PAGAR" numeric, "ATRAZADO" numeric, "MONTANTE TOTAL SOLICITADO" character varying, "MONTANTE TOTAL AMORTIZAR" character varying, "MONTANTE TOTAL PAGO" character varying, "MONTANTE TOTAL POR PAGAR" character varying)
	LANGUAGE plpgsql
AS $$

  DECLARE
    vCliente dossiercliente;
    montanteTotalSolicitado DOUBLE PRECISION;
    montanteTotalAmortizar DOUBLE PRECISION;
    montanteTotalPago DOUBLE PRECISION;
    montanteTotalPorPagar DOUBLE PRECISION;
  BEGIN
    select * into vCliente
      from dossiercliente dos
      where dos.dos_nif = "nifClinete";

    select count(*) INTO "TOTAL CREDITO"
    from credito ce
    where ce.credi_dos_nif = "nifClinete";

    select count(*) INTO "POR PAGAR"
      from credito ce
      where ce.credi_state = 1
        and ce.credi_dos_nif = "nifClinete";

    select count(*) INTO "ATRAZADO"
      from credito ce
      where ce.credi_state = 1
          and ce.credi_dos_nif = "nifClinete"
        and ce.credi_dtfinalizar < now();
    
    

    "PAGOS" := "TOTAL CREDITO" - "POR PAGAR";

    "DATA REGISTRO" :=  replace(replace (replace(replace(to_char(vCliente.dos_dtreg, 'DD "de" MONTH "de" YYYY'), '  ', ' '), '  ', ' '), '  ', ' '), '  ', ' ');
    "IDADE NA EMPRESA" := to_number( to_char(age(vCliente.dos_dtreg), 'yyy'), '000');
    
    /*
     "MONTANTE TOTAL SOLICITADO" character varying,
               "MONTANTE TOTAL AMORTIZAR" character varying,
               "MONTANTE TOTAL PAGO" character varying,
               "MONTANTE TOTAL POR PAGAR" character varying
     */
    
    SELECT (sum(ce.credi_valuecredito))  into montanteTotalSolicitado
      from credito ce
      where ce.credi_dos_nif = "nifClinete";
    
    SELECT (sum(ce.credi_totalpagar))  into montanteTotalAmortizar
      from credito ce
      where ce.credi_dos_nif = "nifClinete";
    
    SELECT (sum(ce.credi_valuepago))  into montanteTotalPago
      from credito ce
      where ce.credi_dos_nif = "nifClinete";
    
    montanteTotalPorPagar := montanteTotalAmortizar - montanteTotalPago;
    
    "MONTANTE TOTAL SOLICITADO" := lib.money(montanteTotalSolicitado);
    "MONTANTE TOTAL AMORTIZAR" := lib.money(montanteTotalAmortizar);
    "MONTANTE TOTAL PAGO" := lib.money(montanteTotalPago);
    "MONTANTE TOTAL POR PAGAR" := lib.money(montanteTotalPorPagar);
    return next;

  END;
$$
