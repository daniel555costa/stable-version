CREATE FUNCTION funct_datasource_client_garantias () RETURNS TABLE("NIF" character varying, "NAME" character varying, "SURNAME" character varying, "DOSSIER" character varying, "TELE" character varying, "ID AGENCIA" integer, "QUANTIDADE DE CREDITO" integer, name_noaccent character varying, surname_noaccent character varying, "GARRANTIA ENTREGE" character varying, "TYPE GARRANTIA" character varying, typegarrantia_noaccent character varying, garrantia_noaccent character varying)
	LANGUAGE sql
AS $$

  SELECT mcs."NIF",
    mcs."NAME",
    mcs."SURNAME",
    mcs."DOSSIER",
    mcs."TELE",
    mcs."ID AGENCIA",
    mcs."QUANTIDADE DE CREDITO",
    mcs.name_noaccent,
    mcs.surname_noaccent,
    gar.garcredi_desc AS "GARRANTIA ENTREGE",
    tpgar.obj_desc AS "TYPE GARRANTIA",
    upper(lib.funaccent(tpgar.obj_desc)) AS typegarrantia_noaccent,
    upper(lib.funaccent((gar.garcredi_desc)::text)) AS garrantia_entrege
   FROM filter.funct_datasource_client_simple() mcs("NIF", "NAME", "SURNAME", "DOSSIER", "TELE", "ID AGENCIA", "QUANTIDADE DE CREDITO", name_noaccent, surname_noaccent)
     JOIN credito ce ON mcs."NIF"  = ce.credi_dos_nif
     JOIN garrantiacredito gar ON ce.credi_id = gar.garcredi_credi_id
     JOIN objecto tpgar ON gar.garcredi_obj_garrantia = tpgar.obj_id
$$
