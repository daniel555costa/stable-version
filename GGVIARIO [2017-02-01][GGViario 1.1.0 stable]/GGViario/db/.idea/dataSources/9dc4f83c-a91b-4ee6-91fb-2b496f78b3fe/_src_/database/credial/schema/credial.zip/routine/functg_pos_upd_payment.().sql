CREATE FUNCTION functg_pos_upd_payment () RETURNS trigger
	LANGUAGE plpgsql
AS $$

  declare
    -- TG_WHEN {BEFORE, AFTER, or INSTEAD OF}
    -- TG_EVENT {INSERT, UPDATE, DELETE, TRUNCATE}
    -- TG_LEVEL {ROW, STATEMENT}

    vNew pagamento;
    vOld Pagamento;

    isLiquidado boolean;
  begin

    if tg_when  = 'AFTER'
      -- AND tg_event = 'UPDATE'
      and new is of (pagamento)
    then
      vNew := new;
      vOld := old;

      isLiquidado := (vNew.paga_reembolso = vOld.paga_prestacao);

      --Quando for efectuado alguma alteracao no pagamento alterar tabem o credito corespondente
        -- Podendo aumentar o numero de prestacao paga e aumentando o tatal de prestacao a pagar
      if isLiquidado then
      
        update credito
          set credi_numprestacaofalta = (case
                                          when isLiquidado and vNew.paga_state = 0 then credi_numprestacaofalta + 1
                                          else credi_numprestacaofalta
                                         end),
            credi_valuepago = credi_valuepago - vOld.paga_prestacao + vNew.paga_prestacao
          where credi_id = vOld.paga_credi_id
        ;
      END IF;

      RETURN null;

    end if;

  end;
$$
