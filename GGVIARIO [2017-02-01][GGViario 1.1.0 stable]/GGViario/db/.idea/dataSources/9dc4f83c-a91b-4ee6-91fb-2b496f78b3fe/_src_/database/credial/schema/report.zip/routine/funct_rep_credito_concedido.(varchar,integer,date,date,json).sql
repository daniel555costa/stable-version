CREATE FUNCTION funct_rep_credito_concedido (iduser character varying, idagencia integer, datainicio date, datafim date, filter json) RETURNS TABLE("NIF" character varying, "NAME" character varying, "SURNAME" character varying, "DATA" character varying, "ESTADO" character varying, "VALOR CREDITO" double precision, "NUM CREDITO DOSSCIER" character varying, "TOTAL PAGAR MONTANTE DIVIDA" double precision, "TAEG" double precision, "DATA INICIO" character varying, "DATA FINALIZAR" character varying)
	LANGUAGE plpgsql
AS $$


  -- Apresentar os creditos no intervalo fornecido e calcular os somatorios corresnpondentes
  -- Quando a agentia ou o tipo do credito equals -1 then siginifica que se pretende carregar todas as informacoes
  DECLARE
    I RECORD;
    anoSubtrairReport INTEGER DEFAULT filter->>'anoSub';
    idTipoCreditoReport INTEGER DEFAULT filter->>'tipoCredito';
    idAgenciaReport INTEGER DEFAULT filter->>'agencia';

    -- criar data dos anos antigos
    vInterval CHARACTER VARYING DEFAULT anoSubtrairReport||' year ';
    vPastDataInicio DATE DEFAULT datainicio - (vInterval::INTERVAL);
    vPastDataFim DATE DEFAULT datafim - (vInterval::INTERVAL);

    sumValorCredito FLOAT DEFAULT 0.0;
    sumTotalPagarMontanteDividaTaeg FLOAT DEFAULT 0.0;
    sumTaeg FLOAT DEFAULT 0.0;

  BEGIN

    SELECT * INTO i
      from credial.dossiercliente dos
        inner join credial.credito ct on dos.dos_nif = ct.credi_dos_nif
        inner join taxa tx on ct.credi_taxa_id = tx.taxa_id
    LIMIT 0;


    FOR I IN (
      SELECT *
        from credial.dossiercliente dos
          INNER JOIN credial.credito ct on dos.dos_nif = ct.credi_dos_nif
          INNER JOIN credial.taxa tx on ct.credi_taxa_id = tx.taxa_id
        where (ct.credi_dtinicio BETWEEN datainicio AND datafim)
        and (tx.taxa_obj_tipocredito = idTipoCreditoReport OR idTipoCreditoReport IS NULL)
        and (ct.credi_age_id = idAgenciaReport OR idAgenciaReport IS NULL)
    ) LOOP

      sumValorCredito := sumValorCredito + i.credi_valuecredito;
      sumTotalPagarMontanteDividaTaeg := sumTotalPagarMontanteDividaTaeg + i.credi_totalpagar;
      sumTaeg := sumTaeg + i.credi_taeg;

      "NIF" := i.dos_nif;
      "NAME" := i.dos_name;
      "SURNAME" := i.dos_surname;
      "DATA" := i.credi_dtrge;
      "ESTADO" := CASE WHEN i.credi_state = 1 then 'Por pagar' else 'Pago' END;
      "VALOR CREDITO" := i.credi_valuecredito;
      "NUM CREDITO DOSSCIER" := i.credi_numcredito;
      "TOTAL PAGAR MONTANTE DIVIDA" :=  i.credi_totalpagar;
      "TAEG" := i.credi_taeg;
      "DATA INICIO" := i.credi_dtinicio;
      "DATA FINALIZAR" := i.credi_dtfinalizar;

      RETURN  NEXT;
    END LOOP;

    "NIF" := 'TOTAL';
    "NAME" := 'NA DATA';
    "SURNAME" := NULL;
    "DATA" := NULL;
    "ESTADO" := NULL;
    "VALOR CREDITO" := sumValorCredito;
    "NUM CREDITO DOSSCIER" := NULL;
    "TOTAL PAGAR MONTANTE DIVIDA" := sumTotalPagarMontanteDividaTaeg;
    "TAEG" := sumTaeg;
    "DATA INICIO" := NULL;
    "DATA FINALIZAR" := NULL;

    RETURN NEXT;

    if anoSubtrairReport > 0 THEN
      sumTaeg := 0.0;
      sumValorCredito := 0.0;
      sumTotalPagarMontanteDividaTaeg := 0;

      SELECT sum(ct.credi_valuecredito),
             sum(ct.credi_totalpagar),
             sum(ct.credi_taeg)
                INTO sumValorCredito,
                  sumTotalPagarMontanteDividaTaeg,
                  sumTaeg

      from credial.dossiercliente dos
        inner join credial.credito ct on dos.dos_nif = ct.credi_dos_nif
        inner join taxa tx on ct.credi_taxa_id = tx.taxa_id
      where (ct.credi_dtinicio BETWEEN vPastDataInicio AND vPastDataFim)
        and (tx.taxa_obj_tipocredito = idTipoCreditoReport OR idTipoCreditoReport IS NULL)
        and (ct.credi_age_id = idAgenciaReport OR idAgenciaReport IS NULL);
    END IF;

    "NIF" := 'TOTAL';
    "NAME" := 'EM '||anoSubtrairReport||' ANOS PASSADOS';
    "VALOR CREDITO" := sumValorCredito;
    "TOTAL PAGAR MONTANTE DIVIDA" := sumTotalPagarMontanteDividaTaeg;
    "TAEG" := sumTaeg;

    RETURN NEXT;

  END;
$$
