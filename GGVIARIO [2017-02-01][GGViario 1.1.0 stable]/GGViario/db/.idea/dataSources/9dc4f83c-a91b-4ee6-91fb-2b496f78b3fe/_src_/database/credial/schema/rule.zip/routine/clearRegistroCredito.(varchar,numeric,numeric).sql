CREATE FUNCTION clearRegistroCredito ("idUser" character varying, "idAgencia" numeric, "idCredito" numeric) RETURNS void
	LANGUAGE sql
AS $$

   -- Remover todas as garrantias que puderao ser registradas
      delete from garrantiacredito
        where garcredi_credi_id = "idCredito";
      
      -- Remover todos os pagamentos registrados para esse credito
      delete from pagamento
        where paga_credi_id = "idCredito";
      
      -- Remover todos os documentos
      delete from documentoentregue 
        where docentre_credi_id = "idCredito";
      
      -- Remover o proprio credito
      delete from credito 
        where credi_id = "idCredito";
$$
