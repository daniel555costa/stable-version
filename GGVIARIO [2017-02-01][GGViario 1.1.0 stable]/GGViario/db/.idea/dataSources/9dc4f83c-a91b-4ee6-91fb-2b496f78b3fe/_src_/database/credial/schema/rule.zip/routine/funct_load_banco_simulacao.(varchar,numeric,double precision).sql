CREATE FUNCTION funct_load_banco_simulacao ("idUser" character varying, "idAgencia" numeric, "valorRequisicao" double precision) RETURNS TABLE("ID" numeric, "NAME" character varying, "SIGLA" character varying, "STATE" integer, "MESSAGE" character varying)
	LANGUAGE plpgsql
AS $$


  DECLARE
    i RECORD;
  BEGIN
     FOR i iN (
      SELECT ct.*
        from credial.conta ct
          INNER JOIN credial.banco bc ON ct.conta_banco_id = bc.banco_id
    )
    LOOP
       "ID" := i.conta_id;
       "NAME" := i.banco_name;
       "SIGLA" := i.banco_sigla;
       "STATE" := 1;
       "MESSAGE" := 'Disponivel';

       RETURN NEXT ;
       /*
       select bc.banco_id as "ID",
          bc.banco_name as "NAME",
          bc.banco_sigla as "SIGLA",
          1,
          'Disponivel'
    from banco bc
      LEFT JOIN credial.conta ct on bc.banco_id = ct.conta_banco_id
      LEFT JOIN chequempresa ch on ct.conta_id = ch.cheq_conta_id
    GROUP BY bc.banco_id, bc.banco_name, bc.banco_sigla
    where ch.cheq_state = 1
      and ch.cheq_age_owner = "idAgencia"
      and bc.banco_saldo >= "valorRequisicao"
        */

    END LOOP;
  END;
$$
