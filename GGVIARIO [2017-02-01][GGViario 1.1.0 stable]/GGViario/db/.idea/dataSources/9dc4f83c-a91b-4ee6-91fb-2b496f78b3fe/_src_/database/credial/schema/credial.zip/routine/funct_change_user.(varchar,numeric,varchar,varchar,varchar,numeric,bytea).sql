CREATE FUNCTION funct_change_user ("idUser" character varying, "idAgencia" numeric, "idUserChage" character varying, "newName" character varying, "newSurName" character varying, "newPerfilId" numeric, "newPhoto" bytea) RETURNS result
	LANGUAGE plpgsql
AS $$

  declare
    res result;
  begin

    res.result := FALSE;

    update "user"
      set user_name = "newName",
          user_surname = "newSurName",
          user_tperf_id = "newPerfilId",
          user_photo = "newPhoto"
      where user_id = "idUserChage";

    res.result := TRUE;
    res.message := 'Sucesso';
    return res;
  end;
$$
