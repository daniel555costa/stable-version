CREATE VIEW ver_client_simple AS
SELECT m."NIF",
    m."NAME",
    m."SURNAME",
    m."DOSSIER",
    m."TELE",
    m."ID AGENCIA",
    m."QUANTIDADE DE CREDITO",
    m.name_noaccent,
    m.surname_noaccent
   FROM filter.mver_client_simple m