CREATE FUNCTION funct_reg_salario ("idUser" character varying, "idAgencia" numeric, "nifCliente" character varying, valor double precision) RETURNS SETOF "Result"
	LANGUAGE plpgsql
AS $$

   DECLARE
      res "Result";
   BEGIN
      res."RESULT" := 'false';
      
      -- Desabilitar o altigo saliroio do cliente
      update salario
         set sal_state = 0
         where sal_dos_nif = "nifCliente"
            and sal_state = 1;
      
      -- criar o novo salario do cliente
      insert into salario(
         sal_age_id, 
         sal_user_id,
         sal_dos_nif,
         sal_value
      ) values (
         "idAgencia",
         "idUser",
         "nifCliente",
         valor
      );
      
      res."RESULT" := 'true';
      res."MESSAGE" := 'Sucesso';
      return next res;
   END;
$$
