CREATE FUNCTION functg_pos_reg_bancomovimento () RETURNS trigger
	LANGUAGE plpgsql
AS $$

  declare
    -- TG_WHEN {BEFORE, AFTER, or INSTEAD OF}
    -- TG_EVENT {INSERT, UPDATE, DELETE, TRUNCATE}
    -- TG_LEVEL {ROW, STATEMENT}

    vNew bancomovimento;
    vOld bancomovimento;
    isDebito boolean;
    isCredito boolean;
    invalid boolean;
  begin

   
    if -- tg_event = 'INSERT'
       tg_when = 'AFTER'
      and new is of (bancomovimento)
    then
      
      vNew := new;
      -- vOld := old;
      
      isCredito := (vNew.bancomov_credito > 0);
      isDebito := (vNew.bancomov_debito > 0);
      invalid := (vNew.bancomov_credito = vNew.bancomov_debito
        or ( isDebito and isCredito )
    );

      RAISE  NOTICE  'Valor credito = % and debito = % ', vNew.bancomov_credito, vNew.bancomov_debito;

      if invalid then
        RAISE EXCEPTION 'Operacao invalida Ou credito ou debito deve ser igual a zero | atual:{CREDITO AND DEBITOS equals 0 OR CREDITO AND DEBITO > 0}';
      end if;
      
      update banco
        set banco_saldo = (case
                             when isDebito then banco_saldo - vNew.bancomov_debito
                             when isCredito then banco_saldo + vNew.bancomov_credito
                             else banco_saldo
                           end)
        where banco_id = vNew.bancomov_banco_id
          and NOT invalid ;
      
      return new;

    end if;

  end;
$$
