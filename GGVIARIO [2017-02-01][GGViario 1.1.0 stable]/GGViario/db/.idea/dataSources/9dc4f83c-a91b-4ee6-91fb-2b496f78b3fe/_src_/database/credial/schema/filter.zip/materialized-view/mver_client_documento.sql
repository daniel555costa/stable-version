CREATE MATERIALIZED VIEW mver_client_documento AS
SELECT funct_datasource_client_paymment."NIF",
    funct_datasource_client_paymment."NAME",
    funct_datasource_client_paymment."SURNAME",
    funct_datasource_client_paymment."DOSSIER",
    funct_datasource_client_paymment."TELE",
    funct_datasource_client_paymment."ID AGENCIA",
    funct_datasource_client_paymment."QUANTIDADE DE CREDITO",
    funct_datasource_client_paymment.name_noaccent,
    funct_datasource_client_paymment.surname_noaccent,
    funct_datasource_client_paymment."CREDITO CHEQUE NUMBER",
    funct_datasource_client_paymment."CREDITO NUMNER",
    funct_datasource_client_paymment."PAGAMENTO DOCUMENTO PREVISTO",
    funct_datasource_client_paymment."PAGAMENTO DOCUMENTO REAL"
   FROM filter.funct_datasource_client_paymment() funct_datasource_client_paymment("NIF", "NAME", "SURNAME", "DOSSIER", "TELE", "ID AGENCIA", "QUANTIDADE DE CREDITO", name_noaccent, surname_noaccent, "CREDITO CHEQUE NUMBER", "CREDITO NUMNER", "PAGAMENTO DOCUMENTO PREVISTO", "PAGAMENTO DOCUMENTO REAL")