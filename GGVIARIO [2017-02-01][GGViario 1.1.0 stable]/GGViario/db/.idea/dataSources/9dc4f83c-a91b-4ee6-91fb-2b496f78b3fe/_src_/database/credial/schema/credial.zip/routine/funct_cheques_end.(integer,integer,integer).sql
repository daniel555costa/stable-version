CREATE FUNCTION funct_cheques_end ("idAgencia" integer, "idUser" integer, "idCheque" integer) RETURNS result
	LANGUAGE plpgsql
AS $$

  DECLARE

  BEGIN
    UPDATE chequempresa
      set cheq_state = 0
      where cheq_id = "idCheque";

    RETURN '(true,success)'::result;
  END;
$$
