CREATE FUNCTION funct_load_users ("idUser" character varying, "idAgencia" numeric) RETURNS TABLE("NIF" character varying, "NAME" character varying, "SURNAME" character varying, "PERFIL" character varying, "PERFIL ID" numeric, "AGENCIA" character varying, "AGENCIA ID" numeric, "PHOTO" bytea, "STATE" character varying, "STATE COD" numeric)
	LANGUAGE plpgsql
AS $$


  DECLARE
    r record;
  BEGIN
    for r in (
      select *
        from "user" us
          inner join typeperfil tper on us.user_tperf_id = tper.tperf_id
          left join trabalha tr on (us.user_id = tr.trab_user_user and tr.trab_state = 1)
          left join agencia ag on (tr.trab_age_agencia = ag.age_id)
    )loop
      "NIF" := r.user_id;
      "NAME" := r.user_name;
      "SURNAME" := r.user_surname;
      "PERFIL" := r.tperf_desc;
      "PERFIL ID" := r.tperf_id;
      "AGENCIA" := r.age_name;
      "AGENCIA ID" := r.age_id;
      "PHOTO" := r.user_photo;
      "STATE" := (
        case r.user_access
          when 1 then 'Ativo'
          when 2 then 'Pre-Ativo'
          else 'Inativo'
        end
      );
      "STATE COD" := r.user_access;

      return next;
    end LOOP;
  END;
$$
