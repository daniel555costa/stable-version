CREATE FUNCTION funct_login (accessname character varying, accesspwd character varying) RETURNS TABLE("RESULT" character varying, "MESSAGE" character varying, "ID" character varying, "ID LOGIN" numeric, "ID PERFIL" numeric, "ID AGENCIA" numeric, "STATE" numeric, "NAME" name, "SURNAME" name, "PERFIL" character varying, "AGENCIA" character varying, "PHOTO" bytea, "STATE NAME" character varying)
	LANGUAGE plpgsql
AS $$

   declare
      tt  numeric;
      i record;
      idLogin numeric;
   begin
	   
	  -- Default message is access negado
	  "RESULT" := 'false';
      "MESSAGE" := 'Acesso negado';
      
      -- Verificar a existencia do utilizador
      -- on tt = 0 siguinifica que nao encontrou nenhum utilizador
      select count(*) into tt
         from "user" us
            inner join trabalha tr on us.user_id = tr.trab_user_user
         where us.user_id = accessName
            and us.user_pwd = md5(accessPwd)
            and us.user_access != 0
            and tr.trab_state = 1
            ;

      if tt = 1 then
        -- carregar as informacao completa do utilizador
        for i in(
		 select us.user_id as "ID",
		        tp.tperf_id as "ID PERFIL",
		        ag.age_id as "ID AGENCIA",
		        us.user_access "STATE",
		        us.user_name AS "NAME",
		        us.user_surname AS "SURNAME",
		        tp.tperf_desc as "PERFIL",
		        ag.age_name as "AGENCIA",
		        us.user_photo as "PHOTO",
		        case
		           when us.user_access = 1 then 'Ativo'
		           when us.user_access = 2 then 'Pre-Ativo'
		           else 'Inativo'
		        end as "STATE NAME"
		    from "user" us
		       inner join typeperfil tp on us.user_tperf_id = tp.tperf_id
		       inner join trabalha tr on us.user_id = tr.trab_user_user
		       inner join agencia ag on tr.trab_age_agencia = ag.age_id
		    where us.user_id = accessName
		       and tr.trab_state = 1
		       )
         loop

            -- criar o login do utilizador
            insert into login(login_user_id)
                         values(accessName)
                         returning login_id into idLogin;

            
            -- publicar as informacoes do utilizador
            "ID" := i."ID";
            "ID PERFIL" := i."ID PERFIL";
            "ID AGENCIA" := i."ID AGENCIA";
            "STATE" := i."STATE";
            "NAME" := i."NAME";
            "SURNAME" := i."SURNAME";
            "PERFIL" := i."PERFIL";
            "AGENCIA" := i."AGENCIA";
            "PHOTO" := i."PHOTO";
            "STATE NAME" := i."STATE NAME";
            "ID LOGIN" := idLogin;
            "RESULT" := 'true';
            "MESSAGE" := 'Bem Vindo';
         end loop;
      end if;
      
      return next;
      
   end;
$$
