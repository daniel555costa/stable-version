CREATE MATERIALIZED VIEW mver_client_garantias AS
SELECT funct_datasource_client_garantias."NIF",
    funct_datasource_client_garantias."NAME",
    funct_datasource_client_garantias."SURNAME",
    funct_datasource_client_garantias."DOSSIER",
    funct_datasource_client_garantias."TELE",
    funct_datasource_client_garantias."ID AGENCIA",
    funct_datasource_client_garantias."QUANTIDADE DE CREDITO",
    funct_datasource_client_garantias.name_noaccent,
    funct_datasource_client_garantias.surname_noaccent,
    funct_datasource_client_garantias."GARRANTIA ENTREGE",
    funct_datasource_client_garantias."TYPE GARRANTIA",
    funct_datasource_client_garantias.typegarrantia_noaccent,
    funct_datasource_client_garantias.garrantia_noaccent
   FROM filter.funct_datasource_client_garantias() funct_datasource_client_garantias("NIF", "NAME", "SURNAME", "DOSSIER", "TELE", "ID AGENCIA", "QUANTIDADE DE CREDITO", name_noaccent, surname_noaccent, "GARRANTIA ENTREGE", "TYPE GARRANTIA", typegarrantia_noaccent, garrantia_noaccent)