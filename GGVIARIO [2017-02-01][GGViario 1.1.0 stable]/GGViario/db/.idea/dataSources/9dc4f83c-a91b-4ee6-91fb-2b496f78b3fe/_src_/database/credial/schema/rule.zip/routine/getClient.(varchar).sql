CREATE FUNCTION getClient ("idCliente" character varying) RETURNS dossiercliente
	LANGUAGE sql
AS $$

  select *
    from dossiercliente dos
    where dos.dos_nif = "idCliente";
$$
