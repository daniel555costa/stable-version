CREATE FUNCTION funct_reg_menuser_revoke ("idUser" character varying, "idAgencia" numeric, "idUserRevoke" character varying, "idMenuRevoke" numeric) RETURNS TABLE("RESULT" character varying, "MESSAGE" text)
	LANGUAGE plpgsql
AS $$

   DECLARE
      tt numeric;
   BEGIN
      "RESULT" := 'false';
      select count(*) into tt
         from menuser mu
         where mu.muser_user_user = "idUserRevoke"
            and mu.muser_menu_id = "idMenuRevoke"
            and mu.muser_state = 1;

      if tt = 0 then
         "MESSAGE" := message('MUSER NOT FOUND');
      else
         -- Quando o menu ja havia sido previemnet definido para o utilizador
         update menuser
            set muser_state = 0,
               muser_dtfim = now()
            where muser_user_user = "idUserRevoke"
               and muser_menu_id = "idMenuRevoke"
               and muser_state = 1;

         "MESSAGE" := 'Sucess';
         "RESULT" := 'true';
      END IF;

      return next;
   END;
$$
