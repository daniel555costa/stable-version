CREATE VIEW ver_type_user AS
SELECT t.tperf_id AS "ID",
    t.tperf_desc AS "NAME"
   FROM typeperfil t
  WHERE (t.tperf_state = (1)::numeric)
  ORDER BY t.tperf_id