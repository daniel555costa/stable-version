CREATE FUNCTION funct_reg_user (iduser character varying, idagencia numeric, nif character varying, typeperfil numeric, username character varying, usersurname character varying, addressip character varying, dataaccess date, photofile bytea) RETURNS "Result"
	LANGUAGE plpgsql
AS $$


   DECLARE
     pwd character varying(32) := md5(nif);
     res "Result";
   BEGIN
      res."RESULT" := 'false';

      -- verificar se o nif que o do utilizador ja esta em uso
      if rule."hasUserNif"(nif) then
         res."MESSAGE" := message('USER NIF ALERED EXIST');
      ELSE
         insert into "user" (
            user_id,
            user_user_id,
            user_tperf_id,
            user_age_id,
            user_name,
            user_surname,
            user_addressip,
            user_dataaccess,
            user_photo,
            user_pwd
         ) VALUES (
            nif,
            idUser,
            typePerfil,
            idAgencia,
            userName,
            userSurName,
            addressIp,
            dataAccess,
            photoFile,
            pwd
         );

         res."RESULT" := 'true';
         res."MESSAGE"  := 'Sucesso';
      end if;

      RETURN res ;
   END;
$$
