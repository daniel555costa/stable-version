CREATE FUNCTION message_require (cod character varying) RETURNS text
	LANGUAGE plpgsql
AS $$

   declare
      result text;
   begin
      result := pack_regras.message(cod, cod);
      return message(cod);
   end;
$$
