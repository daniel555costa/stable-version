CREATE FUNCTION funct_reg_activity (idlogin numeric, name character varying, content json, level integer DEFAULT 3) RETURNS result
	LANGUAGE sql
AS $$

  insert into credial.activity(
    activ_log_id,
    activ_name,
    activ_content,
    activ_level
  ) VALUES (
      idLogin,
      name,
      content,
      level
  );
  
  SELECT '(true, success)'::credial.result;
$$
