CREATE FUNCTION funct_reg_taxa ("idUser" character varying, "idAgencia" numeric, "idObjectoTipoCredito" numeric, periodo numeric, valor double precision) RETURNS "Result"
	LANGUAGE plpgsql
AS $$


  declare
    res "Result";
  begin

    res."RESULT" := 'false';

    -- Regra a antiga aplicaco
    if valor > 0
       and valor <= 100
       and periodo > 0
    then
      -- desabilitar a aniga taxa para esse periodo do referenciado tipo de credito
      update taxa
        set taxa_state = 0,
            taxa_dtfim = now()
        where taxa_obj_tipocredito = "idObjectoTipoCredito"
          and taxa_periodo = periodo;

      -- criar a nova taxa
      insert into taxa(
        taxa_age_id,
        taxa_user_id,
        taxa_value,
        taxa_periodo,
        taxa_obj_tipocredito
      ) values (
        "idAgencia",
        "idUser",
        valor,
        periodo,
        "idObjectoTipoCredito"
      );

      res."RESULT" := 'true';
      res."MESSAGE" := 'Sucesso';
    elseif periodo <= 0 then
      res."MESSAGE" := message('TAXA DAY INVALID');
    else 
      res."MESSAGE" := message('TAXA VALUE INVALID');
    END IF;
    
    return res;
  END;
$$
