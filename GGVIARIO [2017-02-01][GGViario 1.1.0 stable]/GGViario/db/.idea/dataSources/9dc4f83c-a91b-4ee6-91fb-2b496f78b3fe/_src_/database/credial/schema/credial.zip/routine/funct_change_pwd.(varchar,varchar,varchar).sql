CREATE FUNCTION funct_change_pwd (userid character varying, useroldpwd character varying, usernewpwd character varying) RETURNS TABLE("RESULT" character varying, "MESSAGE" text)
	LANGUAGE plpgsql
AS $$


   declare
      userInfo record;
      oldMd5 character varying := md5(userOldPwd);
      newMd5 character varying := md5(userNewPwd);
   begin
	  "RESULT" := 'false';
	  
      select * into userInfo
         from "user" us
         where us.user_id = userId
            and us.user_pwd = oldMd5;
         
      if userInfo.user_id is null then
          "MESSAGE" := 'Credencial invalida';
      elsif userInfo.user_access != 1 then 
         "MESSAGE" := 'O utilizador não esta ativo';
      else
         update "user"
             set user_pwd = newMd5
             where user_id = userInfo.user_id;
         "RESULT" := 'true';
         "MESSAGE" := 'Palavra passe alterada';
      end if;
      
      return next;
   END ;
$$
