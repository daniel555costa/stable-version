CREATE VIEW ver_menu_structure AS
SELECT me.menu_id AS "ID",
    me.menu_cod AS "COD",
    me.menu_name AS "NAME",
    me.menu_level AS "LEVEL",
    me.menu_link AS "LINK",
    me.menu_icon AS "ICON",
    me.menu_state AS "STATE",
    mm.menu_id AS "SUPER.ID",
    mm.menu_cod AS "SUPER.COD",
    me.menu_raiz AS "RAIZ"
   FROM (menu me
     LEFT JOIN menu mm ON ((me.menu_menu_id = mm.menu_id)))
  ORDER BY me.menu_raiz