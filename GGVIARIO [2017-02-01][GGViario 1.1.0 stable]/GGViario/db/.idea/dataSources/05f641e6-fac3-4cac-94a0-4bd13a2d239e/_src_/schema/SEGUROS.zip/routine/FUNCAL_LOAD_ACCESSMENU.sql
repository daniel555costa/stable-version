create FUNCTION FUNCAL_LOAD_ACCESSMENU 
(
    ID_USER NUMBER
)
RETURN TB_ARRAY_STRING
IS
    listMenu TB_ARRAY_STRING := TB_ARRAY_STRING();
BEGIN
    -- BUSCAR PELOS MENUS ATIVO QUE O UTILIZADOR TEM ACCESSO 
    FOR I IN 
            (SELECT * 
                FROM T_MENU
                  INNER JOIN T_USA U ON MN_ID = U.USA_MENU_ID
                WHERE U.USA_USER_ID = ID_USER
                  AND U.USA_STATE = 1)
        LOOP
            -- ARMAZENAR OS MENU ENCONTRADOS EM UMA ESTRUTURA
            listMenu.EXTEND;
            listMenu(listMenu.count) := I.MN_ID||';'||I.MN_NOME||';'||I.MN_LINK;
    END LOOP;
    
    RETURN listMenu;
END;