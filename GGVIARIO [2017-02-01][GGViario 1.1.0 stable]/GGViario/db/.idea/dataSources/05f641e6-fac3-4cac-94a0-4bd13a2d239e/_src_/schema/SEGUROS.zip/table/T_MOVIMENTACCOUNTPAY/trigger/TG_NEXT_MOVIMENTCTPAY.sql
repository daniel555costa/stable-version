create trigger TG_NEXT_MOVIMENTCTPAY
	before insert
	on T_MOVIMENTACCOUNTPAY
	for each row
begin  
   if inserting then 
      if :NEW."MOVCOUNTPAY_ID" is null then 
         select SEQ_MOVIMENTACCOUNTPAY.nextval into :NEW."MOVCOUNTPAY_ID" from dual; 
      end if; 
   end if; 
end;