create TYPE BODY "TP_OBJ_SEGURODINHEIRO" AS

  CONSTRUCTOR FUNCTION TP_OBJ_SEGURODINHEIRO(
                                             NOME_FABRICANTE VARCHAR2,
                                             NUMERO_FABRICANTE VARCHAR2,
                                             TAMANHO VARCHAR,
                                             DETENTOR_CHAVES VARCHAR2,
                                             PESO FLOAT,
                                             ID_OBJTCONTROCOFRE NUMBER,
                                             estrutura varchar2)RETURN SELF AS RESULT AS
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_OBJ_SEGURODINHEIRO.TP_OBJ_SEGURODINHEIRO
    SELF.NOME_FABRICANTE := NOME_FABRICANTE;
    SELF.NUMERO_FABRICANTE := NUMERO_FABRICANTE;
    SELF.TAMANHO  := TAMANHO ;
    SELF.DETENTOR_CHAVES := DETENTOR_CHAVES;
    SELF.PESO := PESO;
    SELF.ID_OBJTCONTROCOFRE := ID_OBJTCONTROCOFRE;
     SELF.estrutura := estrutura;
    RETURN ;
  END TP_OBJ_SEGURODINHEIRO;

  STATIC FUNCTION INSTANCEOF RETURN NUMBER AS
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_OBJ_SEGURODINHEIRO.INSTANCEOF
    RETURN 5;
  END INSTANCEOF;


END;