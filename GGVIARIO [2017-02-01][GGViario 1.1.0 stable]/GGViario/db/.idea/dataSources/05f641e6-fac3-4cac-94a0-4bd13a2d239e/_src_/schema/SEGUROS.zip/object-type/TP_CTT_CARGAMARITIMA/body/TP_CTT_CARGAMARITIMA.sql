create TYPE BODY "TP_CTT_CARGAMARITIMA" IS

  CONSTRUCTOR FUNCTION TP_CTT_CARGAMARITIMA ( fly_pais_origem NUMBER,
                                              fly_pais_destino NUMBER,
                                              fly_portoCarga VARCHAR2,
                                              fly_portoDescarga VARCHAR2,
                                              fly_nomeNavio VARCHAR2,
                                              fly_valorMaximoRisco  BINARY_DOUBLE,
                                              
                                              -- COBRE -- Ambito da cobertura
                                              cobre_escolha NUMBER, -- {1 - Todos Riscos, 2 - Restrita, 3 - Mais Restrita}
                                              cobre_valorEscolha BINARY_DOUBLE,
                                              cobre_propositoSeguro VARCHAR2,
                                              
                                              -- VMAXRISCO >> Valor maximo em risco para
                                              vMaxRisco_qualquerNavio VARCHAR2,
                                              vMaxRisco_qualquerLocalizacao BINARY_DOUBLE,
                                              vMaxRisco_anualMercadoria VARCHAR2, -- Anula para cada mercadoria
                                              
                                              --FSEND >> Forma de emvio
                                              fsend_escolha NUMBER, -- {1 - Maritimo, 2 - Aeio, 3 - Encomenda Postal, 4 - Correio}
                                              
                                              --OTHER >> Outros
                                              other_tempoNegocio NUMBER,
                                              other_custoPorto NUMBER, -- Custo do porto (10% %)
                                              
                                              
                                             -- Informacao do segurado 
                                              infoSeg_descMercadoria VARCHAR2,
                                              infoSeg_areaActividade VARCHAR2,
                                              infoSeg_segEfectuadoComp VARCHAR2,
                                              infoSeg_nameCompania VARCHAR2
                                              ) RETURN SELF AS RESULT
    IS
    BEGIN

        --Voo 
        SELF.fly_pais_origem := fly_pais_origem;
        SELF.fly_pais_destino := fly_pais_destino;
        SELF.fly_portoCarga := fly_portoCarga;
        SELF.fly_portoDescarga := fly_portoDescarga;
        SELF.fly_nomeNavio := fly_nomeNavio;
        SELF.fly_valorMaximoRisco := fly_valorMaximoRisco;
        
        -- COBRE -- Ambito da cobertura
        SELF.cobre_escolha := cobre_escolha; -- {1 - Todos Riscos, 2 - Restrita, 3 - Mais Restrita}
        SELF.cobre_valorEscolha := cobre_valorEscolha;
        SELF.cobre_propositoSeguro := cobre_propositoSeguro;
        
        -- VMAXRISCO >> Valor maximo em risco para
        SELF.vMaxRisco_qualquerNavio := vMaxRisco_qualquerNavio;
        SELF.vMaxRisco_qualquerLocalizacao := vMaxRisco_qualquerLocalizacao;
        SELF.vMaxRisco_anualMercadoria := vMaxRisco_anualMercadoria; -- Anula para cada mercadoria
        
        --FSEND >> Forma de emvio
        SELF.fsend_escolha := fsend_escolha; -- {1 - Maritimo, 2 - Aeio, 3 - Encomenda Postal, 4 - Correio}
        
        --OTHER >> Outros
        SELF.other_tempoNegocio := other_tempoNegocio;
        SELF.other_custoPorto := other_custoPorto; -- Custo do porto (10% 20%)
        
        
        -- Informacao do segurado 
        SELF.infoSeg_descMercadoria := infoSeg_descMercadoria;
        SELF.infoSeg_areaActividade := infoSeg_areaActividade;
        SELF.infoSeg_segEfectuadoComp :=infoSeg_segEfectuadoComp;
        SELF.infoSeg_nameCompania := infoSeg_nameCompania;
        
        
        SELF.instance_of := TP_CTT_CARGAMARITIMA.INSTANCEOF;
        SELF.state := 1;

        RETURN;
    END;


  -- Instace Of
    STATIC FUNCTION INSTANCEOF RETURN NUMBER 
    IS
    BEGIN
       RETURN 3;
    END;

END;