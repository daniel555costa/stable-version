create FUNCTION           "FUNC_REG_RESEGUROSTATE" 
(
   idUser NUMBER,
   idReseguro NUMBER,
   newStateReseguro NUMBER,  -- {-1 ANULAR O RESEGIO}
   observacao CHARACTER VARYING
)
RETURN CHARACTER VARYING
IS
   reseguro T_RESEGURO%ROWTYPE;
BEGIN
   SELECT * INTO reseguro
      FROM T_RESEGURO re
      WHERE re.RES_ID = idReseguro;
      
   IF reseguro.RES_STATE = -1 THEN
      RETURN 'false;'||'O reseguro esta num estado anulado.';
   END IF;
   
   UPDATE T_RESEGURO
      SET RES_STATE = newStateReseguro
      WHERE RES_ID = idReseguro;
      
   INSERT INTO T_RESEGUROSTATE(RESSTT_RES_ID, 
                               RESSTT_USER_ID,
                               RESSTT_NEWSTATE,
                               RESSTT_OBS)
                               VALUES(idReseguro,
                                      idUser,
                                      newStateReseguro,
                                      observacao);
    RETURN 'true;Sucess';
                               
END;