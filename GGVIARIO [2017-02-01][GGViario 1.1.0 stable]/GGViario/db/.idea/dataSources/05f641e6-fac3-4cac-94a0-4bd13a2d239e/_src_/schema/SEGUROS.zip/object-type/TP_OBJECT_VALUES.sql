create TYPE           "TP_OBJECT_VALUES"                                          IS OBJECT 
(
   objSupe NUMBER(9),
   objName VARCHAR2(500),
   objValue VARCHAR2(4000)
);