create view VER_TYPE_MOVIMENTITEM as
select tim.TITEMOV_ID AS "ID",
           tim.TITEMOV_DESC AS "TIPO MOVIMENTO"
       from T_TYPEITEMOVIMENT tim
