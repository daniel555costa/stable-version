create trigger TG_NEXT_ITEM
	before insert
	on T_ITEM
	for each row
begin  
   if inserting then 
      if :NEW."ITEM_ID" is null then 
         select SEQ_ITEM.nextval into :NEW."ITEM_ID" from dual; 
      end if; 
   end if; 
end;