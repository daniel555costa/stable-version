create FUNCTION           "FUNC_REG_PERGUNTA" 
(
    USER_ID NUMBER,
    ID_SEGURO NUMBER,
    ID_PERGUNTA_SUPERIO NUMBER,
    ID_TIPOPERGUNTA NUMBER,
    QUESTAO VARCHAR2 
)
RETURN VARCHAR2
IS
    TT NUMBER;
 
BEGIN
    
    -- CRIANDO NOVA PERGUNTA
    INSERT INTO T_PERGUNTA(PER_TPER_ID, 
                            PER_USER_ID,
                            PER_SEG_ID,
                            PER_QUESTAO,
                            PER_PER_ID) VALUES(ID_TIPOPERGUNTA,
                                                USER_ID,
                                                ID_SEGURO,
                                                QUESTAO,
                                                ID_PERGUNTA_SUPERIO);
    RETURN 'true';
END;