create FUNCTION           "FUNCAL_COLLETAR_COMBOS" 
(
    viewName VARCHAR2,
    colunaId VARCHAR2,
    colunaDesc VARCHAR2
)
RETURN TB_ARRAY_STRING
IS
    sqlQuere VARCHAR2(4000) := 'SELECT '||colunaId||'||'';''||'||colunaDesc||' FROM '||viewName;
    listResult TB_ARRAY_STRING;
BEGIN
    EXECUTE IMMEDIATE sqlQuere BULK COLLECT INTO listResult;
    RETURN listResult;
    
    EXCEPTION 
      WHEN OTHERS THEN 
          listResult.EXTEND;
          listResult(listResult.COUNT) :=sqlQuere;
          RETURN listResult;
                
END;