create trigger TG_NEXT_ACCOUNTACCOUNTBANK
	before insert
	on T_ACCOUNTACCOUNTBANK
	for each row
begin  
   if inserting then 
      if :NEW."AACOUNTBANK_ID" is null then 
         select SEQ_ACCOUNTACCOUNTBANK.nextval into :NEW."AACOUNTBANK_ID" from dual; 
      end if; 
   end if; 
end;
