create PROCEDURE           "PRC_REG_SEGURADORA" (
    ID_USER NUMBER,--foi feito para fazer o registo da seguradora
    nome varchar2,
    gerente varchar2,
    nif varchar2,
    razaosocial varchar2,
    morada varchar2,
    telefone varchar2,
    mail varchar2,
    capital_social CHARACTER VARYING,
    codigo_postal varchar2,
    data_inauguracao DATE,
    facebook varchar2,
    twitter varchar2,
    sobre varchar2,
    logotipo blob,
    rodope blob,
    cabecalho blob)
is
begin
  delete from T_SEGURADORA; -- essa linha devera ser eliminada antes da aplicacao entrege
  
  /*update t_seguradora              --atualiza a seguradora tornando um antigo registo desactivo
    set segd_state =0               --registo antigo
  where segd_state = 1;            --registo novo
  */
  insert into t_seguradora (SEGD_USER_ID,
                            segd_nome,
                            segd_gerente,
                            segd_nif,
                            SEGD_RASASOCIAL,
                            segd_res_id,
                            segd_telefone,
                            segd_mail,
                            segd_capitalsocial,
                            segd_cp,
                            segd_dtinauguracao,
                            segd_facebook,
                            segd_twitter,
                            segd_sobre,
                            segd_logotipo,
                            segd_rodope,
                            segd_cabecalho)
                            values(ID_USER,
                                    nome,
                                    gerente,
                                    nif,
                                    razaosocial,
                                    PACK_REGRAS.GET_RESIDENCE(morada,ID_USER),
                                    telefone,
                                    mail,
                                    capital_social,
                                    codigo_postal,
                                    data_inauguracao,
                                    facebook,
                                    twitter,
                                    sobre,
                                    logotipo,
                                    rodope,
                                    cabecalho);
end;