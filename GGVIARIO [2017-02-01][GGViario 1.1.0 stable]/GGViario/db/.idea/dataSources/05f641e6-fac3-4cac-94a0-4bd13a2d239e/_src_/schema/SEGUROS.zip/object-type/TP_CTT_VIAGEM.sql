create TYPE           "TP_CTT_VIAGEM"                                          UNDER TP_CTT
   (  
    OBJECTIVO_VIAGEM VARCHAR2(1000),
    PAIS_DESTINO NUMBER(3),
    DATA_INICIO VARCHAR2(30),
    DATA_FIM VARCHAR2(30),
    niconComisao FLOAT,
    premio FLOAT,
    numDias NUMBER,
    impostoConsumo FLOAT,
    impostoSelo FLOAT,
    netOutFax FLOAT,
    totalPremio FLOAT,
    numPassageiros NUMBER,
    CONSTRUCTOR FUNCTION TP_CTT_VIAGEM(
                                        OBJECTIVO_VIAGEM VARCHAR2,
                                        PAIS_DESTINO VARCHAR2,
                                        DATA_INICIO DATE,
                                        DATA_FIM DATE,
                                        niconComisao FLOAT,
                                        premio FLOAT,
                                        numDias NUMBER,
                                        impostoConsumo FLOAT,
                                        impostoSelo FLOAT,
                                        netOutFax FLOAT,
                                        totalPremio FLOAT,
                                        numPassageiros NUMBER
                                      )RETURN SELF AS RESULT, --CONSTRUTOR  DO OBJECTO
                                      
    STATIC FUNCTION INSTANCEOF RETURN NUMBER
    
)FINAL;