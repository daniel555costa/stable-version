create TYPE           "SYS_PLSQL_24493_31_1"                                          as object ("ID" NUMBER(9),
"TOTAL CONTRATO" NUMBER,
"CONTRATO ACTIVO" NUMBER,
"TOTAL IN SEGURO" NUMBER(4));