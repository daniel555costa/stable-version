create TYPE           "TP_CTT_DINHEIRO"                                          UNDER TP_CTT
(
   distanciaBanco VARCHAR2(60),
   distanciaCoreio VARCHAR2(60),
   distanciaOutra VARCHAR2(60),
   
   transpDinheiro VARCHAR2(60),
   preocupacao VARCHAR2(60),
   tempoPermanencio VARCHAR2(60),
   dinheiroPaga CHAR(1), -- {Y - Sim  | N- Nao}
   
   CONSTRUCTOR FUNCTION TP_CTT_DINHEIRO (distanciaBanco VARCHAR2,
                                         distanciaCoreio VARCHAR2,
                                         distanciaOutra VARCHAR2,
                                         
                                         transpDinheiro VARCHAR2,
                                         preocupacao VARCHAR2,
                                         tempoPermanencio VARCHAR2,
                                         dinheiroPaga CHAR-- {Y - Sim  | N- Nao}
                                         ) RETURN SELF AS RESULT
);