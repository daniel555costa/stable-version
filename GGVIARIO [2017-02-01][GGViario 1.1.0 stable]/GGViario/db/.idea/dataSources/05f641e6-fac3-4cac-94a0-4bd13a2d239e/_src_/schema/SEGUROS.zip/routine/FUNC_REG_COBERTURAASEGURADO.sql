create FUNCTION           "FUNC_REG_COBERTURAASEGURADO" 
(
   idUser NUMBER,
   idContrato NUMBER,
   idAsegurado NUMBER,
   idCobertura NUMBER,
   taxa FLOAT,
   valor FLOAT,
   premio FLOAT,
   detalhes varchar2
)
RETURN VARCHAR2
IS
BEGIN
   INSERT INTO T_COBERTURASEGURADO(COBREASE_CTT_ID,
                                    COBREASE_USER_ID,
                                    COBREASE_COBRE_ID,
                                    COBREASE_TAXA,
                                    COBREASE_VALOR,
                                    COBREASE_PREMIO,
                                    COBREASE_DETALHES)
                                    VALUES(idContrato,
                                           idUser,
                                           idCobertura,
                                           taxa,
                                           valor,
                                           premio,
                                           detalhes);
  RETURN 'true';
END;