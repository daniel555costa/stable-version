create FUNCTION           "FUNCT_LOAD_SEGURADORA" 
RETURN TB_SEGURADORA
IS
    RES TB_SEGURADORA := TB_SEGURADORA();
    K INTEGER := 1;
BEGIN
    -- CARREGAR AS INFORMACOE ACTIVA DA SEGURADORA
    FOR I IN (SELECT * FROM T_SEGURADORA SEG
                INNER JOIN T_FUNCIONARIO FUNC ON SEG.SEGD_USER_ID = FUNC.FUNC_ID
                INNER JOIN VER_RESIDENCIA RES ON SEG.SEGD_RES_ID = RES.REALID 
                  WHERE SEGD_STATE != 0) LOOP
        RES.EXTEND;
        
        -- PREPARAR O RETORN DA SEGURADORA
        RES(K) := TP_SEGURADORA(I.FUNC_ACCESSNAME,
                                I.RESIDENCIA, 
                                I.SEGD_NOME,
                                I.SEGD_GERENTE,
                                I.SEGD_SIGLA,
                                I.SEGD_NIF,
                                I.SEGD_RASASOCIAL, 
                                I.SEGD_TELEFONE,
                                I.SEGD_MAIL,
                                I.SEGD_CAPITALSOCIAL,
                                I.SEGD_CP,
                                PACK_LIB.asDDMMYYYY(I.SEGD_DTINAUGURACAO),
                                I.SEGD_FACEBOOK,
                                I.SEGD_TWITTER,
                                I.SEGD_SOBRE,
                                I.SEGD_LOGOTIPO,
                                I.SEGD_RODOPE,
                                I.SEGD_CABECALHO
                                 );
        K := K + 1;
    END LOOP;
    RETURN RES;
END;