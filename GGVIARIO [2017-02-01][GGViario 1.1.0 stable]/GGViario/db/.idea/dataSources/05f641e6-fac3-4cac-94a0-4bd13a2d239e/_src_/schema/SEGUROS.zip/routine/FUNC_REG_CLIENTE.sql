create FUNCTION           "FUNC_REG_CLIENTE" 
(
    ID_USER NUMBER,
    ID_GENERO NUMBER,
    ID_TIPO_CLIENTE NUMBER,
    ID_PAIS NUMBER,
    DATA_NASCIMENTO DATE,
    NOME VARCHAR2,
    NIF VARCHAR2,
    ID_CLIENTE_SHOW NUMBER,
    APELIDO VARCHAR2,  --- Apelido para o responsave no tipo colectivo
    
    -- HISTORICO DO FUNCINARIO
    LOCAL_TRABALHO VARCHAR2,
    RESIDENCIA VARCHAR2,
    ID_ESTADO_CIVIL NUMBER, 
    ID_TIPO_DOCUMENTO NUMBER,
    NUMERO_DOCUMENTO VARCHAR2,
    CAIXA_POSTAL VARCHAR2,
    TELEMOVEL VARCHAR2,
    TELEFONE VARCHAR2,
    EMAIL VARCHAR2,
    PROFISAO VARCHAR2,
    SITE VARCHAR2,
    ALVARA VARCHAR2,
    RAZAOSOCIAL VARCHAR2
)
RETURN VARCHAR2
IS
    TT NUMBER;
    id_cliente number;
BEGIN
    
    --REGISTAR O NOVO CLIENTE
    INSERT INTO T_CLIENTE (CLI_USER_ID, 
                            CLI_GEN_ID,
                            CLI_TCLI_ID, 
                            CLI_PAIS_ID,
                            CLI_DTNASC,
                            CLI_NOME,
                            CLI_NIF,
                            CLI_COD,
                            CLI_APELIDO,
                            CLI_ALVARA,
                            CLI_RSOCIAL)
                            VALUES(ID_USER,
                                    ID_GENERO,
                                    ID_TIPO_CLIENTE,
                                    ID_PAIS,
                                    DATA_NASCIMENTO,
                                    NOME,
                                    NIF,
                                    ID_CLIENTE_SHOW,
                                    APELIDO,
                                    ALVARA,
                                    RAZAOSOCIAL
                                    )RETURNING  cli_id into  id_cliente ;
                                    
    -- CRIAR O NOVO HISTORICO DO CLIENTE                                
    PRC_UPD_CLIENTE(ID_USER, 
                    ID_CLIENTE,
                    1,
                    LOCAL_TRABALHO, 
                    RESIDENCIA,
                    ID_TIPO_DOCUMENTO,
                    ID_ESTADO_CIVIL,
                    NUMERO_DOCUMENTO,
                    CAIXA_POSTAL, 
                    TELEMOVEL, 
                    TELEFONE, 
                    EMAIL,
                    PROFISAO,
                    SITE,
                    null,
                    null,
                    null,
                    null,
                    null);
    RETURN 'true';
END;