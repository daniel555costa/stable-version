create TYPE BODY TP_CLASS AS

  CONSTRUCTOR FUNCTION TP_CLASS(idObjetc NUMBER, idContrato NUMBER) RETURN SELF AS RESULT AS
  BEGIN
     loadDatas(idObjetc, idContrato);
     onRestore(SELF.content);
     
     RETURN;
  END TP_CLASS;
  
  
  MEMBER PROCEDURE loadDatas (SELF IN OUT TP_CLASS, idObjetc NUMBER, idContrato NUMBER)
  IS
     table_key CHARACTER VARYING(1999);
  BEGIN
     SELF.content := BUNDLE();
     IF (idObjetc IS NOT NULL AND idContrato IS NULL)
        OR (idObjetc IS NULL AND idContrato IS NOT NULL) THEN
        
        FOR OVALL IN (SELECT OVALL.ATRIBUTO, OVALL."TREAT VALUE", OVALL.VALUE
                     FROM MVER_OBJECT_VALUES OVALL
                     WHERE OVALL."ID OBJECTO" = idObjetc
                        OR OVALL."ID CONTRATO" = idContrato)
        LOOP
           SELF.content.put(OVALL.ATRIBUTO, OVALL."TREAT VALUE");
           table_key := 'TABLE_VALUE#'||OVALL.ATRIBUTO;
           IF OVALL."TREAT VALUE" != OVALL."VALUE" THEN
              SELF.content.put(table_key, OVALL.VALUE);
           END IF;
        END LOOP;
     END IF;
  END loadDatas;
  
  MEMBER PROCEDURE onRestore(content BUNDLE) AS
  BEGIN
    NULL;
  END onRestore;

END;