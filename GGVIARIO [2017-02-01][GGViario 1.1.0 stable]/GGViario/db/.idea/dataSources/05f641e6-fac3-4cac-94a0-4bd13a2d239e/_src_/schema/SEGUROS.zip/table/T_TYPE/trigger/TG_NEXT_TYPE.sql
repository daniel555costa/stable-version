create trigger TG_NEXT_TYPE
	before insert
	on T_TYPE
	for each row
begin  
   if inserting then 
      if :NEW."T_ID" is null then 
         select SEQ_TYPE.nextval into :NEW."T_ID" from dual; 
      end if; 
   end if; 
end;