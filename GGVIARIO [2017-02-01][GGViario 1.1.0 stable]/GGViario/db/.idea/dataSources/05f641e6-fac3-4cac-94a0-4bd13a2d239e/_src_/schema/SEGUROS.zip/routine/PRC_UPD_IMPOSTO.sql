create PROCEDURE           "PRC_UPD_IMPOSTO" 
(
    userId NUMBER,
    newValueConsumo FLOAT,
    newValueSelo FLOAT,
    newFGA FLOAT
)
IS
BEGIN
    -- Desativar o imposto anterior
    UPDATE T_IMPOSTO I
      SET I.IMP_STATE = 0
      WHERE I.IMP_STATE = 1;
  
    -- Criar um no registro de imposto
    INSERT INTO T_IMPOSTO(IMP_USER_ID, 
                          IMP_CONSUMO, 
                          IMP_SELO, 
                          IMP_FGA)
                          VALUES(userId,
                                newValueConsumo,
                                newValueSelo,
                                newFGA);
END;