create FUNCTION           "FUNCT_LOGAR" 
(
   loginAccess VARCHAR2,
   PWD        VARCHAR2
)
RETURN TB_ARRAY_STRING
IS
  TYPE TUser IS TABLE OF VER_USER%ROWTYPE;
  listUser TUser := TUser();
  arrayData TB_ARRAY_STRING := TB_ARRAY_STRING();
  seletedUser VER_USER%ROWTYPE;
BEGIN
    --Collectar todos os utilizador com essas credenciais para a lista
    SELECT * BULK COLLECT INTO listUser
        FROM VER_USER FU
        WHERE  FU.ID_USER IN (SELECT US.FUNC_ID
                                FROM T_FUNCIONARIO US
                                WHERE US.FUNC_ACCESSNAME = loginAccess
                                   AND US.FUNC_PWD = PWD) ;
                               
    PRT.PRINT('COUNt = '|| listUser.COUNT);
                                   
    
    IF listUser.COUNT = 1 THEN
    
       seletedUser := listUser (1);
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'ID;'||seletedUser.ID_USER;
       
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'NOME;'||seletedUser.NOME;
       
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'APELIDO;'||seletedUser.APELIDO;
       
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'NIF;'||seletedUser.NIF;
       
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'ESTADO;'||seletedUser.ACESSO;
       
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'NIVEL;'||seletedUser.NIVEL;
       
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'NOME_NIVEL;'||seletedUser."NOME NIVEL";
       
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'DEPARTAMENTO;'||seletedUser.DEPARTAMENTO;
       
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'NOME_DEPARTAMENTO;'||seletedUser."NOME DEPARTAMENTO";
       
       -- Criar o login da secao
       -- INSERT INTO LOGIN (LOGIN_USER_ID) VALUES (seletedUser.NIF) RETURNING LOGIN_ID INTO tt;
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'LOGIN;'||12;
    END IF;
    RETURN arrayData;
END;