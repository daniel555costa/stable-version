create view VER_TYPEACCOUNTBANK as
SELECT ot.OBJT_ID AS ID,
      OT.OBJT_DESC  as TYPECONTA
    from T_OBJECTYPE ot 
    where ot.OBJT_T_ID = 24
