create FUNCTION           "FUNC_REG_RESPOSTA" 
(
    ID_USER NUMBER,
    ID_CONTRATO NUMBER,
    ID_PERGUNTA NUMBER,
    RESPOSTA VARCHAR2,
    EXPECIFICACAO VARCHAR2
)
    RETURN VARCHAR2
IS
    TT NUMBER;
BEGIN
    -- Verificar a existencia de alguma resposta para esse contrato
    SELECT COUNT(*) INTO TT FROM T_RESPOSTA WHERE RESP_CTT_ID = ID_CONTRATO AND RESP_PER_ID = ID_PERGUNTA;
    
    -- Se Existiu alguma antiga resposta para a pergunta desativar a antiga resposta
    IF TT != 0 THEN 
        UPDATE T_RESPOSTA 
            SET RESP_STATE = 0
            WHERE RESP_STATE = 1
                AND RESP_CTT_ID = ID_CONTRATO
                AND RESP_PER_ID = ID_PERGUNTA;
          return 'true';
    END IF;
    
    -- Registrar a nova resposta para a questao
    INSERT INTO T_RESPOSTA (RESP_PER_ID, 
                            RESP_USER_ID, 
                            RESP_CTT_ID, 
                            RESP_RESPOSTA, 
                            RESP_EXPECIFICACAO)
                            VALUES (ID_PERGUNTA,
                                    ID_USER,
                                    ID_CONTRATO,
                                    RESPOSTA,
                                    EXPECIFICACAO);
    return 'true';
END;