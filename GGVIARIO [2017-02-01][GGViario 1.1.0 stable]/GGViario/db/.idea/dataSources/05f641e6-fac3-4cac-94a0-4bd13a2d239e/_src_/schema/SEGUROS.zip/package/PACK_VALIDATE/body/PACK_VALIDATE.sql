create PACKAGE BODY           "PACK_VALIDATE" AS

  FUNCTION apoliceNumber (userId NUMBER,  codigoApolice VARCHAR2,  idSeguro NUMBER) RETURN PACK_TYPE.Resultado IS
     tt NUMBER;
     res PACK_TYPE.Resultado;
  BEGIN
    NULL;
  END apoliceNumber;
  
  
  
  FUNCTION apoliceExist(numApolice VARCHAR2) RETURN VARCHAR2
  IS
     tt NUMBER;
  BEGIN
     SELECT COUNT(*) INTO tt
        FROM T_CONTRATO CT
        WHERE UPPER(CT.CTT_NUMAPOLICE) = UPPER(numApolice)
           AND CT.CTT_STATE != -1;
           
     IF tt =0 THEN  RETURN 'true';
     ELSE RETURN 'false';
     END IF;
  END;
  
  
  
  FUNCTION dadosContrato(ID_SEGURO NUMBER, -- Aqui deve ser um nuber
                          ID_CLIENTE NUMBER,
                          NUMERO_APOLICE VARCHAR2,
                          CODIGO_CONTRATO VARCHAR2, 
                          INICIO DATE, -- Aqui deve ser um DATE(A data do inicio)
                          FIM DATE,--, -- Aqui deve ser um DATE  (A DATA Do FIM)
                          DATA_CONTRATO DATE, -- Aqui deve ser um DATA (DATA do contrato)
                          DATA_RENOVACAO DATE, -- Aqui deve ser um DATA (DATA de Renovacao)
                          PREMIO_BRUTO FLOAT,  --  Aqui deve ser Um FLOAT
                          PRIMEIRO_PREMIO FLOAT,  --  Aqui deve ser Um FLOAT
                          MENOS FLOAT,  --  Aqui deve ser Um FLOAT
                          LIQUIDO_PAGAR FLOAT,  --  Aqui deve ser Um FLOAT,
                          TOTAL_SEGURADO FLOAT,  --  Aqui deve ser Um FLOAT
                          PREMIO_ANUAL FLOAT,  --  Aqui deve ser Um FLOAT
                          TAXA_ADICIONAR FLOAT,  --  Aqui deve ser Um FLOAT
                          EXECESSO FLOAT, --,  --  Aqui deve ser Um FLOAT
                          OBSERVACAO CLOB, --,  --  Aqui deve ser Um Clod
                          numeroRegistroExterno VARCHAR2) RETURN VARCHAR2
  IS
      msg VARCHAR2(4000);
  BEGIN
      /*APOLICE,
      ID,
      NUN-REG,
      TOTAL-SEGURADO,
      PREMIO,
      DATA-INICIO,
      DATA-FIM,
      DATA-CONTRATO
    */
    IF NUMERO_APOLICE IS NULL THEN msg := 'Não existe numero de apolice'||nl; END IF;
    IF ID_CLIENTE IS NULL THEN msg := msg||'Não existe cliente'||nl; END IF;
    -- ID numeroRegistroExterno IS NULL THEN msg := msg ||
  END;
  
  
  -- Retorno 1 - Esta valido
    -- Retorno 0 - Esta invalido
    FUNCTION isValidApolice(numApolice VARCHAR2, idSeguroo NUMBER) RETURN NUMBER
    IS
    BEGIN
       NULL;
    END;
    
    
    
    /*FUNCTION getMissingAccountOperaction(idSeguro NUMBER, operaction CHARACTER VARYING) RETURN CHARACTER VARYING
    IS
       notExist  NUMBER := 0;
       accountNotFound CHARACTER VARYING(4000) := '';    
    BEGIN
       -- VERIFICAR SE TODAS AS CONTA DE DESTINO EXTEJEM PREVIAMENTE CADASTRADo NO SISTEMA
       -- EM CASO DE AUSENCIA DE ALGUMAS DESSA CONTAS O SISTEMA DEVERA ANULAR O REGISTRO DE CONTRATO FEITO APRESENTADO AS CONTAS FALTOSAS

       FOR NFOUND IN(SELECT *
                       FROM VER_OPERACTION_DESTINO_ACCOUNT NFOUND
                          WHERE NFOUND."CONTA DESTINO"  NOT IN (SELECT AC.COD
                                                                   FROM VER_ALL_ACCOUNT AC
                                                                   WHERE  AC.TP = 'P')
                             AND NFOUND."OPERACAO COD" =operaction
                             AND NFOUND."SEGURO ID" = idSeguro)
      LOOP
         IF notExist > 0 THEN accountNotFound := accountNotFound||', '; END IF;
         accountNotFound := accountNotFound || 'conta '||NFOUND."TIPO MOVIMENTO"||' '||NFOUND."CONTA DESTINO";
         notExist := notExist + 1;
      END LOOP;
      
      -- Quando estiver em falta uma ou mais conta da operacao enta
      IF notExist = 1 THEN 
         RETURN 'Não foi encontrado a '||accountNotFound;
      ELSIF notExist > 1 THEN
         RETURN 'Não foram encontradas as: '||accountNotFound;
      END IF;
      
      RETURN NULL;
    END;
    */
END PACK_VALIDATE;