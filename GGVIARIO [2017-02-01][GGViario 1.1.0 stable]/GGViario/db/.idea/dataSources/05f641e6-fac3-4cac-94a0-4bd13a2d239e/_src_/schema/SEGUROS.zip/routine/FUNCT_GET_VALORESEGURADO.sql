create FUNCTION           "FUNCT_GET_VALORESEGURADO" 
(
    dataInicial DATE,
    dataFinal DATE,
    tipoViagem NUMBER -- 1 Viagem Normal | 2 Mult -Viagem
)RETURN PACK_TYPE.TaxasImpostaSegurado PIPELINED
IS
    numDias NUMBER (8) := dataFinal - dataInicial+1;
BEGIN
  FOR I IN (SELECT
                T.ID,
                T.NC, 
                T.SUBTOTAL,
                T.CONSUMO,
                T.SELO,
                T.FGA,
                T.DIAMININO,
                T.DIAMAX,
                numDias AS DIAS,
                PRE.PREC_TOTAL AS TOTAL
                FROM TABLE(FUNCT_VER_TAXAX_IMPOSTAS) T 
                   INNER JOIN T_PRECARIO PRE ON PRE.PREC_ID = T."ID"
                WHERE 1 = (CASE 
                              WHEN tipoViagem = 1
                                 AND (numDias BETWEEN T.DIAMININO AND T.DIAMAX 
                                          OR numDias BETWEEN  T.DIAMAX AND T.DIAMININO)
                                 THEN 1
                              WHEN tipoViagem = 2 AND T.DIAMAX = -1 AND T.DIAMININO = -1
                                 THEN 1
                              ELSE 0
                          END))
  LOOP
    PIPE ROW(I);
  END LOOP;
END;