create TYPE BODY "TP_OBJ_SEGUROINCENDIO" IS

  CONSTRUCTOR FUNCTION TP_OBJ_SEGUROINCENDIO(
                                              ENDERECO_EDIFICIO NUMBER,
                                              NUMERO_ANDARES NUMBER,
                                              CONDICAO VARCHAR2,
                                              ANO DATE,
                                              EQUI_COMBATE_INCENDIO VARCHAR2,
                                              FONTE_AGUA_DISPONIVEL VARCHAR2,
                                              DISTANCIA_COM_BOMBEIRO VARCHAR2,
                                              PAVIMENTO_EDIFICIO NUMBER,
                                              TETOS NUMBER,
                                              PAREDE NUMBER)RETURN SELF AS RESULT AS
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_OBJ_SEGUROINCENDIO.TP_OBJ_SEGUROINCENDIO
    SELF.ENDERECO_EDIFICIO := ENDERECO_EDIFICIO;
    SELF.NUMERO_ANDARES :=   NUMERO_ANDARES;
    SELF.CONDICAO := CONDICAO;
    SELF.ANO :=   ANO;
    SELF.EQUI_COMBATE_INCENDIO := EQUI_COMBATE_INCENDIO;
    SELF.FONTE_AGUA_DISPONIVEL := FONTE_AGUA_DISPONIVEL;
    SELF.DISTANCIA_COM_BOMBEIRO := DISTANCIA_COM_BOMBEIRO;
    SELF.PAVIMENTO_EDIFICIO  := PAVIMENTO_EDIFICIO ;
    SELF.TETOS := TETOS;
    SELF.PAREDE := PAREDE;
    RETURN ;
  END TP_OBJ_SEGUROINCENDIO;

  STATIC FUNCTION INSTANCEOF RETURN NUMBER AS
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_OBJ_SEGUROINCENDIO.INSTANCEOF
    RETURN 6;
  END INSTANCEOF;
  

END;