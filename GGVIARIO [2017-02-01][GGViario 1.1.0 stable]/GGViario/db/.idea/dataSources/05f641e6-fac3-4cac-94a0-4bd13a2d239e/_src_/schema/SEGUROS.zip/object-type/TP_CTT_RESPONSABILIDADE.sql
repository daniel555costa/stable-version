create TYPE           "TP_CTT_RESPONSABILIDADE"                                          UNDER TP_CTT
( 
   SALARIO_DET_COLABORADORES FLOAT,
   SALARIOA_SUB_EMPRETEIROS FLOAT,
   EDIFICIO_EST_CONSERVACAO NUMBER(8), --  VER_ESTADOCONSERVACAO
    CONSTRUCTOR FUNCTION TP_CTT_RESPONSABILIDADE(
                                                 SALARIO_DET_COLABORADORES FLOAT,
                                                 SALARIOA_SUB_EMPRETEIROS FLOAT,
                                                 EDIFICIO_EST_CONSERVACAO NUMBER
                                                  ) RETURN SELF AS RESULT, --CONSTRUTOR VAZIO DO OBJECTO
    STATIC FUNCTION INSTANCEOF RETURN NUMBER
    
)NOT FINAL;