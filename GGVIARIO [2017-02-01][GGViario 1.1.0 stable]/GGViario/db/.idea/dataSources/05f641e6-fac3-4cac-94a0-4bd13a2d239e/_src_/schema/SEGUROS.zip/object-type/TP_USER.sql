create TYPE           "TP_USER"                                          UNDER TP_OBJECT
( 
  ID_USER NUMBER,
  NOME VARCHAR2(50), 
  NIF VARCHAR2(9), 
  ACCESSNAME VARCHAR(30), 
  STATE NUMBER, 
  PHOTO BLOB,
  
  CONSTRUCTOR FUNCTION TP_USER(ID_USER NUMBER,
                                 NOME VARCHAR2,
                                 NIF VARCHAR2,
                                 ACCESSNAME VARCHAR2,
                                 STATE NUMBER,
                                 PHOTO BLOB) RETURN SELF AS RESULT
);