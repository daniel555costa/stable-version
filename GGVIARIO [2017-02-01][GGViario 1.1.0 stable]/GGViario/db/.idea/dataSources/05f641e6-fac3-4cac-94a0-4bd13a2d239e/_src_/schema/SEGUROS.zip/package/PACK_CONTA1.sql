create PACKAGE           "PACK_CONTA1" AS 
  
  function func_preview_lancamento_seq return character VARYING;
  
  function func_reg_lancamento ( idUser NUMBER,
                                 idTypeLancamento NUMBER,
                                 ttContaLancamento NUMBER,
                                 dataLancamento DATE) return CHARACTER;
                                 
  function func_reg_lancamentoaccount (idLancamento NUMBER, -- id devolvida da primeira funcao
                                       idUser NUMBER,
                                       idTypeMoviment NUMBER, -- 1 DEBITO| 2 - CREDITO
                                       idAccount NUMBER,
                                       idMoeda NUMBER,
                                       documentNumber CHARACTER VARYING,
                                       documentDesc CHARACTER VARYINg,
                                       documentData DATE,
                                       descrincao CHARACTER VARYING,
                                       valor FLOAT
                                       ) return CHARACTER VARYING;
                                       
                                       
  FUNCTION func_end_lancamento(idUser NUMBER,
                               idLancamento NUMBER) RETURN CHARACTER VARYING;

END PACK_CONTA1;