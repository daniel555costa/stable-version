create PROCEDURE           "PRC_REG_VEICULO_MARCA" 
(
   idUser NUMBER,
   nomeMarca VARCHAR2
)
IS
BEGIN
   INSERT INTO T_OBJECTYPE(OBJT_USER_ID, 
                            OBJT_T_ID,
                            OBJT_DESC)
                            VALUES(idUser,
                                    1,
                                    nomeMarca);
END;