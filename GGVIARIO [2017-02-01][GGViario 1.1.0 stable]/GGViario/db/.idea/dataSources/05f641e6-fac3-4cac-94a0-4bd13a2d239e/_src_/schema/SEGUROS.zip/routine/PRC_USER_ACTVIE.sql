create PROCEDURE           "PRC_USER_ACTVIE" 
(
   idUser NUMBER,
   userNewPwd VARCHAR2
)
IS
   tt NUMBER;
BEGIN
   UPDATE T_FUNCIONARIO U
      SET U.FUNC_ACCESS = 1, --,
           U.FUNC_PWD =  userNewPwd --   FUNC_MD5(userNewPwd)
      WHERE U.FUNC_ACCESS = 2
         AND U.FUNC_ID = idUser
         --AND U.USER_PWD= FUNC_MD5(userNif);
         ;
END;