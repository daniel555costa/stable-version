create FUNCTION           "FUNC_REGOBJ_RESPONSAPUBLICA" 
(
    USER_ID NUMBER,
    ID_CONTRATO NUMBER,
    EMPREGADO VARCHAR,
    PROFISSAO VARCHAR,
    ENDERECO_EDIFICIO VARCHAR
)
RETURN VARCHAR2
IS
    res PACK_TYPE.Resultado;
    -- Criar um novo objecto de responsabilidade publica
       parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
BEGIN
                               
    PRC_ADD_LISTVALUE(parsValues, null, 'empregado', EMPREGADO);
    PRC_ADD_LISTVALUE(parsValues, null, 'profissao', PROFISSAO);
    PRC_ADD_LISTVALUE(parsValues, null, 'enderecoEdificio', ENDERECO_EDIFICIO);
    
    -- 
    res := PACK_REGRAS.REG_OBJECTO(USER_ID , ID_CONTRATO , 239, 1);
    
    PACK_REGRAS.REGOBJECTVALUES(USER_ID, res.resultado, null, 13, parsValues);
    IF  res.resultado != -1 THEN RETURN 'true';
    ELSE RETURN res.message;
    END IF;
END;