create FUNCTION           "FUNCT_LOAD_DATA_CONTRATO" 
(
    idUser NUMBER,
    codSeguro VARCHAR2,
    idContrato NUMBER   
)RETURN TB_LOAD_CONTRATO -- PIPELINED
IS
   tbResp TB_LOAD_CONTRATO := TB_LOAD_CONTRATO();
BEGIN
  -- ID do contrato
  
   /*
    5	NHI	Seguro Maritimo
    6	DI	Seguro de Roubo
    7	MAC	Mercadoria em Transito
    8	RP	Responsabiliddae Publica
    9	DH	Seguro Dinheiro
    10	MR	Seguro Multe Risco
   */
   --PACK_CONTRATOS.PLOADGENERIC(IDCONTRATO NUMBER,OBJNAME VARCHAR2,CTTNAME VARCHAR2,LISTRESULT TABLE)
   PACK_CONTRATOS.PLOADGENERIC(idContrato, tbResp);
   -- Incluir as reposta do seguro
   PACK_CONTRATOS.pAddRespostas(tbResp, idContrato);
   RETURN tbResp;
END;