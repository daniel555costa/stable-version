create PACKAGE           "PACK_SINISTRO" as 

    TYPE OCORRENCIA IS TABLE OF T_OCORRENCIA%ROWTYPE;
    
    TYPE TESTEMNUNHA IS TABLE OF T_TESTEMUNHAS%ROWTYPE;
    
    TYPE HIPOTECA IS TABLE OF T_HIPOTECA%ROWTYPE;
    
    TYPE paymentMap IS RECORD("APOLICE" CHARACTER VARYING(120), "SINISTRO" CHARACTER VARYING(32), "CLIENTE" CHARACTER VARYING(120), "VALOR REQUISITADO" CHARACTER VARYING (120),"VALOR PAGO" CHARACTER VARYING(128), "DATA" CHARACTER VARYING(20), "OBSERVACAO"     TYPE filterMapaPayment IS TABLE OF paymentMap;
    
    FUNCTION FUNC_REG_OCORRENCIA(ID_USER NUMBER,
                    ID_CTTOCORRENCIA NUMBER,
                    residenciaPolicial VARCHAR2,
                    residenciaSinistrado VARCHAR2,
                    localInspecao VARCHAR2,
                    DTINSPECAO DATE,
                    HORA_DATAOCORRENCIA TIMESTAMP, 
                    LOCALOCORRENCIA VARCHAR2,
                    -- ESTADO_SINISTRADO VARCHAR2,
                    NARRACAO_SUCEDIDO VARCHAR2,
                    ESTIMATIVA_RECUPERACAO VARCHAR2,
                    NUMERO_VEICULOTERCEIRO VARCHAR2,
                    NUMERO_CHASSI VARCHAR2,
                    DESCRICAO_OCORRENCIA VARCHAR2,-- Como medidas tomdas
                    idSuperOcorencia NUMBER,
                    codigoSinistro CHARACTER VARYING
                      )RETURN VARCHAR2;
  
  
  
      
    FUNCTION FUNC_REG_HIPOTECA( ID_USER NUMBER,
                                OCORRENCIA_HIPOTECA NUMBER, -- Id de ocorencia
                                NOME_RESIDENCIA VARCHAR2,
                                NOME_INTERESSADO varchar2, -- Nome do endereco
                                idOldHipoteca NUMBER
                                  )RETURN varchar2;
  
  
  
  
  
    FUNCTION FUNC_REG_TESTEMUNHAS ( ID_USER NUMBER,
                                    OCORRENCIA_TESTEMUNHO NUMBER,
                                    NOME_RESIDENCIA varchar2,
                                    NOME_TESTEMUNHA VARCHAR2,
                                    TELEFONE_TESTEMUNHA VARCHAR2,
                                    idOldeTestemunha NUMBER
                                    )RETURN VARCHAR2;
                                    
                                    
   FUNCTION FUNC_REG_SINISTROPAYMENT(idUser NUMBER, idOcorencia NUMBER, valorOcorencia FLOAT, observacao CHARACTER VARYING, dataPaymemte DATE) RETURN CHARACTER VARYING;
             
   FUNCTION FUNC_DISABLE_SINISTRO(idUser NUMBER, idOcorrencia NUMBER, observacao CHARACTER VARYING) RETURN CHARACTER VARYING;
   
   FUNCTION FUNC_EDITE_SINISTRO (idUser NUMBER, idOcorrencia NUMBER) RETURN CHARACTER VARYING;
    
   FUNCTION FUNCT_LOAD_OCORRENCIA(idOcorrencia NUMBER) RETURN OCORRENCIA PIPELINED;
   
   FUNCTION FUNCT_LOAD_TESTEMNUNHA(idOcorencia NUMBER) RETURN TESTEMNUNHA PIPELINED;
   
   FUNCTION FUNCT_LOAD_HIPOTECA(idOcorencia NUMBER) RETURN HIPOTECA PIPELINED;
   
   FUNCTION FUNCT_LOAD_MAPAPAYMENT (dataInicio DATE, dataFim date) RETURN filterMapaPayment PIPELINED; 
   
   FUNCTION FUNC_PAY_SINISTRO (idUser NUMBER, idRequisicaoPagamento NUMBER, idPayment NUMBER) RETURN CHARACTER VARYING;
    
END PACK_SINISTRO;