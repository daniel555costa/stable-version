create TYPE BODY "TP_CTT_VIAGEM" IS

  CONSTRUCTOR FUNCTION TP_CTT_VIAGEM(
                                        OBJECTIVO_VIAGEM VARCHAR2,
                                        PAIS_DESTINO VARCHAR2,
                                        DATA_INICIO DATE,
                                        DATA_FIM DATE,
                                        niconComisao FLOAT,
                                        premio FLOAT,
                                        numDias NUMBER,
                                        impostoConsumo FLOAT,
                                        impostoSelo FLOAT,
                                        netOutFax FLOAT,
                                        totalPremio FLOAT,
                                        numPassageiros NUMBER
                                      )RETURN SELF AS RESULT --CONSTRUTOR  DO OBJECTO
  IS
  BEGIN
    SELF.OBJECTIVO_VIAGEM := OBJECTIVO_VIAGEM;
    SELF.PAIS_DESTINO := PAIS_DESTINO;
    SELF.DATA_INICIO := DATA_INICIO;
    SELF.DATA_FIM := DATA_FIM;
    
    SELF.niconComisao := niconComisao;
    SELF.premio := premio;
    SELF.numDias := numDias;
    SELF.impostoConsumo := impostoConsumo;
    SELF.impostoSelo := impostoSelo;
    SELF.netOutFax := netOutFax;
    SELF.totalPremio := totalPremio;
    SELF.numPassageiros := numPassageiros;
    SELF.state := 1;
    SELF.instance_of := TP_CTT_VIAGEM.INSTANCEOF();
    RETURN;
  END;
                
                        
   STATIC FUNCTION INSTANCEOF RETURN NUMBER
   IS
   BEGIN
      RETURN 5;
   END;

END;