create TYPE           "TP_CTT_INCENDIO"                                          UNDER TP_CTT
(
   CONDICAO VARCHAR2(60),
   FONTE_AGUA_DISPONIVEL VARCHAR2(60),
   EQUI_COMBATE_INCENDIO VARCHAR2(60),
   ENDERECO_RES_ID NUMBER, -- Endereco completo do edificio
   
   NUMERO_ANDARES NUMBER,
   ANO NUMBER(4),
   DISTANCIA_COM_BOMBEIRO VARCHAR2(20),
   
   usoEdificio NUMBER(8),  --uso {VER_USO_EDIFICIO}
   usoDescrincao VARCHAR2(100),
   processoFabricacao VARCHAR2(200), -- {NULL - nao checado | descrincoa caso checado}
   
   CONSTRUCTOR FUNCTION TP_CTT_INCENDIO(CONDICAO VARCHAR2,
                                        FONTE_AGUA_DISPONIVEL VARCHAR2,
                                        EQUI_COMBATE_INCENDIO VARCHAR2,
                                        ENDERECO_RES_ID NUMBER, -- Endereco completo do edificio
                                        
                                        NUMERO_ANDARES NUMBER,
                                        ANO NUMBER,
                                        DISTANCIA_COM_BOMBEIRO VARCHAR2,
                                        
                                        usoEdificio NUMBER,  --uso {1 - Comercial | 2 - Residencial}
                                        usoDescrincao VARCHAR2,
                                        processoFabricacao VARCHAR2 -- {NULL - nao checado | descrincoa caso checado}
                                        )RETURN SELF AS RESULT,
                                              
  STATIC FUNCTION INSTANCEOF RETURN NUMBER
)FINAL;