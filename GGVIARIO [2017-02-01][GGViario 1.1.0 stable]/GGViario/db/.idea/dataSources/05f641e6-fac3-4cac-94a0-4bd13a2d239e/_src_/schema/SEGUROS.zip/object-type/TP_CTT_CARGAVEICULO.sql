create TYPE           "TP_CTT_CARGAVEICULO"                                          UNDER TP_CTT
(
    conservacao_noite CHAR(1), -- {Y - Yes | N - NO}
    numRegistro VARCHAR2(30),
    veiculoRegistrado VARCHAR2(50),
    valorCarregamento FLOAT,
    marca FLOAT,
    valorMaxCarregamnto FLOAT,
    valorMaxVeiculo FLOAT,
    usoDescolacaoComer NUMBER(1), --Usado para deslocação comercial {0 NOT Chequed, 1 Chequed}
    possTranca NUMBER(1), -- Possibilidade de trancar {0 NOT Chequed, 1 Chequed}
    
    CONSTRUCTOR FUNCTION TP_CTT_CARGAVEICULO(conservacao_noite CHAR, -- {Y - Yes | N - NO}
                                              numRegistro VARCHAR2,
                                              veiculoRegistrado VARCHAR2,
                                              valorCarregamento FLOAT,
                                              marca FLOAT,
                                              valorMaxCarregamnto FLOAT,
                                              valorMaxVeiculo FLOAT,
                                              usoDescolacaoComer NUMBER, --Usado para deslocação comercial {0 NOT Chequed, 1 Chequed}
                                              possTranca NUMBER)RETURN SELF AS RESULT,
                                              
   STATIC FUNCTION INSTANCEOF RETURN NUMBER
    		
);