create TYPE           "TP_LOAD_CONTRADO"                                          IS OBJECT
(
    STYPE VARCHAR2(100),
    COD VARCHAR2(100),
    VALUE VARCHAR2(4000)
);