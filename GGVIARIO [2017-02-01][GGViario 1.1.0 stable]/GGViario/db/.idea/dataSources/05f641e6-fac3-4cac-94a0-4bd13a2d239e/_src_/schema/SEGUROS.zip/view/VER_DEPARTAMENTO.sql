create view VER_DEPARTAMENTO as
SELECT 
D.DEP_ID as ID,
D.dep_desc as Departamento

from T_DEPARTAMENTO D
