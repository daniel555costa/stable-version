create TYPE           "SYS_PLSQL_21674_58_1"                                          as object ("ID_USER" NUMBER(7),
"NOME" VARCHAR2(60),
"NIF" VARCHAR2(9),
"ACCESSNAME" VARCHAR2(30),
"STATE" NUMBER(1),
"ACESSO" NUMBER(1),
"PHOTO" BLOB);