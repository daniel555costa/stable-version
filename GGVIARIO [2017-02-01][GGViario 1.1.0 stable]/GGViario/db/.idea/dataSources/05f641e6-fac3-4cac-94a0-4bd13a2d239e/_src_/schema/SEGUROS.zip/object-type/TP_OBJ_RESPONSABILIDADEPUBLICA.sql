create TYPE           "TP_OBJ_RESPONSABILIDADEPUBLICA"                                          UNDER TP_OBJ
( 
    EMPREGADO VARCHAR(60),
    PROFISSAO VARCHAR(50),
    ENDERECO_EDIFICIO VARCHAR(60),
    CONSTRUCTOR FUNCTION TP_OBJ_RESPONSABILIDADEPUBLICA( 
                                                        EMPREGADO VARCHAR,
                                                        PROFISSAO VARCHAR,
                                                        ENDERECO_EDIFICIO VARCHAR)RETURN SELF AS RESULT,
                                                        
    STATIC FUNCTION INSTANCEOF RETURN NUMBER
 );