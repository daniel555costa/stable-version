create PROCEDURE           "PRC_UPD_CLIENTE" 
(
    ID_USER NUMBER,
    ID_CLIENTE VARCHAR2,
    operationType NUMBER, -- OPEATION TYPE {1 - REGISTRAR | 2 - Atualizar}
    LOCAL_TRABALHO VARCHAR2,
    RESIDENCIA VARCHAR2,   -- ALIAS AS MORADA | ALIAS AS LOCALIZACAO
    ID_TIPO_DOCUMENTO NUMBER,
    ID_ESTADO_SOCIAL NUMBER,
    NUMERO_DOCUMENTO VARCHAR2,
    CAIXA_POSTAL VARCHAR2,
    TELEMOVEL VARCHAR2,
    TELEFONE VARCHAR2,
    EMAIL VARCHAR2,
    PROFISAO VARCHAR2, -- ALIAS AS FUNCAO
    SITE VARCHAR2,
    
    -- 
    SEXO NUMBER,
    NOVO_NIF VARCHAR2,
    ID_NACIONALIDADE NUMBER,
    APELIDO VARCHAR2, -- ALIAS AS RESPONSAVEL
    RAZAO_SOCIAL VARCHAR2
)
IS 
  
    ID_RESIDENCIA NUMBER;
    ID_LOCAL_TRABALHO NUMBER;

BEGIN
    
    -- CASO For FRNECIDO A RESIDENCIA CRIAR CRIAR A IDENTIFICACAO DO CLIENTE
    IF RESIDENCIA IS NOT NULL THEN 
        ID_RESIDENCIA := PACK_REGRAS.GET_RESIDENCE(RESIDENCIA, ID_USER);
    ELSE ID_RESIDENCIA := NULL;
    END IF;

    -- CASO FOR FORNECIDO O LOCAL DO TRABALHO DO CLIENTE REGISTRAR O CLIENTE
    IF LOCAL_TRABALHO IS NOT NULL THEN 
      ID_LOCAL_TRABALHO:= PACK_REGRAS.GET_RESIDENCE(LOCAL_TRABALHO, ID_USER);
    ELSE ID_LOCAL_TRABALHO:=NULL;
    END IF;
    
    -- Inativar o antigo historico do cliente
      UPDATE T_LINHACLIENTE
          SET LCLI_STATE = 0
          WHERE LCLI_CLI_ID = ID_CLIENTE
              AND LCLI_STATE = 1;
      
      -- Criar um novo historico do cliente
      INSERT INTO T_LINHACLIENTE (LCLI_USER_ID,
                                  LCLI_RES_IDEMPRESA,
                                  LCLI_RES_ID,
                                  LCLI_SC_ID,
                                  LCLI_TDOC_ID,
                                  LCLI_NDOC,
                                  LCLI_CP,
                                  LCLI_PHONE,
                                  LCLI_MOVEL,
                                  LCLI_MAIL,
                                  LCLI_OCUPACAO,
                                  LCLI_CLI_ID,
                                  LCLI_SITE)
                                  VALUES(ID_USER,
                                          ID_LOCAL_TRABALHO,
                                          ID_RESIDENCIA,
                                          ID_ESTADO_SOCIAL,
                                          ID_TIPO_DOCUMENTO,
                                          NUMERO_DOCUMENTO,
                                          CAIXA_POSTAL,
                                          TELEFONE,
                                          TELEMOVEL,
                                          EMAIL,
                                          PROFISAO,
                                          ID_CLIENTE,
                                          SITE
                                    );
                                    
    -- Quando for a operacao de atualizar enta
    IF operationType = 2 THEN
        UPDATE T_CLIENTE CT
           SET CT.CLI_APELIDO = APELIDO,
               CT.CLI_GEN_ID = SEXO,
               CT.CLI_NIF = NOVO_NIF,
               CT.CLI_PAIS_ID = ID_NACIONALIDADE,
               CT.CLI_RSOCIAL = RAZAO_SOCIAL
           WHERE CT.CLI_ID = ID_CLIENTE;
    END IF;
                        

END;