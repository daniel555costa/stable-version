create view VER_SITUACAOFAMILIAR as
select
        sf.situa_id AS "ID",
        sf.situa_numfilhos as "NUMERO FILHO",
        sf.SITUA_VALORPAGAR as "PERCENTAGEM",
        (sf.SITUA_VALORPAGAR)*(sn.salnacio_valor) as "VALOR"
    from t_situacaofamiliar sf
        inner join T_SALARIONACIONAL sn on sn.SALNACIO_STATE = 1
    WHERE sn.SALNACIO_STATE = 1
        and sf.SITUA_STATE = 1
    ORDER BY sf.situa_numfilhos  ASC
