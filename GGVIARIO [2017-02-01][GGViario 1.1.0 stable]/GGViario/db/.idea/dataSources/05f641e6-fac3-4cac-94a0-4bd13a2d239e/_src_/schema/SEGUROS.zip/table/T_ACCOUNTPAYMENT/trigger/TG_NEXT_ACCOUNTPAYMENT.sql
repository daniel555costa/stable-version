create trigger TG_NEXT_ACCOUNTPAYMENT
	before insert
	on T_ACCOUNTPAYMENT
	for each row
begin  
   if inserting then 
      if :NEW."COUNTPAY_ID" is null then 
         select SEQ_ACCOUNTPAYMENT.nextval into :NEW."COUNTPAY_ID" from dual; 
      end if; 
   end if; 
end;