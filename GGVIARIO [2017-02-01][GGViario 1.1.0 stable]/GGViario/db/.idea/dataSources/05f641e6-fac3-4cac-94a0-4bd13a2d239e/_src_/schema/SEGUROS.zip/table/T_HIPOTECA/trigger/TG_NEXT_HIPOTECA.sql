create trigger TG_NEXT_HIPOTECA
	before insert
	on T_HIPOTECA
	for each row
begin  
   if inserting then 
      if :NEW."HIPO_ID" is null then 
         select SEQ_HIPOTECA.nextval into :NEW."HIPO_ID" from dual; 
      end if; 
   end if; 
end;