create trigger TG_NEXT_ITEMOVIMENTATION
	before insert
	on T_ITEMOVIMENTATION
	for each row
begin  
   if inserting then 
      if :NEW."ITEMOV_ID" is null then 
         select SEQ_ITEMOVIMETATION.nextval into :NEW."ITEMOV_ID" from dual; 
      end if; 
   end if; 
end;