create FUNCTION           "FUNC_REG_CUBERTURA" (
 ID_SEGURO number,
 NIVEL_COBERTURA_ID NUMBER, 
COBERTURA_user_id number,
DESCRICAO_COBERTURA varchar2
)
RETURN VARCHAR2
IS
BEGIN
    INSERT INTO T_COBERTURA(COBRE_SEG_ID,
                            COBRE_NCOBRE_ID,
                            COBRE_USER_ID,
                            COBRE_DESC)
                            VALUES( ID_SEGURO,
                                     NIVEL_COBERTURA_ID,
                                     COBERTURA_user_id,
                                     DESCRICAO_COBERTURA );
            RETURN 'true';
                                     

END;