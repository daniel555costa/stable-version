create TYPE           "TP_OBJ_SEGURODINHEIRO"                                          UNDER TP_OBJ
( /* TODO enter attribute and method declarations here */
 NOME_FABRICANTE VARCHAR2(60),
 NUMERO_FABRICANTE VARCHAR2(30),
 TAMANHO VARCHAR(20),
 DETENTOR_CHAVES VARCHAR2(60),
 PESO FLOAT,
 ID_OBJTCONTROCOFRE NUMBER(8), -- VER_OBJTCONTROCOFRE
 estrutura varchar2(200),
 CONSTRUCTOR FUNCTION TP_OBJ_SEGURODINHEIRO(
                                             NOME_FABRICANTE VARCHAR2,
                                             NUMERO_FABRICANTE VARCHAR2,
                                             TAMANHO VARCHAR,
                                             DETENTOR_CHAVES VARCHAR2,
                                             PESO FLOAT,
                                             ID_OBJTCONTROCOFRE NUMBER,
                                             estrutura varchar2)RETURN SELF AS RESULT,
                                             
  STATIC FUNCTION INSTANCEOF RETURN NUMBER
    
)FINAL;