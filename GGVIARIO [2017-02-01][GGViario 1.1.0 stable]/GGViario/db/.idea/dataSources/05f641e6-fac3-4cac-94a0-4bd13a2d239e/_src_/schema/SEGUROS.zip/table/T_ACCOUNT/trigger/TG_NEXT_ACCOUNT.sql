create trigger TG_NEXT_ACCOUNT
	before insert
	on T_ACCOUNT
	for each row
BEGIN
  IF inserting AND :new.account_id is null THEN
     :new.account_id :=  seq_account.nextval;
  END IF;
END;