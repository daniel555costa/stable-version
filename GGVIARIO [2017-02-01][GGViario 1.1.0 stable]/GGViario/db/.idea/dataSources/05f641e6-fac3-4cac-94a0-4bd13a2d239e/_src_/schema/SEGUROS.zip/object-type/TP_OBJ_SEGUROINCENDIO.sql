create TYPE           "TP_OBJ_SEGUROINCENDIO"                                          UNDER TP_OBJ
( 
   ENDERECO_EDIFICIO NUMBER,
   NUMERO_ANDARES NUMBER,
   CONDICAO VARCHAR2(60),
   ANO VARCHAR2(30),
   EQUI_COMBATE_INCENDIO VARCHAR2(60),
   FONTE_AGUA_DISPONIVEL VARCHAR2(60),
   DISTANCIA_COM_BOMBEIRO VARCHAR2(20),
   PAVIMENTO_EDIFICIO NUMBER(1),
   TETOS NUMBER(1),
   PAREDE NUMBER(1),
   CONSTRUCTOR FUNCTION TP_OBJ_SEGUROINCENDIO(
                                              ENDERECO_EDIFICIO NUMBER,
                                              NUMERO_ANDARES NUMBER,
                                              CONDICAO VARCHAR2,
                                              ANO DATE,
                                              EQUI_COMBATE_INCENDIO VARCHAR2,
                                              FONTE_AGUA_DISPONIVEL VARCHAR2,
                                              DISTANCIA_COM_BOMBEIRO VARCHAR2,
                                              PAVIMENTO_EDIFICIO NUMBER,
                                              TETOS NUMBER,
                                              PAREDE NUMBER)RETURN SELF AS RESULT,
                                              
  STATIC FUNCTION INSTANCEOF RETURN NUMBER
)FINAL;