create PACKAGE BODY           "PACK_CONTRATOS" AS

   PROCEDURE pLoadGeneric (idContrato NUMBER, listResult IN OUT TB_LOAD_CONTRATO) 
    IS
        className CHARACTER VARYING(1000);
        objGenric TB_OBJECT_VALUES;
        countRow NUMBER := 1;
    BEGIN
    
      -- Loopar todos os segurado do contrato
      FOR OB IN (SELECT *
                 FROM T_ASSEGURA ASS 
                    INNER JOIN T_OBJECTO OB ON ASS.ASE_OBJ_ID = OB.OBJ_ID
                 WHERE ASS.ASE_CTT_ID = idContrato)
      LOOP
          -- Carregar as infomacao do objecto
          objGenric := PACK_REGRAS.LOADOBJECTBYID(OB.OBJ_ID, NULL);
          className := objGenric(objGenric.COUNT).objValue;
          FOR I IN 1..objGenric.COUNT-1
          LOOP
              pAddList(listResult, OB.OBJ_ID, className, countRow, objGenric(I).objName,  objGenric(I).objValue);
          END LOOP;
          -- colocar os valores nas lista que sera apresentada
          pAddCobertura(listResult, null, OB.ASE_ID, countRow);
          countRow := countRow + 1;
      END LOOP;
     
     -- se tiver invormacao no ctt info entoa buscala
      
      objGenric := PACK_REGRAS.LOADOBJECTBYID(NULL, idContrato);
      className := objGenric(objGenric.COUNT).objValue;
      FOR I IN 1..objGenric.COUNT-1
      LOOP
          IF objGenric(I).objSupe IS NOT NULL THEN
             countRow := objGenric(I).objSupe;
          ELSE countRow := 1;
          END IF;
          pAddList(listResult, idContrato, className, countRow, objGenric(I).objName,  objGenric(I).objValue);
      END LOOP;
      pAddCobertura(listResult, idContrato, NULL, countRow);
    END pLoadGeneric;
    
    
   PROCEDURE pAddCobertura(listOut  IN OUT TB_LOAD_CONTRATO, idContrato NUMBER, idAssegurado NUMBER, codAssegura NUMBER) 
   IS
      premio FLOAT;
      detalhes FLOAT;
      taxa FLOAT;
      valor FLOAT;
      nameCobertura VARCHAR2(100);
      catCod VARCHAR2(100);
      
      categoriaName VARCHAR2(100);
   BEGIN
      IF (idContrato IS NULL OR idAssegurado IS NULL) AND (idContrato IS NOT NULL OR idAssegurado IS NOT NULL) THEN
        FOR CA IN (SELECT *
                     FROM T_COBERTURASEGURADO CA 
                        INNER JOIN  T_COBERTURA CO ON CO.COBRE_ID = CA.COBREASE_COBRE_ID
                        WHERE CA.COBREASE_ASE_ID = idAssegurado
                          OR CA.COBREASE_CTT_ID = idContrato)
        LOOP
           premio := CA.COBREASE_PREMIO;
           detalhes := CA.COBREASE_DETALHES;
           taxa := CA.COBREASE_TAXA;
           valor := CA.COBREASE_VALOR;
           nameCobertura := CA.COBRE_DESC;
           
           IF CA.COBREASE_ASE_ID IS NOT NULL THEN 
               catCod := codAssegura; 
           ELSE catCod := 'CTT';
           END IF;
           
           -- Dependendo
           IF idContrato IS NOT NULL THEN categoriaName := 'COBERTURA CTT'; 
           ELSE categoriaName := 'COBERTURA';
           END IF;
           
           pAddList(listOut, CA.COBREASE_COBRE_ID, categoriaName, catCod, 'tipoCobertura', nameCobertura);
           IF premio IS NOT NULL THEN pAddList(listOut, CA.COBREASE_COBRE_ID, 'COBERTURA', catCod, 'premio', premio); END IF;
           IF valor IS NOT NULL THEN pAddList(listOut, CA.COBREASE_COBRE_ID, 'COBERTURA', catCod, 'valorPremio', valor); END IF;
           IF taxa IS NOT NULL THEN pAddList(listOut, CA.COBREASE_COBRE_ID, 'COBERTURA', catCod, 'taxa', taxa); END IF;
           IF detalhes IS NOT NULL THEN pAddList(listOut, CA.COBREASE_COBRE_ID, 'COBERTURA', catCod, 'detalhes', detalhes); END IF;
        END LOOP;
      END IF;
      
   END;
   
  FUNCTION fGet(tableName VARCHAR2, columnName VARCHAR2, whereCondicion VARCHAR2) RETURN VARCHAR2
    IS
       stmt VARCHAR2(4000) := 'SELECT '||columnName||' FROM '||tableName;
       resultValue VARCHAR2(4000) ;
    BEGIN
       IF whereCondicion IS NOT NULL THEN 
          stmt := stmt||' WHERE '||whereCondicion;
       END IF;
       EXECUTE IMMEDIATE stmt INTO resultValue;
       RETURN resultValue;
       
       EXCEPTION 
          WHEN OTHERS THEN
                RETURN stmt;
       
    END;
    
    
     -- Carregar o numero de apolice
   FUNCTION funcLoadNumeroApolice(idCliente NUMBER, idSeguro NUMBER) RETURN CHARACTER VARYING
   IS
      numneroApolice CHARACTER VARYING(100);
   BEGIN
      SELECT AP.APOLICE_NUMERO INTO numneroApolice
         FROM T_APOLICE AP
         WHERE AP.APOLICE_SEG_ID = idSeguro AND AP.APOLICE_CLI_ID = idCliente
           AND ROWNUM <= 1;
         
      RETURN numneroApolice;
      
      EXCEPTION 
         WHEN NO_DATA_FOUND THEN RETURN NULL;
   END;
    
    
   PROCEDURE pAddRespostas(listOut IN OUT TB_LOAD_CONTRATO, idContrato NUMBER) 
   IS 
   BEGIN
      FOR RE IN (SELECT  * 
                   FROM VER_RESPOSTA RE
                   WHERE RE.CONTRATO  = idContrato)
      LOOP
         pAddList(listOut, RE."ID PERGUNTA", 'RESPOSTA', RE.QUESTAO, RE.RESPOSTA, RE.EXPECIFICACAO);
      END LOOP;
   END;
    
    -- Procedimento para adicionar na list
   PROCEDURE pAddList(listResult IN OUT TB_LOAD_CONTRATO, idRow NUMBER, categoria VARCHAR2, categoriaCod VARCHAR2, valueCod VARCHAR2, valueRow VARCHAR2)
   IS
   BEGIN
      listResult.EXTEND;
      listResult(listResult.COUNT) := TP_LOAD_CONTRATO(idRow, categoria, categoriaCod, valueCod, valueRow);
   END pAddList;
   
   
   FUNCTION funcRegReseguro(idUser NUMBER, 
                            idTipoReseguro NUMBER, 
                            idContrato NUMBER, 
                            inicion DATE,
                            fim DATE,
                            descrincao CHARACTER VARYING,
                            deducao FLOAT,
                            limite FLOAT,
                            apolice CHARACTER VARYING,
                            tipoCobertura CHARACTER VARYING,
                            idMoeda NUMBER, 
                            premioGrosso FLOAT,
                            nomeCliente CHARACTER VARYING, 
                            idSeguro NUMBER,
                            notaDebito CHARACTER VARYING)
   RETURN CHARACTER VARYING
   IS 
      contrato T_CONTRATO%ROWTYPE;
      total FLOAT;
      idReseguro NUMBER;
      mDeducao FLOAT := (CASE WHEN deducao IS NULL THEN 0 ELSE deducao END);
   BEGIN
      IF idContrato IS NOT NULL THEN 
          SELECT * INTO contrato
             FROM T_CONTRATO ct
             WHERE ct.ctt_id = idContrato;
             
          total := contrato.CTT_VPAGAR * ( 1- (mDeducao/100));
      ELSE
         total := premioGrosso  * (1 - (mDeducao/100));
      END IF;
      
      
      INSERT INTO T_CONTRATO(CTT_USER_ID,
                             CTT_TCTT_ID,
                             CTT_CTT_ID,
                             CTT_DTINICIO,
                             CTT_DTFIM,
                             CTT_OBS,
                             CTT_TADICIONAR, -- AS DEDUCAO
                             CTT_VPAGAR, -- AS TOTAL IN RESEGURO
                             CTT_VTTSEGURADO, -- AS LIMITE DE RESPONSABILIDADE
                             CTT_NUMAPOLICE, -- AS NUMERO DE APOLICE EM RESEGURO
                             CTT_COBERTURA,
                             CTT_MOE_ID,
                             CTT_PBRUTO, --AS PREMIO GROSSO
                             CTT_CLIENT, -- AS NOME DO CLIENTE
                             CTT_SEG_ID, -- AS SEGURO
                             CTT_EXTERNALCOD, -- AS NOTA DEBITO
                             CTT_CLI_ID,
                             CTT_STATE
                            ) VALUES (idUser,
                                      idTipoReseguro,
                                      idContrato,
                                      inicion,
                                      fim,
                                      descrincao,
                                      mDeducao,
                                      total,
                                      limite,
                                      apolice,
                                      tipoCobertura,
                                      idMoeda,
                                      premioGrosso,
                                      nomeCliente,
                                      idSeguro, 
                                      notaDebito,
                                      0,    --- 0 AS CLIENTE ANONIMO (UNKNOW CLIENT)
                                      2 -- O estado de pendente
                                      )RETURNING CTT_ID INTO idReseguro;
                                      
      -- Criara a primeira linha de autualizacao do registro
    INSERT INTO T_LINHACONTRATO(LCTT_CTT_ID,
                                LCTT_USER_ID,
                                LCTT_OBS,
                                LCTT_FORSTATE,
                                LCTT_DTRENOVACAO,
                                LCTT_DTFINALIZAR,
                                LCTT_DTINICIAR)
                                VALUES (idReseguro,
                                        idUser,
                                        'NEW RESEGURO',
                                        1,
                                        NULL,
                                        FIM,
                                        inicion);
                                      
                                      
      INSERT INTO T_PRESTACAO(PREST_CTT_ID,
                        PREST_USER_ID,
                        PREST_VALOR,
                        PREST_DTINIC,
                        PREST_DTPRAZO)
                        VALUES(idReseguro,
                               idUser,
                               total,
                               inicion,
                               fim);
                           
      RETURN 'true;'||idReseguro;
   END;
   
   FUNCTION funcResponsabilidade (idUser NUMBER, idEmpresa NUMBER, idReseguro NUMBER, precentagen FLOAT, premio FLOAT, risco FLOAT) 
   RETURN CHARACTER VARYING
   IS
      reseguro T_CONTRATO%ROWTYPE;
   BEGIN
   
      SELECT * INTO reseguro
         FROM T_CONTRATO ct
         WHERE ct.CTT_ID = idReseguro;
         
      INSERT INTO T_RESPONSABILIDADE(RESPO_EMP_ID,
                                     RESPO_CTT_ID,
                                     RESPO_USER_ID,
                                     RESPO_PERECENTAGE,
                                     RESPO_PREMIO,
                                     RESPO_RISCO)
                                     VALUES (idEmpresa,
                                             idReseguro,
                                             idUser,
                                             precentagen,
                                             premio,
                                             risco);
      RETURN 'true;Sucesso';
   END;
   
   FUNCTION funcEndReseguro (idReseguro NUMBER) RETURN CHARACTER VARYING
   IS
   BEGIN
      UPDATE T_CONTRATO RE
         SET RE.CTT_STATE = 1
         WHERE RE.CTT_ID = idReseguro;
         
      
      RETURN 'true;Sucesso';
         
   END;
   
   
   FUNCTION funcRegNotCredito 
   (
      idUser NUMBER,
      idContrato NUMBER,
      codRegistro CHARACTER VARYING,
      beneficiary CHARACTER VARYING,
      sendAddress CHARACTER VARYING,
      observation CHARACTER VARYING,
      premioGross FLOAT,
      deducao FLOAT,
      total FLOAT
   )
   RETURN CHARACTER VARYING
   AS 
      idNotaDebito NUMBER;
   BEGIN
      INSERT INTO T_NOTACREDITO(NCRED_CTT_ID,
                                NCRED_USER_ID,
                                NCRED_CODREG,
                                NCRED_BENEFICIARY,
                                NCRED_SENDADDRESS,
                                NCRED_DESC,
                                NCRED_PREMIOGROSS,
                                NCRED_DEDUCAO,
                                NCRED_TOTAL)
                                VALUES(idContrato,
                                       idUser,
                                       codRegistro,
                                       beneficiary,
                                       sendAddress,
                                       observation,
                                       premioGross,
                                       deducao,
                                       total)
                                       RETURNING NCRED_ID INTO idNotaDebito;
                                       
      RETURN 'true;'||idNotaDebito;
   END;
   
   

END PACK_CONTRATOS;