create trigger TG_NEXT_OBJECTVALUE
	before insert
	on T_OBJECTVALUE
	for each row
begin  
   if inserting then 
      if :NEW."OBJVALL_ID" is null then 
         select SEQ_OBJECTVALUE.nextval into :NEW."OBJVALL_ID" from dual; 
      end if; 
   end if; 
end;