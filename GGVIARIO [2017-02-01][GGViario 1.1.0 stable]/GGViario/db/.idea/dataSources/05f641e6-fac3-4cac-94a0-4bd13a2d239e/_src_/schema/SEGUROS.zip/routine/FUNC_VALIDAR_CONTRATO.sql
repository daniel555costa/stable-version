create FUNCTION           "FUNC_VALIDAR_CONTRATO" 
(
   idUser NUMBER,
   idContrato NUMBER,
   numApolice VARCHAR2,
   totalCoberturas NUMBER,
   totalObjectos NUMBER,
   totalCttInf NUMBER
)
RETURN VARCHAR2
IS
BEGIN
   RETURN 'true';
END;