create view VER_BANK as
SELECT BK.BK_ID AS "ID",
           BK.BK_NOME AS "NOME", 
           BK.BK_SIGLA AS "SIGLA" 
        FROM T_BANK BK
        WHERE BK.BK_ID >0
        order by nome desc
