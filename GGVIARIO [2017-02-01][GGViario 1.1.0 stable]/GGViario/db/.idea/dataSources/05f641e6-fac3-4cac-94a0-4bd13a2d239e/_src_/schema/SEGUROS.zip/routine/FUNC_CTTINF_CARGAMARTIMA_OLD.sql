create FUNCTION           "FUNC_CTTINF_CARGAMARTIMA_OLD" 
(
  idUser NUMBER,
  idContrato NUMBER,

  pais_origem NUMBER,
  pais_destino NUMBER,
  portoCarga VARCHAR2,
  portoDescarga VARCHAR2,
  nomeNavio VARCHAR2,
  valorMaximoRisco  BINARY_DOUBLE,
  
  -- COBRE -- Ambito da cobertura
  escolha_cobertura NUMBER, -- {1 - Todos Riscos, 2 - Restrita, 3 - Mais Restrita}
  valorCoberturaSelecionada BINARY_DOUBLE,
  propositoSeguro CLOB,
  
  -- VMAXRISCO >> Valor maximo em risco para
  qualquerNavio VARCHAR2,
  qualquerLocalizacao BINARY_DOUBLE,
  anualMercadoria VARCHAR, -- Anula para cada mercadoria
  
  --FSEND >> Forma de emvio
  escolha_formaEnvio NUMBER, -- {VER_FORMA_ENVIO}
  
  --OTHER >> Outros
  tempoNegocio NUMBER,
  custoPorto NUMBER, -- Custo do porto (10% 20%)
  
  
  -- Informacao do segurado 
    infoSeg_descMercadoria VARCHAR2,
    infoSeg_areaActividade VARCHAR2,
    infoSeg_segEfectuadoComp VARCHAR2,
    infoSeg_nameCompania VARCHAR2,
  
  -- MTRANS >> Mercadorias Transportadas
  lista_mercadoriaTransportada TB_ARRAY_STRING -- {VER_TIPOMERCADORIA}


)
RETURN VARCHAR2
IS
    /*resp VARCHAR2(100);
    infCargaMaritima TP_CTT_CARGAMARITIMA := NEW TP_CTT_CARGAMARITIMA(pais_origem,
                                                                      pais_destino,
                                                                      portoCarga,
                                                                      portoDescarga,
                                                                      nomeNavio,
                                                                      valorMaximoRisco,
                                                                      
                                                                      -- COBRE -- Ambito da cobertura
                                                                      escolha_cobertura, -- {1 - Todos Riscos, 2 - Restrita, 3 - Mais Restrita}
                                                                      valorCoberturaSelecionada,
                                                                      propositoSeguro,
                                                                      
                                                                      -- VMAXRISCO >> Valor maximo em risco para
                                                                      qualquerNavio,
                                                                      qualquerLocalizacao,
                                                                      anualMercadoria, -- Anula para cada mercadoria
                                                                      
                                                                      --FSEND >> Forma de emvio
                                                                      escolha_formaEnvio, -- {1 - Maritimo, 2 - Aeio, 3 - Encomenda Postal, 4 - Correio}
                                                                      
                                                                      --OTHER >> Outros
                                                                      tempoNegocio,
                                                                      custoPorto, -- Custo do porto (10% 20%)
                                                                      
                                                                      
                                                                      -- Informacao do segurado 
                                                                      infoSeg_descMercadoria,
                                                                      infoSeg_areaActividade,
                                                                      infoSeg_segEfectuadoComp,
                                                                      infoSeg_nameCompania
                                                                      );
*/
BEGIN
    -- Essa funcao serve para criar um objecto do tipo TP_CTT_CARGAMARTIMA publica e armazenala na entidade contrato
    
    /*INSERT INTO T_CONTRATOADD(CTTAD_USER_ID, 
                              CTTAD_CTT_ID, 
                              CTTAD_CARGAMARITIMA)
                              VALUES(idUser,
                                    idContrato,
                                    infCargaMaritima);
                                    
      
   
    /*
    47	Viagem 
    48	Pais destino
    49	Porto de carga
    50	Nome do navio /voo
    51	Pais de origem
    52	Porto de descarga
    54	Formas do envio 
    63	Negocio | Outros
    64	Tempo de negocio
    65	Custo do porto (10% e 20%)
    66	Proposito de seguro
    67	Detalhes da mercadoria
    68	Discricao das mercadorias
    69	Area de atividade comercial
    70	Mercadorias transportadas
    212	Detalhes
    213	Qualquer Navio
    214	Qualquer Mercadoria
    215	Anual para cada mercadoria
    216	Informações Adicionais
    217	Seguros efectuados com a Companhia
    218	Companhia que já efectuou essa classe de seguro
    
    -- PRC_REG_RESPOSTA();
    
    -- Registras as respostas para as pergutas das mercadorias
    --  Usar a lista resposta
    IF lista_mercadoriaTransportada.COUNT = 0 THEN
      FOR I IN 1..lista_mercadoriaTransportada.COUNT LOOP
          resp := FUNC_REG_RESPOSTA(idUser, idContrato, lista_mercadoriaTransportada(i), 1, NULL);
      END LOOP;
    END IF;
                               */       
    RETURN 'true';
END;