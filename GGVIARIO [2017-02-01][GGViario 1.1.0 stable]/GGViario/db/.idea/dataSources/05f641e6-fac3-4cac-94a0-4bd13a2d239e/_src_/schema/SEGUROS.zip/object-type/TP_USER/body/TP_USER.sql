create TYPE BODY "TP_USER" AS

  CONSTRUCTOR FUNCTION TP_USER(ID_USER NUMBER,
                                 NOME VARCHAR2,
                                 NIF VARCHAR2,
                                 ACCESSNAME VARCHAR2,
                                 STATE NUMBER,
                                 PHOTO BLOB) RETURN SELF AS RESULT AS
  BEGIN
    -- TODO: Implementation required for FUNCTION "TP_USER".TP_USER
    
    SELF.ID_USER := ID_USER;
    SELF.NOME := NOME;
    SELF.NIF := NIF;
    SELF.ACCESSNAME := ACCESSNAME;
    SELF.STATE := STATE;
    SELF.PHOTO := PHOTO;
    RETURN;
  END TP_USER;

END;