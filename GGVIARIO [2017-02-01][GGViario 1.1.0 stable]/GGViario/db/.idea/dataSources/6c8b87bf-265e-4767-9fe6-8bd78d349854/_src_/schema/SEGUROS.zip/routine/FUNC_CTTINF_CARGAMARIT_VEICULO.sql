create FUNCTION FUNC_CTTINF_CARGAMARIT_VEICULO 
(
    ID_USER NUMBER,
    ID_CONTRATO NUMBER,
    conservacao_noite CHAR, -- {Y - Yes | N - NO}
    numRegistro VARCHAR2,
    veiculoRegistrado VARCHAR2,
    valorCarregamento FLOAT,
    marca VARCHAR2,
    valorMaxCarregamnto FLOAT,
    valorMaxVeiculo FLOAT,
    usoDescolacaoComer NUMBER, --Usado para deslocação comercial {0 NOT Chequed, 1 Chequed}
    possTranca NUMBER  -- Possibilidade de trancar {0 NOT Chequed, 1 Chequed}
)RETURN VARCHAR2
   
IS
   idMarca NUMBER := PACK_REGRAS.GETOBJECTID(marca, id_user, 1, null, null);
   parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
   idSuper NUMBER;
BEGIN
   -- CLASS = 9 -- A classe de veiculo das carga maritima
   idSuper := PACK_REGRAS.REGOBJVALL(ID_USER, 'VEICULO TRANSPORT', 'VEICULO TRANSPORT', null, 9, null, ID_CONTRATO);
   
   
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'conservacaoNoite', conservacao_noite);
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'numRegistro', numRegistro);
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'veiculoComercialRegistrado', veiculoRegistrado);
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'numeroRegistro', numRegistro);
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'marcaVeiculo', idMarca);
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'valorMaximoCarregamento', valorMaxCarregamnto);
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'valorMaximoVeiculo', valorMaxVeiculo);
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'deslocacaoComercial', usoDescolacaoComer);
   PRC_ADD_LISTVALUE(parsValues, idSuper, 'possibilidadeTranca', possTranca);
   
   PACK_REGRAS.REGOBJECTVALUES(ID_USER, null, ID_CONTRATO, 9, parsValues);
   
   RETURN 'true';
END;