create trigger TG_POS_REG_MOVIMENT
	after insert
	on T_MOVIMENT
	for each row
DECLARE 
   idType NUMBER := :NEW.MOV_TMOV_ID;
   idSource NUMBER := :NEW.MOV_COUNT_SOURCE;
   idDest NUMBER := :NEW.MOV_COUNT_DESTINATION;
BEGIN
    -- Validar os parametros estejam validos
    -- Se os parametros nao for bem definido então criar uma execessao na triger
    IF (idType = 3 AND (idSource IS NULL OR idDest IS NULL))
        OR (idType = 2 AND idSource IS NULL )-- OPERACAO DO CREDITO
        OR (idType = 1 AND idDest IS NULL) --OPERACAO DO DEBITO
    THEN
        -- Lançar uma exção para impedir que a transação seja feita
       raise_application_error (-20100, 'Movimentação invalida');
    END IF;

  
    -- Se for definido a conta da saida do dinheiro entao diminuir o saldo da conta e aumentar o valor da debeto da conta
    -- SIGUNIFICA QUE É UM LEVANTAMENTO OU UMA TRANSFERECIA VINDA DE ESSDA CONTA 
    IF :NEW.MOV_COUNT_SOURCE IS NOT NULL THEN
       UPDATE T_ACCOUNT AC
          SET AC.COUNT_SALDO = AC.COUNT_SALDO - :NEW.MOV_VALOR,
              AC.COUNT_CREDITO = AC.COUNT_CREDITO + :NEW.MOV_VALOR
          WHERE AC.COUNT_ID = :NEW.MOV_COUNT_SOURCE;
    END IF;
    
    -- Quando for informadao a conta da entrada do dinheiro então aumentar o saldo a conta e aumentar o valor de credito da conta
    -- SIGUNIFICA QUE É UM DEPOSITO OU UMA TRASFERECIA PARA ESSA CONTA
    IF :NEW.MOV_COUNT_DESTINATION IS NOT NULL THEN
       UPDATE T_ACCOUNT AC
          SET AC.COUNT_SALDO = AC.COUNT_SALDO + :NEW.MOV_ACCOUNTVALUE,
              AC.COUNT_DEBITO = AC.COUNT_DEBITO + :NEW.MOV_ACCOUNTVALUE
          WHERE AC.COUNT_ID = :NEW.MOV_COUNT_DESTINATION;
    END IF;
END;