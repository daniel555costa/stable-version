create FUNCTION FUNC_CTTINF_ACIDENTEGRUPO 
(
    userId NUMBER,
    idContrato NUMBER,
    idCobertura NUMBER
    /* ID COBERTURA
      17  Durante 24 Horas
      18  Apenas em situação de acidente de trabalho
    */
)
RETURN VARCHAR2
IS
BEGIN
    -- Essa funcao serve para criar um objecto do tipo ctt_viagem publica e armazenala na entidade contrato
    PRC_REG_COBERTURACONTRATO(idCobertura, idContrato, userId, null, null, null);
    RETURN 'true';
END FUNC_CTTINF_ACIDENTEGRUPO;