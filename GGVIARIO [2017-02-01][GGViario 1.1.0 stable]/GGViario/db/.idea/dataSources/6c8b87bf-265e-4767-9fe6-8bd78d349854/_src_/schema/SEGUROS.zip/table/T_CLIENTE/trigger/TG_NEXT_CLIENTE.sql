create trigger TG_NEXT_CLIENTE
	before insert
	on T_CLIENTE
	for each row
begin  
   if inserting then 
      if :NEW."CLI_ID" is null then 
         select SEQ_CLIENTE.nextval into :NEW."CLI_ID" from dual; 
      end if; 
   end if; 
end;