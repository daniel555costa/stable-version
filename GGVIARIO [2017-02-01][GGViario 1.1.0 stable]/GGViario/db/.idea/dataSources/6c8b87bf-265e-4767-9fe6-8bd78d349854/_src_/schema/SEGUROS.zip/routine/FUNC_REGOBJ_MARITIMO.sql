create FUNCTION "FUNC_REGOBJ_MARITIMO" 
(
    USER_ID NUMBER,
    ID_CONTRATO VARCHAR,
    BANDEIRA_DO_NAVIO VARCHAR2,
    USO_NAVIO VARCHAR2,
    CLASSE_ESTATUTO_RENOVACAO VARCHAR2,
    POTENCIA_MOTOR VARCHAR2,
    TIPO_COMBUSTIVEL VARCHAR2,
    QUANTIDADE_PESO FLOAT,
    NUMERO_MOTOR VARCHAR2,
    MARCA_MOTOR VARCHAR2, 
    NUMERO_TRIPULANTE NUMBER,
    NOME_NAVIO VARCHAR2,
    MARCA_MODELO VARCHAR2,
    NUMERO_CHASSI VARCHAR2,
    IDADE_NAVIO number,
    TIPO_NAVIO VARCHAR2,
    EXPERIENCIA_RECLAMACAO VARCHAR2, 
    NAVEGACAO_INSTALADA VARCHAR2,
    AREA_OPERACAO  VARCHAR2,
    TIPO_CONSTRUCAO_NAVIO VARCHAR2,
    CONDICAO_NAVIO VARCHAR2,
    COBERTURAS TB_ARRAY_STRING
)


RETURN VARCHAR2
IS 
    
  res PACK_TYPE.Resultado;
  idCobertura NUMBER;
  valor FLOAT;
  taxa FLOAT;
  premio FLOAT;
  arraySplit TB_ARRAY_STRING;
  --	id; Taxa(%); Valor;  Prémio
  message VARCHAR2(2000) := '';
  

   parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
BEGIN

-- Essa funcao serve para criar um objecto do tipo ctt_responsabilidade publica e armazenala na entidade contrato
 IF COBERTURAS.COUNT >0 THEN
      res := PACK_REGRAS.REG_OBJECTO(USER_ID , ID_CONTRATO , 235, 1);
    
    PRC_ADD_LISTVALUE(parsValues, null, 'bandeiraNavio', BANDEIRA_DO_NAVIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'usoNavio', USO_NAVIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'classeEstruturaRenovacao', CLASSE_ESTATUTO_RENOVACAO);
    
    PRC_ADD_LISTVALUE(parsValues, null, 'potenciaMotor', POTENCIA_MOTOR);
    PRC_ADD_LISTVALUE(parsValues, null, 'tipoCombustivel', TIPO_COMBUSTIVEL);
    PRC_ADD_LISTVALUE(parsValues, null, 'quantidadePeso', QUANTIDADE_PESO);
    
                                              
    PRC_ADD_LISTVALUE(parsValues, null, 'numeroMotor', NUMERO_MOTOR);
    PRC_ADD_LISTVALUE(parsValues, null, 'marcaMotor', MARCA_MOTOR);
    PRC_ADD_LISTVALUE(parsValues, null, 'numeroTripulantes', NUMERO_TRIPULANTE);
    
    
    PRC_ADD_LISTVALUE(parsValues, null, 'nomeNavio', NOME_NAVIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'marcaModeloNavio', MARCA_MODELO);
    PRC_ADD_LISTVALUE(parsValues, null, 'numeroChassi', NUMERO_CHASSI);
    
    PRC_ADD_LISTVALUE(parsValues, null, 'idadeNavio', IDADE_NAVIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'tipoNavio', TIPO_NAVIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'experienciaRenovacao', EXPERIENCIA_RECLAMACAO);
    
    PRC_ADD_LISTVALUE(parsValues, null, 'navegacaoInstalada', NAVEGACAO_INSTALADA);
    PRC_ADD_LISTVALUE(parsValues, null, 'arreaOperacao', AREA_OPERACAO);
    PRC_ADD_LISTVALUE(parsValues, null, 'tipoCombustivel', TIPO_CONSTRUCAO_NAVIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'idadeNavio', IDADE_NAVIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'tipoNavio', TIPO_NAVIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'condicaoNavio', CONDICAO_NAVIO);
    
    
    PACK_REGRAS.REGOBJECTVALUES(USER_ID, res.resultado, null, 15, parsValues);
   
        
      /*
       
        Isso esta comentado porq essa parte de codig sera registrada directamente da aplicação 
        
        FOR I IN 1 .. COBERTURAS.COUNT LOOP
        arraySplit := PACK_LIB.SPLITALL(COBERTURAS(i), ';');
        
        idCobertura := arraySplit(1);
        taxa := arraySplit(2);
        valor := arraySplit(3);
        premio := arraySplit(4);
        message := message || 'COBERTURA ID = '||idCobertura || '; TAXA = '||taxa || ' valor = '||valor|| ' PREMIO = '||premio||NL;
        INSERT INTO T_COBERTURASEGURADO(COBREASE_CTT_ID,
                                        COBREASE_USER_ID,
                                        COBREASE_COBRE_ID,
                                        COBREASE_TAXA,
                                        COBREASE_VALOR,
                                        COBREASE_PREMIO
                                        )
                                        VALUES(ID_CONTRATO,
                                               USER_ID,
                                               idCobertura,
                                               taxa,
                                               valor,
                                               premio);
                                               
                                               
      END LOOP;*/
      -- RETURN message;
      -- message := 'DATA BASE RESULT  TOTAL COBERTURAS = '||COBERTURAS.COUNT|| 'MESAGE = '|| message;
      RETURN 'true';
  END IF;
  RETURN 'Nenhuma cubertura selecionada';
END ;