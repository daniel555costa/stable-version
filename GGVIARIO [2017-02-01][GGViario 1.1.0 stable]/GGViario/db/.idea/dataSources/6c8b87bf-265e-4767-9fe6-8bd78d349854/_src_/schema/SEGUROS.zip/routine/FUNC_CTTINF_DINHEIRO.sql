create FUNCTION FUNC_CTTINF_DINHEIRO 
(
  idUser NUMBER,
  idContrato NUMBER,
  distanciaBanco VARCHAR2,
  distanciaCoreio VARCHAR2,
  distanciaOutra VARCHAR2,
  
  transpDinheiro VARCHAR2,
  preocupacao VARCHAR2,
  tempoPermanencio VARCHAR2,
  dinheiroPaga CHAR,-- {Y - Sim  | N- Nao}
  idCobertura NUMBER,
  limite FLOAT,
  valorPremio FLOAT
)
RETURN VARCHAR2
IS
   resp VARCHAR2(10);
   parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
BEGIN
    PRC_ADD_LISTVALUE(parsValues, null, 'distanciaBanco', distanciaBanco);
    PRC_ADD_LISTVALUE(parsValues, null, 'distanciaCoreio', distanciaCoreio);
    PRC_ADD_LISTVALUE(parsValues, null, 'distanciaOutra', distanciaOutra);
    PRC_ADD_LISTVALUE(parsValues, null, 'transpDinheiro', transpDinheiro );
    PRC_ADD_LISTVALUE(parsValues, null, 'preocupacao', preocupacao);
    PRC_ADD_LISTVALUE(parsValues, null, 'tempoPermanencio', tempoPermanencio);
    PRC_ADD_LISTVALUE(parsValues, null, 'dinheiroPagoRecepcao', dinheiroPaga);
    
    PACK_REGRAS.REGOBJECTVALUES(idUser, null, idContrato, 11, parsValues);
                                   
  resp := FUNC_REG_COBERTURAASEGURADO(idUser, idContrato, null, idCobertura, null, limite, valorPremio, null);
                                   
  
  RETURN 'true';
END;