create trigger TG_NEXT_EMPRESA
	before insert
	on T_EMPRESA
	for each row
begin  
   if inserting then 
      if :NEW."EMP_ID" is null then 
         select SEQ_EMPRESA.nextval into :NEW."EMP_ID" from dual; 
      end if; 
   end if; 
end;