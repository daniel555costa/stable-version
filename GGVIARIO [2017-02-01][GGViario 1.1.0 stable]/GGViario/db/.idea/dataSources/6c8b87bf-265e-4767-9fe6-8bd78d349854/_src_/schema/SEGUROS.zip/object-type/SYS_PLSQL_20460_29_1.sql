create type           SYS_PLSQL_20460_29_1 as object ("ID" NUMBER(3),
"NOME" VARCHAR2(60),
"CODIGO" VARCHAR2(10));