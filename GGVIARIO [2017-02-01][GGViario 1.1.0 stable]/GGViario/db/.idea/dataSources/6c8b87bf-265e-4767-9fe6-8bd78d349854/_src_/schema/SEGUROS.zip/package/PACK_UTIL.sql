create PACKAGE PACK_UTIL IS

    FUNCTION FUNC_ACTIVADESACTIVA_CATEGORIA (NOME VARCHAR2,
                                          USER_ID VARCHAR2
                                          ) RETURN VARCHAR2;
                              
    FUNCTION FUNC_ACTDESACT_COBERTURA (ID_CONTRATO NUMBER,
                                    identificacao_segurado NUMBER,
                                    USER_ID NUMBER
                                    )RETURN VARCHAR2;

    FUNCTION FUNC_ACTDESACT_DEPENDENTE(USER_ID NUMBER,
                                    ID_DEP VARCHAR2
                                    )RETURN VARCHAR2;

   /* FUNCTION FUNC_ACTDESACT_EMPRESA( idEmpresa number,
                                  user_id VARCHAR2
                                  )RETURN VARCHAR2;
*/

    FUNCTION FUNC_ACTIVADESACTIVA_CONTA(NIB VARCHAR2,
                                    USER_ID VARCHAR2
                                    )RETURN VARCHAR2;
                   
                   
    FUNCTION FUNC_ACTIVADESACTIVA_BANK (sigla VARCHAR2,
                                        USER_ID VARCHAR2
                                        )RETURN VARCHAR2;
                    
                    
                    
    FUNCTION FUNC_ACTIVADESATIVA_PAIS(idUser NUMBER,
                                       idPais NUMBER
                                      )RETURN VARCHAR2;
              
              
              
    FUNCTION FUNC_ACTIVARDESATIVAR_PERGUNTA (USER_ID NUMBER,
                                          ID_PERGUNTA NUMBER
                                          )RETURN VARCHAR2;
            
            
                                        
    FUNCTION FUNC_ACTIVADESACTIVA_MOEDA(idUtilizador NUMBER,
                                        ID_MOE NUMBER 
                                        )RETURN VARCHAR2;
    
    
    
    
    PROCEDURE PRC_REG_OBJECTYPE(ID_USER  NUMBER,
                            ID_SUPER NUMBER ,
                            DESC_OBJT VARCHAR,
                            ID_TYPE NUMBER);
                            
    PROCEDURE PRC_DISABLE_OBJECTYPE (idUser NUMBER, idobjtdisable  NUMBER);
    
    
    procedure prc_update_informacao (idInformacao NUMBER, idUser NUMBER, idCobertura NUMBER, textInformacao VARCHAR2);
    
    -- 
    procedure prc_disableEnpresa (idUser NUMBER, idEmpresa NUMBER);
    
    
    
    
    
    Function FUNC_ALTERAPRECARIO( precsegid number,
                                  precuserid number,
                                  precdiamini number,
                                  precdiamax number,
                                  total float,
                                  precpremiAlterar float
                                ) Return VARCHAR2;
                                
                                
    FUNCTION FUNC_SET_TAXA (nomeMoedaBase CHARACTER VARYING, moneyName VARCHAR2, idUser NUMBER, valorCompra FLOAT, valorVenda FLOAT) RETURN VARCHAR2;
    
    
END;