create view VER_MOEDA as
SELECT M.ID,
       M.MOEDA,
       M.SIGLA
  FROM VER_ADM_MOEDA M
  WHERE M.ESTADO = 1
  order by M.MOEDA desc
