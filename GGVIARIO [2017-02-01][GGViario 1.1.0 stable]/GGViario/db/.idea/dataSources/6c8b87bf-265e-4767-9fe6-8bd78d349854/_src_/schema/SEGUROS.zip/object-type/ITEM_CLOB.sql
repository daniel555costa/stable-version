create TYPE ITEM_CLOB UNDER ITEM(

  value CLOB
  
)