create PROCEDURE PRC_ERROR 
(
   COD VARCHAR2,
   SOURCE_ERROR VARCHAR2,
   MSG VARCHAR2
)
IS
   ERROR_TEXT  VARCHAR2(4000) := NULL;
   TT NUMBER;
BEGIN
   SELECT COUNT(*) INTO TT
      FROM T_MESSAGERROR ME
      WHERE UPPER(ME.MSG_COD) =UPPER(COD);
      
  IF TT = 0 THEN 
      INSERT INTO T_MESSAGERROR(MSG_COD,
                                MSG_SOURCE,
                                MSG_TEXT)
                                VALUES (COD,
                                        SOURCE_ERROR,
                                        MSG);
  ELSE 
     raise_application_error( -20000, 'O codigo definido ja existe');
  END IF; 
END;