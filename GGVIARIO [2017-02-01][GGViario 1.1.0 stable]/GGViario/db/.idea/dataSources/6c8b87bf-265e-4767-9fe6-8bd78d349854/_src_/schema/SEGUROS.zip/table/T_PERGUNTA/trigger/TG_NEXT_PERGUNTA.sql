create trigger TG_NEXT_PERGUNTA
	before insert
	on T_PERGUNTA
	for each row
begin  
   if inserting then 
      if :NEW."PER_ID" is null then 
         select SEQ_PERGUNTA.nextval into :NEW."PER_ID" from dual; 
      end if; 
   end if; 
end;