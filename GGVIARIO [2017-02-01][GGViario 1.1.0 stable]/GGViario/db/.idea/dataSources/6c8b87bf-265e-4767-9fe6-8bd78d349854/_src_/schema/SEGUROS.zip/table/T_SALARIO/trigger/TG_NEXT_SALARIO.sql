create trigger TG_NEXT_SALARIO
	before insert
	on T_SALARIO
	for each row
begin  
   if inserting then 
      if :NEW."SAL_ID" is null then 
         select SEQ_SALARIO.nextval into :NEW."SAL_ID" from dual; 
      end if; 
   end if; 
end;