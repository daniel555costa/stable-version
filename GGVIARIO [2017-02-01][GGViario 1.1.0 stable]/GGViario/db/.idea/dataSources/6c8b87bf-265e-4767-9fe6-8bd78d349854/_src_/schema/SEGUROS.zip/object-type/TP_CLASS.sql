create TYPE TP_CLASS AS OBJECT
(

   content Bundle,
   
    --Start by object or contract
    CONSTRUCTOR FUNCTION TP_CLASS(idObjetc NUMBER, idContrato NUMBER) RETURN SELF AS RESULT,
    
    MEMBER PROCEDURE loadDatas (SELF IN OUT TP_CLASS, idObjetc NUMBER, idContrato NUMBER),
    
    MEMBER PROCEDURE onRestore(content BUNDLE)
) NOT FINAL