create trigger TG_NEXT_SITUACAOFAMILIAR
	before insert
	on T_SITUACAOFAMILIAR
	for each row
begin  
   if inserting then 
      if :NEW."SITUA_ID" is null then 
         select SEQ_SITUACAOFAMILIAR.nextval into :NEW."SITUA_ID" from dual; 
      end if; 
   end if; 
end;