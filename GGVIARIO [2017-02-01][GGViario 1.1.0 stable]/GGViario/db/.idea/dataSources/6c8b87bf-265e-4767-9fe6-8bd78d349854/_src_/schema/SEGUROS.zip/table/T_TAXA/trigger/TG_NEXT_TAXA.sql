create trigger TG_NEXT_TAXA
	before insert
	on T_TAXA
	for each row
begin  
   if inserting then 
      if :NEW."TX_ID" is null then 
         select SEQ_TAXA.nextval into :NEW."TX_ID" from dual; 
      end if; 
   end if; 
end;