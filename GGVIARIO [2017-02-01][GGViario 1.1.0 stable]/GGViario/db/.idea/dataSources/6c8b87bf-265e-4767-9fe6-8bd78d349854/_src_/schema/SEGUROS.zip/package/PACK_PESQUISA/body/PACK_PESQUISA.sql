create PACKAGE BODY PACK_PESQUISA IS

  FUNCTION pesqClienteCampo(CAMPO VARCHAR,VALOR VARCHAR) return PACK_TYPE.filterCliente PIPELINED IS
     resTab PACK_TYPE.filterCliente;
     pesquisa VARCHAR2 (1000) := 'SELECT * FROM VER_CLIENTE WHERE PACK_LIB.NO_ACCENT_UPPER('||CAMPO||') LIKE PACK_LIB.NO_ACCENT_UPPER(:VAL)';
  BEGIN
     IF CAMPO = 'APOLICE' THEN 
        pesquisa := 'SELECT CL.*
                         FROM VER_CLIENTE CL
                            INNER JOIN T_APOLICE AP ON (CL.ID = AP.APOLICE_CLI_ID)
                         WHERE PACK_LIB.NO_ACCENT_UPPER(APOLICE_NUMERO) LIKE PACK_LIB.NO_ACCENT_UPPER(:VAL)';
     END IF;
     EXECUTE IMMEDIATE pesquisa bulk collect into resTab USING IN '%'||valor||'%';
     
     FOR i IN 1..resTab.COUNT LOOP
        PIPE ROW(resTab(i));
     END LOOP;
  END pesqClienteCampo;
  
  
  FUNCTION 
  
  pesqContrato return PACK_TYPE.filterContrato PIPELINED
  IS
  BEGIN
     FOR I IN (SELECT * FROM VER_CONTRATO I ) LOOP
        PIPE ROW (I);
     END LOOP;
  END;
  
  
  FUNCTION pesqContratoSeguro(codSeguro VARCHAR2) RETURN PACK_TYPE.filterContrato PIPELINED
  IS
  BEGIN
     FOR I IN(SELECT I.*
                 FROM VER_CONTRATO I 
                 WHERE I.SEGURO = codSeguro) LOOP
        PIPE ROW(I);
     END LOOP;
  END;
  
  
  
  FUNCTION pesqContratoGold(quantidade NUMBER)  RETURN PACK_TYPE.filterContrato PIPELINED
  IS
  BEGIN
     FOR I IN (SELECT * 
                  FROM (SELECT I.* 
                            FROM VER_CONTRATO I
                                INNER JOIN T_CONTRATO CT ON I.ID = CT.CTT_ID
                                INNER JOIN TABLE(PACK_CONTA.GETTAXADAY(CT.CTT_DTREG, CT.CTT_MOE_ID)) TAX ON 1 = 1
                            ORDER BY (LIQUIDOSF * TAX.TX_VENDA) DESC) 
                  WHERE ROWNUM <= quantidade) LOOP
        PIPE ROW (I);
     END LOOP;
  END;
  
  -- 
  FUNCTION pesqContratoType(typePesquisa CHARACTER VARYING)  RETURN PACK_TYPE.filterContrato PIPELINED
  IS
  BEGIN
     CASE
        -- Carregar os contratos atrasados quando o tipo igual a GOLD
        WHEN typePesquisa = 'ATRASADO' THEN 
           FOR R IN (SELECT CT.* 
                        FROM VER_CONTRATO CT 
                           INNER JOIN T_CONTRATO CCT ON CCT.CTT_ID = CT."ID" 
                      WHERE CCT.CTT_DTFIM < SYSDATE 
                        AND CCT.CTT_PAYSTATE != 0)
           LOOP
              PIPE ROW(R);
           END LOOP;
           
        -- Quando for para ordernar dos mais caros aos mais baratos
        WHEN typePesquisa = 'MCARO' THEN
           FOR R IN (SELECT CT.* 
                        FROM VER_CONTRATO CT 
                           INNER JOIN T_CONTRATO CCT ON CCT.CTT_ID = CT."ID" 
                        ORDER BY CCT.CTT_VPAGAR DESC)
           LOOP
              PIPE ROW(R);
           END LOOP;
           
        -- Quando o tipo pesquisa for ouro
        WHEN typePesquisa = 'GOLD' THEN 
           FOR I IN (SELECT * 
                        FROM(SELECT * 
                                FROM VER_CONTRATO 
                                ORDER BY LIQUIDOSF 
                                DESC) I 
                        WHERE ROWNUM <= 10) LOOP
              PIPE ROW (I);
           END LOOP;
        
        -- Quando o tipo for todos pagos
        WHEN typePesquisa = 'TPAGOS' THEN 
           FOR R IN (SELECT CT.* 
                        FROM VER_CONTRATO CT 
                           INNER JOIN T_CONTRATO CCT ON CCT.CTT_ID = CT."ID" 
                        WHERE CCT.CTT_PAYSTATE = 0)
           LOOP
              PIPE ROW(R);
           END LOOP;
      END CASE;
  END;
  
  

  
  
  
  FUNCTION pesqContratoCliente (idCliente NUMBER) RETURN PACK_TYPE.filterContratoCliente PIPELINED
  IS
  BEGIN
      FOR I IN (SELECT * FROM  VER_CONTRATO_CLIENTE I WHERE I.CLIENTE = idCliente) LOOP
         PIPE ROW(I);
      END LOOP;
  END;
  
  
  -- Pesquisar todos os contratos que um cliente tem em um dado seguro
  FUNCTION pesqContratoClineteSeguro(idCliente NUMBER, idSeguro NUMBER) RETURN PACK_TYPE.filterContratoCliente PIPELINED
  IS
     
  BEGIN
      FOR I IN (SELECT * 
                  FROM  VER_CONTRATO_CLIENTE I 
                  WHERE I.CLIENTE = idCliente
                    AND I.ID_SEGURO = idSeguro) LOOP
         PIPE ROW(I);
      END LOOP;
  END;
  
  
  
  -- Para eliminar X XXXXXXXXXXXXXXXX NELE
  FUNCTION pesqContrato(tipo VARCHAR2, CAMPO VARCHAR,VALOR VARCHAR) return PACK_TYPE.filterContrato PIPELINED
  IS
     resTab PACK_TYPE.filterContrato;
     pesquisa VARCHAR2 (1000) ;
     valorUsar VARCHAR2(4000);
  BEGIN
     -- MCARO > Corresponde ao mais carro
     -- 
     pesquisa := (CASE
                    WHEN UPPER(tipo) = 'CAMPO' AND CAMPO IS NOT NULL  THEN 'SELECT * FROM VER_CONTRATO WHERE UPPER("'||CAMPO||'") LIKE UPPER(:VAL)'
                    -- WHEN UPPER(tipo) = 'GOLD' THEN ''||valor
                    WHEN UPPER(tipo)  = 'SEGURO' AND VALOR IS NOT NULL THEN 'SELECT * FROM VER_CONTRATO WHERE UPPER(SEGURO) = UPPER(:VAL)'
                    WHEN UPPER(tipo) = 'MCARO' THEN 'SELECT * FROM VER_CONTRATO ORDER BY LIQUIDOSF DESC'
                    WHEN UPPER(tipo) = 'ATRASO' THEN 'SELECT CT.* FROM VER_CONTRATO CT INNER JOIN T_CONTRATO CCT ON CCT.CTT_ID = CT."ID" WHERE CT.CTT_DTFIM < SYSDATE AND CT.CTT_STATE != 0'
                    ELSE  'SELECT * FROM VER_CONTRATO'
                  END);
                  
     IF valor IS NULL OR UPPER(tipo) IN ( 'GOLD', 'MCARO', 'ATRASO') THEN
        EXECUTE IMMEDIATE pesquisa bulk collect into resTab;
     ELSE
        valorUsar := (CASE
                        WHEN UPPER(tipo)  = 'CAMPO' THEN '%'||valor||'%'
                        ELSE valor
                     END);
        EXECUTE IMMEDIATE pesquisa bulk collect into resTab USING IN valorUsar;
     END IF;
     
     FOR i IN 1..resTab.COUNT LOOP
        PIPE ROW(resTab(i));
     END LOOP;
     
     EXCEPTION 
        WHEN OTHERS THEN
           resTab.EXTEND; --SQLERRM
           resTab(resTab.COUNT)."PREMIO BRUTO" := 'ERROR: '||SQLERRM;
           resTab(resTab.COUNT)."DATA INICIO" := 'LINHA: '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
           resTab(resTab.COUNT).CLIENTE := pesquisa || ' | VAL = '||valorUsar  || ' | CAMPO = '|| CAMPO;
           PIPE ROW (resTab(resTab.COUNT));
        
  END;
  
  
  
  FUNCTION pesqStateClienteSeguro (ID_CLIENTE NUMBER, ID_SEGURO NUMBER) RETURN PACK_TYPE.InformacaoUtilCliente PIPELINED
  IS
  BEGIN
    FOR CLI IN (SELECT * FROM VER_STATUS_CLIENTE CLI WHERE CLI.ID = ID_CLIENTE) LOOP
      SELECT COUNT(*) INTO CLI."TOTAL IN SEGURO"
        FROM T_CONTRATO CT
        WHERE CT.CTT_SEG_ID = ID_SEGURO
          AND CT.CTT_CLI_ID = ID_CLIENTE;
      PIPE ROW(CLI);
    END LOOP;
  END;
  
  
  
  FUNCTION pesqClienteBySeguro (ID_SEGURO NUMBER) RETURN PACK_TYPE.filterCliente PIPELINED 
  IS
  BEGIN
     FOR CLI IN (SELECT * 
                    FROM VER_CLIENTE CT 
                    WHERE CT.ID IN (SELECT CCT.CTT_CLI_ID
                                      FROM T_CONTRATO CCT
                                      WHERE CCT.CTT_SEG_ID  = ID_SEGURO))  LOOP
        PIPE ROW(CLI);
    END LOOP;
  END;
  
  
  
  FUNCTION pesqClienteByColumn (columnName VARCHAR2, columnValues VARCHAR2) RETURN PACK_TYPE.filterCliente PIPELINED
  IS
    sqlQuery VARCHAR(4000) := 'SELECT * FROM VER_CLIENTE WHERE UPPER('||columnName||') LIKE UPPER(:VAL) ORDER BY NOME ASC';
    resTab PACK_TYPE.filterCliente;
  BEGIN
     EXECUTE IMMEDIATE sqlQuery bulk collect into resTab USING IN '%'||columnValues||'%';
     FOR i IN 1..resTab.COUNT LOOP
        PIPE ROW(resTab(i));
     END LOOP;
  END;
  
  
  
  FUNCTION loadModelo (nomeMarca VARCHAR2) RETURN PACK_TYPE.filterModelo PIPELINED
  IS
  BEGIN
     FOR I IN(SELECT *
                 FROM VER_VEICULO_MODELO VM
                 WHERE UPPER(VM.MARCA) = UPPER(CASE WHEN nomeMarca IS NULL THEN VM.MARCA  ELSE nomeMarca END ))
     LOOP
         PIPE ROW(I);
     END LOOP;
  END;
  
  FUNCTION getFrequenteSeguroCliente(idCliente NUMBER) RETURN VARCHAR2
  IS
     nomeSeguro VARCHAR(60);
  BEGIN
     SELECT HH.SEG_NOME INTO nomeSeguro
      FROM (SELECT  SE.SEG_NOME, COUNT(*) AS HHK
               FROM T_CONTRATO CT
                  INNER JOIN T_SEGURO SE ON SE.SEG_ID = CTT_SEG_ID
               WHERE CTT_CLI_ID = idCliente
               GROUP BY SE.SEG_NOME
               ORDER BY HHK DESC ) HH
      WHERE ROWNUM <= 1;
      
      RETURN nomeSeguro;
  END;
  
  
  FUNCTION reportClient (dataInicio DATE, dataFim DATE) RETURN PACK_TYPE.filterReportClient PIPELINED
  IS
  BEGIN
      NULL;
  END;
  
  
  
  FUNCTION pesqcontratoinformacao (IDCTT NUMBER) RETURN PACK_TYPE.filtercontratoinformacao PIPELINED
  IS
  
  /* TYPE contratoinformacao IS RECORD (" APOLICE"VARCHAR(30),"DATA INICIO" DATE ,"DATA FIM" DATE,"CLIENTE" NUMBER,
  "VALOR SEGURADO " FLOAT ,"VALOR PREMIO BRUTO" FLOAT,"VALOR EXCESSO" FLOAT,"ESTADO CONTRATO" NUMBER,"ESTADO PAGAMENTO"NUMBER);
    TYPE  filtercontratoinformacao IS TABLE OF contratoinformacao; */
  
   BEGIN
        FOR I IN (SELECT 
                        CTT_NUMAPOLICE,
                        CTT_DTINICIO,
                        CTT_DTFIM,
                        CTT_CLI_ID
                        CTT_VTTSEGURADO,
                        CTT_PBRUTO,
                        CTT_EXCESSO,
                        CTT_STATE,
                        CTT_PAYSTATE
                        FROM T_CONTRATO
                           WHERE CTT_ID  = IDCTT ) 
        
        LOOP                     
          --PIPE ROW (I);
          NULL;
      END LOOP;  
                
   END;
   
   
   FUNCTION functLoadAtributoSegurado(idClassType NUMBER, atributeNameRequest CHARACTER VARYING)RETURN TB_ARRAY_STRING PIPELINED
   IS
   BEGIN
      FOR I IN (SELECT DISTINCT VAL.OBJVALL_VALUE AS "TIPO"
                   FROM T_OBJCLASSATTRIBUTE ATB
                      INNER JOIN T_OBJECTVALUE VAL ON ATB.CLASSATB_ID = VAL.OBJVALL_CLASSATB_ID
                   WHERE ATB.CLASSATB_CLASS_ID = idClassType
                      AND ATB.CLASSATB_NAME = atributeNameRequest)
      LOOP
         PIPE ROW (I."TIPO");
      END LOOP;
   END;
   
   
   
    FUNCTION functLoadObjectByAttribute (idClassObject NUMBER, attributeName VARCHAR2, valueObject VARCHAR2) RETURN PACK_PESQUISA.HasMap PIPELINED
    IS
       TYPE ListNumber IS TABLE OF NUMBER;
       lista ListNumber := ListNumber();
       item PACK_PESQUISA.ItemPar;
    BEGIN
        -- Efectuar uma busca para carregar o objecto da classe que possui o id com o valor fornecido para o atributo fornecido
        SELECT 
            OV."ID OBJECTO" BULK COLLECT INTO lista
           FROM MVER_OBJECT_VALUES OV
           WHERE OV.ATRIBUTO = attributeName
              AND OV.VALUE = valueObject
              AND OV.CLASSE = idClassObject;
              
       

        FOR I IN 1..lista.COUNT LOOP
          item."KEY" := 'OBJECT.ID';
          item."VALUE":= lista(I);
          PIPE ROW(item);
          
          -- 0 | - TEXT | 1 - VARCHAR | 2 - NUMBER | 3 - FLOAT | 4 - DATE | 5 - TIMESTAMP
          -- O OBJ.* e o valor que contem o id do objecto
          FOR OV IN (SELECT *
                       FROM MVER_OBJECT_VALUES OV
                       WHERE OV."ID OBJECTO" = lista(I))
          LOOP
             item."KEY" := OV.ATRIBUTO;
             item."VALUE" := OV.VALUE;
             item."ID VALUE" := OV.VALUE;
             
              -- Se o valor estiver sendo referenciado da ourtra entiade entao efectuar a buscao do real valor na entidade referenciada
             IF OV."TABLE ORIGIN" IS NOT NULL 
                AND OV."TABLE ID" IS NOT NULL
                AND OV."TABLE VALUE" IS NOT NULL
             THEN 
                item."VALUE" := PACK_LIB.GETVALL(OV."TABLE ORIGIN", OV."TABLE ID", OV."TABLE VALUE", OV.VALUE, '=', 1);
             END IF;
             PIPE ROW(item);
             
          END LOOP;
       END LOOP;
    END;
END PACK_PESQUISA;