create TYPE BODY BUNDLE AS

  CONSTRUCTOR FUNCTION BUNDLE RETURN SELF AS RESULT AS
  BEGIN
    SELF.items := BUNDLE_LIST();
    SELF.FMT_DATE := 'YYYY-MM-DD';
    SELF.FMT_TIMESTAMP := 'YYYY-MM-DD HH:MI:SS FF3';
    RETURN;
  END BUNDLE;
  
  MAP MEMBER FUNCTION to_string RETURN CHARACTER VARYING AS
  BEGIN
     RETURN 'Bundel{}';
  END;

  MEMBER PROCEDURE put(SELF IN OUT BUNDLE, key CHARACTER VARYING, value CHARACTER VARYING) AS
     item BUNDLE_ITEM;
  BEGIN
    IF NOT contains(key) THEN 
       item := BUNDLE_ITEM(key, value);
       SELF.items.extend;
       SELF.items(items.count) := item;
       SELF.items(items.count).key := key;
       SELF.items(items.count).value := value;
    END IF;
  END put;

  MEMBER FUNCTION get(key CHARACTER VARYING) RETURN CHARACTER VARYING AS
     position NUMBER;
     item BUNDLE_ITEM;
  BEGIN
     -- Obter a primeira posicao
     position := SELF.items.FIRST;
     
     -- Percore por todas as posicoes proucurando pela posicao onde o item tem o valor fornecido
     WHILE 
        position IS NOT NULL 
     LOOP
        IF SELF.items(position).key = key THEN RETURN SELF.items(position).value; END IF;
        position := SELF.items.next(position);
     END LOOP;
     RETURN NULL;
  END get;
  
  
   MEMBER FUNCTION index_of(key CHARACTER VARYING) RETURN NUMBER AS
      i_index NUMBER;
   BEGIN
      i_index := SELF.items.FIRST;
      WHILE(i_index IS NOT NULL) LOOP
         IF (items(i_index).key = key) THEN RETURN i_index; END IF;
         i_index := items.next(i_index);
      END LOOP;
      RETURN i_index;
   END index_of;
  
   MEMBER FUNCTION asnumber(key CHARACTER VARYING) RETURN NUMBER AS 
     FMT  CHARACTER VARYING(1024):= '99999999999999999999999999999999999999D999999999999999999999999';
     value CHARACTER VARYING (4000);
     number_value NUMBER;
   BEGIN
     IF SELF.FMT_NUMBER IS NOT NULL THEN
        FMT := SELF.FMT_NUMBER;
     END IF;
     value := get(key);
     --RETURN value;
     number_value :=  TO_NUMBER(value, FMT);
     RETURN number_value;
   END;
   
   MEMBER FUNCTION asdate (key CHARACTER VARYING) RETURN DATE AS
      FMT CHARACTER VARYING(16) := 'YYYY-MM-DD';
      value CHARACTER VARYING(4000);
   BEGIN
      IF SELF.FMT_DATE IS NOT NULL THEN 
         FMT := SELF.FMT_DATE;
      END IF;
      value := get(key);
      RETURN TO_DATE(value, FMT);
   END;
  
  MEMBER FUNCTION astimestamp(key CHARACTER VARYING) RETURN TIMESTAMP AS
      FMT CHARACTER VARYING(32) := 'YYYY-MM-DD HH24:MI:SS FF3';
      value CHARACTER VARYING(4000);
      timestamp_value timestamp;
   BEGIN
      value := get(key);
      
      IF SELF.FMT_TIMESTAMP IS NOT NULL THEN 
          timestamp_value := TO_TIMESTAMP(value, 'YYYY-MM-DD HH24:MI:SS FF3');
      ELSE
         timestamp_value := TO_TIMESTAMP(value, SELF.FMT_TIMESTAMP);
      END IF;
      RETURN timestamp_value;
   END;

  MEMBER FUNCTION count RETURN NUMBER AS
  BEGIN
    RETURN items.count;
  END count;

  MEMBER FUNCTION remove(SELF IN OUT BUNDLE, key CHARACTER VARYING) RETURN CHARACTER VARYING AS
    i NUMBER;
    value CHARACTER VARYING(4000);
    last BOOLEAN;
    item BUNDLE_ITEM;
  BEGIN
    i := SELF.index_of(key);
    last := i = SELF.items.LAST;
    IF i IS NOT NULL THEN
       value := SELF.items(i).value;
       IF NOT last THEN
          item := SELF.items(SELF.items.LAST);
          SELF.items(i) := item;
       END IF;
       SELF.items.TRIM;
    END IF;
    RETURN value;
  END remove;

  MEMBER PROCEDURE clear(SELF IN OUT BUNDLE) AS
  BEGIN
     SELF.items.trim(SELF.count);
  END clear;

  MEMBER PROCEDURE replace(key CHARACTER VARYING, value CHARACTER VARYING) AS
     i_index NUMBER := SELF.index_of(key);
  BEGIN
     SELF.items(i_index).value := value;
  END replace;

  MEMBER FUNCTION contains(key CHARACTER VARYING) RETURN BOOLEAN AS
    i_count NUMBER;
  BEGIN
     RETURN SELF.index_of(key) IS NOT NULL;
  END contains;
  
  MEMBER FUNCTION isEmpty RETURN BOOLEAN AS
  BEGIN
     RETURN SELF.items.COUNT = 0;
  END;
  
  MEMBER PROCEDURE iterator(SELF IN OUT BUNDLE) AS
  BEGIN
     SELF.i_iterator := SELF.items.FIRST;
  END;
  
  MEMBER PROCEDURE iterator_end(SELF IN OUT BUNDLE) AS
  BEGIN
     SELF.i_iterator := SELF.items.LAST;
  END;
  
  MEMBER PROCEDURE iterator_in(iterator_index NUMBER) AS
  BEGIN
     IF iterator_index >= SELF.items.FIRST 
        AND iterator_index <= SELF.items.LAST THEN
        i_iterator := iterator_index;
     END IF;
  END iterator_in;
  
  MEMBER FUNCTION next(SELF IN OUT BUNDLE)  RETURN BUNDLE_ITEM AS
     item BUNDLE_ITEM := NULL;
  BEGIN
     IF SELF.i_iterator IS NOT NULL THEN 
        item := items(SELF.i_iterator);
        SELF.i_iterator := SELF.items.next(i_iterator);
     END IF;
     RETURN item;
  END;
  
  MEMBER FUNCTION preview(SELF IN OUT BUNDLE)  RETURN BUNDLE_ITEM AS
     item BUNDLE_ITEM;
     pre NUMBER;
  BEGIN
      IF SELF.i_iterator IS NOT NULL THEN 
        item := items(SELF.i_iterator);
        SELF.i_iterator := SELF.items.prior(i_iterator);
     END IF;
     RETURN item;
  END;
  
  MEMBER FUNCTION has_next RETURN BOOLEAN AS
  BEGIN
     RETURN SELF.i_iterator IS NOT NULL 
         AND i_iterator <=  SELF.items.LAST;
  END has_next;
  
  MEMBER FUNCTION has_preview RETURN BOOLEAN AS
  BEGIN
     RETURN SELF.i_iterator IS NOT NULL 
         AND i_iterator >= SELF.items.FIRST;
  END has_preview;
END;