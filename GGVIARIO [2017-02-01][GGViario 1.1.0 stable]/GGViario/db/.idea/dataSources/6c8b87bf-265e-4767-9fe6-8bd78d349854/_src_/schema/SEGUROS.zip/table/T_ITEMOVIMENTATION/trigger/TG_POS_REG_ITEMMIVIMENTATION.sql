create trigger TG_POS_REG_ITEMMIVIMENTATION
	after insert
	on T_ITEMOVIMENTATION
	for each row
BEGIN
   -- Aumentar o diminuir a quantidade do item a ser mivimentado
     -- TIPO MOVIMENTO = 1 -> Siguinifica entrada do novo item
     -- TIPO MOVIMENTO = 2 -> Siguinifica a saida do item
     
     UPDATE T_ITEM IT
        SET IT.ITEM_QUANTITY = (CASE
                                   WHEN :NEW.ITEMOV_TITEMOV_ID = 1 THEN IT.ITEM_QUANTITY + :NEW.ITEMOV_QUANTITY 
                                   ELSE IT.ITEM_QUANTITY - :NEW.ITEMOV_QUANTITY
                                END)
        WHERE IT.ITEM_ID = :NEW.ITEMOV_ITEM_ID;
END;