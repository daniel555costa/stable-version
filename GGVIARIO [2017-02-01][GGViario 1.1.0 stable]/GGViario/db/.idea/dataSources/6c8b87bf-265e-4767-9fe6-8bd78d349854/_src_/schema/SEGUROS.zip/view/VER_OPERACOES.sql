create view VER_OPERACOES as
SELECT "ID","CODIGO","OP","Operacao","TIPO","DATA","VALOR","COLABORADOR","REGISTRO","DT_DATA","DTREG"
    FROM (SELECT "ID",
       "CODIGO",
       "OP",
       "Operacao",
       "TIPO",
       "DATA",
       "VALOR",
       "COLABORADOR",
       "REGISTRO",
       "DT_DATA",
       "DTREG"
   FROM VER_OPERACAO_LANCAMENTO
      UNION (SELECT "ID",
                     "CODIGO",
                     "OP",
                     OPERACAO,
                     "TIPO",
                     "DATA",
                     "VALOR",
                     "COLABORADOR",
                     "REGISTRO",
                     "DT_DATA",
                     "DTREG"
                FROM VER_OPERACAO_PAGAMENTO)
      UNION (SELECT REC."ID",
                    REC.DOCUMENTO,
                    REC."OP",
                    REC.OPERACAO,
                    '' AS  "TIPO",
                    REC."DATA",
                    PACK_LIB.MONEY(REC."VALOR"),
                    REC.COLABORADOR,
                    REC."REGISTRO",
                    REC."DATA_SF",
                    REC."REGISTRO_SF"
                    
                 FROM VER_CONTA_MOVIMENTO_RECEBIMENT REC)) OPR
     ORDER BY  OPR.DTREG DESC, OPR.CODIGO DESC
