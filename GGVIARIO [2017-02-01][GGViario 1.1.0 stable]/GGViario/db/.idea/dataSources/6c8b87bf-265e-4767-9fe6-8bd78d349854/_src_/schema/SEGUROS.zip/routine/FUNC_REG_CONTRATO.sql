create FUNCTION "FUNC_REG_CONTRATO" 
(
    USER_ID NUMBER, -- Aqui deve ser um nuber
    ID_CLIENTE NUMBER,--,-- , -- Aqui deve ser um nuber
    ID_SEGURO NUMBER, -- Aqui deve ser um nuber
    NUMERO_APOLICE VARCHAR2,
    CODIGO_CONTRATO VARCHAR2, 
    INICIO DATE, -- Aqui deve ser um DATE(A data do inicio)
    FIM DATE,--, -- Aqui deve ser um DATE  (A DATA Do FIM)
    DATA_CONTRATO DATE, -- Aqui deve ser um DATA (DATA do contrato)
    DATA_RENOVACAO DATE, -- Aqui deve ser um DATA (DATA de Renovacao)
    PREMIO_BRUTO FLOAT,  --  Aqui deve ser Um FLOAT
    PRIMEIRO_PREMIO FLOAT,  --  Aqui deve ser Um FLOAT
    MENOS FLOAT,  --  Aqui deve ser Um FLOAT
    LIQUIDO_PAGAR FLOAT,  --  Aqui deve ser Um FLOAT,
    TOTAL_SEGURADO FLOAT,  --  Aqui deve ser Um FLOAT
    PREMIO_ANUAL FLOAT,  --  Aqui deve ser Um FLOAT
    TAXA_ADICIONAR FLOAT,  --  Aqui deve ser Um FLOAT
    EXECESSO CHARACTER VARYING, --,  --  Aqui deve ser Um FLOAT
    OBSERVACAO CLOB, --,  --  Aqui deve ser Um Clod
    numeroRegistroExterno VARCHAR2,
    idMoeda NUMBER, -- Identificacao da moeda a se usada no contrato
    idContratoMultirisco NUMBER
)
    RETURN VARCHAR2
IS
    TT NUMBER;
    id_ctt number;
    idImpostoAplicar NUMBER;
    countTaxa NUMBER;
    -- Validar o  numero de apolice
    -- validacaoNumApolice PACK_TYPE.Resultado := PACK_VALIDATE.apoliceNumber(USER_ID,
                                                                          -- NUMERO_APOLICE,
                                                                         -- ID_SEGURO);
    idImpostoSelo NUMBER;
    idImpostoConsumo NUMBER;
    idImpostoFGA NUMBER;
    
    missingAccount CHARACTER VARYING(4000) := '';    
BEGIN
  -- return 'NUMERO_APOLICE = '||NUMERO_APOLICE;
  -- Caso do numer de apolice invalido
   -- IF validacaoNumApolice.resultado = -1 THEN RETURN 'NUMERO APOLICE INVALIDO! '||validacaoNumApolice.message; END IF;
   
   /*
    1	GPA	Seguro de Acidente do trabalho
    2	MV	Seguro Automóvel
    3	TIN	Seguro de Viagem
    4	FR	Seguro de Incêndio
    5	NHI	Seguro Maritimo
    6	DI	Seguro de Roubo
    7	MAC	Mercadoria em Trânsito
    8	RP	Responsabilidade Pública
    9	DH	Seguro Dinheiro
    10	MR	Seguro MultI Risco
   */
   
   
   FOR TAXA IN (SELECT *
               FROM VER_IMPOSTOS_TAXAS TAXA 
               WHERE TAXA.NOME IN ('FGA', 'SELO', 'CONSUMO'))
   LOOP
      IF TAXA.NOME = 'FGA' AND ID_SEGURO = 2 THEN
         idImpostoFGA := TAXA."ID";
      ELSIF TAXA.NOME = 'SELO' THEN
         idImpostoSelo := TAXA."ID";
      ELSIF TAXA.NOME = 'CONSUMO' THEN
         idImpostoConsumo := TAXA."ID";
      END IF;
   END LOOP;
   
   
     
    -- Verificar se existe alguma taxa activa para essa moeda
    countTaxa  := PACK_CONTA.hasTaxaTOMoney(idMoeda);
    
    -- Quando nao encontrar  nenhuma taxa activa para a moeda entao
    IF countTaxa  = 0 THEN RETURN 'Não existe nenhuma taxa activa para moeda selecionada.'; END IF;
    
    -- Validar se as taxas de impostos estaão bem definidas previamente
    IF idImpostoConsumo IS NULL
       OR idImpostoSelo IS NULL
       OR (ID_SEGURO = 2 AND idImpostoFGA IS NULL )
    THEN 
       RETURN 'false;'||FUNC_ERROR('NO IMPOSTO FOUND');
    END IF;
    
    missingAccount := PACK_VALIDATE.GETMISSINGACCOUNTOPERACTION(ID_SEGURO, 'REG');
    IF missingAccount IS NOT NULL THEN
       RETURN 'false;'||missingAccount;
    END IF;
    
    -- Verificar se esse cliente ja possui apolice para esse contrato
    SELECT COUNT(*) INTO TT
       FROM T_APOLICE AP
       WHERE AP.APOLICE_CLI_ID = ID_CLIENTE
          AND AP.APOLICE_SEG_ID = ID_SEGURO;
          
    IF TT = 0 THEN
       SELECT COUNT(*) INTO TT 
          FROM T_APOLICE AP
          WHERE AP.APOLICE_NUMERO = NUMERO_APOLICE;
          
       IF TT != 0 THEN
          RETURN 'false;O numero de apolice '||NUMERO_APOLICE||' pertence ao outro cliente';
       END IF;
       INSERT INTO T_APOLICE (APOLICE_NUMERO,
                              APOLICE_USER_ID,
                              APOLICE_CLI_ID,
                              APOLICE_SEG_ID)
                              VALUES(NUMERO_APOLICE,
                                     USER_ID,
                                     ID_CLIENTE,
                                     ID_SEGURO);
    END IF;
          
   -- EXCEPTION
      -- WHEN NO_DATA_FOUND THEN
         -- RETURN 'Nao foi encontrado nenhum imposto definido';
      -- WHEN TOO_MANY_ROWS THEN
          -- UPDATE T_IMPOSTO IP
            -- SET IP.IMP_STATE = 0;
          --- RETURN 'Houve uma falha no imposto devera redifinir novamente os imposto para continuar';
          
          
   INSERT INTO T_CONTRATO (CTT_CLI_ID,
                            CTT_USER_ID, 
                            CTT_PBRUTO,
                            CTT_PPREMIO,
                            CTT_MENOS,
                            CTT_DTINICIO,
                            CTT_DTFIM,
                            CTT_NUMAPOLICE,
                            CTT_DTCONTRATO,
                            CTT_DTRENOVACAO,
                            CTT_VPAGAR,
                            CTT_VTTSEGURADO,
                            CTT_PANUAL,
                            CTT_TADICIONAR,
                            CTT_EXCESSO,
                            CTT_OBS,
                            CTT_EXTERNALCOD,
                            CTT_SEG_ID,
                            CTT_MOE_ID,
                            CTT_CTT_ID,
                            CTT_IMPTAX_CONSUMO,
                            CTT_IMPTAX_SELO,
                            CTT_IMPTAX_FGA
                            )VALUES(ID_CLIENTE,
                                    USER_ID,
                                    PREMIO_BRUTO,
                                    PRIMEIRO_PREMIO,
                                    MENOS,
                                    INICIO,
                                    FIM,
                                    NUMERO_APOLICE,
                                    DATA_CONTRATO,
                                    DATA_RENOVACAO,
                                    LIQUIDO_PAGAR,
                                    TOTAL_SEGURADO,
                                    PREMIO_ANUAL,
                                    TAXA_ADICIONAR,
                                    EXECESSO,
                                    OBSERVACAO,
                                    numeroRegistroExterno,
                                    ID_SEGURO,
                                    idMoeda,
                                    idContratoMultirisco,
                                    idImpostoConsumo,
                                    idImpostoSelo,
                                    idImpostoFGA)  returning ctt_id into id_ctt;
    
    -- Criara a primeira linha de autualizacao do registro
    INSERT INTO T_LINHACONTRATO(LCTT_CTT_ID,
                                LCTT_USER_ID,
                                LCTT_OBS,
                                LCTT_FORSTATE,
                                LCTT_DTRENOVACAO,
                                LCTT_DTFINALIZAR,
                                LCTT_DTINICIAR)
                                VALUES (id_ctt,
                                        USER_ID,
                                        'New Contrato',
                                        1,
                                        DATA_RENOVACAO,
                                        FIM,
                                        INICIO);
    
    -- Efectura a busca pela identificacado contrato que a cabou de ser registrado e retornar a sua identificacao
                                    
    RETURN 'true;'||id_ctt;
END;