create trigger TG_POS_UPD_SEG_DESABLE_PER
	after update
	on T_SEGURO
	for each row
BEGIN
    IF :NEW.SEG_STATE = 0 AND :OLD.SEG_STATE = 1 THEN
       UPDATE T_PERGUNTA
          SET PER_STATE = 0 
          WHERE (PER_SEG_ID)= :OLD.SEG_ID;
    END IF;
END;