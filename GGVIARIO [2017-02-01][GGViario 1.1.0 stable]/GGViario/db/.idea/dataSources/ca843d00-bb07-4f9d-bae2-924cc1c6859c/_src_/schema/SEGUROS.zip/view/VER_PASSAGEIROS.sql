create view VER_PASSAGEIROS as
SELECT 
   OO.OBJECTO_ID AS "ID",
   OO.CONTENT.get('nomePessoaSegurada') AS "NOME",
   OO.CONTENT.get('tipoDoc') AS "TIPO DOCUMENTO",
   OO.CONTENT.get('numDoc') AS "DOCUMENTO",
   OO.CONTENT.get('dataNasc') AS "DATA NASCIMENTO",
   OO.CONTENT.get('dataEmissao') AS "DATA EMISSAO",
   OO.CONTENT.get('localNascimento') AS "LOCAL NASCIMENTO",
   OO.CONTENT.get('localEmisao') AS "LOCAL EMISAO",
   OO.CONTENT.get('endereco') AS "ENDERECO",
   OO.CONTENT.get('sexo') AS "SEXO",
   OO.CONTENT.get('TABLE_VALUE#sexo') AS SEXO_ID,
   OO.CONTENT.get('telefone') AS "TELEFONE",
   OO.CONTENT.get('outrasInformacao') AS "OUTRAS INFORMACOES",
   OO.CONTENT.get('numApolice') AS "NUMERO APOLICE",
   OO.CONTENT.get('zonaDestino') AS "ZONA DESTINO",
   OO.CONTENT.get('cidadeDestino') AS "CIDADE DESTINO",
   OO.CONTENT.get('objetivoViagem') AS "OBJECTIVO VIAGEM",
   OO.CONTENT.get('paisDestino') AS "PAIS DESTINO",
   OO.CONTENT.get('TABLE_VALUE#paisDestino') AS "PAIS DESTINO ID",
   OO.CONTENT.get('dataInicio') AS "DATA INICIO",
   OO.CONTENT.get('dataFim') AS "DATA FIM",
   OO.CONTENT.get('nacionalidade') AS "NACIONALIDADE",
   OO.CONTENT.get('TABLE_VALUE#nacionalidade') AS "ID NACIONALIDADE",
   OO.CONTENT.get('TABLE_VALUE#tipoDoc') AS "ID DOCUMENTO"
FROM MVER_OBJECT_CONTENT OO
WHERE OO.CLASS_DESC = 'PASSAGEIRO'
ORDER BY OO.OBJECTO_ID DESC
