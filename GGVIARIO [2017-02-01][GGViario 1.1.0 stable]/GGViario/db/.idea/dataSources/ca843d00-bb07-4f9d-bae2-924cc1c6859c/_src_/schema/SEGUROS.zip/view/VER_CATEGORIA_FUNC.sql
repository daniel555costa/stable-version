create view VER_CATEGORIA_FUNC as
select 
      TYPE_CATEGORIA.OBJT_DESC as "Nome",
      NIVEL.OBJT_DESC AS NIVEL,
      ca.CAT_NUMDIAS as  "Dias",
      ca.CAT_BASESALARY as "salario base",
      ca.CAT_HOUSESUBVENTION as "Subsidio Alagamento",
      ca.CAT_LUNCHSUBVENTION as "Subsidio lanche",
      ca.CAT_TRANSPORTSUBVENTION as "subsidio Transporte",
      pack_lib.asddmmyyyy(ca.CAT_DTREG) as "registo",
     (ca.CAT_BASESALARY)+(ca.CAT_LUNCHSUBVENTION)+(ca.CAT_TRANSPORTSUBVENTION)+( ca.CAT_HOUSESUBVENTION)as "total",
      ca.CAT_ALMOCOBONUS AS "BONUS ALMOCO", -- AS ALMOCO LIVRE DOS IMPOSTOS
      CASE 
        WHEN ca.cat_state = 1  THEN 'activo'
        ELSE 'DESATIVO'  
      END   AS ESTADO 
    FROM T_CATEGORY ca
      INNER JOIN T_OBJECTYPE NIVEL ON ca.CAT_OBJT_LEVELCAT = NIVEL.OBJT_ID
      INNER JOIN T_OBJECTYPE TYPE_CATEGORIA ON TYPE_CATEGORIA.OBJT_ID = ca.cat_objt_typecategory
   WHERE ca.cat_state = 1
   ORDER BY CAT_STATE DESC ,"Nome" ASC, NIVEL ASC
