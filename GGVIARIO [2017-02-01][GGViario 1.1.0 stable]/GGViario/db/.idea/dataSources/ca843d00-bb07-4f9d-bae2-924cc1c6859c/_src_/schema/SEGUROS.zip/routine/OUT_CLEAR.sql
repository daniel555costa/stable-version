create PROCEDURE out_clear
IS
BEGIN
  DELETE from output;
END;