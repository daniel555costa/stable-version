create trigger TG_NEXT_OBJECTYPE
	before insert
	on T_OBJECTYPE
	for each row
begin  
   if inserting then 
      if :NEW."OBJT_ID" is null then 
         SELECT SEQ_OBJECTYPE.nextval into :NEW."OBJT_ID" from dual;
      end if;
      
      SELECT T.T_SEQUENCIA 
          INTO :NEW.OBJT_SEQUENCE 
          FROM T_TYPE T WHERE T.T_ID = :NEW.OBJT_T_ID;
          
      UPDATE T_TYPE 
          SET T_SEQUENCIA = T_SEQUENCIA + 1
          WHERE T_ID =  :NEW.OBJT_ID;
   end if; 
end;