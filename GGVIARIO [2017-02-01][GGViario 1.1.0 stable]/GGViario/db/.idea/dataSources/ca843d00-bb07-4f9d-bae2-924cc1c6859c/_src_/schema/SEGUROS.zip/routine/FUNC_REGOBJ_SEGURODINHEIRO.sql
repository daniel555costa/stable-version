create FUNCTION "FUNC_REGOBJ_SEGURODINHEIRO" 
( 
    USER_ID NUMBER,
    ID_CONTRATO VARCHAR,
    NOME_FABRICANTE VARCHAR2,
    NUMERO_FABRICANTE VARCHAR2, 
    TAMANHO VARCHAR,
    DETENTOR_CHAVES VARCHAR2, 
    PESO BINARY_FLOAT, 
    idConstrucao NUMBER, -- NA VIEW VER_OBJTCONSTRUCAOCOFRE 
    ESTRUTURA VARCHAR2
)

RETURN VARCHAR2 
IS
  res PACK_TYPE.Resultado;
  
  -- Instancia de um novo seguro deinheiro (ojecto segurado)
  parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
BEGIN
    PRC_ADD_LISTVALUE(parsValues, null, 'nomeFabricante', NOME_FABRICANTE);
    PRC_ADD_LISTVALUE(parsValues, null, 'numeroFabricante', NUMERO_FABRICANTE);
    PRC_ADD_LISTVALUE(parsValues, null, 'tamanho', TAMANHO);
    PRC_ADD_LISTVALUE(parsValues, null, 'detentorChaves', DETENTOR_CHAVES );
    PRC_ADD_LISTVALUE(parsValues, null, 'peso', PESO);
    PRC_ADD_LISTVALUE(parsValues, null, 'construção', idConstrucao);
    PRC_ADD_LISTVALUE(parsValues, null, 'estrutura', ESTRUTURA);
    
    
    -- Criara o resgistro do segurado
    res := PACK_REGRAS.REG_OBJECTO(USER_ID , ID_CONTRATO , 234, 1);
    
    PACK_REGRAS.REGOBJECTVALUES(USER_ID, res.resultado, null, 12, parsValues);
    
    IF res.resultado != -1 THEN res.message := 'true'; END IF;
    RETURN res.message;
END ;