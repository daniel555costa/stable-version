create TYPE BODY ROW_ITEM AS

  MEMBER FUNCTION get(itemName CHARACTER VARYING) RETURN ITEM AS
  BEGIN
    -- TODO: Implementation required for FUNCTION ROW_ITEM.get
    RETURN NULL;
  END get;

  MEMBER PROCEDURE put(itemValue ITEM) AS
  BEGIN
    -- TODO: Implementation required for PROCEDURE ROW_ITEM.put
    NULL;
  END put;

  MEMBER FUNCTION get_clob(itemName CHARACTER VARYING) RETURN ITEM_CLOB AS
  BEGIN
    -- TODO: Implementation required for FUNCTION ROW_ITEM.get_clob
    RETURN NULL;
  END get_clob;

  MEMBER FUNCTION get_date(itemName CHARACTER VARYING) RETURN ITEM_DATE AS
  BEGIN
    -- TODO: Implementation required for FUNCTION ROW_ITEM.get_date
    RETURN NULL;
  END get_date;

  MEMBER FUNCTION get_float(itemName CHARACTER VARYING) RETURN ITEM_FLOAT AS
  BEGIN
    -- TODO: Implementation required for FUNCTION ROW_ITEM.get_float
    RETURN NULL;
  END get_float;

  MEMBER FUNCTION get_number(itemName CHARACTER VARYING) RETURN ITEM_NUMBER AS
  BEGIN
    -- TODO: Implementation required for FUNCTION ROW_ITEM.get_number
    RETURN NULL;
  END get_number;

  MEMBER FUNCTION get_timestamp(itemName CHARACTER VARYING) RETURN ITEM_TIMESTAMP AS
  BEGIN
    -- TODO: Implementation required for FUNCTION ROW_ITEM.get_timestamp
    RETURN NULL;
  END get_timestamp;

  MEMBER FUNCTION get_string(itemName CHARACTER VARYING) RETURN ITEM_VARCHAR AS
  BEGIN
    -- TODO: Implementation required for FUNCTION ROW_ITEM.get_string
    RETURN NULL;
  END get_string;

END;