create PROCEDURE PRC_REFRESH_MVIEWS
(
   GROUP_MVIEW CHARACTER VARYING 
)
IS
   num NUMBER;
BEGIN
   IF UPPER(GROUP_MVIEW) = UPPER('OBJECT_VALUES') THEN 
      dbms_job.submit(num, 'dbms_mview.refresh( ''MVER_OBJECT_VALUES'' );');
      dbms_job.submit(num, 'dbms_mview.refresh( ''MVER_OBJECT_CLASS'' );');
      dbms_job.submit(num, 'dbms_mview.refresh( ''MVER_OBJECT_CONTENT'' );');
   END IF;
END;