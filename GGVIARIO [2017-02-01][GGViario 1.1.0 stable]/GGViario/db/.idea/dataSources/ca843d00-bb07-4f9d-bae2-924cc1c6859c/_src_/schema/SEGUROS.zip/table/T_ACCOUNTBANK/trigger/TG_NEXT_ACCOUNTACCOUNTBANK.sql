create trigger TG_NEXT_ACCOUNTACCOUNTBANK
	before insert
	on T_ACCOUNTBANK
	for each row
begin  
   if inserting then 
      if :NEW."ACCOUNTBANK_ID" is null then 
         select SEQ_ACCOUNTACCOUNTBANK.nextval into :NEW."ACCOUNTBANK_ID" from dual; 
      end if; 
   end if; 
end;
