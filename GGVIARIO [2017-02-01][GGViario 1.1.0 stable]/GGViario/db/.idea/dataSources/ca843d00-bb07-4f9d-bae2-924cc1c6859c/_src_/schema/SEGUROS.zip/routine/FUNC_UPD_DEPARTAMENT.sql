create FUNCTION FUNC_UPD_DEPARTAMENT 
(
   idUser NUMBER,
   idFuncionario NUMBER,
   idDepartamento NUMBER,
   idLevelDepartamento NUMBER
)
RETURN VARCHAR2
IS
   tt NUMBER;
BEGIN
   SELECT COUNT(*) INTO tt
      FROM T_FUNCIONARIO F
         WHERE F.FUNC_DEP_ID = idDepartamento
            AND F.FUNC_NVUSER_ID = idLevelDepartamento
            AND F.FUNC_STATE = 1 
            AND F.FUNC_ID = idFuncionario;
   IF tt !=0 THEN 
       RETURN 'Esse funcionario ja esta alocado e esse departamento no nivel selecionado!';
   END IF;
   UPDATE T_FUNCIONARIO F
      SET F.FUNC_DEP_ID = idDepartamento,
          F.FUNC_NVUSER_ID = idLevelDepartamento
      WHERE F.FUNC_ID = idFuncionario;
END;