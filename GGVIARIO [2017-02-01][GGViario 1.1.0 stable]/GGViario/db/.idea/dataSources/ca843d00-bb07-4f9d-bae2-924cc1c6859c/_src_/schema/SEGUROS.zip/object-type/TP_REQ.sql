create TYPE           "TP_REQ"                                          IS OBJECT
(
   "TYPE" NUMBER
)NOT FINAL;