create trigger TG_NEXT_PRESTACAO
	before insert
	on T_PRESTACAO
	for each row
begin  
   if inserting then 
      if :NEW."PREST_ID" is null then 
         select SEQ_PRESTACAO.nextval into :NEW."PREST_ID" from dual; 
      end if; 
   end if; 
end;