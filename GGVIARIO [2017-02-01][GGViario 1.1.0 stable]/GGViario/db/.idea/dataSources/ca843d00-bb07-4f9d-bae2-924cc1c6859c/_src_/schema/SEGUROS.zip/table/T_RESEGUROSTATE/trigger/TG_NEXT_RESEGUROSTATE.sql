create trigger TG_NEXT_RESEGUROSTATE
	before insert
	on T_RESEGUROSTATE
	for each row
begin  
   if inserting then 
      if :NEW."RESSTT_ID" is null then 
         select SEQ_RESEGUROSTATE.nextval into :NEW."RESSTT_ID" from dual; 
      end if; 
   end if; 
end;
