create FUNCTION FUNC_LOAD_OBJTYPE 
(
    IDENTIDADE NUMBER
) 
RETURN PACK_TYPE.filterObjectoType PIPELINED 
IS
  BEGIN
    
    FOR I IN (SELECT *
                  FROM VER_OBJECTYPE V
                  WHERE V."ID ENTIDADE"= IDENTIDADE)
      LOOP
         PIPE ROW(I);
      END LOOP;
    END;