create FUNCTION FUNC_CTTINF_CARGAMARTIMA_NEW 
(
  idUser NUMBER,
  idContrato NUMBER,

  pais_origem NUMBER,
  pais_destino NUMBER,
  portoCarga VARCHAR2,
  portoDescarga VARCHAR2,
  nomeNavio VARCHAR2,
  valorMaximoRisco  BINARY_DOUBLE,
  
  -- COBRE -- Ambito da cobertura
  escolha_cobertura NUMBER, -- {1 - Todos Riscos, 2 - Restrita, 3 - Mais Restrita}
  valorCoberturaSelecionada BINARY_DOUBLE,
  propositoSeguro CLOB,
  
  -- VMAXRISCO >> Valor maximo em risco para
  qualquerNavio VARCHAR2,
  qualquerMercadoria FLOAT,
  anualMercadoria VARCHAR, -- Anula para cada mercadoria
  
  --FSEND >> Forma de emvio
  formaEnvio NUMBER, -- {VER_FORMA_ENVIO}
  
  --OTHER >> Outros
  tempoNegocio NUMBER,
  custoPorto NUMBER, -- Custo do porto (10% 20%)
  
  
  -- Informacao do segurado 
    descMercadoria VARCHAR2,
    areaActividade VARCHAR2,
    infoSeg_segEfectuadoComp VARCHAR2,
    infoSeg_nameCompania VARCHAR2,
  
  -- MTRANS >> Mercadorias Transportadas
  mercadorias TB_ARRAY_STRING -- {VER_TIPOMERCADORIA}


)
RETURN VARCHAR2
IS
    resp VARCHAR2(100);
    

BEGIN
    -- Essa funcao serve para criar um objecto do tipo TP_CTT_CARGAMARTIMA publica e armazenala na entidade contrato
    PRC_REG_RESPOSTA(idUser, idContrato, 48, pais_destino, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 49, portoCarga, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 50, nomeNavio, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 51, pais_origem, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 52, portoDescarga, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 54, formaEnvio, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 64, tempoNegocio, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 65, custoPorto, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 66, propositoSeguro, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 68, descMercadoria, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 69, areaActividade, null);
    -- pergunta setanta pode ter mais que uma escolha
    
    FOR I IN 1..mercadorias.COUNT LOOP
        PRC_REG_RESPOSTA(idUser, idContrato, 70, mercadorias(i)||'', null);
    END LOOP;
    
    PRC_REG_RESPOSTA(idUser, idContrato, 213, qualquerNavio, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 214, qualquerMercadoria, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 215, anualMercadoria, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 217, infoSeg_segEfectuadoComp, null);
    PRC_REG_RESPOSTA(idUser, idContrato, 218, infoSeg_nameCompania, null);
    
    -- Criar as resposta para as perguntas
    RETURN 'true';
END FUNC_CTTINF_CARGAMARTIMA_NEW;