create trigger TG_NEXT_RESPOSTA
	before insert
	on T_RESPOSTA
	for each row
begin  
   if inserting then 
      if :NEW."RESP_ID" is null then 
         select SEQ_RESPOSTA.nextval into :NEW."RESP_ID" from dual; 
      end if; 
   end if; 
end;