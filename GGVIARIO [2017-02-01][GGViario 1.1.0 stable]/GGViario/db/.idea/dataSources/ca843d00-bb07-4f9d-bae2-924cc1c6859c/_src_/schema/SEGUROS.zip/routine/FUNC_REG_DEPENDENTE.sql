create FUNCTION "FUNC_REG_DEPENDENTE" (
    USER_ID NUMBER, -- Identificacao do utilizador que esta a registrar  o dependente
    NOME VARCHAR,
    apelido VARCHAR2,
    ID_FUNCIONARIO NUMBER, -- Identificaoa do funcionario que o dependete pertence
    ID_GRAU_PARENTESCO NUMBER,
    ID_SEXO NUMBER,
    ID_ESTADO_CIVIL NUMBER,
    dtNascimento DATE,
    RESIDENCIA VARCHAR2
)

RETURN VARCHAR2
IS
    -- Obtendo a identificacao de residencia
    ID_RESIDENCIA NUMBER := PACK_REGRAS.GET_RESIDENCE(RESIDENCIA,USER_ID);

BEGIN
    /*
          46	2	Conjuge
          47	2	Irmao
          48	2	Pae
          49	2	Mãe
          50	2	FILHO
    */
    -- Quando for a conjuje desabilitar a jonjuge anterior
    IF ID_GRAU_PARENTESCO = 46 THEN
       UPDATE T_DEPENDENTE DE
          SET DE.DEP_STATE = 0
          WHERE DE.DEP_FUNC_ID = ID_FUNCIONARIO
             AND DE.DEP_GRAU_ID = 46;
    END IF;
    -- Criando (Registrando o dependente)
    INSERT INTO T_DEPENDENTE(DEP_FUNC_ID,
                              DEP_USER_ID,
                              DEP_SC_ID,
                              DEP_GEN_ID,
                              DEP_RES_ID,
                              DEP_GRAU_ID,
                              DEP_NOME,
                              DEP_APELIDO,
                              DEP_DTNASC)
                              VALUES(ID_FUNCIONARIO,
                                    USER_ID,
                                    ID_ESTADO_CIVIL,
                                    ID_SEXO,
                                    ID_RESIDENCIA,
                                    ID_GRAU_PARENTESCO,
                                    NOME,
                                    apelido,
                                    dtNascimento);
       RETURN 'true';                             
                              
END;