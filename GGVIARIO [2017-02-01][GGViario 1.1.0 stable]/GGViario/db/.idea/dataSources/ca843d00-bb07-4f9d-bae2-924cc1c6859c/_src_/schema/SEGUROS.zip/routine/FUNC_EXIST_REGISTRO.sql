create FUNCTION FUNC_EXIST_REGISTRO 
(
    nRegistro VARCHAR2
)RETURN NUMBER IS
  tt NUMBER;
BEGIN
  -- Buscar a quantidade dos contratos com o codigo
  SELECT COUNT(*) INTO tt
    FROM T_CONTRATO ct
    WHERE ct.CTT_EXTERNALCOD = nRegistro;
    
   RETURN tt;
END;