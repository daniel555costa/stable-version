create TYPE           "TP_LOAD_CONTRATO"                                          IS OBJECT
(
    ID  NUMBER, -- O id correspondente a resposta
    CATEGORIA VARCHAR2(1000),  -- Categoria
    CATEGIRIA_COD VARCHAR2(1000),  -- CODIGO Categoria
    COD VARCHAR2(1000),  -- Codigo do valor
    VALUE_1 VARCHAR2(4000) -- Valor
);