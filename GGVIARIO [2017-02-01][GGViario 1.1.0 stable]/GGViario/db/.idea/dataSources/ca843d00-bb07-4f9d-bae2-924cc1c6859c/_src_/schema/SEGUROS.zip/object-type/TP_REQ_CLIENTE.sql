create TYPE           "TP_REQ_CLIENTE"                                          UNDER TP_REQ
(
    "CLIENTE" VARCHAR2(100),
    "APELIDO" VARCHAR2(100)
);