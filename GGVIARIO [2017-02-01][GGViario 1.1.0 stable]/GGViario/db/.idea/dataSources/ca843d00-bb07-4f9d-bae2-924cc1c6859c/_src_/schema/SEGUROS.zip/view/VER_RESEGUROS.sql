create view VER_RESEGUROS as
SELECT     ct.CTT_ID AS "ID",
           ct.CTT_CTT_ID AS "ID CONTRATO",
           ct.CTT_TCTT_ID AS "ID TIPO RESEGURO",
           ct.CTT_SEG_ID AS "ID SEGURO",
           ct.CTT_CLIENT AS "CLIENTE",
           ct.CTT_NUMAPOLICE AS "APOLICE",
           MD.MOE_SIGLA AS "MOEDA",
           ct.CTT_DTINICIO AS "DT INICIO",
           ct.CTT_DTFIM AS "DT FIM",
           TO_CHAR(ct.CTT_DTINICIO, 'DD-MM-YYYY') AS "INICIO",
           TO_CHAR(ct.CTT_DTFIM, 'DD-MM-YYYY') AS "FIM",
           ct.CTT_MOE_ID AS "ID MOEDA",
           ct.CTT_VTTSEGURADO AS "LIMITE",
           ct.CTT_PBRUTO AS "PREMIO GROSSO",
           ct.CTT_VPAGAR AS "TOTAL",
           ct.CTT_STATE AS "ESTADO",
           ct.CTT_COBERTURA AS "TIPO COBERTURA",
           ct.CTT_TADICIONAR AS "DEDUCAO",
           ct.CTT_OBS AS "DESCRICAO",
           TCTT.TCTT_DESC AS "TIPO RESEGURO",
           ct.CTT_DTREG AS "DT REG",
           ct.CTT_EXTERNALCOD AS "NUM DEBITO"
      FROM T_CONTRATO ct
         INNER JOIN T_MOEDA MD ON ct.CTT_MOE_ID = MD.MOE_ID
         INNER JOIN T_TYPECONTRATO TCTT ON ct.CTT_TCTT_ID = TCTT.TCTT_ID
     WHERE ct.CTT_TCTT_ID IN (2, 3)
        AND ct.CTT_STATE != -1
    ORDER BY ct.CTT_DTREG DESC
