create trigger TG_NEXT_BANCK
	before insert
	on T_BANK
	for each row
begin  
   if inserting then 
      if :NEW."BK_ID" is null then 
         select SEQ_BANK.nextval into :NEW."BK_ID" from dual; 
      end if; 
   end if; 
end;