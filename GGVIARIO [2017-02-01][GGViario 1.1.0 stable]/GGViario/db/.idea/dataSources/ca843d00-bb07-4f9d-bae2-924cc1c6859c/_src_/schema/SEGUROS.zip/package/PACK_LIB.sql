create PACKAGE "PACK_LIB" IS

    /*-- Tipo unidade
    -- unit O nome para a unidade
    -- minLenth O tamanho do numero nimimo
    -- maxLenth O tamanho do numero maximo
    -- minRange O Ranque minimo da unidade
    -- maxRange O Ranque maximo da unidade
    TYPE unit IS RECORD (unit VARCHAR2(30), minLenth NUMBER, maxLenth NUMBER, minRange NUMBER, maxRange NUMBER);
    */
    
    -- ESSA FUNCAO SERVE PARA CALCULAR AS IDADE A PARTIR DE UMA DATA DADA
    FUNCTION calcIdade(OLD_DATE date) RETURN NUMBER; 
    
    
    -- CONVERTER UM VALOR NUMERICO EM UM FARMATO DE MOEDA
    FUNCTION money (VALOR BINARY_DOUBLE) RETURN VARCHAR2;

    
    -- PEGAR HARA DO DE UMA DATA
    FUNCTION asTime (DATE_PARAM TIMESTAMP) RETURN VARCHAR2;
    
    -- COVERTER A DATA EM DIA MES ANO
    FUNCTION asDDMMYYYY (DATE_PARAM TIMESTAMP) RETURN VARCHAR2;
    
    -- CONVERTER A DATA EM ANO MES DIA
    FUNCTION asYYYYMMDD (DATE_PARAM TIMESTAMP) RETURN VARCHAR2; 
    
    -- BUSCARTAR O VALOR DO ESTADO DE UM TIPULO EM UMA ENTIDADE
    FUNCTION state(ENTIDADE VARCHAR, COD NUMBER)RETURN VARCHAR2; 
    
    -- OBTER O ANO ACTUAL
    FUNCTION getCurrentYear RETURN VARCHAR2;
    
    
    FUNCTION isNumber (argment VARCHAR2) RETURN NUMBER;
    
    -- COMPLETAR UMA STRING COM O CARACTER ANTES OU DEPIS FRIST {TRUE=ANTES, FLASE=DEPOIS} 
    FUNCTION complet (ARGMENT IN VARCHAR2, COMPLETION IN CHAR, FINAL_LENGTH IN NUMBER, FRIST IN BOOLEAN) RETURN VARCHAR2;
    
    
    -- Essa funcao devede um varcar nas fendas fornecida (splitCase) excluido as casas nulas ou que o tamnho seja zero 
      -- argment <O que se pretende separar>
      -- splitCase <Aonde deve ser separada>
    FUNCTION splitNotNull (argment VARCHAR2, splitCase VARCHAR2) RETURN TB_ARRAY_STRING;
    
    
    -- Essa fucao efectua um split mais rigoros incluido as casas nulas ou que o tamanho seja zero
      -- argment <O que se pretende separar>
      -- splitCase <Aonde deve ser separada>
    FUNCTION splitAll (argment VARCHAR2, splitCase VARCHAR2) RETURN TB_ARRAY_STRING;
    
    -- Essa funcao serve para obter um carater em um dado index de uma varchar
      -- argment e a varchar2 que se pretende obter o seu caracter
      -- charIndex o index do carater que se pretende
    FUNCTION charAt(argment VARCHAR2, charIndex INTEGER) RETURN CHAR;
    
    
    -- Função para obter o total do registro em uma entiade
      -- tableName O nome da tabela a contar os registro
    FUNCTION tableLength(tableName VARCHAR2) RETURN  NUMBER; 
    
    
    FUNCTION getValues(tableName VARCHAR2, tableCollId VARCHAR2, tableCollVAlue VARCHAR2, valueId VARCHAR2, comparator VARCHAR2, toString NUMBER ) RETURN TB_ARRAY_STRING;
    
    FUNCTION getVall(tableName VARCHAR2, tableCollId VARCHAR2, tableCollVAlue VARCHAR2, valueId VARCHAR2, comparator VARCHAR2, toString NUMBER ) RETURN VARCHAR2;
    
    FUNCTION getVallView(tableName VARCHAR2, tableCollId VARCHAR2, tableCollVAlue VARCHAR2, valueId VARCHAR2, comparator VARCHAR2, toString NUMBER ) RETURN VARCHAR2;
    
    
    FUNCTION getFreeId(tableName VARCHAR2, tableId VARCHAR2) RETURN NUMBER;
    
    
    FUNCTION betweenDate(currentDate TIMESTAMP, intiDate TIMESTAMP, endDate TIMESTAMP) RETURN NUMBER;
    
    
    -- Essas funcoes sao para mater os valores do tipo em um determindado formato em base de dados
  
    FUNCTION charValue(argment DATE) RETURN CHARACTER VARYING;
    
    FUNCTION charValue(argment TIMESTAMP) RETURN CHARACTER VARYING;
    
    
    FUNCTION getIntervalNumber (arg1 DATE, arg2 DATE) RETURN NUMBER;
    
    
    FUNCTION NO_ACCENT(argment CHARACTER VARYING) RETURN CHARACTER VARYING;
   
   
    FUNCTION NO_ACCENT_UPPER(argment CHARACTER VARYING) RETURN CHARACTER VARYING;
    
    
    
END PACK_LIB;