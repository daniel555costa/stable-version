create view VER_PAIS as
SELECT
      PA.ID,
      PA.NOME,
      PA.ISO2,
      PA.ISO3
    FROM VER_ADM_PAIS PA
    WHERE PA.ESTADO = 1
