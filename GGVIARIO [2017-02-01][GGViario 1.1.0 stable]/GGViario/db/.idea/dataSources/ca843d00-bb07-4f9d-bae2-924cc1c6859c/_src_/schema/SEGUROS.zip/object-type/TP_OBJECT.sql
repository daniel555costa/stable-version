create TYPE           "TP_OBJECT"                                          IS OBJECT
(
    type_name VARCHAR2 (30),
    CONSTRUCTOR FUNCTION TP_OBJECT RETURN SELF AS RESULT
)NOT FINAL;