create FUNCTION FUNCT_VER_TAXAX_IMPOSTAS RETURN LISTA_TAXA_VIAGEM PIPELINED
IS
   nicomComision FLOAT;
   taxa TAXA_VIAGEM;
BEGIN
      FOR PR IN(SELECT *
                   FROM T_PRECARIO PR
                      FULL JOIN T_IMPOSTO IP ON 1=1
                    WHERE IP.IMP_STATE = 1
                      AND PR.PREC_STATE = 1)
      LOOP
         nicomComision := PACK_CONTRATO_VIAGEM.CALC_NICON_COMISION(PR.PREC_ID, SYSTIMESTAMP);
         
         taxa := TAXA_VIAGEM(PR.PREC_ID, -- AS ID
                             nicomComision,  -- AS NICON COMISSION
                             PR.PREC_PREMINOOBJ, -- AS SUBTOTAL <<O premio do objecto>>
                             PR.IMP_CONSUMO/100,  -- AS TAXA DE CONSUMO
                             PR.IMP_SELO/100,  -- AS TAXA DE SELO
                             PR.IMP_FGA/100, -- AS TAXA DO FGA
                             PR.PREC_DIAMIN, -- AS DIA MINIMO
                             PR.PREC_DIAMAX, -- AS DIA MAXIMO
                             9999999 -- AS DIAS
                             );
          PIPE ROW (taxa);
      END LOOP;
END;