CREATE PROCEDURE `prc_reg_avaliacao`(IN `idMatricula` INT(11), IN `idLancamento` INT(11), IN `Tipoavaliacao` INT(11),
                                     IN `nota`        FLOAT, IN `dataavaliacao` DATE)
  BEGIN

    INSERT INTO avalicacao (
        avalia_matpe_id,
        avalia_lanca_id,
        avalia_tpaval_id,
        avalia_nota,
        avalia_dtavaliacao
      ) VALUE (
        idMatricula,
        idLancamento,
        Tipoavaliacao,
        nota,
        dataavaliacao
    );
    
    SELECT TRUE as RESULT, 'SUCCESS' AS MESSAGE;

END