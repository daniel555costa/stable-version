CREATE VIEW `ver_tipodoc` AS
  SELECT
    `tipodoc`.`tipoDoc_id`   AS `ID`,
    `tipodoc`.`tipoDoc_desc` AS `DESCRICAO`
  FROM `academico`.`tipodocumento` `tipodoc`
  WHERE (`tipodoc`.`tipoDocState` = 1)