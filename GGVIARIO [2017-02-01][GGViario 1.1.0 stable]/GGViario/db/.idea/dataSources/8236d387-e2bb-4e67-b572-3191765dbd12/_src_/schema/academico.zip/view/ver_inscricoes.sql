CREATE VIEW `ver_inscricoes` AS
  SELECT
    `alu`.`alu_id`      AS `ALUNO.ID`,
    `alu`.`alu_name`    AS `ALUNO.NOME`,
    `alu`.`alu_surname` AS `ALUNO.APELIDO`,
    `alu`.`alu_dtreg`   AS `DATA REGISTO`,
    (SELECT `c`.`cur_name`
     FROM ((`academico`.`inscricao` `insc`
       JOIN `academico`.`vaga` `v` ON ((`insc`.`insc_vaga_id` = `v`.`vaga_id`))) JOIN `academico`.`curso` `c`
         ON ((`c`.`cur_id` = `v`.`vaga_cur_id`)))
     WHERE ((`insc`.`insc_option` = 1) AND (`insc`.`insc_alu_id` = `alu`.`alu_id`) AND (`insc`.`insc_state` <> -(1)))
     ORDER BY `insc`.`insc_dtreg` DESC
     LIMIT 1)           AS `OPC1`,
    (SELECT `c`.`cur_name`
     FROM ((`academico`.`inscricao` `insc`
       JOIN `academico`.`vaga` `v` ON ((`insc`.`insc_vaga_id` = `v`.`vaga_id`))) JOIN `academico`.`curso` `c`
         ON ((`c`.`cur_id` = `v`.`vaga_cur_id`)))
     WHERE ((`insc`.`insc_option` = 2) AND (`insc`.`insc_alu_id` = `alu`.`alu_id`) AND (`insc`.`insc_state` <> -(1)))
     ORDER BY `insc`.`insc_dtreg` DESC
     LIMIT 1)           AS `OPC2`
  FROM `academico`.`aluno_candidato` `alu`
  ORDER BY `alu`.`alu_dtreg` DESC