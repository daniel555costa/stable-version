CREATE PROCEDURE `prc_regnotacertificado`(IN `idInsc` INT(4), IN `nota` FLOAT, IN `id_disc_nucl` INT(4))
  BEGIN
    INSERT INTO notacertificado
    (
      nt_insc_id,
      nt_nota,
      nt_dicnu_id
    )
    VALUES
      (
        idInsc,
        nota,
        id_disc_nucl
      );
    select true as 'RESULT';
  END