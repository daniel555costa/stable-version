CREATE PROCEDURE `rule_selection_process_for_xy`(IN `idCandadatu` INT(11), IN `xAlocation` INT(11),
                                                 IN `xIdVaga`     INT(11), IN `yAlocation` INT(11),
                                                 IN `yIdVaga`     INT(11))
  BEGIN
    -- DECLARE xVariable as variable of option 1
    -- DECLARE yVariable as variable of option 2

    -- Para as candidaturas x que estao enquadradas
    IF xAlocation = b'1' THEN
      call rule_selection_delete_candidature(yIdVaga, idCandadatu);
      call rule_selection_select_candidature(idCandadatu, xIdVaga);

    ELSEIF yAlocation = b'1'
           AND NOT `rule_selection_has_enter_possiblit`(idCandadatu, xIdVaga) THEN
      call rule_selection_delete_candidature(xIdVaga, idCandadatu);
      call rule_selection_select_candidature(idCandadatu, yIdVaga);


    ELSEIF NOT rule_selection_has_enter_possiblit(idCandadatu, yIdVaga) THEN
      call rule_selection_delete_candidature(yIdVaga, idCandadatu);
    END IF;
  END