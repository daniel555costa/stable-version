CREATE PROCEDURE `prc_reg_residencia`(IN `idlocalidade` INT(5), IN `idAluno` INT(5), IN `idTipoDoc` INT(4),
                                      IN `numeroDoc`    VARCHAR(45))
  BEGIN
    DECLARE alunoExiste int(5) DEFAULT 0;

    SELECT res.res_alu_id into alunoExiste
        from residencia res
    WHERE res.res_alu_id = idAluno
      and res.res_state = 1;

    if alunoExiste = 0 then
        INSERT INTO residencia
        (
          res_local_id,
          res_alu_id) VALUES
          (
            idlocalidade,
            idAluno
          );

        INSERT into documento
        (
          doc_numero,
          doc_tipodoc_id,
          doc_aluno_id)
          VALUES
          (
              numeroDoc,
              idTipoDoc,
              idAluno
          );
       SELECT true as RESULT;
      ELSE
        UPDATE residencia
          set res_local_id = idlocalidade
        WHERE res_alu_id = idAluno;

       SELECT true as RESULT;
    END IF;
END