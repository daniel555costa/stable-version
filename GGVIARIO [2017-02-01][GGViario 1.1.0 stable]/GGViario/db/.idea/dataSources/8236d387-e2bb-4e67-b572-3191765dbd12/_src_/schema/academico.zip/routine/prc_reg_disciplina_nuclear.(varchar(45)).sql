CREATE PROCEDURE `prc_reg_disciplina_nuclear`(IN `NAME` VARCHAR(45))
  BEGIN
    IF (NAME=(SELECT  dicnu_desc FROM discnuclear DN WHERE UPPER(DN.dicnu_desc)=UPPER(NAME))) THEN
       select false as RESULT, 'Já existe esta disciplina nuclear.'as MESSAGE;
    ELSE
        INSERT INTO discnuclear(dicnu_desc)VALUES(NAME);
        select true as RESULT;
    END IF;
END