CREATE VIEW `ver_periodo` AS
  SELECT
    `p`.`periodo_id`   AS `ID`,
    `p`.`periodo_desc` AS `DESCRICAO`
  FROM `academico`.`periodo` `p`