CREATE PROCEDURE `rule_selection_delete_candidature`(IN `idVaga` INT(11), IN `idCandidatu` INT(11))
  BEGIN

    DECLARE position, vagas INTEGER;

    SELECT ca.candr_position, v.vaga_numero
    into position, vagas
    FROM candidature ca
      inner JOIN vaga v on ca.candr_vaga_id = v.vaga_id
    WHERE ca.candr_vaga_id = idVaga
          AND ca.candr_alu_id = idCandidatu;

    -- Remover o estidante da lista
    DELETE from candidature
    where candr_alu_id = idCandidatu
          and candr_vaga_id = idVaga;

    -- Atualizar das posicoes para essa vaga
    UPDATE candidature
    set candr_position = candr_position - 1
    where candr_position > position
          and candr_vaga_id = idVaga;

    -- Atualizar o resultado dos outrs candidatos dessa vaga
    UPDATE candidature
    set candr_alocation = (case
                           when candr_position <= vagas then b'1'
                           else b'0'
                           end)
    where candr_vaga_id = idVaga
          and candr_position >= position;

  END