CREATE PROCEDURE `prc_regcandidato`(IN `idUser` INT(4), IN `nome` VARCHAR(45), IN `apelido` VARCHAR(45),
                                    IN `dtNasc` DATE, IN `idSexo` INT(1))
  BEGIN
        INSERT INTO aluno_candidato
        (alu_name, alu_surname,alu_dtnasc, alu_sexo_id)
          VALUE( nome, apelido, dtNasc,idSexo);
        select true as 'RESULT', last_insert_id() as 'ALUNO.ID';

  END