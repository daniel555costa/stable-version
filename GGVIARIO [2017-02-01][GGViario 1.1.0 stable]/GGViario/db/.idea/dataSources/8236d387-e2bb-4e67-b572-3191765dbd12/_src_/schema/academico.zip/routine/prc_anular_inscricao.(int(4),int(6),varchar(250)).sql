CREATE PROCEDURE `prc_anular_inscricao`(IN `idUser` INT(4), IN `idCandidato` INT(6), IN `observacao` VARCHAR(250))
  BEGIN

        update inscricao
            set insc_state = -1, insc_observacao = observacao
          WHERE insc_alu_id = idCandidato;

     UPDATE notacertificado nota
        INNER JOIN inscricao insc on insc.insc_id = nota.nt_insc_id
      set nota.nt_state = -1
    WHERE insc.insc_state = -1;

    SELECT true as RESULT;

  END