CREATE VIEW `ver_all_user` AS
  SELECT
    `ca`.`alu_id`         AS `ID`,
    `u`.`udom_id`         AS `DOMAIN.ID`,
    `ca`.`alu_name`       AS `USER.NAME`,
    `ca`.`alu_surname`    AS `USER.SURNAME`,
    `ca`.`alu_accessname` AS `USER.ACCESSNAME`,
    `ca`.`alu_pwd`        AS `USER.PWD`,
    `ca`.`alu_dtreg`      AS `USER.DTREG`,
    `ca`.`alu_access`     AS `USER.ACCESS`,
    `u`.`udom_usertype`   AS `DOMAIN.TYPE`,
    `u`.`udom_domain`     AS `DOMAIN.DOMAIN`
  FROM (`academico`.`aluno_candidato` `ca`
    JOIN `academico`.`userdomain` `u` ON ((upper(`u`.`udom_usertype`) = 'STUD')))
  UNION (SELECT
           `u`.`user_id`           AS `user_id`,
           `u`.`user_udom_id`      AS `user_udom_id`,
           `u`.`user_name`         AS `user_name`,
           `u`.`user_surname`      AS `user_surname`,
           `u`.`user_accessname`   AS `user_accessname`,
           `u`.`user_pwd`          AS `user_pwd`,
           `u`.`user_dtreg`        AS `user_dtreg`,
           `u`.`user_state`        AS `user_state`,
           `udoma`.`udom_usertype` AS `udom_usertype`,
           `udoma`.`udom_domain`   AS `udom_domain`
         FROM (`academico`.`t_user` `u`
           JOIN `academico`.`userdomain` `udoma` ON ((`u`.`user_udom_id` = `udoma`.`udom_id`))))
  UNION (SELECT
           `d`.`do_id`               AS `do_id`,
           `ddomain`.`udom_id`       AS `udom_id`,
           `d`.`do_name`             AS `do_name`,
           `d`.`do_surname`          AS `do_surname`,
           `d`.`do_accessname`       AS `do_accessname`,
           `d`.`do_pwd`              AS `do_pwd`,
           `d`.`do_dtreg`            AS `do_dtreg`,
           `d`.`do_access`           AS `do_access`,
           `ddomain`.`udom_usertype` AS `udom_usertype`,
           `ddomain`.`udom_domain`   AS `udom_domain`
         FROM (`academico`.`docente` `d`
           JOIN `academico`.`userdomain` `ddomain` ON ((upper(`ddomain`.`udom_usertype`) = 'DOSC'))))