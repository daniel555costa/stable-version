CREATE PROCEDURE `prc_login`(IN `accessName` VARCHAR(32), IN `pwd` VARCHAR(32))
  BEGIN
    SELECT user.ID,
          user.`DOMAIN.ID`,
          user.`USER.NAME`,
          user.`USER.SURNAME`,
          user.`DOMAIN.TYPE`,
          user.`DOMAIN.DOMAIN`,
          user.`USER.ACCESSNAME`,
          user.`USER.ACCESS`,
          user.`USER.DTREG`,
          CASE 
            WHEN user.`USER.ACCESS` = 1 THEN 'Ativo'
            WHEN user.`USER.ACCESS` = 2 then 'Pré-ativo'
            ELSE NULL 
          END AS 'USER.ACCESS-DESC'
      
        FROM ver_all_user user
        WHERE upper(user.`USER.ACCESSNAME`) = upper(accessName) 
              AND  user.`USER.PWD` = md5(pwd)
              AND user.`USER.ACCESS` !=0;
  END