CREATE VIEW `ver_menu_structure` AS
  SELECT
    `me`.`mn_id`                            AS `mn_id`,
    `me`.`mn_code`                          AS `mn_code`,
    `me`.`mn_name`                          AS `mn_name`,
    `me`.`mn_level`                         AS `mn_level`,
    `me`.`mn_link`                          AS `mn_link`,
    `me`.`mn_uselink`                       AS `mn_uselink`,
    `me`.`mn_raiz`                          AS `mn_raiz`,
    `me`.`mn_state`                         AS `mn_state`,
    `me`.`mn_mn_id`                         AS `mn_mn_id`,
    `me`.`mn_udom_id`                       AS `mn_udom_id`,
    `u`.`udom_domain`                       AS `udom_domain`,
    `u`.`udom_usertype`                     AS `udom_usertype`,
    `mm`.`mn_code`                          AS `mn_mn_code`,
    `mm`.`mn_link`                          AS `mn_mn_link`,
    `mm`.`mn_name`                          AS `mn_mn_name`,
    (SELECT (CASE WHEN (count(0) > 0)
      THEN 1
             ELSE 0 END)
     FROM `academico`.`menu` `m`
     WHERE (`m`.`mn_mn_id` = `me`.`mn_id`)) AS `mn_haschidren`
  FROM ((`academico`.`menu` `me`
    JOIN `academico`.`userdomain` `u` ON ((`me`.`mn_udom_id` = `u`.`udom_id`))) LEFT JOIN `academico`.`menu` `mm`
      ON ((`me`.`mn_mn_id` = `mm`.`mn_id`)))
  ORDER BY `me`.`mn_raiz`