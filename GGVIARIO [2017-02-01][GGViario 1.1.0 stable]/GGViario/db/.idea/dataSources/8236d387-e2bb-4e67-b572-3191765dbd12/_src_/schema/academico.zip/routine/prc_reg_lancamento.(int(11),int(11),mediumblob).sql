CREATE PROCEDURE `prc_reg_lancamento`(IN `idDocente` INT(11), IN `idUser` INT(11), IN `fileLancamento` MEDIUMBLOB)
  BEGIN

   insert  into lancamento (
	  lanca_do_id,
      lanca_file,
      lanca_user_id
   )  values (
      idDocente,
      fileLancamento,
      idUser
   );

   SELECT TRUE AS RESULT,
      'SUCESS' AS MESSAGE,
      last_insert_id() AS 'LANCAMENTO.ID';
END