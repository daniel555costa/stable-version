CREATE VIEW `ver_vagas_disponiveis` AS
  SELECT
    `v`.`vaga_id`                                       AS `ID VAGA`,
    `c`.`cur_id`                                        AS `ID CURSO`,
    `c`.`cur_name`                                      AS `NOME CURSO`,
    `grau`.`grau_academico_desc`                        AS `GRAU ACADÉMICO`,
    `c`.`cur_saidasproficionais`                        AS `SAIDAS PROFESSIONAIS`,
    `v`.`vaga_numero`                                   AS `NÚMERO VAGA`,
    `v`.`vaga_datainicio`                               AS `DATA INICIO`,
    `v`.`vaga_datafim`                                  AS `DATA FIM`,
    `per`.`periodo_desc`                                AS `PERIODO`,
    concat(`ano`.`ano_inicial`, '/', `ano`.`ano_final`) AS `ANO LETIVO`,
    `v`.`vaga_dtreg`                                    AS `DATA REGISTO`
  FROM ((((`academico`.`curso` `c`
    JOIN `academico`.`vaga` `v` ON ((`c`.`cur_id` = `v`.`vaga_cur_id`))) JOIN `academico`.`anolectivo` `ano`
      ON ((`ano`.`ano_id` = `v`.`vaga_ano_id`))) JOIN `academico`.`grau_academico` `grau`
      ON ((`grau`.`grau_academico_id` = `c`.`grau_academico_id`))) JOIN `academico`.`periodo` `per`
      ON ((`per`.`periodo_id` = `v`.`periodo_id`)))
  WHERE (`v`.`vaga_state` = 1)