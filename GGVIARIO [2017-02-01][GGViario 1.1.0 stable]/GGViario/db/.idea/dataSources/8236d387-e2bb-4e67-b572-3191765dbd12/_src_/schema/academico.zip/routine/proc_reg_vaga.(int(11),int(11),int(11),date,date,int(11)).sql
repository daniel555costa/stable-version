CREATE PROCEDURE `proc_reg_vaga`(IN `ID_CURSO`    INT(11), IN `NUM_VAGA` INT(11), IN `ID_ANO_LECTIVO` INT(11),
                                 IN `DATA_INICIO` DATE, IN `DATA_FIM` DATE, IN `ID_PERIODO` INT(11))
  BEGIN
    INSERT INTO vaga(vaga_cur_id,
                     vaga_numero,
                     vaga_ano_id,
                     vaga_datainicio,
                     vaga_datafim,
                     periodo_id)VALUES(ID_CURSO,
                                       NUM_VAGA,
                                       ID_ANO_LECTIVO,
                                       DATA_INICIO,
                                       DATA_FIM,
                                       ID_PERIODO);
END