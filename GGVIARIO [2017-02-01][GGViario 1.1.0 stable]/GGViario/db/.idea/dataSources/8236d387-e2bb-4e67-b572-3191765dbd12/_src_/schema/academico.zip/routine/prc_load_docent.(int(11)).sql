CREATE PROCEDURE `prc_load_docent`(IN `idUnidadeOrganica` INT(11))
  BEGIN

  If idUnidadeOrganica is NOT NULL THEN

    -- Carregar os doccentes que possui hora em uma dada unidade organica
    SELECT d.do_id as 'id',
        d.do_name as 'name',
        d.do_surname as 'surname',
        concat(d.do_name, ' ', d.do_surname) as 'docent'
      from docente d;

  ELSE

    -- Carregar todos os docentes
    SELECT d.do_id as 'id',
           d.do_name as 'name',
           d.do_surname as 'surname',
           concat(d.do_name, ' ', d.do_surname) as 'docent'
    from docente d;
  end IF ;


END