CREATE FUNCTION `rule_selection_has_enter_possiblit`(`idCandidatu` INT(11), `idVaga` INT(11))
  RETURNS TINYINT(1)
BEGIN

        DECLARE totalConcorentes, totalVagasEsistentes, position INTEGER;

        SELECT ca.candr_position into position
        FROM candidature ca
        WHERE ca.candr_vaga_id = idVaga
              AND ca.candr_alu_id = idCandidatu;


        SELECT v.vaga_numero into totalVagasEsistentes
        from vaga v
        where v.vaga_id = idVaga;

        -- Carregar a quantidades de candidaturas com melhor posicao que do a cadidatura x
        -- E que estao como a segunda opcao sem serem colocada
        SELECT count(*) into totalConcorentes
        from candidature ca
        where  ca.candr_vaga_id = idVaga
               and candr_option = 2
               and ca.candr_position < position
               and ca.candr_state = 2
        ;


        -- Verificar se existe a probabilidade de que essa candidatura seja alocada
        RETURN (position - totalConcorentes  <= totalVagasEsistentes);

    END