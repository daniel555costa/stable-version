CREATE PROCEDURE `prc_reg_disciplina`(IN `CODIGO` INT(11), IN `NAME` VARCHAR(64))
  BEGIN
    IF (CODIGO=(SELECT disc_codigo FROM disciplina D WHERE D.disc_codigo=CODIGO))THEN
        select false as RESULT, 'Já existe disciplina com este código.' as MESSAGE;
    ELSEIF (NAME=(SELECT disc_name FROM disciplina DD WHERE UPPER(DD.disc_name)=NAME)) THEN
        SELECT FALSE AS RESULT,'Já existe disciplina com este nome.' AS MESSAGE;
    ELSE
        INSERT INTO disciplina(disc_codigo,
                               disc_name)VALUES(CODIGO,
                                                NAME);
        SELECT TRUE AS RESULT;
    END IF;
END