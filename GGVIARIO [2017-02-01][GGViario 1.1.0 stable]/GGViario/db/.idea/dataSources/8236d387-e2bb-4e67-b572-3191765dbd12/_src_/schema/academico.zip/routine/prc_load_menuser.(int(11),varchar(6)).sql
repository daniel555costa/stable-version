CREATE PROCEDURE `prc_load_menuser`(IN `idUser` INT(11), IN `typeDomain` VARCHAR(6))
  BEGIN
      if upper(typeDomain) in ('STUD', 'DOSC') THEN
        SELECT m.mn_id as 'ID',
               m.mn_name as 'NAME',
               SUBSTR(concat(md5(rand()*999999)), 1, 10) as 'CODE',
               m.mn_link as 'LINK',
               m.mn_mn_id as 'SUPER.ID',
               m.mn_mn_name as 'SUPER.NAME',
               m.mn_mn_code as 'SUPER.CODE',
               m.mn_mn_link as 'SUPER.LINK',
               m.mn_haschidren as 'MENU.HASCHILDREN',
               m.mn_level as 'MENU.LEVEL',
               m.mn_raiz as 'MENU.RAIZ',
               m.mn_uselink as 'MENU.USE-LINK'
            from ver_menu_structure m
            WHERE upper(m.udom_usertype) = upper(typeDomain);
      ELSE
        SELECT m.mn_id as 'ID',
             m.mn_name as 'NAME',
             SUBSTR(concat(md5(rand()*999999)), 1, 10) as 'CODE',
             m.mn_link as 'LINK',
             m.mn_mn_id as 'SUPER.ID',
             m.mn_mn_name as 'SUPER.NAME',
             m.mn_mn_code as 'SUPER.CODE',
             m.mn_mn_link as 'SUPER.LINK',
             m.mn_haschidren as 'MENU.HASCHILDREN',
             m.mn_level as 'MENU.LEVEL',
             m.mn_raiz as 'MENU.RAIZ',
             m.mn_uselink as 'MENU.USE-LINK'
          from ver_menu_structure m
            inner JOIN menuser muser on m.mn_id = muser.muser_mn_id
          where muser.muser_user_user = idUser;
      END IF;
  END