CREATE FUNCTION `funct_checkDoc`(`idTipoDoc` INT(4), `numeroDoc` VARCHAR(45))
  RETURNS INT(7)
BEGIN
    DECLARE idAluno int(6) DEFAULT 0;

    SELECT doc.doc_aluno_id into idAluno
        FROM documento doc
    WHERE doc.doc_tipodoc_id = idTipoDoc 
          and upper(doc.doc_numero) = upper(numeroDoc)
          and doc.doc_state = 1;
  
    RETURN idAluno;
  END