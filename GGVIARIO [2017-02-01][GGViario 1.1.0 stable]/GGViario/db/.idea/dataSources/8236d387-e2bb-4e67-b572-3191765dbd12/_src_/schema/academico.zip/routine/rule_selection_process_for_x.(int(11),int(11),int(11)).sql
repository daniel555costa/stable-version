CREATE PROCEDURE `rule_selection_process_for_x`(IN `idCandidatu` INT(11), IN `xIdVaga` INT(11), IN `xAlocation` INT(11))
  BEGIN
    -- DECLARE xVariable as variable of position 1

    IF xAlocation = b'1' THEN
      call `rule_selection_select_candidature`(idCandidatu, xIdVaga);

    ELSEIF NOT `rule_selection_has_enter_possiblit`(idCandidatu, xIdVaga) THEN
      call `rule_selection_suplente_candidature`(idCandidatu, xIdVaga);

    END IF;

  END