CREATE FUNCTION `funct_checkBI`(`bi` VARCHAR(12))
  RETURNS INT(11)
BEGIN
      DECLARE exist int(2);

      SELECT count(*) into exist
          from aluno_candidato alun
      where alun.alu_bi = bi;

       RETURN exist;
  END