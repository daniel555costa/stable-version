CREATE VIEW `ver_localidade` AS
  SELECT
    `local`.`local_id`   AS `ID`,
    `local`.`local_desc` AS `DESCRICAO`
  FROM `academico`.`localidade` `local`