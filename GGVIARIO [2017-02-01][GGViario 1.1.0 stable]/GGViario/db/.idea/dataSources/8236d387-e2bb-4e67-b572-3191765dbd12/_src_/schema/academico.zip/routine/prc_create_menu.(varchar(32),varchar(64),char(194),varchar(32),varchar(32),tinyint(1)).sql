CREATE PROCEDURE `prc_create_menu`(IN `cod`       VARCHAR(32), IN `menuName` VARCHAR(64), IN `link` CHAR(194),
                                   IN `domainKey` VARCHAR(32), IN `menuCodeSuper` VARCHAR(32), IN `useLink` TINYINT(1))
  BEGIN

  DECLARE mnSuperId INT(3) DEFAULT NULL ;
  DECLARE domainId INT(3);
  DECLARE  iCount INTEGER;
  DECLARE iCountSuper INTEGER DEFAULT 0;
  DECLARE superLevel INTEGER DEFAULT -1;
  DECLARE superRaiz CHARACTER VARYING(32) DEFAULT '';
  DECLARE ttRaiz INTEGER;
  DECLARE raiz CHARACTER VARYING(32);
  DECLARE menuLeve INTEGER DEFAULT 0;


  select count(*) into iCount
    from menu m
    where m.mn_code = cod;

  select count(*) into iCountSuper
    from menu m
    where m.mn_code = menuCodeSuper;

  if iCount = 0
    AND  (menuCodeSuper IS NULL OR (iCountSuper = 1)) then


    select count(*) into ttRaiz
      from menu m
      where m.mn_mn_id IS NULL;

    if menuCodeSuper IS NOT NULL THEN
      select m.mn_id,
          concat(m.mn_raiz,'.'),
          m.mn_level
        into mnSuperId,
            superRaiz,
            superLevel
      from menu m
      WHERE upper(m.mn_code) = upper(menuCodeSuper);

      select count(*) into ttRaiz
      from menu m
      where m.mn_mn_id = mnSuperId;

    END IF;

    set @rRaiz = CONCAT(ttRaiz,'');
    if length(@rRaiz) = 1 then set @rRaiz = concat('0', @rRaiz); end if;
    set raiz = concat(superRaiz,@rRaiz);
    set menuLeve = superLevel +1;


    SELECT udomain.udom_id into domainId
      from userdomain udomain
      WHERE upper(udomain.udom_usertype) = upper(domainKey);

    INSERT into menu(
      mn_name,
      mn_code,
      mn_link,
      mn_mn_id,
      mn_udom_id,
      mn_level,
      mn_raiz,
      mn_uselink
    )VALUES(
      menuName,
      cod,
      link,
      mnSuperId,
      domainId,
      menuLeve,
      raiz,
      useLink
    );
    select true as RESULT;
  else
    SELECT  false as RESULT;
  end if;
END