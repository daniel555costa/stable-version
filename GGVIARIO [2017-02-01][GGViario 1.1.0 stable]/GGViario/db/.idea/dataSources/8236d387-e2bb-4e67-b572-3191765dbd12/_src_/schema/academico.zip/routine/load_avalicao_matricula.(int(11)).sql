CREATE PROCEDURE `load_avalicao_matricula`(IN `idMatricula` INT(11))
  BEGIN
    SELECT
        ta.tpaval_desc AS 'AVALIACAO',
        a.avalia_nota AS 'NOTA'
      FROM avalicacao a
          INNER JOIN tipo_avalicao ta ON a.avalia_tpaval_id = ta.tpaval_id
    WHERE a.avalia_mat_id = idMatricula
      AND a.avalia_state = 1;
  END