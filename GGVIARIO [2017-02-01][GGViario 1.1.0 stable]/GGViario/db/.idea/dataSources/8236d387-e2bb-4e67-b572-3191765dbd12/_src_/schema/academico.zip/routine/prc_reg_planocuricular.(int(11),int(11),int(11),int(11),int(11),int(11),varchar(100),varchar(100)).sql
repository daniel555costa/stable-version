CREATE PROCEDURE `prc_reg_planocuricular`(IN `ID_CURSO`          INT(11), IN `ID_DISCIPLINA` INT(11),
                                          IN `ID_LEVEL`          INT(11), IN `ID_TIPO_DURACAO` INT(11),
                                          IN `ID_TIPO_OBRIGACAO` INT(11), IN `CARGA_HORARIA` INT(11),
                                          IN `UNIDADE_CREDITO`   VARCHAR(100), IN `PrECEDENCIA` VARCHAR(100))
  BEGIN
  IF (25<(SELECT SUM(p.plest_cargahoraria) FROM planoestudo p WHERE (p.plest_cur_id=ID_CURSO and p.plest_lev_id=ID_LEVEL and p.plest_tpd_id=ID_TIPO_DURACAO and p.plest_state=1))) THEN
     select false as RESULT, 'Limite de carga horaria excedida!' as MESSAGE;
  ELSEIF (ID_DISCIPLINA=(SELECT pp.plest_disc_id from planoestudo pp WHERE (pp.plest_cur_id=ID_CURSO and pp.plest_lev_id=ID_LEVEL and pp.plest_tpd_id=ID_TIPO_DURACAO and pp.plest_state=1))) THEN
     select FALSE  as RESULT, 'A disciplina já esta neste plano de estudo!' as MESSAGE;
  ELSE
    INSERT INTO planoestudo(plest_cur_id,
                            plest_disc_id,
                            plest_lev_id,
                            plest_tpd_id,
                            plest_tpob_id,
                            plest_cargahoraria,
                            plest_unidadecredito,
                            plest_precedencia)VALUES(ID_CURSO,
                                                     ID_DISCIPLINA,
                                                     ID_LEVEL,
                                                     ID_TIPO_DURACAO,
                                                     ID_TIPO_OBRIGACAO,
                                                     CARGA_HORARIA,
                                                     UNIDADE_CREDITO,
                                                     PrECEDENCIA);
    select true as RESULT;
  END IF;
END