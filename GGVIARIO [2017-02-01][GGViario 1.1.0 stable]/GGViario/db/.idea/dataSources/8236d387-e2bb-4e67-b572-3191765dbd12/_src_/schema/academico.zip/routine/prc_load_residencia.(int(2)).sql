CREATE PROCEDURE `prc_load_residencia`(IN `idDistrito` INT(2))
  BEGIN
      SELECT local.local_desc LOCALIDADE,
             local.local_id "ID LOCALIDADE"
          from distrito dist
               INNER JOIN localidade local ON dist.dist_id = local.local_dist_id
          WHERE dist.dist_id = idDistrito;
  END