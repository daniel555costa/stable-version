CREATE PROCEDURE `test`()
  BEGIN
    if exists(select *
        from test_b a 
        where (a.a_id, a.b_id) in (select b.b_id, b.a_id
                                    from test_b b)
    )
    then
      SELECT '1';
    END IF;
  END