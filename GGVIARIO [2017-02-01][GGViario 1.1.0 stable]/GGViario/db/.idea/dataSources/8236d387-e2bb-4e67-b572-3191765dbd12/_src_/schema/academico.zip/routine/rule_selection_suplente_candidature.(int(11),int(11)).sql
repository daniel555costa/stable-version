CREATE PROCEDURE `rule_selection_suplente_candidature`(IN `idCandidatu` INT(11), IN `xIdVaga` INT(11))
  BEGIN
    -- DECLARE xVariable as variable of option 1

    UPDATE candidature
    set candr_state = 0
    WHERE candr_alu_id = idCandidatu
          AND candr_vaga_id = xIdVaga;
  END