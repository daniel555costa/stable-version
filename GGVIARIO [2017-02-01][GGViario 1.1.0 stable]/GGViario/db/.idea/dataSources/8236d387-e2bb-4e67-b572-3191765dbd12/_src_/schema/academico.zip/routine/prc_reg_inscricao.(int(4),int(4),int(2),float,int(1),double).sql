CREATE PROCEDURE `prc_reg_inscricao`(IN `idUser`  INT(4), IN `idAluno` INT(4), IN `idCurso` INT(2), IN `media` FLOAT,
                                     IN `optione` INT(1), IN `desvioPadrao` DOUBLE)
  BEGIN
    -- estado 0 = NÃO SELECIONADO
    -- estado 1 = SELECIONADO
    -- estado 2 = PRE-INSCRITO
    DECLARE contInc INT;
    DECLARE idVaga INT;

    SELECT vaga_id into idVaga
    FROM vaga
    WHERE vaga_cur_id = idCurso AND vaga_state = 1;


    SELECT count(*) into contInc
      from vaga v
      INNER JOIN anolectivo ano on ano.ano_id = v.vaga_ano_id
      INNER JOIN inscricao insc
    where insc.insc_alu_id = idAluno;

    if(contInc > 2) THEN
      select FALSE as 'RESULT', 'Já foi inscrito neste ano letivo.' as 'MESSAGE';
    ELSE
      INSERT INTO inscricao
      (
        insc_alu_id,
        insc_vaga_id,
        insc_result,
        insc_mediacertificad,
        insc_option,
        insc_desviopadraomedia
      )
        VALUE(
        idAluno,
        idVaga,
        1,
        media,
        optione,
        desvioPadrao
      );
      select true as 'RESULT', last_insert_id() as 'INSCRICAO.ID';
    END IF;
  END