CREATE VIEW `ver_grau_academico` AS
  SELECT
    `grau`.`grau_academico_id`   AS `ID`,
    `grau`.`grau_academico_desc` AS `DESCRICAO`
  FROM `academico`.`grau_academico` `grau`