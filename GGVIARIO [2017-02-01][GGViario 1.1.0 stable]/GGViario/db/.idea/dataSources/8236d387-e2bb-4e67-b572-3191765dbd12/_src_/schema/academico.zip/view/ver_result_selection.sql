CREATE VIEW `ver_result_selection` AS
  SELECT
    `ca`.`candr_id`                                       AS `ID`,
    `v`.`vaga_id`                                         AS `VAGA.ID`,
    `al`.`alu_id`                                         AS `ALUNO.ID`,
    `al`.`alu_name`                                       AS `NAME`,
    `al`.`alu_surname`                                    AS `SURNAME`,
    `age`(`al`.`alu_dtnasc`)                              AS `AGE`,
    `s`.`sexo_desc`                                       AS `SEXO`,
    `c`.`cur_name`                                        AS `CURSO`,
    `c`.`cur_id`                                          AS `CURSO.ID`,
    `ca`.`candr_valuecandidate`                           AS `VALOR`,
    concat(`ca`.`candr_position`, '/', `v`.`vaga_numero`) AS `POSICAO`,
    concat(`ca`.`candr_option`, 'ª')                      AS `OPCAO`,
    (CASE WHEN (`ca`.`candr_state` = 0)
      THEN 'SUPLENTE'
     WHEN (`ca`.`candr_state` = 1)
       THEN 'SELECIONADO'
     WHEN (`ca`.`candr_state` = 2)
       THEN 'PENDENTE'
     WHEN (`ca`.`candr_state` = -(1))
       THEN 'REMOVIDO'
     ELSE 'ELSE' END)                                     AS `RESULTADO`,
    `ca`.`candr_alocation`                                AS `alocation`
  FROM ((((`academico`.`candidature` `ca`
    JOIN `academico`.`aluno_candidato` `al` ON ((`ca`.`candr_alu_id` = `al`.`alu_id`))) JOIN `academico`.`vaga` `v`
      ON ((`ca`.`candr_vaga_id` = `v`.`vaga_id`))) JOIN `academico`.`curso` `c`
      ON ((`v`.`vaga_cur_id` = `c`.`cur_id`))) JOIN `academico`.`sexo` `s` ON ((`al`.`alu_sexo_id` = `s`.`sexo_id`)))
  ORDER BY `ca`.`candr_id`