CREATE PROCEDURE `prc_regcontato`(IN `idAluno` INT(5), IN `nome` VARCHAR(15), IN `contacto` VARCHAR(48))
  BEGIN
    DECLARE nomeContactoExist INT;
    DECLARE idTypeContact INT;
    DECLARE idAlunoExist INT(5) DEFAULT 0;

    SELECT COUNT(*) INTO nomeContactoExist
    FROM typecontacto type
    WHERE type.tpcont_desc = nome;

    SELECT max(co.cont_alu_id) into idAlunoExist
        from contacto co
    WHERE co.cont_alu_id = idAluno
          and co.cont_state = 1
          and co.cont_tpcont_id= 1;

    IF nomeContactoExist >0 THEN  -- verifica -se o nome de contacto já existe
      SELECT type.tpcont_id INTO idTypeContact
      FROM typecontacto type
      WHERE type.tpcont_desc = nome;

      if idAlunoExist = 0 then
          INSERT INTO contacto
          (cont_alu_id, cont_contacto, cont_tpcont_id) VALUES(idAluno, contacto, idTypeContact);
      else
          UPDATE contacto
              set cont_contacto = contacto,
              cont_tpcont_id = idTypeContact
          WHERE cont_alu_id = idAluno;
      END IF;
    ELSE
      INSERT INTO typecontacto (tpcont_desc) VALUES (nome);
      SELECT type.tpcont_id INTO idTypeContact
      FROM typecontacto type
      WHERE type.tpcont_desc = nome;
      if idAlunoExist = 0 then
           INSERT INTO contacto (cont_alu_id, cont_contacto, cont_tpcont_id)VALUES(idAluno, contacto, idTypeContact);
      ELSE
         UPDATE contacto
            set cont_contacto = contacto,
            cont_tpcont_id = idTypeContact
        WHERE cont_alu_id = idAluno;
        END IF;
    END IF;

    SELECT TRUE as RESULT;
  END