CREATE PROCEDURE `proc_insert_type_service`(IN `descrico` VARCHAR(32))
  BEGIN
 
 			INSERT INTO type_service  (tser_id, tser_desc)
 			VALUES(descrico); 
   
END