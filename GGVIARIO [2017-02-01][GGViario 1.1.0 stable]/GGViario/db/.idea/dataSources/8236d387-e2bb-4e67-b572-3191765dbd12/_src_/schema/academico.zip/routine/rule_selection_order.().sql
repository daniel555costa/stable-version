CREATE PROCEDURE `rule_selection_order`()
  BEGIN

    -- Definir as candidaturas que iram para selecao
    -- As candidatura que que nao tem os requisitos minimos serao reprovados des de ja

    DECLARE done BOOLEAN DEFAULT FALSE;
    DECLARE idStudent, idVaga, vOption, nota, lastVaga, curentPosition, vagasAvalible INTEGER;
    DECLARE nota1, vagaMinNota REAL;
    DECLARE candidate_cursor cursor for
      select alu_id,
             vaga_id,
             ins_opcao,
             ins_nota
        from ver_inicial_incricion;

    DECLARE continue handler for not found set done = true;

    DELETE FROM candidature;
    ALTER TABLE candidature AUTO_INCREMENT = 1;
    DROP table IF EXISTS  selection_order;

    SET lastVaga = -1;
    set curentPosition = 1;

    OPEN candidate_cursor;

    read_candidate: LOOP

      FETCH candidate_cursor INTO  idStudent, idVaga, vOption, nota;
      if done then LEAVE read_candidate; end if;

      -- Quando mundar da lista de vagas caregar o munero de vagas disponivel assim como a nota minima desejada
      if lastVaga != idVaga  then
        SET  lastVaga = idVaga;
        set curentPosition = 1;

        select vaga_numero, 10
        into vagasAvalible, vagaMinNota
        from vaga
        where vaga_id = idVaga;
      END IF;

      -- A candidatura so ira para selecao se tiver a nota monima desejada
      IF nota >=  vagaMinNota then

        INSERT  INTO candidature (
          candr_alu_id,
          candr_vaga_id,
          candr_option,
          candr_valuecandidate,
          candr_position,
          candr_alocation
        ) values (
          idStudent,
          idVaga,
          vOption,
          nota,
          curentPosition,
          (case when curentPosition <= vagasAvalible then b'1' ELSE b'0' end)
        );

        set curentPosition = curentPosition + 1;
      end if;

    END LOOP;

    CLOSE candidate_cursor;
    CREATE TABLE  selection_order as select * from ver_result_selection;

    SELECT  * from ver_result_selection;

  end