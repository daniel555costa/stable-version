CREATE VIEW `ver_docente` AS
  SELECT
    `d`.`do_id`                                  AS `ID`,
    concat(`d`.`do_name`, ' ', `d`.`do_surname`) AS `NAME`
  FROM `academico`.`docente` `d`