CREATE PROCEDURE `prc_reg_menu`(IN `menuName`      VARCHAR(32), IN `menuCode` VARCHAR(32), IN `menuLink` VARCHAR(64),
                                IN `menuCodeSuper` VARCHAR(32), IN `domainCode` VARCHAR(6))
  BEGIN 
    DECLARE mnSuperId INT(3) DEFAULT NULL ;
    DECLARE domainId INT(3);
    
    if menuCodeSuper IS NOT NULL THEN 
        select m.mn_id into menuCodeSuper
            from menu m
            WHERE upper(m.mn_code) = upper(menuCodeSuper);
    END IF;
    
    SELECT udomain.udom_id into domainId
        from userdomain udomain
        WHERE upper(udomain.udom_usertype) = upper(domainCode);
    
    INSERT into menu(
      mn_name, 
      mn_code,
      mn_link,
      mn_mn_id,
      mn_udom_id
    )VALUES(
       menuName,
       menuCode,
       menuLink,
       mnSuperId,
       domainId
    );
    select true as RESULT;
  END