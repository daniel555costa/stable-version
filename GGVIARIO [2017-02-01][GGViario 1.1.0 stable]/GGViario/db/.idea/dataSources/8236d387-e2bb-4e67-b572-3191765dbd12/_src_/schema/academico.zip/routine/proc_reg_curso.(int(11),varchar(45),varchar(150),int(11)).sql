CREATE PROCEDURE `proc_reg_curso`(IN `ID_DEPARTAMENTO`     INT(11), IN `CURSO_NAME` VARCHAR(45),
                                  IN `SAIDAS_PROFICIONAIS` VARCHAR(150), IN `ID_GRAU_ACADEMICO` INT(11))
  BEGIN
  IF (CURSO_NAME=(SELECT cur_name FROM curso C WHERE UPPER(cur_name)=UPPER(CURSO_NAME))) THEN
    SELECT FALSE AS RESULT, "Já existe curso com este nome!" AS MESSAGE;
  ELSE
    INSERT INTO curso(cur_dep_id,
                      cur_name,
                      cur_saidasproficionais,
                      grau_academico_id)VALUES(ID_DEPARTAMENTO,
                                               CURSO_NAME,
                                               SAIDAS_PROFICIONAIS,
                                               ID_GRAU_ACADEMICO);
    SELECT TRUE AS RESULT, "True sucesso!" AS MESSAGE;
  END IF;
END