CREATE VIEW `ver_aluno_exame` AS
  SELECT
    `al`.`alu_id`                                      AS `ID_ALUNO`,
    concat_ws('', `al`.`alu_name`, `al`.`alu_surname`) AS `NOME_DO_ALUNO`,
    `d`.`disc_name`                                    AS `NOME_DISCIPLINA`,
    `av`.`avalia_nota`                                 AS `NOTA`,
    `l`.`lev_desc`                                     AS `ANO`
  FROM (((((`academico`.`avalicacao` `av`
    JOIN `academico`.`matricula` `m` ON ((`av`.`avalia_mat_id` = `m`.`mat_id`))) JOIN `academico`.`aluno_candidato` `al`
      ON ((`av`.`avalia_mat_id` = `m`.`mat_id`))) JOIN `academico`.`planoestudo` `pl`
      ON ((`pl`.`plest_id` = `m`.`mat_plest_id`))) JOIN `academico`.`disciplina` `d`
      ON ((`d`.`disc_codigo` = `pl`.`plest_disc_id`))) JOIN `academico`.`level` `l`
      ON ((`l`.`lev_id` = `pl`.`plest_lev_id`)))
  WHERE ((`av`.`avalia_state` = 1) AND (`av`.`avalia_nota` < 10))