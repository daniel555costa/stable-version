CREATE FUNCTION `rule_selection_count_candidature_of`(`idCandidatu` INT(11))
  RETURNS INT(11)
BEGIN
    RETURN (SELECT COUNT(*)
            FROM candidature ca
            WHERE ca.candr_alu_id = idCandidatu);
  END