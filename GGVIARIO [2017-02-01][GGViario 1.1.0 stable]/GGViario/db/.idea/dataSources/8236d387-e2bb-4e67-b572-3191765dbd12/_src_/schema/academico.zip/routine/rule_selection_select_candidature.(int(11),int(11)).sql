CREATE PROCEDURE `rule_selection_select_candidature`(IN `idCandidatu` INT(11), IN `idVaga` INT(11))
  BEGIN

    update candidature
    set candr_state = 1
    where candr_alu_id = idCandidatu
          and candr_vaga_id = idVaga;
  END