CREATE VIEW `ver_inicial_incricion` AS
  SELECT
    `a`.`alu_id`                 AS `alu_id`,
    `a`.`alu_name`               AS `alu_nome`,
    `a`.`alu_surname`            AS `alu_surname`,
    `c`.`cur_name`               AS `vaga_name`,
    `ins`.`insc_option`          AS `ins_opcao`,
    `ins`.`insc_mediacertificad` AS `ins_nota`,
    `v`.`vaga_id`                AS `vaga_id`
  FROM (((`academico`.`aluno_candidato` `a`
    JOIN `academico`.`inscricao` `ins` ON ((`a`.`alu_id` = `ins`.`insc_alu_id`))) JOIN `academico`.`vaga` `v`
      ON ((`ins`.`insc_vaga_id` = `v`.`vaga_id`))) JOIN `academico`.`curso` `c` ON ((`v`.`vaga_cur_id` = `c`.`cur_id`)))
  WHERE (`ins`.`insc_state` = 2)
  ORDER BY `v`.`vaga_id`, `ins`.`insc_mediacertificad` DESC, `a`.`alu_dtnasc`, `ins`.`insc_desviopadraomedia`