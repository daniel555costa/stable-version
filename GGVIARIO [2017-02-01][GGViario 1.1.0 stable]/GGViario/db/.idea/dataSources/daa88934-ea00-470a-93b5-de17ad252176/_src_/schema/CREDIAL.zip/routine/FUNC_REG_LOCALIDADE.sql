create FUNCTION FUNC_REG_LOCALIDADE 
(
   idUser NUMBER,
   idAgencia NUMBER,
   descricao CHARACTER VARYING,
   algoOd CHARACTER VARYING   
)
RETURN CHARACTER VARYING
IS
   ttLocalidade NUMBER;
BEGIN
   SELECT count(*) INTO ttLocalidade
      FROM LOCALIDADE l
      WHERE UPPER(l.LOCAL_DESIG) = UPPER(descricao);
      
   IF ttLocalidade = 0 THEN
       INSERT INTO LOCALIDADE(LOCAL_DESIG,
                              LOCAL_ALGO_OD,
                              LOCAL_AGE_ID,
                              LOCAL_USER_ID)
                              VALUES(descricao,
                                     algoOd,
                                     idAgencia,
                                     idUser);
    ELSE                             
       UPDATE LOCALIDADE L
          SET L.LOCAL_STATE = 1,
              L.LOCAL_DESIG = descricao
          WHERE UPPER(L.LOCAL_DESIG) = UPPER(descricao)
             AND ROWNUM <= 1;
   END IF;
   
   RETURN 'true;Sucess';
END;