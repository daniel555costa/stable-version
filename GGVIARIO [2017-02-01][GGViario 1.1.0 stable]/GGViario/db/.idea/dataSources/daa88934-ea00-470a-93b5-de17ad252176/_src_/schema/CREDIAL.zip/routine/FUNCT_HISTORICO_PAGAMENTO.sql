create FUNCTION  FUNCT_HISTORICO_PAGAMENTO 
(
    ID_CREDITO VARCHAR2,
    idAgencia NUMBER
) RETURN PACK_VIEW.FilterHistoricoPagamento  PIPELINED
  IS
  BEGIN
      /**
          Amortizacao do pagamento do credito do cliente
      */
      FOR H IN (SELECT * 
                   FROM VER_HISTORICOPAGAMENTO  h
                   WHERE h.CREDITO = ID_CREDITO
                      AND h."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN h."ID AGENCIA" ELSE idAgencia END)) LOOP
        H.REEMBOSO := PACK_LIB.MONEY(h.REEMBOSO, '');
        H."PRESTAÇÃO PAGA" := PACK_LIB.MONEY(h."PRESTAÇÃO PAGA", '');
        
        PIPE ROW(H);
      END LOOP;
  END;