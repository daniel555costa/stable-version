create FUNCTION FUNC_MD5 
(
    senha VARCHAR2
) RETURN VARCHAR2
IS
    hexkey VARCHAR2(32) := null;
    v_input VARCHAR2(4000) := senha;
BEGIN
   hexkey := rawtohex(dbms_obfuscation_toolkit.md5(input => utl_raw.cast_to_raw(v_input)));
   return nvl(hexkey,'');
END;