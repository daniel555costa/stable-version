create FUNCTION FUNCT_LOAD_REQ_COBRANCA 
(
    dataInicio DATE,
    dataFim DATE,
    idTipoCredito NUMBER,
    idBanco NUMBER,
    quantidadeAnoSubtrair NUMBER,
    idAgencia NUMBER
)RETURN PACK_VIEW.FilterCobranca PIPELINED
IS
   dataInicioPast VARCHAR2(10) := TO_CHAR(dataInicio, 'DD')||'-'||TO_CHAR(dataInicio, 'MM')||'-'|| (TO_NUMBER(TO_CHAR(dataInicio, 'YYYY'))-quantidadeAnoSubtrair);
   dataFimPast VARCHAR2(10) := TO_CHAR(dataFim, 'DD')||'-'||TO_CHAR(dataFim, 'MM')||'-'|| (TO_NUMBER(TO_CHAR(dataFim, 'YYYY'))-quantidadeAnoSubtrair);
   
   sumValorCreditoDT FLOAT := 0;
   sumDividaDT FLOAT := 0;
   sumTaegDT FLOAT := 0;
   
   sumValorCreditoOld FLOAT := 0;
   sumDividaOld FLOAT := 0;
   sumTaegOld FLOAT := 0;
   
   linhaSomatorioAno VER_COBRANCA_PAGAMENTO%ROWTYPE;
   linhaSomatorioOld VER_COBRANCA_PAGAMENTO%ROWTYPE;
BEGIN
    -- Essa funcao serve para listar todas as cobrancas que foram sendo feita em um intervalo de tempo
      -- Carregar todos as cobranca no intervalo indicado  null banco indicado null tipo do credito indicado
        -- Atenção que as cobranças correspondem ao pagamentos feito
    -- No final deve ser somado o valor de totas essas cobrancas feitas
    FOR I IN(SELECT * 
                FROM VER_COBRANCA_PAGAMENTO I
                WHERE I."DATA DOC PAGAMENTO" BETWEEN dataInicio AND dataFim
                   AND I."ID BANCO REAL" = idBanco
                   AND I."TIPO CREDITO" = idTipoCredito
                   AND I."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN  I."ID AGENCIA" ELSE idAgencia END)
                 ) LOOP
        -- Calcular o somatorio de todos os valores de reenbolso
        sumValorCreditoDT := sumValorCreditoDT + I.REMBOLSO;
        
        I.REMBOLSO := PACK_LIB.money(I.REMBOLSO, '');
        PIPE ROW(I);
    END LOOP;
    
    -- Aplicar o valor do somatorio no resultado da seleção
    linhaSomatorioAno.NIF := 'TOTAL';
    linhaSomatorioAno.REMBOLSO := PACK_LIB.money(sumValorCreditoDT, '');
    PIPE ROW(linhaSomatorioAno);
    
    -- Quando for disponibilizado a diferenca do ano enta deves efetuar um somatorio de todas as cobrancas feita no
      -- intervalo indicado mais aplicando a diferenca exemplo
            -- SE FOR DE 10-11-2015 PARA 10-12-2015 COM DIFERENCA = 2
            -- ENTÃO SERA 10-11-2013 PARA 10-12-2013 DIFERENCA de 2 Anos
    IF quantidadeAnoSubtrair  IS  NOT NULL AND quantidadeAnoSubtrair>0 THEN
        sumValorCreditoDT := 0;
        sumDividaDT  := 0;
        sumTaegDT := 0;
        
       -- Utilizar o for loop ao envez de select sum para evitar os problemas de no data found
       FOR I IN( SELECT *
                    FROM VER_COBRANCA_PAGAMENTO I
                    WHERE I."DATA DOC PAGAMENTO" BETWEEN TO_DATE(dataInicioPast, 'DD-MM-YYYY') 
                                                      AND TO_DATE(dataFimPast, 'DD-MM-YYYY')
                        AND I."ID BANCO REAL" = idBanco
                        AND I."TIPO CREDITO" = idTipoCredito
                        AND I."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN I."ID AGENCIA" ELSE idAgencia END)
                        ) LOOP
            -- Calcular o somatorio de todos os valores de reenbolso
            sumValorCreditoDT := sumValorCreditoDT + I.REMBOLSO;
        END LOOP;
        -- Colocar o somatorio do ano passado na ultima linha de reultado
        linhaSomatorioOld.NIF := quantidadeAnoSubtrair||' ANOS';
        linhaSomatorioOld.REMBOLSO := PACK_LIB.money(sumValorCreditoDT, '');
        PIPE ROW(linhaSomatorioOld);
    END IF;
    
    IF quantidadeAnoSubtrair  IS NULL OR quantidadeAnoSubtrair=0 THEN
       PIPE ROW(linhaSomatorioAno);
    END IF;
END;