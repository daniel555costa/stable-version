create FUNCTION  FUNCT_LOAD_CONTACREDITO 
(
    dataInicio DATE,
    dataFim DATE,
    anuSubtrair NUMBER,
    idLocalTrabalho NUMBER,
    idAgencia NUMBER
    
)RETURN PACK_VIEW.FilterContaCreditoCliente PIPELINED
IS
   -- Criar data inicio do ano antido
   sDataInicio VARCHAR(10) := TO_CHAR(dataInicio, 'DD')||'-'||TO_CHAR(dataInicio, 'MM')||'-'|| (TO_NUMBER(TO_CHAR(dataInicio, 'YYYY'))-anuSubtrair);
   
   -- Criar a data fim do ano anterior
   sDataFim VARCHAR2(10) := TO_CHAR(dataFim, 'DD')||'-'||TO_CHAR(dataFim, 'MM')||'-'|| (TO_NUMBER(TO_CHAR(dataFim, 'YYYY'))-anuSubtrair);
   
   totalCreditoData NUMBER;
   totalCreditoOther NUMBER;
   diferencaData NUMBER;
   linhaSomatorio VER_CONTARCREDITO_CLIENTE%ROWTYPE;
   
   countNumber NUMBER := 0 ; 
BEGIN
    
    linhaSomatorio."VALOR DATA" := 0;
    linhaSomatorio."VALOR ANTIGO" := 0;
    linhaSomatorio."DIFIFERENCA VALOR" := 0;
    FOR I IN (SELECT * 
                  FROM VER_CONTARCREDITO_CLIENTE VCL
                      WHERE VCL.LOCALIDADE = idLocalTrabalho) LOOP
        -- Buscar o total dos credito para a data forncida
        SELECT COUNT(*) INTO 
              totalCreditoData
            FROM CERDITO CD
            WHERE  CD.CREDI_DOS_NIF = I.NIF
                AND CD.CREDI_DATAINI BETWEEN dataInicio AND dataFim
                AND CD.CREDI_AGE_ID = (CASE WHEN idAgencia IS NULL THEN CD.CREDI_AGE_ID ELSE idAgencia END );
                
                
         -- Buscar o total dos credito para a data forncida antiga
        SELECT COUNT(*) INTO 
              totalCreditoOther
            FROM CERDITO CD
            WHERE  CD.CREDI_DOS_NIF = I.NIF
                AND CD.CREDI_DATAINI BETWEEN TO_DATE(sDataInicio, 'DD-MM-YYYY') AND TO_DATE(sDataFim, 'DD-MM-YYYY')
                AND CD.CREDI_AGE_ID = (CASE WHEN idAgencia IS NULL THEN CD.CREDI_AGE_ID ELSE idAgencia END);
        
        -- Calcular a diferenca entre a data fornecida e a outra data
        diferencaData :=  totalCreditoData - totalCreditoOther;
        
        I."VALOR DATA" := totalCreditoData;
        I."VALOR ANTIGO" := totalCreditoOther;
        I."DIFIFERENCA VALOR" := diferencaData;
        
        IF diferencaData >0 THEN
            I."VALOR DATA" := (I."VALOR DATA");
            I."VALOR ANTIGO" := (I."VALOR ANTIGO");
            I."DIFIFERENCA VALOR" := (I."DIFIFERENCA VALOR");
            
            linhaSomatorio."VALOR DATA" := linhaSomatorio."VALOR DATA" + totalCreditoData;
            linhaSomatorio."VALOR ANTIGO" := linhaSomatorio."VALOR ANTIGO" +  totalCreditoOther;
            linhaSomatorio."DIFIFERENCA VALOR" := linhaSomatorio."DIFIFERENCA VALOR" + diferencaData;
            
            countNumber := countNumber + 1;
            PIPE ROW(I);
        END IF;
    END LOOP;
    
    linhaSomatorio."VALOR DATA" := (linhaSomatorio."VALOR DATA");
    linhaSomatorio."VALOR ANTIGO" := (linhaSomatorio."VALOR ANTIGO");
    linhaSomatorio."DIFIFERENCA VALOR" := (linhaSomatorio."DIFIFERENCA VALOR");
    linhaSomatorio.NIF := 'TOTAL '||countNumber;
    
    PIPE ROW(linhaSomatorio);
    
END;