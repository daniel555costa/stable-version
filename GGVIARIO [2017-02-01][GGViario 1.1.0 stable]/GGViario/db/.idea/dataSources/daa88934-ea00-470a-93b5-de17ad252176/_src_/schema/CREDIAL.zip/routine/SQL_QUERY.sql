create FUNCTION SQL_QUERY 
( 
   p_address in  v$sqltext.address%type,
   p_hash_value in v$sqltext.hash_value%type
) return varchar2
as
   l_text  long;
begin
   for x in (select sql_text 
                from v$sqltext 
                where address = p_address 
                   and hash_value = p_hash_value 
                   order by piece )
   loop
      l_text := l_text || x.sql_text;
      exit when length(l_text) > 4000;
   end loop;
   return substr( l_text, 1, 4000 );
end;