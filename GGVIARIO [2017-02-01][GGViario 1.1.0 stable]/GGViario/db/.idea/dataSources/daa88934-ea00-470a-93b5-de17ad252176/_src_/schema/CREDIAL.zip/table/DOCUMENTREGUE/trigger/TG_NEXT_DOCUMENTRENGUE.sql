create trigger TG_NEXT_DOCUMENTRENGUE
	before insert
	on DOCUMENTREGUE
	for each row
BEGIN
  IF inserting
  THEN
    IF :NEW."DOCENTR_ID" IS NULL
    THEN
      SELECT SEQ_DOCUMENTETREGUE.NEXTVAL
        INTO :NEW."DOCENTR_ID"
        FROM dual;
    END IF;
  END IF;
END;
