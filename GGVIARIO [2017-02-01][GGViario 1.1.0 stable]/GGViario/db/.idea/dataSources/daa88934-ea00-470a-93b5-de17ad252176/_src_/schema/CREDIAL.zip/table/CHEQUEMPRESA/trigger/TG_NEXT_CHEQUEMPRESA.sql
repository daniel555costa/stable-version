create trigger TG_NEXT_CHEQUEMPRESA
	before insert
	on CHEQUEMPRESA
	for each row
BEGIN
  IF inserting
  THEN
    IF :NEW."CHEQ_ID" IS NULL
    THEN
      SELECT SEQ_CHEQUEMPRESA.NEXTVAL
        INTO :NEW."CHEQ_ID"
        FROM dual;
    END IF;
  END IF;
END;
