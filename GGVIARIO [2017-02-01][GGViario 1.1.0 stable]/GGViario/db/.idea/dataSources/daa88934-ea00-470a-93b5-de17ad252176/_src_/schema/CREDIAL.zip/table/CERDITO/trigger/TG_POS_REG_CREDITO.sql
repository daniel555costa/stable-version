create trigger TG_POS_REG_CREDITO
	after insert
	on CERDITO
	for each row
BEGIN
  
  
  /**
     Quando a requisicao for eliminada siginifica que o cheque foi utilizado em um credito
     Nesse caso depois de eliminar a requisicao deve:
     Diminuir o verdadeiro saldo da conta bancaria
 */
  --Repor o valor antigo e retirar o novo valor



  -- Remover o numero de cheque fornecido da endidade temporaria
  DELETE FROM REQUISICAOCHEQUE r
    WHERE r.REQCHEQ_CODIGO = :NEW.CREDI_NUMCHEQUE
      AND r.REQCHEQ_CHEQ_ID = :NEW.CREDI_CHEQ_ID;

  -- Incrementar os cheques destribuidos
  UPDATE CHEQUEMPRESA c
      SET c.CHEQ_ESTADO = (CASE WHEN c.CHEQ_TOTALCHEQUES = c.CHEQ_TOTALDISTRIBUIDOS+1 THEN 0 ELSE c.CHEQ_ESTADO END),
          c.CHEQ_TOTALDISTRIBUIDOS = c.CHEQ_TOTALDISTRIBUIDOS + 1
      WHERE c.CHEQ_ID = :NEW.CREDI_CHEQ_ID;
END;
