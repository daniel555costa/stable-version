create FUNCTION  FUNC_GET_DOCPAGAMENTO 
( -- RETORNO SEPARADO POR ;
  -- Primeira posicao Numero do documebnto
    -- Segunda posicao Id banco
    idPagamento NUMBER
)
RETURN VARCHAR2
IS
   res VARCHAR2(50);
BEGIN
   SELECT
        p.PAGA_NUMDOCPAGAMENTO||';'||p.PAGA_BANCO_ID||';'||(p.PAGA_REEMBOLSO - p.PAGA_PRESTACAO)||';'||idPagamento
          INTO res
      FROM PAGAMENTO p
      WHERE p.PAGA_ID = idPagamento;
  RETURN res;
END;