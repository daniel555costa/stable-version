create FUNCTION "FUNC_REG_TRACEDOSSIER" 
(
  USUARIO     VARCHAR2,
  NIF         VARCHAR2,
  NUMERO_CAPA VARCHAR2,
  MES         VARCHAR2,
  ANO         VARCHAR2,
  LETRA       VARCHAR2,
  SEQUENCIA   VARCHAR2,
  idAgencia NUMBER
)
  RETURN VARCHAR2
  IS
    TT NUMBER;
  BEGIN
    SELECT COUNT(*)
      INTO TT
      FROM DOSSIERCLIENTE d
      WHERE UPPER(d.DOS_NIF) = UPPER(NIF);
    IF TT != 1
    THEN
      RETURN 'Dossier o cliente nao existe!';
    END IF;
    -- DESATIVAR O REGISTRO ANTIGO
    UPDATE TRACEDOSSIER
      SET TRADO_ESTADO = 0
      WHERE TRADO_DOS_NIF = NIF
      AND TRADO_ESTADO = 1;

    -- CRIANDO NOVO REGISTRO
    INSERT INTO TRACEDOSSIER (TRADO_DOS_NIF,
                              TRADO_NUMCAPA,
                              TRADO_MES,
                              TRADO_ANO,
                              TRADO_LETRA,
                              TRADO_SEQUENCIA,
                              TRADO_USER_ID,
                              TRADO_AGE_ID)
                              VALUES (NIF,
                                      NUMERO_CAPA,
                                      MES,
                                      ANO,
                                      LETRA,
                                      SEQUENCIA,
                                      USUARIO,
                                      idAgencia);

    RETURN 'true';
  END;