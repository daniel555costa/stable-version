create PROCEDURE PRC_USER_ACTVIE 
(
   userNif VARCHAR2,
   userNewPwd VARCHAR2
)
IS
   tt NUMBER;
BEGIN
   UPDATE T_USER U
      SET U.USER_ACCESS = 1,
          U.USER_PWD = FUNC_MD5(userNewPwd)
      WHERE U.USER_ACCESS = 2
         AND U.USER_ID = userNif
         AND U.USER_PWD= FUNC_MD5(userNif);
END;