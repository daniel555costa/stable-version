create PACKAGE BODY PACK_REGRAS 
  IS

  -- FUNCAO PARA OBTER O SEGURO ACTIVO
  FUNCTION PFUNC_GET_SEGURO_ACTIVO
    RETURN BINARY_DOUBLE
    IS
      TT    NUMBER;
      VALOR BINARY_DOUBLE;
    BEGIN
      SELECT COUNT(*) INTO TT
        FROM SEGURO SE
        WHERE SE.SEG_STATE = 1;

      IF TT != 0 THEN
        SELECT SE.SEG_VALOR INTO VALOR
          FROM SEGURO SE
          WHERE SE.SEG_STATE = 1; 
        RETURN VALOR;
      ELSE
        RETURN -1;
      END IF;
    END;


  -- FUNCOA PARA OBTER A TAXA QUE ESTA A CIMA DE UM PERIODO
  FUNCTION PFUNC_GET_PERIODO_TAXA
  (
      PERIODO     NUMBER,
      CREDITO_REQ NUMBER
  )
    RETURN PACK_REGRAS.PTP_RESULT_TAXA
    IS
      RES PTP_RESULT_TAXA;
    BEGIN
      RES.ID := -1;
      RES.PERIODO := 0;
      RES.ESTADO := 0;
      RES.VALOR := 0;

      FOR TA2 IN (SELECT *
                    FROM (SELECT *
                            FROM TAXA TA2
                              INNER JOIN VER_TIPOCREDITO vt
                                ON vt.REALID = TA2.TAXA_TIPOCRED_ID
                              WHERE vt.REALID = CREDITO_REQ
                                AND TA2.TAXA_ESTADO = 1
                                AND TA2.TAXA_PERIODO > PERIODO
                              ORDER BY TA2.TAXA_PERIODO ASC)
          WHERE ROWNUM <= 1)
      LOOP
         RES.ID := TA2.TAXA_ID;
          RES.PERIODO := TA2.TAXA_PERIODO;
          RES.ESTADO := TA2.TAXA_ESTADO;
          RES.VALOR := TA2.TAXA_VALOR;
      END LOOP;

      RETURN RES;
    END;



  FUNCTION PFUNC_GET_PERIODO_TAXA_INF
   (
      PERIODO NUMBER,
      CREDITO_REQ NUMBER
    )
    RETURN PACK_REGRAS.PTP_RESULT_TAXA
    IS
      RES PACK_REGRAS.PTP_RESULT_TAXA;
    BEGIN

      FOR TA2 IN (SELECT *
                  FROM (SELECT TA2.*
                            FROM TAXA TA2
                              INNER JOIN VER_TIPOCREDITO vt
                                ON vt.REALID = TA2.TAXA_TIPOCRED_ID
                            WHERE vt.REALID = CREDITO_REQ
                              AND TA2.TAXA_ESTADO = 1
                              AND TA2.TAXA_PERIODO <= PERIODO
                            ORDER BY TA2.TAXA_PERIODO DESC)
                        WHERE ROWNUM <= 1)
      LOOP
          RES.ID := TA2.TAXA_ID;
          RES.PERIODO := TA2.TAXA_PERIODO;
          RES.ESTADO := TA2.TAXA_ESTADO;
          RES.VALOR := TA2.TAXA_VALOR;
      END LOOP;
      RETURN RES;

    END;


  -- Procedimento para atulizara a penalidade
  PROCEDURE PPRC_UPD_PENALIDADE
  (
      valorPenalidade BINARY_DOUBLE,
      idCredito       NUMBER,
      NIFCredito      VARCHAR2
   )
    IS
    BEGIN
      UPDATE CERDITO c
        SET c.CREDI_PENALIDADE = valorPenalidade, c.CREDIT_DATAPENALIDADE = SYSTIMESTAMP
        WHERE c.CREDI_DOS_NIF = NIFCredito
        AND c.CREDI_ID = idCredito
        AND c.CERDI_ESTADO = 1;
    END;



  FUNCTION PFUNC_GET_CHEQUEMPRESA_BANCK(idBanco NUMBER)
    RETURN TB_BANCOCHECK
    IS
      res TB_BANCOCHECK := TB_BANCOCHECK();

      k   NUMBER        := 1;

    BEGIN
      --(inicio NUMBER, fim NUMBER, TOTAL NUMBER, DESTRIBUIDO NUMBER
      FOR i IN (SELECT *
                  FROM VER_CHEQUEMPRESA
                  WHERE BANCOID = idBanco)
      LOOP
        res.EXTEND;
        res(k) := TP_BANCOCHECK(i.AGENCIA, I.inicio, I.fim, i.TOTAL, i.DESTRUBUIDO);

      END LOOP;

      RETURN res;
    END;


  /**
   */
  FUNCTION PFUNC_GET_CHEQUE_RANDOM
  (
      userid VARCHAR,
     idBanco         NUMBER,
     idAgencia       NUMBER,
     valorRequisicao BINARY_DOUBLE
  ) 
    RETURN PTP_RandomCheck
    
    IS
      numSequencia                 VARCHAR2(30);
      ram                          NUMBER;
      inicio                       VARCHAR2(30);
      fim                          VARCHAR2(30);
      id                           NUMBER;
      tt                           NUMBER := -1;
      ttCredito NUMBER ;
      ttChequesExpirados NUMBER;
      res                          PTP_RandomCheck;
      looper                       NUMBER := 0;
      ttDestribuido NUMBER;
      ttExistente NUMBER;
      saldoSuf NUMBER;
      valorAnterio FLOAT;
      totalValorRequistado BINARY_DOUBLE; --Corresponde a todos os valores que o utilizador requistou
    BEGIN
        -- 1º Destruir todas as atigas requisicoes feitas que ja estao expiradas independentemente do banco e da agencia
      
       --Carregar todas as requisicoees invalidas
      /*FOR d IN (SELECT *
                    FROM REQUISICAOCHEQUE d
                    WHERE d.REQCHEQ_USER_ID = userid
                         OR d.REQCHEQ_STATE = 0 
                         OR d.REQCHEQ_DTLAST <= (SYSDATE - INTERVAL '15' MINUTE)
                          )
      LOOP
          -- Repor o valor virtual anteriormente requisitado de todas as requisicao 
             -- Indepenetentemente do banco ou da agencia desde que estaja em um estado incalido
          UPDATE BANCO B
            SET B.BANCO_SALDOVIRTUAL = B.BANCO_SALDOVIRTUAL + d.REQCHEQ_VALOREQ
            WHERE B.BANCO_ID = d.REQCHEQ_BANCO_ID;
      END LOOP;*/
      
     /* -- Remover todas as requisicoes ja invalidas
      DELETE FROM REQUISICAOCHEQUE d
        WHERE d.REQCHEQ_USER_ID = userid
           OR d.REQCHEQ_STATE = 0
           OR d.REQCHEQ_DTLAST <= (SYSDATE - INTERVAL '15' MINUTE);
    */     

      --Verificar a existencia da sequecia desso bancoa para a aguencia
      SELECT COUNT(*)
        INTO tt
        FROM CHEQUEMPRESA c
        WHERE c.CHEQ_BANCO_ID = idBanco
          AND c.CHEQ_AGE_ID = idAgencia
          AND c.CHEQ_TOTALCHEQUES > c.CHEQ_TOTALDISTRIBUIDOS
          AND c.CHEQ_ESTADO = 1;
          
      -- buscar o total de saldo disponivel no banco requistado
      SELECT COUNT(*)
          INTO saldoSuf 
          FROM BANCO b
          WHERE b.BANCO_SALDO >= valorRequisicao
          AND b.BANCO_ID = idBanco;
      
      -- Caso existir na aguencia algum cheque para o banco entao
         -- VERIFICANDO SE EXISTE ALGUMA CARDINETA PARA DAR RESPOSTA A TAL REQUISICAO
      IF tt != 0 AND saldoSuf = 1 THEN
            -- Buscar a identificacao, a sequencia inicial e a sequencia final   
    
            SELECT c.CHEQ_ID,
                   c.CHEQ_SEQUENCIAINICIO,
                   c.CHEQ_SEQUENCIAFIM,
                   c.CHEQ_TOTALCHEQUES,
                   c.CHEQ_TOTALDISTRIBUIDOS
              INTO id,
                   inicio,
                   fim,
                   ttExistente,
                   ttDestribuido
              FROM CHEQUEMPRESA c
                INNER JOIN BANCO b ON c.CHEQ_BANCO_ID = b.BANCO_ID
              WHERE c.CHEQ_BANCO_ID = idBanco
                AND c.CHEQ_AGE_ID = idAgencia
                AND b.BANCO_SALDO >= valorRequisicao
                AND c.CHEQ_TOTALCHEQUES > c.CHEQ_TOTALDISTRIBUIDOS
                AND c.CHEQ_ESTADO = 1;
                
           
            -- BEGIN PROXIMALING -- A proxima linha e pro causa da requiscisão do credito que deixou de ser aplicado
                tt := 0;
            -- END PROXIMALINHA
            
            numSequencia := SUBSTR(fim, 1, LENGTH(fim) - 3);
            
            /*-- Criando um ciclo para gerarm um numero de sequencia aletoria entre o inicio e o fim da sequencia
            tt := -1;
            
            WHILE tt != 0 AND looper < ttExistente LOOP
              
              -- Retirar um cheque au calhar do lote
              ram := dbms_random.value(inicio, fim + 1);
  
              -- Garatir que o valor gerado nao ultrapasse a mega final por causa de +1
                IF ram > TO_NUMBER(fim) THEN
                  ram := ram - 1;
                END IF;
  
                -- Formatar o valor gerado para 21 digitos
                numSequencia := TO_CHAR(ram || '', 'FM00000000000000000000000000000');
  
                -- Verificar se o cheque criado ja esta ou nao sendo usado
                SELECT COUNT(*) INTO ttCredito
                  FROM CERDITO c
                  WHERE c.CREDI_CHEQ_ID = id
                    AND c.CREDI_NUMCHEQUE = numSequencia;
                    
                -- BEGIN PROXIMALING -- A proxima linha e pro causa da requiscisão do credito que deixou de ser aplicado
                tt := ttCredito;
                -- END PROXIMALINHA
  
                /*IF tt = 0 THEN
                  SELECT COUNT(*)
                    INTO tt
                    FROM REQUISICAOCHEQUE d
                    WHERE d.REQCHEQ_CODIGO = numSequencia
                  ;
                END IF;*/
                -- Se encontar alngum entao recorrer  novamente o looper
            /*IF tt != 0 AND ttCredito != 0 THEN tt := -1; END IF;
                looper := looper + 1; -- Incrementar a volta
              END LOOP;
              */
              -- Terminado o ciclo se o tt for 0 siginifica que o numero do cheque criado nao existe nos credito ne foi requisitado pro nehum utilizador
              IF tt = 0 THEN
                /*-- Criar a requisicao do cheque que foi pedido
                INSERT INTO REQUISICAOCHEQUE (REQCHEQ_USER_ID, 
                                              REQCHEQ_CODIGO, 
                                              REQCHEQ_CHEQ_ID,
                                              REQCHEQ_BANCO_ID,
                                              REQCHEQ_AGE_ID,
                                              REQCHEQ_VALOREQ
                                              )VALUES( userid, 
                                                       numSequencia,
                                                       id,
                                                       idBanco,
                                                       idAgencia,
                                                       valorRequisicao);
                                                       */
                -- tt recebe 2 siginifica que cosegui-se criar o cheque para o utilizador
                tt := 2;
              END IF;
      ELSE -- Se nao existir nessa agencia nennuma cardineta para dar resposta a essa requisicao entao invalidar o pedido
          res.idCheque := -1;
          res.numSequencia := CASE WHEN saldoSuf = 0 THEN 'SALDO' ELSE  'CHEQUE' END;
          RETURN res;
      END IF;
      
      -- CASO encontre o total
      IF tt = 2 THEN
        res.idCheque := id;
        res.numSequencia := numSequencia;
        RETURN res;
      /*ELSE
        -- Nao consegue criar o cheque verificar a quantidade do cheque dessa cardineta que esta reservado temporariamente
        SELECT COUNT(*) INTO tt 
          FROM REQUISICAOCHEQUE d
          WHERE d.REQCHEQ_CHEQ_ID = id
            AND (d.REQCHEQ_STATE = 0
            OR d.REQCHEQ_DTLAST <= (SYSDATE - INTERVAL '15' MINUTE));

        -- O total destribuido = total destribudo realmete mais a quantidade do cheque reservado 
        ttDestribuido := ttDestribuido + tt;
         -- Ainda existe cheques por destribuir nessa secao voltar a reavaliar o pedido do cheque
        IF ttDestribuido < ttExistente THEN
            RETURN PFUNC_GET_CHEQUE_RANDOM(userid,
                                           idBanco, 
                                           idAgencia,
                                           valorRequisicao);
        END IF;*/
      END IF;
      res.idCheque := null;
      res.numSequencia := null;
      RETURN res;
   END;



  -- Funcao para a validacao da sequecia dos cheques {0 Valido | !=0 Invalido}
  FUNCTION PFUNC_validateSequencia(inicio VARCHAR2,
                                   fim    VARCHAR2)
    RETURN NUMBER
    IS
      tt NUMBER;
    BEGIN
      SELECT COUNT(*)
        INTO tt
        FROM CHEQUEMPRESA c
        WHERE TO_NUMBER(inicio) BETWEEN TO_NUMBER(c.CHEQ_SEQUENCIAINICIO) AND TO_NUMBER(c.CHEQ_SEQUENCIAFIM)
          OR TO_NUMBER(fim) BETWEEN TO_NUMBER(c.CHEQ_SEQUENCIAINICIO) AND TO_NUMBER(c.CHEQ_SEQUENCIAFIM)
          OR TO_NUMBER(c.CHEQ_SEQUENCIAFIM) BETWEEN TO_NUMBER(inicio) AND TO_NUMBER(fim)
          OR TO_NUMBER(c.CHEQ_SEQUENCIAINICIO) BETWEEN TO_NUMBER(inicio) AND TO_NUMBER(fim)
          OR fim = c.CHEQ_SEQUENCIAFIM
          OR inicio = c.CHEQ_SEQUENCIAFIM
          OR fim = c.CHEQ_SEQUENCIAINICIO
          OR fim = c.CHEQ_SEQUENCIAINICIO;
          
      /*IF tt =0 THEN
         IF LENGTH(inicio) > 30 
             OR LENGTH(inicio)<21
             OR LENGTH(fim) > 30
             OR LENGTH(fim)<21 THEN
             tt := 1;
         END IF;
      END IF;*/
      RETURN tt;
    END;

  FUNCTION PFUNC_GET_DOSSIER_NUMBER
    RETURN VARCHAR2
    IS
      COD VARCHAR(9);
      RAN NUMBER;
      TT  NUMBER;
    BEGIN

      -- GERAR UM DOUBLE DE 15 CARACTERES
      SELECT dbms_random.value(1, 999999999)
        INTO RAN
        FROM DUAL;

      --TRATAR
      COD := TRUNC(RAN, 0) || '';
      COD := TO_CHAR(COD, 'FM000000000');

      -- VERIFICARA A EXISTENCIA
      SELECT COUNT(*)
        INTO TT
        FROM DOSSIERCLIENTE c
        WHERE c.DOS_NUMDOS = COD;

      IF TT = 0
      THEN
        RETURN COD; --VALIDO
      ELSE
        RETURN PFUNC_GET_DOSSIER_NUMBER(); -- NAO VALIDO
      END IF;
    END;


  FUNCTION PFUNC_GENERATE_NUMCRIDITO(clienteNIF VARCHAR2,
                                     numCheque  NVARCHAR2)
    RETURN VARCHAR2
    IS
    BEGIN
      RETURN (TO_CHAR(SYSDATE, 'YYMM') || SUBSTR2(clienteNIF, -5) || TO_CHAR(SYSTIMESTAMP, 'MMSSFF3') || SUBSTR2(numCheque, -6)) || '';
    END;

END PACK_REGRAS;