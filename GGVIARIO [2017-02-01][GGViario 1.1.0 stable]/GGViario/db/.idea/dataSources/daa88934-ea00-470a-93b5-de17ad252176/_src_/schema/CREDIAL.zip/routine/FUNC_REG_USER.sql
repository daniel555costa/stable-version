create FUNCTION "FUNC_REG_USER" -- Funcao para registar os perfil
(
  NOME     CHARACTER VARYING,
  idUserSuper NUMBER,
  NIF      CHARACTER VARYING,
  idPerfil   NUMBER,
  PHOTO    BLOB,
  enderecoIp CHARACTER VARYING,
  idAgenciaRegistro NUMBER, -- A gencia do utilizador logado que esta a registrar o outro
  idAgenciaTrabalhar NUMBER, -- Id da agenicia em que o novo utilizador ira trabalhar
  dataInicio DATE,
  dataFim DATE
)
  RETURN VARCHAR2 -- {true, MSG} : true - Registrado com sucesso | MSG - Uma mensagem de falha
  IS
     TT NUMBER;
  BEGIN
    -- OBTR O TOTAL DOS UTILIZADORES COM O NIF FORNECIDO
    SELECT COUNT(*)
      INTO TT
      FROM T_USER US
      WHERE US.USER_ID = NIF;
    IF TT != 0 THEN
      RETURN 'NIF existente';
    END IF;

    INSERT INTO T_USER (USER_ID,
                        USER_USER_ID,
                        USER_TPREF_ID,
                        USER_NAME,
                        USER_PWD,
                        USER_PHOTO,
                        USER_AGE_ID)
                        VALUES (NIF,
                                idUserSuper,
                                idPerfil,
                                NOME,
                                FUNC_MD5(NIF),
                                PHOTO,
                                idAgenciaRegistro);
                                
    IF idAgenciaTrabalhar IS NOT NULL  THEN
        
      PRC_USER_ALTERAGENCIA(idUserSuper,
                            NIF,
                            idAgenciaRegistro,
                            idAgenciaTrabalhar,
                            enderecoIp,
                            dataInicio,
                            dataFim);
    ELSE RETURN 'UTILIZADOR REGISTRADO SEM AGENCIA PARA TRABALHAR!';
    END IF;

    RETURN 'true';

  END;