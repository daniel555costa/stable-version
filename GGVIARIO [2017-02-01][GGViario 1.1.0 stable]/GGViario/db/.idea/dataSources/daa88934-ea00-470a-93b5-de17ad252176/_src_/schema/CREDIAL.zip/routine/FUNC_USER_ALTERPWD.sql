create FUNCTION FUNC_USER_ALTERPWD 
(
   idUser VARCHAR2,
   oldSenha VARCHAR2,
   newSenha VARCHAR2
)RETURN VARCHAR2
IS
   ttExist NUMBER;
BEGIN
   --Validar a antiga senha do utilizador
   SELECT COUNT(*) INTO ttExist
      FROM T_USER U
      WHERE U.USER_ID = idUser
         AND U.USER_PWD = FUNC_MD5(oldSenha)
         AND U.USER_ACCESS = 1;
   IF ttExist = 0 THEN RETURN 'Palavra passe invalida!'; END IF;
   
   -- Alterar o senha do utilizador
   UPDATE T_USER U
      SET U.USER_PWD = FUNC_MD5(newSenha)
      WHERE U.USER_ID = idUser;
    
   RETURN 'true';
END;