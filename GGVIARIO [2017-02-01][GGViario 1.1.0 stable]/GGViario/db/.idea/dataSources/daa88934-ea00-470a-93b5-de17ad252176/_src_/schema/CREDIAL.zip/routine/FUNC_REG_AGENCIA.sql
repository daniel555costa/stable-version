create FUNCTION FUNC_REG_AGENCIA 
(
    id_user NUMBER,
    id_localidade NUMBER,
    id_agencia NUMBER,
    nomeAgencia CHARACTER VARYING
)RETURN VARCHAR2
IS
BEGIN
   INSERT INTO AGENCIA(AGE_ID,
                       AGE_USER_ID,
                       AGE_LOCAL_ID,
                       AGE_DESC,
                       AGE_AGE_ID)
                       VALUES (seq_agencia.nextval,
                               id_user,
                               id_localidade,
                               nomeAgencia,
                               id_agencia);
    RETURN 'true';
END;