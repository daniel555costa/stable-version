create PROCEDURE PRC_LOGOUT 
(
   idLogin NUMBER
)IS
BEGIN
   -- desativar o login selecionado
   UPDATE LOGIN LG
      SET LG.LOGIN_STATE = 0
      WHERE LG.LOGIN_ID = idLogin;
END;