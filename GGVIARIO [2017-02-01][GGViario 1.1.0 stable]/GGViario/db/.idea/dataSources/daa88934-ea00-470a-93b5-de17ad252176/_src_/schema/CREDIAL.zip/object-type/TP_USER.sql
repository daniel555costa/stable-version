create TYPE           "TP_USER"                                          
  AS
  OBJECT (NOME VARCHAR2(60),
          NIF VARCHAR2(9),
          ESTADO NUMBER(1),
          PHOTO BLOB);