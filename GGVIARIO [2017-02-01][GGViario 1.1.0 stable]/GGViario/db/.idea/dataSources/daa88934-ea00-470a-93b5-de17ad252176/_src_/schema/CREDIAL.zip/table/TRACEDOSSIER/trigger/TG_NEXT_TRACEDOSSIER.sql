create trigger TG_NEXT_TRACEDOSSIER
	before insert
	on TRACEDOSSIER
	for each row
BEGIN
  IF inserting
  THEN
    IF :NEW."TRADO_ID" IS NULL
    THEN
      SELECT SEQ_TRACEDOSSIER.NEXTVAL
        INTO :NEW."TRADO_ID"
        FROM dual;
    END IF;
  END IF;
END;
