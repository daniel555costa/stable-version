create TYPE           "TYPE_USER"                                          
  AS
  OBJECT (NOME VARCHAR2(50),
          NIF VARCHAR2(9),
          ESTADO NUMBER(1),
          PHOTO BLOB);