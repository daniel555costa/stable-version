create view V_$FIXED_VIEW_DEFINITION as
select "VIEW_NAME","VIEW_DEFINITION" from v$fixed_view_definition
