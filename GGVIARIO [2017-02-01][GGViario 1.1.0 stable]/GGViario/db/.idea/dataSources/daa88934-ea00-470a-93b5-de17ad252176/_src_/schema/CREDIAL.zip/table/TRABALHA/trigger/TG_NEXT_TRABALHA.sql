create trigger TG_NEXT_TRABALHA
	before insert
	on TRABALHA
	for each row
BEGIN
  IF inserting AND :NEW.TRAB_ID IS NULL THEN
    :NEW.TRAB_ID := SEQ_TRABALHA.NEXTVAL;
  END IF;
END;
