create FUNCTION "FUNC_REG_SALARIO" 
(
  USUARIO VARCHAR2,
  NIF     VARCHAR2,
  VALOR   FLOAT,
  idAgencia NUMBER
)
RETURN VARCHAR2
  IS
    TT NUMBER;
  BEGIN
    SELECT COUNT(*)
      INTO TT
      FROM DOSSIERCLIENTE d
      WHERE UPPER(d.DOS_NIF) = UPPER(NIF);

    IF TT != 1
    THEN
      RETURN 'Dossier do cliente inexistente';
    END IF;

    -- INABILITANDO O REGISTRO ANTERIOR
    UPDATE SALARIO
      SET SAL_ESTADO = 0
      WHERE SAL_DOS_NIF = NIF
      AND SAL_ESTADO = 1;

    -- CRIANDO NOVO REGISTRO
    INSERT INTO SALARIO (SAL_USER_ID,
                        SAL_DOS_NIF,
                        SAL_VALOR,
                        SAL_AGE_ID)
                        VALUES (USUARIO,
                                NIF, 
                                VALOR,
                                idAgencia);
    RETURN 'true';
  END;