create view V_$SYS_OPTIMIZER_ENV as
select "ID","NAME","SQL_FEATURE","ISDEFAULT","VALUE","DEFAULT_VALUE" from v$sys_optimizer_env
