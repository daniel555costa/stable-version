create PROCEDURE PRC_USER_ALTERAGENCIA 
(
    idUserAdm VARCHAR2, -- o nif do adiministrador 
    idUserTrabalhar VARCHAR2, -- O id do utilizador que serra forcado a alterar a palavra pada
    idAgenciaLogado NUMBER, -- Id da agencia que esta a pedir a troca de palavra
    ipAgenciaTrabalhar VARCHAR2, -- Id da agencia em que o utlizador ira trabalhar
    enderecoIp VARCHAR2,
    dataInicio DATE,
    dataFin DATE
)IS
BEGIN
   -- Desativar a antiga anegia do utilizador
   UPDATE TRABALHA T
     SET T.TRAB_ESTADO = 0
     WHERE T.TRAB_USER_ID = idUserTrabalhar;
  
  -- Criar a nova agencia do trabalho do utilizador
  INSERT INTO TRABALHA(TRAB_USER_ID,
                       TRAB_USER_IDREG,
                       TRAB_AGE_ID,
                       TRAB_AGE_IDREG,
                       TRAB_DTINI,
                       TRAB_DTFIM)
                       VALUES(idUserTrabalhar,
                              idUserAdm,
                              ipAgenciaTrabalhar,
                              idAgenciaLogado,
                              (CASE WHEN dataInicio IS NULL THEN SYSDATE ELSE dataInicio END),
                              dataFin);
END;