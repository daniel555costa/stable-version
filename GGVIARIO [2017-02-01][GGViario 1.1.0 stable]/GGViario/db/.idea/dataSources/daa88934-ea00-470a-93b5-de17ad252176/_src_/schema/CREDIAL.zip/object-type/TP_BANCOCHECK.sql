create TYPE           "TP_BANCOCHECK"                                          
  IS
  OBJECT (AGENCIA VARCHAR2(50),
          INICIO NUMBER,
          FIM NUMBER,
          TOTAL NUMBER,
          DESTRIBUIDO NUMBER);