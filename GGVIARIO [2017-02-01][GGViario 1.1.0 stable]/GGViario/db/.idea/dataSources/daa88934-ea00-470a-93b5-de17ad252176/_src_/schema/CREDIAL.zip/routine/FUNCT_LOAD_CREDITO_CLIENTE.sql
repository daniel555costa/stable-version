create FUNCTION FUNCT_LOAD_CREDITO_CLIENTE 
(
    dataInicio DATE,
    dataFim DATE,
    idTipoCredito NUMBER,
    quantidadeAnoSubtrair NUMBER,
    idAgencia NUMBER
)RETURN PACK_VIEW.FilterCreditoCliente PIPELINED
IS
   --dataInicioPast DATE := TO_CHAR(dataInicio, 'DD')||'-'||TO_CHAR(dataInicio, 'MM')||'-'|| (TO_NUMBER(TO_CHAR(dataInicio, 'YYYY'))-quantidadeAnoSubtrair);
   dataInicioPast DATE := PACK_LIB.CALCINTERVALDATE(dataInicio, '-', quantidadeAnoSubtrair, 'YEAR');
   dataFimPast DATE := PACK_LIB.CALCINTERVALDATE(dataFim, '-',  quantidadeAnoSubtrair, 'YEAR');
   
   sumValorCreditoDT FLOAT := 0;
   sumDividaDT FLOAT := 0;
   sumTaegDT FLOAT := 0;
   
   sumValorCreditoOld FLOAT := 0;
   sumDividaOld FLOAT := 0;
   sumTaegOld FLOAT := 0;
   
   linhaSomatorioAno VER_CREDITO_CLIENTE%ROWTYPE;
   linhaSomatorioOld VER_CREDITO_CLIENTE%ROWTYPE;
BEGIN
    -- Apresentar os creditos no intervalo fornecido e calcular os somatorios corresnpondentes
    FOR I IN(SELECT * 
                FROM VER_CREDITO_CLIENTE I
                WHERE I.CREDITO = idTipoCredito
                    AND I.INICIO BETWEEN dataInicio AND dataFim
                    AND I."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN I."ID AGENCIA" ELSE idAgencia END) ) LOOP
        sumValorCreditoDT := sumValorCreditoDT + I."VALOR CREDITO";
        sumDividaDT := sumDividaDT + I."MONTANTE DIVIDA";
        sumTaegDT := sumTaegDT + I.TAEG;
        
        I."VALOR CREDITO" := PACK_LIB.MONEY(I."VALOR CREDITO", '');
        I."MONTANTE DIVIDA" := PACK_LIB.money(I."MONTANTE DIVIDA", '');
        I.TAEG := PACK_LIB.MONEY(I.TAEG, '');
        PIPE ROW(I);
    END LOOP;
    
    linhaSomatorioAno.NIF := 'TOTAL';
    linhaSomatorioAno."VALOR CREDITO" := PACK_LIB.money(sumValorCreditoDT, '');
    linhaSomatorioAno."MONTANTE DIVIDA" := PACK_LIB.money(sumDividaDT, '');
    linhaSomatorioAno.TAEG := PACK_LIB.money(sumTaegDT, '');
    
    -- Somatorio do ano actual
    PIPE ROW(linhaSomatorioAno);

    -- Efetuar o somatorio da diferença do ano
    IF quantidadeAnoSubtrair  IS  NOT NULL AND quantidadeAnoSubtrair>0 THEN
        sumValorCreditoDT := 0;
        sumDividaDT  := 0;
        sumTaegDT := 0;
        FOR I IN(SELECT * 
                    FROM VER_CREDITO_CLIENTE I
                    WHERE I.CREDITO = idTipoCredito
                        AND I.INICIO BETWEEN dataInicioPast 
                        AND dataFimPast
                        AND I."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN I."ID AGENCIA" ELSE idAgencia END)) LOOP
            sumValorCreditoDT := sumValorCreditoDT + I."VALOR CREDITO";
            sumDividaDT := sumDividaDT + I."MONTANTE DIVIDA";
            sumTaegDT := sumTaegDT + I.TAEG;
        END LOOP;
        linhaSomatorioOld.NIF := quantidadeAnoSubtrair||' ANOS';
        linhaSomatorioOld."VALOR CREDITO" := PACK_LIB.money(sumValorCreditoDT, '');
        linhaSomatorioOld."MONTANTE DIVIDA" := PACK_LIB.money(sumDividaDT, '');
        linhaSomatorioOld.TAEG := PACK_LIB.money(sumTaegDT, '');
        PIPE ROW(linhaSomatorioOld);
    END IF;
    
    -- Quando a diferença do ano for zero então mostrar o somatorio do ano corrente
    IF quantidadeAnoSubtrair  IS NULL OR quantidadeAnoSubtrair=0 THEN
       PIPE ROW(linhaSomatorioAno);
    END IF;
    
    
    
    
END;