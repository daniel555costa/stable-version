create FUNCTION FUNC_REG_PAGAMENTOFAZENDO 
(
  ID_USER                  VARCHAR,
  ID_PAGAMENTO             NUMBER,
  idBanco  NUMBER,
  NUMERO_DOCPAGAMENTO      VARCHAR2,
  DATA_DOCUMENTO_PAGAMENTO DATE,
  VALOR                    BINARY_DOUBLE,
  idAGencia NUMBER
)
  RETURN VARCHAR2
  IS
    TT       NUMBER;
    ID_BANCO NUMBER;
  BEGIN

    INSERT INTO PAGAMENTOFAZEADOPRESTACOES (PAGAFAZENDO_PAGA_ID, 
                                            PAGAFAZENDO_BANCO_ID,
                                            PAGAFAZENDO_NUMDOCPAGAMENTO, 
                                            PAGAFAZENDO_DATADOCPAGAMENTO, 
                                            PAGAFAZENDO_VALOR, 
                                            PAGAFAZENDO_USER_ID,
                                            PAGAFAZENDO_AGE_ID)
                                            VALUES (ID_PAGAMENTO, 
                                                    idBanco, 
                                                    NUMERO_DOCPAGAMENTO,
                                                    DATA_DOCUMENTO_PAGAMENTO, 
                                                    VALOR, 
                                                    ID_USER,
                                                    idAGencia
                                                    );
    RETURN 'true';
  END;