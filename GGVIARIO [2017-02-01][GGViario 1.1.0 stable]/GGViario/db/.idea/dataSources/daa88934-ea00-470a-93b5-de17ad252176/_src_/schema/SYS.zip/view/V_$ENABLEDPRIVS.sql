create view V_$ENABLEDPRIVS as
select "PRIV_NUMBER" from v$enabledprivs
