create TYPE           "TP_VER_TABLE"                                          
  IS
  OBJECT (TABELA VARCHAR(30),
          TIPO VARCHAR(1));