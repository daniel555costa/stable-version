create FUNCTION FUNCT_LOAD_ADM_CREDITOANULAR 
(
   nifCliente VARCHAR2,
   numCredito VARCHAR2,
   idAgencia NUMBER
)RETURN PACK_VIEW.FilterCreditoAnulado PIPELINED
IS
BEGIN
   -- Selecionar os creditos a partir do nif e ou numero de cridito para posteriormente ser anulada
   FOR I IN (SELECT *
                FROM VER_CREDITO_ANULAR I
                   WHERE I.NIF = (CASE WHEN nifCliente IS NULL THEN I.NIF ELSE  nifCliente END)
                      AND I."NUMERO CREDITO" = (CASE WHEN numCredito IS NULL THEN I."NUMERO CREDITO" ELSE numCredito END)
                      AND I."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN I."ID AGENCIA" ELSE idAgencia END))
      LOOP
         I.TAEG := PACK_LIB.money(I.TAEG, '');
         I."VALOR CREDITO" := PACK_LIB.money(I."VALOR CREDITO", '');
         I."TOTAL PAGAR" := PACK_LIB.money(I."TOTAL PAGAR", '');
         I."VALOR PAGO" := PACK_LIB.money(I."VALOR PAGO", '');
      PIPE ROW(I);
  END LOOP;
END;