create trigger TG_POS_REG_BANCOMOVIMETO
	after insert
	on BANCOMOVIEMNTO
	for each row
BEGIN
   -- Depois de registrar o movimento do banco entao se o credito = 0 entao diminuir o saldo do banco 
      -- Se o debito = 0 entao aumentar o saldo do banco
  UPDATE BANCO b
     SET b.BANCO_SALDO = (CASE
                            WHEN :NEW.BANCOMOV_DEBITO = 0 AND :NEW.BANCOMOV_CERDITO != 0 THEN
                              b.BANCO_SALDO + :NEW.BANCOMOV_CERDITO
                            WHEN :NEW.BANCOMOV_CERDITO = 0 AND :NEW.BANCOMOV_DEBITO !=0 THEN 
                              b.BANCO_SALDO - :NEW.BANCOMOV_DEBITO
                            ELSE b.BANCO_SALDO
                          END)
        /*b.BANCO_SALDOVIRTUAL = (CASE
                                  WHEN :NEW.BANCOMOV_DEBITO = 0 AND :NEW.BANCOMOV_CERDITO != 0 THEN
                                      b.BANCO_SALDOVIRTUAL  + :NEW.BANCOMOV_CERDITO
                                  ELSE b.BANCO_SALDOVIRTUAL 
                                END)*/
     WHERE b.BANCO_ID = :NEW.BANCOMOV_BANCO_ID ;
END;
