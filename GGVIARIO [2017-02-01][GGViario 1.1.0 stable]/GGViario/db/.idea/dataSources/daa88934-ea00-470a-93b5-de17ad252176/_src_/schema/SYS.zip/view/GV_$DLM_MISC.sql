create view GV_$DLM_MISC as
select "INST_ID","STATISTIC#","NAME","VALUE" from gv$dlm_misc
