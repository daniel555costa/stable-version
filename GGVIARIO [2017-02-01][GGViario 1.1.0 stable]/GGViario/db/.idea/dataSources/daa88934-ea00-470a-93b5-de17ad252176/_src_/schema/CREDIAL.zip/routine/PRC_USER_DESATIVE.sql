create PROCEDURE PRC_USER_DESATIVE 
(
    idUserAdm VARCHAR2, -- o nif do adiministrador 
    idUserDesative VARCHAR2, -- O id do utilizador que serra forcado a alterar a palavra pada
    newState VARCHAR2 -- D - Siguinifica desativa | F - forcar alterar senha para ativas
)IS
BEGIN
   UPDATE T_USER U
     SET U.USER_ACCESS = (CASE 
                             WHEN UPPER(newState) ='D' THEN 0
                             ELSE 2
                          END)
     WHERE U.USER_ID = idUserDesative;
END;