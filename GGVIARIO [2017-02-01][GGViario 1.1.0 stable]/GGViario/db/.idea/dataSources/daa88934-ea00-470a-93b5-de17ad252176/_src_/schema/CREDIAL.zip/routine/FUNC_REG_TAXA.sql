create FUNCTION "FUNC_REG_TAXA" 
(
  USUARIO         VARCHAR,
  idTipoCredito   NUMBER,
  PERIODO         NUMBER,
  VALOR           NUMBER,
  idAgencia NUMBER
)RETURN VARCHAR
IS
BEGIN

    IF VALOR > 0 AND VALOR <= 100 AND PERIODO >0 THEN
        -- CRIAR A NOVA TAXA
        INSERT INTO TAXA (TAXA_USER_ID,
                          TAXA_TIPOCRED_ID,
                          TAXA_VALOR,
                          TAXA_PERIODO,
                          TAXA_AGE_ID)
                          VALUES (USUARIO,
                                  idTipoCredito,
                                  VALOR,
                                  PERIODO,
                                  idAgencia);
    RETURN 'true';
    ELSIF PERIODO <= 0 THEN RETURN 'Numero de dias invalido!';
    ELSE RETURN 'Valor de taxa invalida!';
    END IF;                    
END;