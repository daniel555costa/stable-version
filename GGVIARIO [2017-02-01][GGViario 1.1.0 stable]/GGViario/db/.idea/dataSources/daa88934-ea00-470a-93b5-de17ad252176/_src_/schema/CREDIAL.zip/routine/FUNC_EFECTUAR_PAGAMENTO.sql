create FUNCTION FUNC_EFECTUAR_PAGAMENTO 
(
    -- Essa funcao serve para fazer a atualizadc
    idPagamento NUMBER,
    idUser NUMBER,
    documetoPagamentoReal VARCHAR2,
    idBancoReal NUMBER,
    tipoPagamento CHAR, -- S Semelhante | D Diferente | F Faseado
    valorPrestacao FLOAT,
    dataDocumentoPagamento DATE, -- A data que o pagamento foi efetuada
    idAgencia NUMBER
)
RETURN VARCHAR2
IS
    linhaPagamento PAGAMENTO%ROWTYPE;
    linhaCredito CERDITO%ROWTYPE;
    estadoPagamento NUMBER;
    libele VARCHAR2(250);
    res VARCHAR2(30);

    -- Para pagamento tenho
    valorPagar FLOAT;
    documentoUsar VARCHAR2(30);
    bancoUsar NUMBER;
    porTranche NUMBER DEFAULT 0;
    
    valorFazeado NUMBER;
    valido BOOLEAN DEFAULT FALSE;
    diferencaValor FLOAT;
    
    ttPagaOpen NUMBER; -- total de pagamento que resta por pagar
    dataDocumentoUsar DATE;

BEGIN
    SELECT * INTO linhaPagamento
      FROM PAGAMENTO PA
      WHERE PA.PAGA_ID = idPagamento;


    SELECT * INTO linhaCredito
      FROM CERDITO c
      WHERE c.CREDI_ID = linhaPagamento.PAGA_CREDI_ID;


    IF linhaPagamento.PAGA_PARTRANCHE = 1 AND (tipoPagamento  = 'S' OR tipoPagamento = 'D') THEN
        RETURN 'Pagamento nao efectuadao!'||NL
            ||'O pagamento anterior fazeado e o actual nao fazeado.';
    END IF;
    
    -- Caso o pagamento aindo nao foi pago entao
    IF linhaPagamento.PAGA_ESTADO = 1 THEN

      -- Quando for pagamento Semelhante 
          -- Todos os dados meten-se o mesmo
      IF tipoPagamento = 'S' THEN
        valorPagar := linhaPagamento.PAGA_REEMBOLSO;
        documentoUsar := linhaPagamento.PAGA_NUMDOCPAGAMENTO;
        bancoUsar := linhaPagamento.PAGA_BANCO_ID;
        libele := 'Amortizacao do credito do dossier nº'||linhaCredito.CREDI_NUMCERDI||' com seguinte documento '|| documentoUsar;
        valido := TRUE;
        dataDocumentoUsar := dataDocumentoPagamento;

      -- Quando for pagamento diferente nao fazeado 
          -- Valor matem o mesmmo valor que reembolso o documento e o banco e que pode ser alterado
      ELSIF tipoPagamento = 'D' THEN
        valorPagar := linhaPagamento.PAGA_REEMBOLSO;
        documentoUsar := documetoPagamentoReal;
        bancoUsar := idBancoReal;
        libele := 'Amortizacao do credito do dossier nº'||linhaCredito.CREDI_NUMCERDI||' com seguinte documento '|| documentoUsar;
        valido := TRUE;
        dataDocumentoUsar := dataDocumentoPagamento;

      -- Quando for pagamento diferente fazeado
          -- o valor pagar muda  o documento e o banco e que pode ser alterado
      ELSIF tipoPagamento = 'F' THEN
        porTranche := 1;
        valorPagar := valorPrestacao;
        documentoUsar := documetoPagamentoReal;
        bancoUsar := idBancoReal;
        dataDocumentoUsar := dataDocumentoPagamento;
        libele := 'Amortizacao do credito do dossier nº'||linhaCredito.CREDI_NUMCERDI||' pagamento fazeado  '|| documentoUsar;
        
        valorFazeado := linhaPagamento.PAGA_PRESTACAO + valorPagar; --valorFazeado := valorFazeado1 + valorFazeado2;
        IF linhaPagamento.PAGA_PRESTACAO <= valorFazeado 
            AND linhaPagamento.PAGA_REEMBOLSO >= valorFazeado
            AND linhaPagamento.PAGA_VALOREAL >= valorFazeado THEN
            
            -- Calcular a diferenca do valor que ira sobrar
               -- Se a diferenca do valor for algumas sentezimas Entre 0 á 1 Entao adicionar essas centezimas ao valor a pagar
            
            diferencaValor := linhaPagamento.PAGA_REEMBOLSO - valorFazeado;
            IF diferencaValor >0 AND diferencaValor <1 THEN
                valorPagar := valorPagar + diferencaValor;
            END IF;
            valido := TRUE;
        ELSE
           RETURN 'Valor inserido superio ao esperado. Pagamento fazeado não efectuado!';
        END IF;
      END IF;

      IF valido THEN
         -- Amortizar a prestacao
          UPDATE PAGAMENTO PA
              SET PA.PAGA_PARTRANCHE = porTranche,
                  PA.PAGA_PRESTACAO = PA.PAGA_PRESTACAO + valorPagar,
                  PA.PAGA_NUMDOCPAGAMENTOREAL = documentoUsar,
                  PA.PAGA_BANCO_IDREAL = bancoUsar,
                  PA.PAGA_DATADOCPAGAMENTOREAL = dataDocumentoUsar
              WHERE PA.PAGA_ID = idPagamento;
              
    
          -- Registrar as movimentocoes para o banco utilizado no pagamento
          res := FUNC_REG_MOVIMENTOBANCO(idUser,
                                         idBancoReal, 
                                         0,
                                         valorPagar,
                                         libele,
                                         idAgencia
                                         );
    
          -- Quando o pagamento for o pagamento fazeado tambem registar a movementacao do pagamento
          IF tipoPagamento = 'F' AND res = 'true' THEN -- Siguinifaca FAZEADO
              res := FUNC_REG_PAGAMENTOFAZENDO(idUser,
                                               idPagamento,
                                               bancoUsar,
                                               documentoUsar,
                                               dataDocumentoPagamento,
                                               valorPagar,
                                               idAgencia
                                               );
          END IF;
          
          -- contar quantos pagamentos abeto esse credito anida tem
          SELECT COUNT(*) INTO ttPagaOpen
            FROM PAGAMENTO PAG
            WHERE PAG.PAGA_ESTADO != 0
               AND PAG.PAGA_CREDI_ID = linhaCredito.CREDI_ID;
          
          -- Finalizar o credito caso nao tenha mais nehum pagamento aberto
          IF ttPagaOpen = 0 THEN
             UPDATE CERDITO CDT
                SET CDT.CERDI_ESTADO = 0,
                    CDT.CREDI_CREDITOESTADO = 0
                WHERE CDT.CREDI_ID = linhaCredito.CREDI_ID;
          END IF;
      END IF;
    
       RETURN res;
    ELSE
        RETURN 'Essa prestacao ja foi paga';
    END IF;
END;