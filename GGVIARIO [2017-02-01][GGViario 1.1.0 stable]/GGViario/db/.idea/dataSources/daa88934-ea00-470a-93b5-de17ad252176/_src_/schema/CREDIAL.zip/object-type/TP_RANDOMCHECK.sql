create TYPE           "TP_RANDOMCHECK"                                          
  IS
  OBJECT (ID NUMBER,
          SEQUENCIA NUMBER);