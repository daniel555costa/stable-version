create FUNCTION FUNCT_LOAD_CLIENT_BYCHEQUE
(
    tipo NUMBER,  --{1 numeroCheqe | 2 - NIF |  3 Nome | 4 Apelido | 5 Agencia}
    chavePesquisa IN VARCHAR2
) RETURN  PACK_VIEW.FilterClieteSample PIPELINED
IS
BEGIN
    /*
        VISUALIZA
    */
    FOR CLS IN (SELECT  DISTINCT CLS.*
            FROM VER_CLIENTE_SIMPLE CLS 
               INNER JOIN CERDITO CT ON CLS.NIF = CT.CREDI_DOS_NIF
            WHERE UPPER(CT.CREDI_NUMCHEQUE) LIKE UPPER('%'||(CASE WHEN tipo = 1 THEN chavePesquisa ELSE CT.CREDI_NUMCHEQUE END)||'%')
               AND CLS.NIF LIKE '%'||(CASE WHEN tipo  = 2 THEN chavePesquisa ELSE CLS.NIF END)||'%'
               AND UPPER(CLS.NOME) LIKE UPPER('%'||(CASE WHEN tipo = 3 THEN chavePesquisa ELSE CLS.NOME END)||'%')
               AND UPPER(CLS.APELIDO) LIKE UPPER('%'||(CASE WHEN tipo = 4 THEN chavePesquisa ELSE CLS.APELIDO END)||'%')
               
               ) LOOP 
       PIPE ROW(CLS);
   END LOOP;
END;