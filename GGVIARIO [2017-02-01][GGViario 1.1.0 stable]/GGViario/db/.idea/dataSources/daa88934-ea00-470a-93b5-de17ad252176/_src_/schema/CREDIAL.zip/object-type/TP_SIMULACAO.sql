create TYPE           "TP_SIMULACAO"                                          
  IS
  OBJECT (CAMPO VARCHAR(30),
          VALOR BINARY_DOUBLE,
          MESSAGE VARCHAR(300));