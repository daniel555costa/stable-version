create FUNCTION "FUNC_REG_OBJECTO" 
(
  USER_ID    VARCHAR2,
  DESIGNACAO VARCHAR2,
  TIPO       NUMBER,
  idAgencia NUMBER
)RETURN NUMBER
IS
   TT NUMBER;
   idObjecto NUMBER;
BEGIN
    SELECT COUNT(*)
      INTO TT
      FROM OBJECTO
      WHERE UPPER(OBJ_DESC) = UPPER(DESIGNACAO)
        AND OBJ_TOBJ_ID = TIPO;
    IF TT = 0
    THEN
      INSERT  INTO OBJECTO (OBJ_DESC,
                           OBJ_TOBJ_ID,
                           OBJ_USER_ID)
                           VALUES (DESIGNACAO,
                                  TIPO,
                                  USER_ID) 
                          RETURNING OBJ_ID INTO idObjecto;
    ELSE
      UPDATE OBJECTO
        SET OBJ_DESC = DESIGNACAO,
            OBJ_STATE = 1
        WHERE UPPER(OBJ_DESC) = UPPER(DESIGNACAO)
        RETURNING OBJ_ID  INTO idObjecto;
    END IF;
    
    RETURN idObjecto;
END;