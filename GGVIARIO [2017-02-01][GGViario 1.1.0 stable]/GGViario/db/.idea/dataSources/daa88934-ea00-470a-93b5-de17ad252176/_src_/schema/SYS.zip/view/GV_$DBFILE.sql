create view GV_$DBFILE as
select "INST_ID","FILE#","NAME" from gv$dbfile
