create FUNCTION FUNCT_LOAD_MOVIMENTOBANCO 
(
   idBanco NUMBER,
   dataDia DATE,
   idAgencia NUMBER
)RETURN  PACK_VIEW.FilterBancoMovimento PIPELINED 
IS
   -- Gestao do Banco
     -- Visualizar os hitoricos dos movimento feitos num banco 
     -- Em um dado intervalo de tempo em um dia
     
    -- Nao necessario(Quando data nula todas as movimentações serao caregada)
   sumDebito FLOAT :=0; -- Somatorio para debito
   sumCredito FLOAT :=0; -- Somatorio para credito
   
   finalRow VER_BANCOMOVIMENTO%ROWTYPE;
BEGIN
   FOR I IN (SELECT VB.*
                FROM VER_BANCOMOVIMENTO  VB
                WHERE ID_BANCO = idBanco -- Se a data for nula sera iginarada a comparacao com a data
                    AND TO_DATE(VB.DATA, 'DD-MM-YYYY') = (CASE WHEN dataDia IS NULL THEN TO_DATE(VB.DATA,'DD-MM-YYYY') ELSE dataDia END)
                    AND VB."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN  VB."ID AGENCIA" ELSE idAgencia END)) LOOP   
                    
      sumCredito := sumCredito + I.CREDITO;
      sumDebito := sumDebito + I.DEBITO;
      I.CREDITO := PACK_LIB.MONEY(I.CREDITO, '');
      I.DEBITO := PACK_LIB.MONEY(I.DEBITO, '');
      PIPE ROW(I);
  END LOOP;
  
  finalRow.CREDITO := sumCredito;
  finalRow.DEBITO := sumDebito;
  finalRow.DEBITO := PACK_LIB.MONEY(finalRow.DEBITO, '');
  finalRow.CREDITO := PACK_LIB.MONEY(finalRow.CREDITO, '');
  PIPE ROW(finalRow);
END;