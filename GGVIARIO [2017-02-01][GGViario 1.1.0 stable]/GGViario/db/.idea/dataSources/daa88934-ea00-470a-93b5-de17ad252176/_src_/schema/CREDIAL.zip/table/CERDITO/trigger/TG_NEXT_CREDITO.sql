create trigger TG_NEXT_CREDITO
	before insert
	on CERDITO
	for each row
BEGIN
    IF inserting AND :NEW.CREDI_ID IS NULL THEN 
       :NEW.CREDI_ID := SEQ_CREDITO.NEXTVAL;
    END IF;
END;
