create FUNCTION  "FUNC_REG_USER_ACCESS" 
( USUARIO     VARCHAR2, -- USER A DAR PREVILEGIO
  USER_NIF    VARCHAR2, -- USER QUE RECEBERA PREVILEGIO
  ID_MENU     NUMBER,
  DATA_INICIO DATE,
  DATA_FIM    DATE,
  idAgencia NUMBER
)
  RETURN VARCHAR2
  IS
    TT NUMBER;
  BEGIN
    -- VERIFICAR SE O UTILIZADOR JA TEM DIREITO A ESSE MENU
    SELECT COUNT(*)
      INTO TT
      FROM MENUSER
      WHERE MUSER_STATE != 0
        AND MUSER_MENU_ID = ID_MENU
        AND MUSER_USER_ID = USER_NIF;

    -- CASO O USER NAO TEM PREVILEGIO DAQUELE MENU ENTAO DALO PREVILEGIO AO MENU
    IF TT = 0
    THEN
      INSERT INTO MENUSER (MUSER_USER_ID,
                           MUSER_MENU_ID,
                           MUSER_DTINI,
                           MUSER_DTFIN,
                           MUSER_USER_REG,
                           MUSER_AGE_ID)
                           VALUES (USER_NIF,
                                   ID_MENU,
                                   DATA_INICIO,
                                   DATA_FIM,
                                   USUARIO,
                                   idAgencia);
      RETURN 'Granted'; 
    ELSE 
      UPDATE MENUSER  
        SET MUSER_STATE = 0
        WHERE MUSER_USER_ID = USER_NIF
        AND MUSER_MENU_ID = ID_MENU
        AND MUSER_STATE != 0;

      RETURN 'Revoked';
    END IF;
  END;