create trigger TG_NEXT_BANCO
	before insert
	on BANCO
	for each row
begin  
   if inserting then 
      if :NEW."BANCO_ID" is null then 
         select SEQ_BANCO.nextval into :NEW."BANCO_ID" from dual; 
      end if; 
   end if; 
end;
