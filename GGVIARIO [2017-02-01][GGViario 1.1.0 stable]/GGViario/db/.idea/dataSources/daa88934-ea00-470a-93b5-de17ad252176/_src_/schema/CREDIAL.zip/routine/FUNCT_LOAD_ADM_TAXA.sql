create FUNCTION FUNCT_LOAD_ADM_TAXA 
(
  idTipoCredito NUMBER
)RETURN PACK_VIEW.FilterTaxa PIPELINED
IS
BEGIN
   -- Carregar as informações relativas as taxa para apresentar na area de administração
   FOR I IN(SELECT *
              FROM VER_TAXAS I
              WHERE I.TIPO_CREDITO = idTipoCredito) LOOP
              
    I.TAXA := PACK_LIB.money(I.TAXA, '');
    PIPE ROW(I);
  END LOOP;
END;