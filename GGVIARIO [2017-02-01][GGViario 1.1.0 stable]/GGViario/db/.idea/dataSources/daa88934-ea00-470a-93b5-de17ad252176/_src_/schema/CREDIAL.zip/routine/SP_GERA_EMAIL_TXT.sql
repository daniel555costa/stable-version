create Procedure Sp_Gera_Email_Txt
(
   dirName VARCHAR2,
   fileName VARCHAR2,
   operactionType VARCHAR,
   lineText VARCHAR2
)
IS
    /*
       r - texto lido
       w - escrever texto
       a - acrescentar texto
       rb - leia modo byte
       WB - modo de gravação byte
       ab - Modo byte de acréscimo
    */
   --  Lista_Email Utl_File.File_Type;
Begin
/*
   Lista_Email := sys.Utl_File.Fopen(dirName, fileName, operactionType);
   sys.Utl_File.Put_Line(Lista_Email, lineText);
   Utl_File.Fclose(Lista_Email);
   */
   NULL;
End Sp_Gera_Email_Txt;