create FUNCTION FUNCT_HISTORICO_CREDITO 
(
    NIF_CLIENTE VARCHAR2,
    idAgencia NUMBER
) RETURN PACK_VIEW.FilterHostoricoDossier  PIPELINED
IS
  BEGIN
      /**
         Historico do credito do cliente
      */
      FOR I IN (SELECT *
                   FROM VER_HISTORICOCREDITO I 
                   WHERE I.ESCONDE_NIF = NIF_CLIENTE
                      AND I."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN I."ID AGENCIA" ELSE idAgencia END))
      LOOP
        -- Transformar em moeda converter os valores numericos em moeda
        I."CAPITAL INICIAL" := PACK_LIB.MONEY(I."CAPITAL INICIAL", '');
        I."TOTAL CREDITO" := PACK_LIB.MONEY(I."TOTAL CREDITO", '');
        I."VALOR PAGO" := PACK_LIB.MONEY(I."VALOR PAGO", '');
        I.TAEG := PACK_LIB.MONEY(I.TAEG, '');
        I.DATA := PACK_LIB.ASDDMONYYYY(I.DATA);
        
        PIPE ROW(I);
      END LOOP;
END;