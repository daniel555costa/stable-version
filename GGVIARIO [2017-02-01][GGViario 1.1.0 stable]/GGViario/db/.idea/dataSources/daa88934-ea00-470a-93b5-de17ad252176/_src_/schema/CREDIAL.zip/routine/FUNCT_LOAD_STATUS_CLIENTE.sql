create FUNCTION FUNCT_LOAD_STATUS_CLIENTE 
(
   typePesquisa VARCHAR2, -- Tipos {S - Somatorio | SP - Sem paramitero Conta | CP - Com Parametros Conta }
   dataInicio DATE,
   dataFim DATE,
   idLocalTrabalho VARCHAR2,
   idLocalidade VARCHAR2,
   idAgencia NUMBER
)
RETURN PACK_VIEW.FilterStatusCliente PIPELINED 
IS
    valorTotal NUMBER :=0;
    contagem NUMBER;
    somatorio FLOAT;
    
    lastRow VER_STATUS_CLIENTE%ROWTYPE; -- O recorder para a ultima linha
BEGIN
    -- PIPE ROW(RECORDER) >> COLOCA NA TABELA
    FOR I IN(SELECT * FROM VER_STATUS_CLIENTE CLI) LOOP
      -- I é O recorder
      
        SELECT
                SUM(CD.CREDI_VALORCREDITO),
                COUNT(*) INTO somatorio, 
                          contagem
            FROM CERDITO CD
            WHERE CD.CREDI_DOS_NIF = i.NIF
               AND CD.CREDI_DATAINI BETWEEN dataInicio AND dataFim
               AND CD.CREDI_AGE_ID = (CASE WHEN idAgencia IS NULL THEN CD.CREDI_AGE_ID ELSE idAgencia END);
            
        -- Qunado a contagem nao encontrar nada entao forcar a nao aparecer na tabela
        IF contagem =  0 THEN contagem := NULL; END IF;
        
        IF  typePesquisa = 'S' THEN -- Quando for para efectuar o somatorio
            i."VALOR" := somatorio;
        ELSIF typePesquisa = 'SP' THEN -- COntagem sem parametros
            i."VALOR" := contagem;
        ELSIF typePesquisa = 'CP'  -- Contagem com parametros
          AND i."LOCAL TRABALHO" = idLocalTrabalho 
          AND i.LOCALIDADE = idLocalidade THEN
            i."VALOR" := contagem;
        ELSE i."VALOR" := NULL;
        END IF;
        
        -- So colocar na tabela quando o valor for nula
        IF i."VALOR" IS NOT NULL THEN
            valorTotal := valorTotal + i."VALOR";
            
            I."VALOR" := PACK_LIB.money(I."VALOR", '');
            PIPE ROW(i);
        END IF;
    END LOOP;
    
    -- Colocar os valores da linha final
    lastRow."NIF" := 'TOTAL';
    lastRow."VALOR" := PACK_LIB.money(valorTotal, '');
    PIPE ROW(lastRow);
END;