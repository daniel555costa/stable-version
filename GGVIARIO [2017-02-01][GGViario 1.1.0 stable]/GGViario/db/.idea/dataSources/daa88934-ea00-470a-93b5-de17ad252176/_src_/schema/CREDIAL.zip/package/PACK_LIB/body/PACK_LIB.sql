create PACKAGE BODY PACK_LIB 
  IS


  -- OBTRE O NUMERO DO ESTADO A PARTIR DO NOME CORESPONDENTE
  FUNCTION GET_STATE(TABLE_NAME   VARCHAR2,
                     STATE_VALUES VARCHAR2)
    RETURN NUMBER
    IS
      TT NUMBER;
    BEGIN
      SELECT COUNT(*)
        INTO TT
        FROM DEFSTATE d
        WHERE UPPER(d.DSTT_TABLE) = UPPER(TABLE_NAME)
          AND UPPER(STATE_VALUES) = UPPER(d.DSTT_VALUE);
      IF TT = 0
      THEN
        RETURN NULL;
      END IF;
      SELECT d.DSTT_KEY
        INTO TT
        FROM DEFSTATE d
        WHERE UPPER(d.DSTT_TABLE) = UPPER(TABLE_NAME)
          AND UPPER(d.DSTT_VALUE) = UPPER(STATE_VALUES);
      RETURN TT;
    END;

  -- OBTER O VALOR DO ESTADO A PARTIR DO NUMERO CORESPONDENTE
  FUNCTION STATE_VALUES(TABLE_NAME VARCHAR2,
                        STATE      NUMBER)
    RETURN VARCHAR2 
    IS
      TT          NUMBER;
      VALUE_STATE VARCHAR2(50);
    BEGIN
      SELECT COUNT(*)
        INTO TT
        FROM DEFSTATE d
        WHERE UPPER(d.DSTT_TABLE) = UPPER(TABLE_NAME)
          AND UPPER(STATE) = UPPER(d.DSTT_KEY);
      IF TT = 0
      THEN
        RETURN NULL;
      END IF;
      SELECT d.DSTT_KEY
        INTO TT
        FROM DEFSTATE d
        WHERE UPPER(d.DSTT_TABLE) = UPPER(TABLE_NAME)
          AND UPPER(d.DSTT_KEY) = UPPER(STATE);
      RETURN VALUE_STATE;
    END;


  FUNCTION GET_RIGTH(argment VARCHAR2,
                     lenth   NUMBER)
    RETURN VARCHAR2
    IS
    BEGIN
      IF lenth < LENGTH(argment)
      THEN
        RETURN SUBSTR(argment, LENGTH(argment) - lenth + 1, lenth);
      ELSE
        RETURN argment;
      END IF;
    END;

  FUNCTION GET_LEFTH(argment VARCHAR2,
                     lenth   NUMBER)
    RETURN VARCHAR2
    IS
    BEGIN
      IF lenth < LENGTH(argment)
      THEN
        RETURN SUBSTR(argment, 0, lenth);
      ELSE
        RETURN argment;
      END IF;
    END;






   FUNCTION calcIdade(OLD_DATE DATE) RETURN NUMBER AS
      new_date DATE  := to_char(CURRENT_TIMESTAMP, 'YYYY-MM-DD');
      
      idade_char varchar(10) := trunc((months_between(new_date, OLD_DATE))/12);
  BEGIN
    RETURN to_number(idade_char); 
  END calcIdade;

  FUNCTION money (VALOR NUMBER, SIGLA VARCHAR2) RETURN VARCHAR2 IS
     moneyValue VARCHAR2(300);
  BEGIN 

      --                             FM999G999G999 E A MASCAR UASADA PARA FORMATAR OS VALORES
    moneyValue := TO_CHAR(VALOR, 'FM999G999G999G999G999G999G999G999G999G999G999G999G999G990D90');
    moneyValue := REPLACE(moneyValue, ',', '*');
    moneyValue := REPLACE(moneyValue, '.', ',');
    moneyValue := REPLACE(moneyValue, '*', '.');
    RETURN moneyValue||' '||SIGLA;
  END MONEY; 

  FUNCTION asTime (DATE_PARAM TIMESTAMP) RETURN VARCHAR2 AS 
  BEGIN
    
    RETURN TO_CHAR(DATE_PARAM, 'HH24:MM:SS');
  END asTime;

  FUNCTION asDDMMYYYY (DATE_PARAM TIMESTAMP) RETURN VARCHAR2 IS
     dataFm VARCHAR(10);
  BEGIN
    -- TODO: Implementation required for FUNCTION LIB.AS_DDMMYYYY
     dataFm := TO_CHAR(DATE_PARAM, 'DD-MM-YYYY');
     RETURN dataFm;
  END asDDMMYYYY;

  FUNCTION asYYYYMMDD (DATE_PARAM TIMESTAMP) RETURN VARCHAR2 AS
  BEGIN
    
    RETURN TO_CHAR(DATE_PARAM, 'YYYY-MM-DD');
  END asYYYYMMDD;
  
  
  FUNCTION asDDMONYYYY(dateArg TIMESTAMP) RETURN VARCHAR2
  IS
  BEGIN
      RETURN TO_CHAR(dateArg, 'DD MON YYYY');
  END;
  
  FUNCTION getCurrentYear RETURN VARCHAR2 IS
  BEGIN
      RETURN TO_CHAR(CURRENT_TIMESTAMP, 'YYYY'); 
  END;
  

  
  FUNCTION complet (ARGMENT IN VARCHAR2, COMPLETION IN CHAR, FINAL_LENGTH IN NUMBER, FRIST IN BOOLEAN) RETURN VARCHAR2 IS
      CURRENT_LOCATION NUMBER;
      RESUATADO VARCHAR2(4000) := ARGMENT;
  BEGIN
      IF LENGTH(ARGMENT) < FINAL_LENGTH THEN
          IF FRIST THEN RETURN PACK_LIB.COMPLET(COMPLETION||ARGMENT, COMPLETION, FINAL_LENGTH, FRIST);
          ELSE RETURN PACK_LIB.COMPLET(ARGMENT||COMPLETION, COMPLETION, FINAL_LENGTH, FRIST);
          END IF;
      ELSE RETURN ARGMENT;
      END IF;
  END;
   
  FUNCTION isNumber (argment VARCHAR2) RETURN NUMBER IS
    n number;
  begin
    n :=  to_number(argment);
    RETURN 1;
    exception when others then
      RETURN 0;
   END;
   
   
   
   FUNCTION calcDiferencaAno (dataAno DATE, diferenca NUMBER) RETURN DATE
   IS 
      dataSubTracao VARCHAR(10) := TO_CHAR(dataAno, 'DD')||'-'||TO_CHAR(dataAno, 'MM')||'-'|| (TO_NUMBER(TO_CHAR(dataAno, 'YYYY'))-diferenca);
   BEGIN
      RETURN TO_DATE(dataSubTracao, 'DD-MM-YYYY');
   END;
   
   -- calcular o interval das datas
   FUNCTION calcIntervalDate(dateYear TIMESTAMP, operactor CHAR, countNumber NUMBER,  modo VARCHAR)  RETURN TIMESTAMP
   IS
      vDate TIMESTAMP;
      stmt VARCHAR2(90);
   BEGIN
      -- EXECUTE IMMEDIATE 
         stmt := ('SELECT TO_TIMESTAMP('''||dateYear||''') '||operactor||' interval '''||countNumber||''' '||modo||' from dual');
         EXECUTE IMMEDIATE stmt INTO vDate;
      RETURN vDate;
   END;
   
   
   -- Encriptacao de senha utilizando o algoritimo md5
    FUNCTION md5(senha VARCHAR2) RETURN VARCHAR2 
    IS
        hexkey VARCHAR2(32) := null;
        v_input VARCHAR2(4000) := senha;
    BEGIN
       hexkey := rawtohex(dbms_obfuscation_toolkit.md5(input => utl_raw.cast_to_raw(v_input)));
       return nvl(hexkey,'');
    END;
    
     -- Escrever um ficeheiro
    PROCEDURE writeFile (dirName VARCHAR2, fileName VARCHAR2, operationType VARCHAR2, lineWriter LONG)
    IS
      --  fileWirter UTL_FILE.File_Type;
    Begin
       /* fileWirter := sys.Utl_File.Fopen(dirName, fileName, operationType);
       sys.Utl_File.Put_Line(fileWirter, lineWriter);
       Utl_File.Fclose(fileWirter);*/
       NULL;
    End writeFile;
    
    
    -- criar uma nova linha de backUp
    -- OPERATION TIPE 
         -- I - INSERT
         -- U - UPDATE
    PROCEDURE newBackUpLine (listData TB_BACKUP, tableName VARCHAR2, operactionType  VARCHAR2)
    IS
      lineColumns VARCHAR2(4000) := '';
      lineValues VARCHAR2(4000) := '';
      line VARCHAR2(4000);
      colVal TP_BACKUP;
      command VARCHAR2(15) := null;
    BEGIN
       IF UPPER(operactionType) = 'I' THEN
          command := 'INSERT INTO '||tableName;
       ELSIF UPPER(operactionType) = 'U' THEN
          command := 'UPDATE  '||tableName|| ' SET ';
       END IF;
       
       -- Caso o comando for reconhecido internamente no dbUtil entao
       IF command IS NOT NULL THEN
           FOR i IN 1 .. listData.count LOOP
              colVal := listData(i);
              IF UPPER(operactionType) = 'I' THEN
                  lineColumns := lineColumns  || colVal.getColumn();
                  lineValues := lineValues  || colVal.getValue(); 
                  IF i < listData.count THEN 
                     lineColumns := lineColumns || ', ';
                     lineValues := lineValues || ', ';
                  END IF;
              ELSIF UPPER(operactionType) = 'U' THEN
                 lineValues := lineValues || colVal.getUpdate();
                 IF i < listData.count THEN 
                     lineValues := lineValues || ', ';
                  END IF;
              END IF;
           END LOOP;
           
           IF operactionType = 'I' THEN
              
              writeFile('d:/backupText', 'saveBackup.sql', 'a', line||';');
           END IF;
      END IF;
       
    END;
    
    
    FUNCTION bkDt (dateArgs TIMESTAMP) RETURN VARCHAR2
    IS
      textDate VARCHAR2(1000) := bkTxt(TO_CHAR(dateArgs, 'YYYY-MM-DD HH24:MI:SS'));
    BEGIN
       RETURN 'TO_TIMESTAMP('||textDate||', ''YYYY-MM-DD HH24:MI:SS'')';
    END;
    
    FUNCTION bkTxt(textArgs varchar2) RETURN VARCHAR2
    IS
    BEGIN
       RETURN ''''||textArgs||'''';
    END;
    
    FUNCTION splitNotNull (argment VARCHAR2, splitCase VARCHAR2) RETURN TB_ARRAY_STRING
    IS
        mascara VARCHAR(500) DEFAULT '[^'||splitCase||']+';
        res TB_ARRAY_STRING := TB_ARRAY_STRING();
    BEGIN
        FOR i IN(SELECT 
                      regexp_substr(argment, mascara, 1, level) AS piece 
                    FROM DUAL 
                      CONNECT BY level <= LENGTH(regexp_substr(argment, mascara, 1, level))
                    ) LOOP
            IF i.piece IS NOT NULL THEN
                res.EXTEND; res(res.COUNT) := i.piece;
            END IF;
        END LOOP;
        RETURN res;
    END;
    
    
    
    
    FUNCTION splitAll (argment VARCHAR2, splitCase VARCHAR2) RETURN TB_ARRAY_STRING
    IS
        indexPiece INTEGER;
        piece VARCHAR2(4000) := argment;
        res TB_ARRAY_STRING := TB_ARRAY_STRING();
    BEGIN
        LOOP
          indexPiece := instr(piece, splitCase);
          IF indexPiece > 0 then
              res.EXTEND; res(res.COUNT) := substr(piece, 1,indexPiece-1);
              piece := substr(piece, indexPiece + length(splitCase));
          ELSE
              res.EXTEND; res(res.COUNT) := piece;
              EXIT;
          END IF;
        END LOOP;
        RETURN res;
    END;
    
    
    FUNCTION charAt(argment VARCHAR2, charIndex INTEGER) RETURN CHAR
    IS
    BEGIN
        RETURN substr(argment, charIndex, 1);
    END;
    
    -- Obter o tamanho da quantidade do registro na tabela
    FUNCTION tableLength(tableName VARCHAR2) RETURN  NUMBER
    IS
      queryy VARCHAR2(300) := 'SELECT COUNT(*) FROM '||tableName;
      ttLent NUMBER;
    BEGIN
       EXECUTE IMMEDIATE queryy INTO ttLent;
       RETURN ttLent;
       
       EXCEPTION
         WHEN OTHERS THEN
           DBMS_OUTPUT.PUT_LINE (SQLERRM);
           RETURN NULL;
    END;
    
    
    FUNCTION NO_ACCENT(argment CHARACTER VARYING) RETURN CHARACTER VARYING
    IS
    BEGIN
       RETURN utl_raw.cast_to_varchar2(nlssort(trim(argment), 'nls_sort=binary_ai'));
    END;
    
    
    FUNCTION NO_ACCENT_UPPER(argment CHARACTER VARYING) RETURN CHARACTER VARYING
    IS
    BEGIN
       RETURN UPPER(NO_ACCENT(argment));
    END;
    
    

END PACK_LIB;