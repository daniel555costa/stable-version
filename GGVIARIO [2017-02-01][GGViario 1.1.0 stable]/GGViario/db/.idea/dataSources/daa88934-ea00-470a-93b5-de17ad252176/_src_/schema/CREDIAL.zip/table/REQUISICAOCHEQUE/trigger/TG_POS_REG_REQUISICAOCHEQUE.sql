create trigger TG_POS_REG_REQUISICAOCHEQUE
	after insert
	on REQUISICAOCHEQUE
	for each row
BEGIN
  /**
       Quando for requirido um cheque a valdo virtual do banco deve ser diminuido para que a proxima requisiacao nao veja o mesmo saldo
   */
  -- Diminuir o saldo bancario 
  /*UPDATE BANCO b
    SET b.BANCO_SALDOVIRTUAL = b.BANCO_SALDOVIRTUAL - :NEW.REQCHEQ_VALOREQ
    WHERE b.BANCO_ID = (SELECT s.CHEQ_BANCO_ID
        FROM CHEQUEMPRESA s
        WHERE s.CHEQ_ID = :NEW.REQCHEQ_CHEQ_ID);*/
   NULL;
END;
