create view V_$OBJECT_DEPENDENCY as
select "FROM_ADDRESS","FROM_HASH","TO_OWNER","TO_NAME","TO_ADDRESS","TO_HASH","TO_TYPE" from v$object_dependency
