create PACKAGE BODY PACK_TYPE 
  IS

  FUNCTION PFUNC_GET_DOSSIER_NUMBER
    RETURN VARCHAR2
    IS
      COD VARCHAR(9);
      RAN NUMBER;
      TT  NUMBER;
    BEGIN

      -- GERAR UM DOUBLE DE 15 CARACTERES
      SELECT dbms_random.value(1, 999999999)
        INTO RAN
        FROM DUAL;

      --TRATAR
      COD := TRUNC(RAN, 0) || '';
      COD := TO_CHAR(COD, 'FM000000000');

      -- VERIFICARA A EXISTENCIA
      SELECT COUNT(*)
        INTO TT
        FROM DOSSIERCLIENTE c
        WHERE c.DOS_NUMDOS = COD;

      IF TT = 0
      THEN
        RETURN COD; --VALIDO
      ELSE
        RETURN PFUNC_GET_DOSSIER_NUMBER(); -- NAO VALIDO
      END IF;
    END;



  FUNCTION getBasicPorExtenso(valor NUMBER) RETURN PACK_VIEW.numProExtenco
   IS
      tabExtenco PACK_VIEW.tabNumProExtenco;
   BEGIN
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';
      tabExtenco.EXTEND; tabExtenco(1).numer := 0; tabExtenco(1).nome := 'Zero'; tabExtenco(1).unidade := 'U';

      RETURN tabExtenco(1);
   END;
END PACK_TYPE;