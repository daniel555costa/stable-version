create FUNCTION FUNCT_LOAD_CLIENT 
(
    cod CHARACTER VARYING, -- { * for any atribute | NIF | NOME | CHEQUE | GARANTIA}
    searchValue CHARACTER VARYING
) RETURN  PACK_VIEW.FilterClieteSample PIPELINED
IS
   codValue CHARACTER VARYING(4000) := '%'||searchValue||'%';
BEGIN
    
    /*
        *  AS QUALQUER ATRIBUTO QUE POSSUI UM DETERMINADO VALOR
        VISUALIZA
    */
   FOR CLS IN (SELECT  DISTINCT CLS.*
            FROM VER_CLIENTE_SIMPLE CLS
               LEFT JOIN CERDITO CT ON CLS.NIF = CT.CREDI_DOS_NIF
               LEFT JOIN GARRANTIADOCREDITO GA ON CT.CREDI_ID = GA.GARDOC_CREDI_ID
               LEFT JOIN DOCUMENTREGUE DO ON CT.CREDI_ID = DO.DOCENTER_CREDI_ID
           WHERE (cod IS NULL OR codValue IS NULL)
                             
               -- ON NIF COMPARATION
               OR ((cod = 'NIF' OR cod='*') 
                    AND PACK_LIB.NO_ACCENT(CLS.NIF) LIKE PACK_LIB.NO_ACCENT(codValue))
               
               -- ON FIRST NAME COMPARATION
               OR ((cod = 'NOME' OR cod='*') 
                   AND PACK_LIB.NO_ACCENT(CLS.NOME) LIKE PACK_LIB.NO_ACCENT(codValue))
               
               -- ON SURNAME COMPARATION
             --  OR ((cod = 'NOME' OR cod='*')
                --    AND PACK_LIB.NO_ACCENT_UPPER(CLS.APELIDO) LIKE '%'||PACK_LIB.NO_ACCENT_UPPER(codValue)||'%')
               
               -- ON CHEQUE COMPARATION
               OR ((cod = 'CHEQUE' OR cod='*')
                    AND PACK_LIB.NO_ACCENT(CT.CREDI_NUMCHEQUE) LIKE PACK_LIB.NO_ACCENT(codValue))
               
               -- ON GARATIA DO CREDITO COMPARATION
               OR ((cod = 'GARANTIA' OR cod='*') 
                    AND PACK_LIB.NO_ACCENT(GA.GARDOC_DESC) LIKE PACK_LIB.NO_ACCENT(codValue))
               
               -- ON DOCUMENT CENTER COMPARATION
               OR ((cod = 'GARANTIA' OR cod='*')
                    AND PACK_LIB.NO_ACCENT(DO.DOCENTER_DESC) LIKE PACK_LIB.NO_ACCENT(codValue))
            ORDER BY CLS.NOME, CLS.APELIDO
            -- */
               ) LOOP 
       PIPE ROW(CLS);
   END LOOP;
END;