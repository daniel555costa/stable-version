create trigger TG_POS_UPD_REQUISICAOCHEQUE
	after update
	on REQUISICAOCHEQUE
	for each row
BEGIN
  /**
     Quando a requisicao desse cheque for passado para outra pessoa
     O antigo valor requisitado deve ser reposto ao banco
     O novo valor de requisicao deve ser retirado do banco
 */
  --Repor o valor antigo e retirar o novo valor
  
  
  
  
  
  -- Aqui foi desabilitado por causa  do numero de cheque que devera ser introdusido a mao
  /*IF :OLD.REQCHEQ_VALOREQ != :NEW.REQCHEQ_VALOREQ AND :NEW.REQCHEQ_STATE = 1 THEN
      UPDATE BANCO b
        SET b.BANCO_SALDOVIRTUAL = b.BANCO_SALDOVIRTUAL - :OLD.REQCHEQ_VALOREQ + :NEW.REQCHEQ_VALOREQ
        WHERE b.BANCO_ID = (SELECT s.CHEQ_BANCO_ID
                              FROM CHEQUEMPRESA s
                              WHERE s.CHEQ_ID = :NEW.REQCHEQ_CHEQ_ID);
  END IF;*/
  
  
  
  

  /*
  -- Quando estiver a disativar a antiga requisicao repor o saldo devolta ao banco inicial
  IF :OLD.REQCHEQ_STATE = 1 AND :NEW.REQCHEQ_STATE = 0 THEN
      UPDATE BANCO b
         SET b.BANCO_SALDOVIRTUAL = b.BANCO_SALDOVIRTUAL + :OLD.REQCHEQ_VALOREQ;
        --  WHERE b.BANCO_ID = :OLD.REQCHEQ_BANCO_ID;
  END IF;*/
  NULL;
END;
