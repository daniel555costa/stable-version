create view V_$DBFILE as
select "FILE#","NAME" from v$dbfile
