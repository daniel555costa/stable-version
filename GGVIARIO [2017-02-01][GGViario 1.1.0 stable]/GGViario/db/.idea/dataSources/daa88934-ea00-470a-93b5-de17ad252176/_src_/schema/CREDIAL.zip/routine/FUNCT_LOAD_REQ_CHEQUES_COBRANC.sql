create FUNCTION FUNCT_LOAD_REQ_CHEQUES_COBRANC 
(
   dataInicio DATE,
   dataFim DATE,
   estado NUMBER,
   agencia NUMBER,
   idBanco NUMBER,
   idLocalTrabalho NUMBER
)
RETURN PACK_VIEW.FilterChequesCobrancas PIPELINED
IS
    totalRegistro VER_REQ_CHEQUES_COBRAR_PCOBRAR%ROWTYPE;
BEGIN
    -- Essa funcao corrosponde ao visualizaçao do cheq
    totalRegistro."VALOR CHEQUE" := 0;
    -- Carregar os dados das cobrancas do cheque em um dado intervalo de tempo
      -- Efetuara o somatorio dos valores recoperados
    FOR I IN (SELECT I.*
                  FROM VER_REQ_CHEQUES_COBRAR_PCOBRAR I
                  WHERE I.STATE = (CASE WHEN estado IS NULL THEN I.STATE ELSE estado END)
                    AND I."DATA DEPOSITO" BETWEEN dataInicio AND dataFim
                    AND I.AGENCIA = (CASE WHEN agencia IS NULL THEN I.AGENCIA ELSE agencia END)
                    AND I.IDLOCALTRABALO = (CASE WHEN idLocalTrabalho IS NULL THEN I.IDLOCALTRABALO ELSE idLocalTrabalho END)
                    AND I.IDBANCO = (CASE WHEN idBanco IS NULL THEN I.IDBANCO ELSE  idBanco END))
   LOOP
      -- Efetuar o somatorio dos cheques 
      totalRegistro."VALOR CHEQUE" := totalRegistro."VALOR CHEQUE" + I."VALOR CHEQUE";
      I."VALOR CHEQUE" := PACK_LIB.money(I."VALOR CHEQUE", '');
      PIPE ROW(I);
   END LOOP;
   
   totalRegistro."VALOR CHEQUE" := PACK_LIB.money(totalRegistro."VALOR CHEQUE", '');
   PIPE ROW (totalRegistro);
END;