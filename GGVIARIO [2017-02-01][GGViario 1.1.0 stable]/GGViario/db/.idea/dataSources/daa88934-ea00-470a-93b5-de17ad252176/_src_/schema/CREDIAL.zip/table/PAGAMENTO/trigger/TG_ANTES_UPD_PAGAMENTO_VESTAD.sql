create trigger TG_ANTES_UPD_PAGAMENTO_VESTAD
	before update
	on PAGAMENTO
	for each row
DECLARE
  liquidado BOOLEAN DEFAULT (CASE 
                                WHEN :NEW.PAGA_PRESTACAO = :OLD.PAGA_REEMBOLSO THEN TRUE
                                ELSE FALSE
                             END);
BEGIN
  -- Se o pagamento for finalizado entao
  IF updating AND liquidado THEN
     :NEW.PAGA_ESTADO := 0;
     :NEW.PAGA_DATAENDOSSADO := SYSTIMESTAMP;
     -- :NEW.PAGA_DATADOCPAGAMENTOREAL := SYSTIMESTAMP;
     
     IF :NEW.PAGA_PARTRANCHE = 1 THEN
        :NEW.PAGA_NUMDOCPAGAMENTOREAL := 'Pagamento feito em tranche (O ultimo banco tem mais peso)';
     END IF;
  END IF;
END;