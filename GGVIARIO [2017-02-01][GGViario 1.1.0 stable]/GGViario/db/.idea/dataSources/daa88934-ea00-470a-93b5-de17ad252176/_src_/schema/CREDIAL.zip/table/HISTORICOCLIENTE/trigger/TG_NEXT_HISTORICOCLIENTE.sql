create trigger TG_NEXT_HISTORICOCLIENTE
	before insert
	on HISTORICOCLIENTE
	for each row
BEGIN
  IF inserting
  THEN
    IF :NEW."HISDOS_ID" IS NULL
    THEN
      SELECT SEQ_HISTORICOCLIENTE.NEXTVAL
        INTO :NEW."HISDOS_ID"
        FROM dual;
    END IF;
  END IF;
END;
