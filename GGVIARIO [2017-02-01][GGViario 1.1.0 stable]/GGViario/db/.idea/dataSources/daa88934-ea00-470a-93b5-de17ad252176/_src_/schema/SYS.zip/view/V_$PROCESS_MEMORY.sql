create view V_$PROCESS_MEMORY as
select "PID","SERIAL#","CATEGORY","ALLOCATED","USED","MAX_ALLOCATED" from v$process_memory
