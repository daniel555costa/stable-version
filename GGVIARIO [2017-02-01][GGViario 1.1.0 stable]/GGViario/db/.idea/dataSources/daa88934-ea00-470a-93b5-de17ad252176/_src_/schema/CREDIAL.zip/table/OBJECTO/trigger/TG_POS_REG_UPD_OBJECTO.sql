create trigger TG_POS_REG_UPD_OBJECTO
	before insert or update
	on OBJECTO
DECLARE 
   lastLast varchar2(1000);
BEGIN
    SELECT ff.SQL_FULLTEXT into lastLast 
       -- ff.SQL_FULLTEXT, ff.COMMAND_TYPE
       FROM v$sqlarea ff
    WHERE( UPPER(ff.SQL_TEXT) like 'INSERT%'
         OR UPPER(ff.SQL_TEXT) like 'DELECT%'
         OR UPPER(ff.SQL_TEXT) like 'UPDATE%')
         AND rownum = 1
         
   ORDER BY ff.FIRST_LOAD_TIME desc;
   
   
   
END;
