CREATE FUNCTION prc_reg_disciplina_nuclear (name character varying) RETURNS result
	LANGUAGE plpgsql
AS $$
  BEGIN
    IF (NAME=(SELECT  dicnu_desc FROM discnuclear DN WHERE UPPER(DN.dicnu_desc)=UPPER(NAME))) THEN
       RETURN  '(false,"Já existe esta disciplina nuclear.")'::result;
    ELSE
        INSERT INTO discnuclear(dicnu_desc)VALUES(NAME);
        RETURN '(true,null)';
    END IF;
END
  
$$
