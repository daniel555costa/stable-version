CREATE FUNCTION prc_load_docent (idunidadeorganica integer) RETURNS TABLE(id numeric, name character varying, surname character varying, docent character varying)
	LANGUAGE plpgsql
AS $$
  
  BEGIN

  If idUnidadeOrganica is NOT NULL THEN

    -- Carregar os doccentes que possui hora em uma dada unidade organica
    return query SELECT d.do_id as "id",
        d.do_name as "name",
        d.do_surname as "surname",
        (d.do_name||' '||d.do_surname) as "docent"
      from docente d;

  ELSE

    -- Carregar todos os docentes
    return query SELECT d.do_id as "id",
           d.do_name as "name",
           d.do_surname as "surname",
           (d.do_name||' '||d.do_surname) as "docent"
    from docente d;
  end IF ;


END

$$
