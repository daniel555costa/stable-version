CREATE FUNCTION prc_reg_lancamento (iddocente integer, iduser integer, filelancamento bytea) RETURNS TABLE(result boolean, message character varying, "lancamento.id" numeric)
	LANGUAGE plpgsql
AS $$
  declare  
    idLancamento integer;
  BEGIN

   insert  into lancamento (
	  lanca_do_id,
      lanca_file,
      lanca_user_id
   )  values (
      idDocente,
      fileLancamento,
      idUser
   ) RETURNING lanca_id into idLancamento;
    
    result := true;
    message := 'success';
    "lancamento.id" := idLancamento;
    return next;
END
$$
