CREATE VIEW ver_departamento AS
SELECT dep.dep_id AS "ID",
    dep.dep_name AS "DEPARTAMENTO"
   FROM departamento dep
  WHERE (dep.dep_state = (1)::numeric)