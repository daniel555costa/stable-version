CREATE FUNCTION prc_regcandidato (iduser integer, nome character varying, apelido character varying, dtnasc date, idsexo integer) RETURNS TABLE(result boolean, message character varying, "aluno.id" integer)
	LANGUAGE plpgsql
AS $$

DECLARE
  id integer;
BEGIN
  INSERT INTO aluno_candidato (
    alu_name,
    alu_surname,
    alu_dtnasc,
    alu_sexo_id
  ) VALUES (
    nome,
    apelido,
    dtNasc,
    idSexo
  ) RETURNING  alu_id into id;

  result := true;
  message := 'success';
  "aluno.id" := id;
  RETURN NEXT;
end;
  
$$
