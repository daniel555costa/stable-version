CREATE FUNCTION prc_load_avaliacao_lancamento (idlancamento integer) RETURNS TABLE("ID" numeric, "NAME" character varying, "SURNAME" character varying, "CODE" character varying, "DATA" date, "DATA REGISTRO" timestamp without time zone, "NOTA" double precision, "TIPO.AVALIA.ID" numeric, "MATRICULA.ID" numeric, "TIPO AVALIACAO" character varying, "RESULT" character varying)
	LANGUAGE sql
AS $$
  SELECT
      av.avalia_id as "ID",
      a.alu_name as "NAME",
      a.alu_surname as "SURNAME",
      a.alu_cod::character varying as "CODE",
      av.avalia_dtavaliacao as "DATA",
      av.avalia_dtreg as "DATA REGISTRO",
      av.avalia_nota as "NOTA",
      av.avalia_tpaval_id as "TIPO.AVALIA.ID",
      av.avalia_mat_id as "MATRICULA.ID",
      tvalia.tpaval_desc as "TIPO AVALIACAO",
      CASE
        when av.avalia_result = 1 then 'Aprovado'
        when av.avalia_result = 0 then 'Reprovado'
        else null
      END as "RESULT"
    from avalicacao av
      iNNER JOIN tipo_avalicao tvalia ON av.avalia_tpaval_id = tvalia.tpaval_id
      INNER JOIN matricula m on av.avalia_mat_id = m.mat_id
      INNER JOIN inscricao i On m.mat_ins_id = i.insc_id
      INNER JOIN aluno_candidato a On i.insc_alu_id = a.alu_id
    WHERE av.avalia_lanca_id = idLancamento
      AND av.avalia_state = 1
    ORDER BY avalia_mat_id ASC, tvalia.tpaval_id asc;

$$
