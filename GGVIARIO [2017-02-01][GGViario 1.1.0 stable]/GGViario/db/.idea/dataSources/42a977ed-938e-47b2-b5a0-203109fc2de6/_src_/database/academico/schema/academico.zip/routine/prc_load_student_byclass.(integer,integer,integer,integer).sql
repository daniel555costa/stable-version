CREATE FUNCTION prc_load_student_byclass (idplanstud integer, iddocente integer, idsala integer, idanolectivo integer) RETURNS TABLE("ALUNO.ID" numeric, "ALUNO.COD" character varying, "ALUNO.NAME" character varying, "ALUNO.SURNAME" character varying, "MATRICULA.ID" numeric)
	LANGUAGE sql
AS $$
 
  SELECT DISTINCT a.alu_id "ALUNI.ID",
    a.alu_cod::character varying as "ALUNO.COD",
    a.alu_name as "ALUNO.NAME",
    a.alu_surname as "ALUNO.SURNAME",
    m.mat_id as "MATRICULA.ID"
    
  from matricula m
    inner JOIN inscricao i on m.mat_ins_id = i.insc_id
    inner join aluno_candidato a on i.insc_alu_id = a.alu_id
    inner join planoestudo p on m.mat_plest_id = p.plest_id
    inner join curso c on p.plest_cur_id = c.cur_id
    inner join disciplina d on p.plest_disc_id = d.disc_id
    inner join hora h on p.plest_id = h.h_plest_id
  where h.h_sala_id = idSala
    and h.h_do_id = idDocente
    and h.h_plest_id = idPlanStud
    and m.mat_ano_id = idAnoLectivo
    -- and m.mat_sala_id = idSala
  ;
$$
