CREATE FUNCTION prc_load_lancamento (iddecente integer) RETURNS TABLE("ID" numeric, "DATA" timestamp without time zone, "NAME" character varying, "SURNAME" character varying, "CURSO" character varying, "CADEIRA" character varying, "ANO LECTIVO" character varying, "SIMESTRE" character varying)
	LANGUAGE sql
AS $$
  

    SELECT DISTINCT
      l.lanca_id as "ID",
      l.lanca_dtreg AS  "DATA",
      d.do_name AS "NAME",
      d.do_surname AS "SURNAME",
      c.cur_name AS "CURSO",
      di.disc_name AS "CADEIRA",
      (an.ano_inicial||'/'||(an.ano_inicial+1)) AS "ANO LECTVO",
      'S1' as "SIMESTRE"

    FROM avalicacao a
      INNER JOIN lancamento l ON a.avalia_lanca_id = l.lanca_id
      INNER JOIN docente d ON l.lanca_do_id = d.do_id
      INNER JOIN matricula m ON a.avalia_mat_id = m.mat_id
      INNER JOIN planoestudo p ON m.mat_plest_id = p.plest_id
      INNER JOIN curso c ON p.plest_cur_id = c.cur_id
      INNER JOIN disciplina di ON p.plest_cur_id = di.disc_id
      INNER JOIN anolectivo an ON m.mat_ano_id = an.ano_id
    WHERE idDecente IS NULL
      OR (idDecente IS NOT NULl AND  idDecente = d.do_id);

 
$$
