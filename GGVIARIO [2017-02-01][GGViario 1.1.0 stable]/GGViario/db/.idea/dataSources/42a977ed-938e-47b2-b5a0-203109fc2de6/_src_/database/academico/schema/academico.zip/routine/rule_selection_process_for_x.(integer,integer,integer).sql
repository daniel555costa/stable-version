CREATE FUNCTION rule_selection_process_for_x (idcandidatu integer, xidvaga integer, xalocation integer) RETURNS result
	LANGUAGE plpgsql
AS $$
  BEGIN
    -- DECLARE xVariable as variable of position 1

    IF xAlocation = b'1' THEN
      PERFORM rule.selection_select_candidature(idCandidatu, xIdVaga);

    ELSEIF NOT rule_selection_has_enter_possiblit(idCandidatu, xIdVaga) THEN
      PERFORM rule.selection_suplente_candidature(idCandidatu, xIdVaga);
    END IF;
    
    return '(true,null)'::result;
  END
  
$$
