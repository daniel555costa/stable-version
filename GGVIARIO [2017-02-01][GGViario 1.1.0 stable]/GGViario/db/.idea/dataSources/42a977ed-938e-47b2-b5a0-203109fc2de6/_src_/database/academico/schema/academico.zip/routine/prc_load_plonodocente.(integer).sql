CREATE FUNCTION prc_load_plonodocente (iddocente integer) RETURNS TABLE("ID" numeric, "DOCENTE.ID" numeric, "NAME" character varying, "SURNAME" character varying, "CURSO" character varying, "DISCIPLINA" character varying, "SALA.ID" numeric, "SALA" character varying, "ANO-LECTIVO.ID" numeric)
	LANGUAGE sql
AS $$
  
   select DISTINCT p.plest_id as "ID",
        d.do_id as "DOCENTE.ID",
				d.do_name as "NAME",
				d.do_surname as "SURNAME",
				c.cur_name as "CURSO",
				di.disc_name as "DISCIPLINA",
        s.sala_id as "SALA.ID",
				s.sala_name as "SALA",
        h.h_ano_id as "ANO-LECTIVO.ID"
		  from hora h
		    inner JOIN docente d on h.h_do_id = d.do_id
		    inner join planoestudo p on h.h_plest_id = p.plest_id
		    inner join curso c on p.plest_cur_id = c.cur_id
		    inner JOIN  disciplina di ON p.plest_disc_id = di.disc_id
		    inner join sala s on h.h_sala_id = s.sala_id
		  where h.h_do_id = idDocente;
$$
