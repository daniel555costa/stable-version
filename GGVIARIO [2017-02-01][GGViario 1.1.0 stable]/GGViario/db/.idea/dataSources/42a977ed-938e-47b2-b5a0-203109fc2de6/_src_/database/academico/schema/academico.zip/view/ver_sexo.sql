CREATE VIEW ver_sexo AS
SELECT s.sexo_id AS "ID",
    s.sexo_desc AS "DESCRICAO"
   FROM sexo s