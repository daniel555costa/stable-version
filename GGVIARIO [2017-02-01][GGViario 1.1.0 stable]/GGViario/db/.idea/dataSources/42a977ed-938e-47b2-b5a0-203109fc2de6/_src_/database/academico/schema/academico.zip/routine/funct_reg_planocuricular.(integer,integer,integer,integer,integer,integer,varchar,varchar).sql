CREATE FUNCTION funct_reg_planocuricular (id_curso integer, id_disciplina integer, id_level integer, id_tipo_duracao integer, id_tipo_obrigacao integer, carga_horaria integer, unidade_credito character varying, precedencia character varying) RETURNS result
	LANGUAGE plpgsql
AS $$
  BEGIN
  IF (25<(SELECT SUM(p.plest_cargahoraria) FROM planoestudo p WHERE (p.plest_cur_id=ID_CURSO and p.plest_lev_id=ID_LEVEL and p.plest_tpd_id=ID_TIPO_DURACAO and p.plest_state=1))) THEN
     RETURN '(false,"Limite de carga horaria excedida!")'::result;
  ELSEIF (ID_DISCIPLINA=(SELECT pp.plest_disc_id from planoestudo pp WHERE (pp.plest_cur_id=ID_CURSO and pp.plest_lev_id=ID_LEVEL and pp.plest_tpd_id=ID_TIPO_DURACAO and pp.plest_state=1))) THEN
     RETURN '(FALSE,"A disciplina já esta neste plano de estudo!")'::result;
  ELSE
    INSERT INTO planoestudo(plest_cur_id,
                            plest_disc_id,
                            plest_lev_id,
                            plest_tpd_id,
                            plest_tpob_id,
                            plest_cargahoraria,
                            plest_unidadecredito,
                            plest_precedencia)VALUES(ID_CURSO,
                                                     ID_DISCIPLINA,
                                                     ID_LEVEL,
                                                     ID_TIPO_DURACAO,
                                                     ID_TIPO_OBRIGACAO,
                                                     CARGA_HORARIA,
                                                     UNIDADE_CREDITO,
                                                     PrECEDENCIA);
     RETURN '(true,null)'::result;
  END IF;
END

  
$$
