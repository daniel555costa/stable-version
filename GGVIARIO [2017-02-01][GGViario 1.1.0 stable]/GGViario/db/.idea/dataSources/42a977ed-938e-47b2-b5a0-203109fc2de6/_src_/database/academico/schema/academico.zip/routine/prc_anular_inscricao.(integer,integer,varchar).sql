CREATE FUNCTION prc_anular_inscricao (iduser integer, idcandidato integer, observacao character varying) RETURNS result
	LANGUAGE sql
AS $$
  

        update inscricao
            set insc_state = -1, insc_observacao = observacao
          WHERE insc_alu_id = idCandidato;

     UPDATE notacertificado
      set nt_state = -1
    ; -- WHERE insc.insc_state = -1;
-- valta rever
    

    SELECT '(true,null)'::result;

 
$$
