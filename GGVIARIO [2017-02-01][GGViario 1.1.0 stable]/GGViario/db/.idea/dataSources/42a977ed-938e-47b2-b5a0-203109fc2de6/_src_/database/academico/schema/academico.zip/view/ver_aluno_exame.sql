CREATE VIEW ver_aluno_exame AS
SELECT al.alu_id AS "ID_ALUNO",
    ((al.alu_name)::text || (al.alu_surname)::text) AS "NOME_DO_ALUNO",
    d.disc_name AS "NOME_DISCIPLINA",
    av.avalia_nota AS "NOTA",
    l.lev_desc AS "ANO"
   FROM (((((avalicacao av
     JOIN matricula m ON ((av.avalia_mat_id = m.mat_id)))
     JOIN alunocandidato al ON ((av.avalia_mat_id = m.mat_id)))
     JOIN planoestudo pl ON ((pl.plest_id = m.mat_plest_id)))
     JOIN disciplina d ON (((d.disc_codigo)::text = ((pl.plest_disc_id)::character varying)::text)))
     JOIN level l ON ((l.lev_id = pl.plest_lev_id)))
  WHERE ((av.avalia_state = (1)::numeric) AND (av.avalia_nota < (10)::double precision))