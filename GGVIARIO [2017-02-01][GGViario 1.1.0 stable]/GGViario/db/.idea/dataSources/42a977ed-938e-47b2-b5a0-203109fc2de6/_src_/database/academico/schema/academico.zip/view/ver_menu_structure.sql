CREATE VIEW ver_menu_structure AS
SELECT me.mn_id,
    me.mn_code,
    me.mn_name,
    me.mn_level,
    me.mn_link,
    me.mn_uselink,
    me.mn_raiz,
    me.mn_state,
    me.mn_mn_id,
    me.mn_udom_id,
    me.mn_pagetitle AS mm_pagetitle,
    u.udom_domain,
    u.udom_usertype,
    mm.mn_code AS mn_mn_code,
    mm.mn_link AS mn_mn_link,
    mm.mn_name AS mn_mn_name,
    ( SELECT (count(0) > 0)
           FROM menu m
          WHERE (m.mn_mn_id = me.mn_id)) AS mn_haschidren
   FROM ((menu me
     JOIN userdomain u ON ((me.mn_udom_id = u.udom_id)))
     LEFT JOIN menu mm ON ((me.mn_mn_id = mm.mn_id)))
  WHERE (me.mn_state = (1)::numeric)
  ORDER BY me.mn_raiz