CREATE FUNCTION prc_disciplina_nuclear_curso (idcurso integer) RETURNS TABLE("ID" numeric, "DISCIPLINA" character varying)
	LANGUAGE sql
AS $$
   SELECT
      discN.dicnu_id::numeric,
      discN.dicnu_desc::character varying
   FROM discnuvaga discVaga
      INNER JOIN vaga v ON v.vaga_id = discVaga.dnvaga_vaga_id
      INNER JOIN discnuclear discN ON discN.dicnu_id = discVaga.dnvaga_dicnu_id
      INNER JOIN curso c ON c.cur_id = v.vaga_cur_id
   WHERE v.vaga_cur_id = idCurso;

$$
