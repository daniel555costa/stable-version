CREATE FUNCTION proc_insert_type_service (descrico character varying) RETURNS result
	LANGUAGE plpgsql
AS $$

  BEGIN
 			INSERT INTO type_service  (tser_desc) VALUES(descrico);
    RETURN '(true,null)'::result;
  END
  
$$
