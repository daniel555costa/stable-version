CREATE FUNCTION load_avalicao_matricula (idmatricula integer) RETURNS TABLE("AVALIACAO" character varying, "NOTA" double precision)
	LANGUAGE sql
AS $$
    SELECT
        ta.tpaval_desc,
        a.avalia_nota 

    FROM avalicacao a
          INNER JOIN tipo_avalicao ta ON a.avalia_tpaval_id = ta.tpaval_id
    WHERE a.avalia_mat_id = idMatricula
      AND a.avalia_state = 1;
  
$$
