CREATE FUNCTION prc_reg_avaliacao (idmatricula integer, idlancamento integer, tipoavaliacao integer, nota double precision, dataavaliacao date) RETURNS result
	LANGUAGE sql
AS $$
   
      INSERT INTO avalicacao (
        avalia_mat_id,
        avalia_lanca_id,
        avalia_tpaval_id,
        avalia_nota,
        avalia_dtavaliacao
      ) VALUES(
        idMatricula,
        idLancamento,
        Tipoavaliacao,
        nota,
        dataavaliacao
    );
    
    SELECT '(true,null)'::result;

$$
