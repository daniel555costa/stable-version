CREATE FUNCTION funct_load_curso (filter json) RETURNS TABLE("ID" numeric, "COD" character varying, "NAME" character varying, "GRAU_ACADEMICO" character varying, "SAIDAS_PROFISSIONAIS" character varying, "OBJECTIVO" character varying, "DURACAO" numeric, "DOCUMENTO_SAIDA" character varying, "DEPARTAMENTO" character varying)
	LANGUAGE plpgsql
AS $$
   DECLARE
     search CHARACTER VARYING DEFAULT  filter-> 'search';
     i RECORD;
   BEGIN
     SELECT * into i
     from curso c
       inner join departamento d on c.cur_dep_id = d.dep_id
       inner join grauacademico ga on c.cur_gacademico_id = ga.gacademico_id
       INNER JOIN cursodocumento cd on c.cur_curdoc_id = cd.curdoc_id
      LIMIT 0;


     for i in (
       SELECT *
          from curso c
            inner join departamento d on c.cur_dep_id = d.dep_id
            inner join grauacademico ga on c.cur_gacademico_id = ga.gacademico_id
            INNER JOIN cursodocumento cd on c.cur_curdoc_id = cd.curdoc_id
     ) LOOP

       "ID" := i.cur_id;
       "COD" := i.cur_codigo;
       "NAME" := i.cur_name;
       "GRAU_ACADEMICO" := i.gacademico_desc;
       "SAIDAS_PROFISSIONAIS" := i.cur_saidasproficionais;
       "OBJECTIVO" := i.cur_objetivo;
       "DURACAO" := i.cur_duracao;
       "DOCUMENTO_SAIDA" := i.cur_saidasproficionais;
       "DEPARTAMENTO" := i.dep_name;

       RETURN NEXT;

     END LOOP;
   END;
$$
