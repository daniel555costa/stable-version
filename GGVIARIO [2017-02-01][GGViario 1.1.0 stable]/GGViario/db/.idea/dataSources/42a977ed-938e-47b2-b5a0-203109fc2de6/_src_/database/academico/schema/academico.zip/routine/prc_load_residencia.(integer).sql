CREATE FUNCTION prc_load_residencia (iddistrito integer) RETURNS TABLE("LOCALIDADE" character varying, "ID LOCALIDADE" numeric)
	LANGUAGE sql
AS $$
  
      SELECT local.local_desc LOCALIDADE,
             local.local_id "ID LOCALIDADE"
          from distrito dist
               INNER JOIN localidade local ON dist.dist_id = local.local_dist_id
          WHERE dist.dist_id = idDistrito;
  
$$
