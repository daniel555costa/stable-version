CREATE VIEW ver_all_user AS
SELECT ca.alu_id AS "ID",
    u.udom_id AS "DOMAIN.ID",
    ca.alu_name AS "USER.NAME",
    ca.alu_surname AS "USER.SURNAME",
    ca.alu_accessname AS "USER.ACCESSNAME",
    ca.alu_pwd AS "USER.PWD",
    ca.alu_dtreg AS "USER.DTREG",
    ca.alu_access AS "USER.ACCESS",
    u.udom_usertype AS "DOMAIN.TYPE",
    u.udom_domain AS "DOMAIN.DOMAIN"
   FROM (alunocandidato ca
     JOIN userdomain u ON ((upper((u.udom_usertype)::text) = 'STUD'::text)))
UNION
 SELECT u.user_id AS "ID",
    u.user_udom_id AS "DOMAIN.ID",
    u.user_name AS "USER.NAME",
    u.user_surname AS "USER.SURNAME",
    u.user_accessname AS "USER.ACCESSNAME",
    u.user_pwd AS "USER.PWD",
    u.user_dtreg AS "USER.DTREG",
    u.user_state AS "USER.ACCESS",
    udoma.udom_usertype AS "DOMAIN.TYPE",
    udoma.udom_domain AS "DOMAIN.DOMAIN"
   FROM (t_user u
     JOIN userdomain udoma ON ((u.user_udom_id = udoma.udom_id)))
UNION
 SELECT d.do_id AS "ID",
    ddomain.udom_id AS "DOMAIN.ID",
    d.do_name AS "USER.NAME",
    d.do_surname AS "USER.SURNAME",
    d.do_accessname AS "USER.ACCESSNAME",
    d.do_pwd AS "USER.PWD",
    d.do_dtreg AS "USER.DTREG",
    d.do_access AS "USER.ACCESS",
    ddomain.udom_usertype AS "DOMAIN.TYPE",
    ddomain.udom_domain AS "DOMAIN.DOMAIN"
   FROM (docente d
     JOIN userdomain ddomain ON ((upper((ddomain.udom_usertype)::text) = 'DOSC'::text)))