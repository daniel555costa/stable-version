CREATE VIEW ver_vagas_disponiveis AS
SELECT v.vaga_id AS "ID VAGA",
    c.cur_id AS "ID CURSO",
    c.cur_name AS "NOME CURSO",
    grau.gacademico_desc AS "GRAU ACADÉMICO",
    c.cur_saidasproficionais AS "SAIDAS PROFESSIONAIS",
    v.vaga_numero AS "NÚMERO VAGA",
    v.vaga_datainicio AS "DATA INICIO",
    v.vaga_datafim AS "DATA FIM",
    per.periodo_desc AS "PERIODO",
    concat(ano.ano_inicial, '/', ano.ano_final) AS "ANO LETIVO",
    v.vaga_dtreg AS "DATA REGISTO"
   FROM ((((curso c
     JOIN vaga v ON ((c.cur_id = v.vaga_cur_id)))
     JOIN anolectivo ano ON ((ano.ano_id = v.vaga_ano_id)))
     JOIN grauacademico grau ON ((grau.gacademico_id = c.cur_gacademico_id)))
     JOIN periodo per ON ((per.periodo_id = v.vaga_periodo_id)))
  WHERE (v.vaga_state = (1)::numeric)