CREATE VIEW ver_grauacademico AS
SELECT grau.gacademico_id AS "ID",
    grau.gacademico_desc AS "DESCRICAO",
    grau.gacademico_duracao AS "DURACAO"
   FROM grauacademico grau