CREATE VIEW ver_distrito AS
SELECT dist.dist_id AS "ID",
    dist.dist_desc AS "DESCRICAO"
   FROM distrito dist