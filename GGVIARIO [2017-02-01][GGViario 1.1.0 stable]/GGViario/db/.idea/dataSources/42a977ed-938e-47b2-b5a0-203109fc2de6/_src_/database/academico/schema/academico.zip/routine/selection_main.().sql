CREATE FUNCTION selection_main () RETURNS result
	LANGUAGE plpgsql
AS $$

   

  BEGIN
    /*
    
     -- Enquanto hover uma candidature em estado pendente
    --

    DECLARE totalCandidatureRestante, totalCandidaturaOfCandidatu INTEGER;
    DECLARE idCandidatu INTEGER;
    DECLARE xIdVaga, xAlocation INTEGER;
    DECLARE yIdVaga, yAlocation INTEGER;
    DECLARE idVaga,  alocation,  vOption INTEGER;
    DECLARE oIdVaga, oAlocation INTEGER;
      WHILE (SELECT count(*) from candidature where candr_state = 2) > 0 DO

      -- percorer todas as vagas com candidatura pendente
      BEGIN

        DECLARE  done BOOLEAN;
        DECLARE cursorCandidatureOfVaga CURSOR FOR
          SELECT ca.candr_alu_id,
            ca.candr_vaga_id,
            ca.candr_alocation,
            ca.candr_option
          from candidature ca
          where ca.candr_state = 2
          ORDER BY
            ca.candr_alocation desc,
            ca.candr_option ASC,
            ca.candr_vaga_id asc,
            ca.candr_position asc
        ;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

        OPEN cursorCandidatureOfVaga;

        read_candidature_vaga : LOOP

          FETCH cursorCandidatureOfVaga
          INTO idCandidatu,
            idVaga,
            alocation,
            vOption;
          IF done THEN  LEAVE read_candidature_vaga; END IF ;

          if rule_selection_count_candidature_of(idCandidatu) = 2 THEN

            -- DECLARE @oVariable as variable of other candidature of candidatu
            SELECT ca.candr_vaga_id,
              ca.candr_alocation
            INTO oIdVaga,
              oAlocation
            from candidature ca
            WHERE ca.candr_alu_id = idCandidatu
                  and ca.candr_option <> vOption;

            IF vOption = 1 THEN
              SET xIdVaga = idVaga, xAlocation = alocation;
              SET yIdVaga = oIdVaga, yAlocation = oAlocation;

            ELSE
              SET yIdVaga = idVaga, yAlocation = alocation;
              SET xIdVaga = oIdVaga, xAlocation = oAlocation;
            END IF;

            call rule_selection_process_for_xy(idCandidatu,
                                   xAlocation,  xIdVaga,
                                   yAlocation,  yIdVaga);

          ELSE

            call rule_selection_process_for_x(idCandidatu, idVaga, alocation);

          END IF;

        END LOOP;

        CLOSE cursorCandidatureOfVaga;
      END;

    END WHILE;

    select * from ver_result_selection;
    */
    null;
  END
  
  
$$
