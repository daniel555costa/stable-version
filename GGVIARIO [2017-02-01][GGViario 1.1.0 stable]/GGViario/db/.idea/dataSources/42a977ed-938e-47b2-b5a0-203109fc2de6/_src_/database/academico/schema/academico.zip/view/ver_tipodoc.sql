CREATE VIEW ver_tipodoc AS
SELECT tipodoc.tipodoc_id AS "ID",
    tipodoc.tipodoc_desc AS "DESCRICAO"
   FROM tipodocumento tipodoc
  WHERE (tipodoc.tipodocstate = (1)::numeric)