CREATE VIEW ver_docente AS
SELECT d.do_id AS "ID",
    ((d.do_name)::text || (d.do_surname)::text) AS "NAME"
   FROM docente d