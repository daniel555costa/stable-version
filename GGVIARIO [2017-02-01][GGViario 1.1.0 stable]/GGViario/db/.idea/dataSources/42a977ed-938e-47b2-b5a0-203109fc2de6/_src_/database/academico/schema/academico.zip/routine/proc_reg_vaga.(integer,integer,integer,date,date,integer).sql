CREATE FUNCTION proc_reg_vaga (id_curso integer, num_vaga integer, id_ano_lectivo integer, data_inicio date, data_fim date, id_periodo integer) RETURNS result
	LANGUAGE sql
AS $$
  
    INSERT INTO vaga(vaga_cur_id,
                     vaga_numero,
                     vaga_ano_id,
                     vaga_datainicio,
                     vaga_datafim,
                     periodo_id)VALUES(ID_CURSO,
                                       NUM_VAGA,
                                       ID_ANO_LECTIVO,
                                       DATA_INICIO,
                                       DATA_FIM,
                                       ID_PERIODO);
  
  select '(true,null)'::result;
  
$$
