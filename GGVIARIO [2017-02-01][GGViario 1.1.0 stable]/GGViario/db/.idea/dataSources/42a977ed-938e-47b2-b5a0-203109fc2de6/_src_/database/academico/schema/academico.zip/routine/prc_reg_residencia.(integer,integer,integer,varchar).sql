CREATE FUNCTION prc_reg_residencia (idlocalidade integer, idaluno integer, idtipodoc integer, numerodoc character varying) RETURNS result
	LANGUAGE plpgsql
AS $$
  DECLARE alunoExiste integer DEFAULT 0;
    
  BEGIN
    SELECT res.res_alu_id into alunoExiste
        from residencia res
    WHERE res.res_alu_id = idAluno
      and res.res_state = 1;

    if alunoExiste = 0 then
        INSERT INTO residencia
        (
          res_local_id,
          res_alu_id) VALUES
          (
            idlocalidade,
            idAluno
          );

        INSERT into documento
        (
          doc_numero,
          doc_tipodoc_id,
          doc_aluno_id)
          VALUES
          (
              numeroDoc,
              idTipoDoc,
              idAluno
          );
       RETURN '(true,null)'::result;
      ELSE
        UPDATE residencia
          set res_local_id = idlocalidade
        WHERE res_alu_id = idAluno;

       RETURN '(true,null)'::result;
    END IF;
END
  
$$
