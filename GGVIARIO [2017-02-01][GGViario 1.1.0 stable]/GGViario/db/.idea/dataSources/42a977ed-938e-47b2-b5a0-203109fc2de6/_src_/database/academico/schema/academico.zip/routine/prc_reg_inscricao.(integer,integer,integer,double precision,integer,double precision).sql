CREATE FUNCTION prc_reg_inscricao (iduser integer, idaluno integer, idcurso integer, media double precision, optione integer, desviopadrao double precision) RETURNS TABLE(result boolean, message character varying, "inscricao.id" numeric)
	LANGUAGE plpgsql
AS $$
   DECLARE contInc INTEGER;
     idVaga INTEGER;
     last_id integer;

  BEGIN
    -- estado 0 = NÃO SELECIONADO
    -- estado 1 = SELECIONADO
    -- estado 2 = PRE-INSCRITO

    SELECT vaga_id into idVaga
    FROM vaga
    WHERE vaga_cur_id = idCurso AND vaga_state = 1;


    SELECT count(*) into contInc
      from vaga v
      INNER JOIN anolectivo ano on ano.ano_id = v.vaga_ano_id
      INNER JOIN inscricao insc on v.vaga_id = insc.insc_vaga_id
    where insc.insc_alu_id = idAluno;

    if(contInc > 2) THEN
      result := false;
      message := 'Já foi inscrito neste ano letivo.';
      RETURN next;
    ELSE
      INSERT INTO inscricao
      (
        insc_alu_id,
        insc_vaga_id,
        insc_result,
        insc_mediacertificad,
        insc_option,
        insc_desviopadraomedia
      ) VALUES (
        idAluno,
        idVaga,
        1,
        media,
        optione,
        desvioPadrao
      ) returning insc_id into last_id;

      result := TRUE ;
      "inscricao.id" := last_id;
      RETURN next;
    END IF;
  END
  
$$
