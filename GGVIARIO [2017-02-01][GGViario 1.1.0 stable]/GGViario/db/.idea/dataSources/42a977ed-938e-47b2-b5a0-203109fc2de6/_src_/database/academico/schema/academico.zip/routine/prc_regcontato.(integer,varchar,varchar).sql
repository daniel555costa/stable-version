CREATE FUNCTION prc_regcontato (idaluno integer, nome character varying, contacto character varying) RETURNS result
	LANGUAGE plpgsql
AS $$
  DECLARE nomeContactoExist INT;
     idTypeContact INTeger;
     idAlunoExist INTeger DEFAULT 0;

  BEGIN
    SELECT COUNT(*) INTO nomeContactoExist
    FROM typecontacto type
    WHERE type.tpcont_desc = nome;

    SELECT max(co.cont_alu_id) into idAlunoExist
        from contacto co
    WHERE co.cont_alu_id = idAluno
          and co.cont_state = 1
          and co.cont_tpcont_id= 1;

    IF nomeContactoExist >0 THEN  -- verifica -se o nome de contacto já existe
      SELECT type.tpcont_id INTO idTypeContact
      FROM typecontacto type
      WHERE type.tpcont_desc = nome;

      if idAlunoExist = 0 then
          INSERT INTO contacto
          (cont_alu_id, cont_contacto, cont_tpcont_id) VALUES(idAluno, contacto, idTypeContact);
      else
          UPDATE contacto
              set cont_contacto = contacto,
              cont_tpcont_id = idTypeContact
          WHERE cont_alu_id = idAluno;
      END IF;
    ELSE
      INSERT INTO typecontacto (tpcont_desc) VALUES (nome);
      SELECT type.tpcont_id INTO idTypeContact
      FROM typecontacto type
      WHERE type.tpcont_desc = nome;
      if idAlunoExist = 0 then
           INSERT INTO contacto (cont_alu_id, cont_contacto, cont_tpcont_id)VALUES(idAluno, contacto, idTypeContact);
      ELSE
         UPDATE contacto
            set cont_contacto = contacto,
            cont_tpcont_id = idTypeContact
        WHERE cont_alu_id = idAluno;
        END IF;
    END IF;

    return '(true,null)'::result;
  END

  
$$
