CREATE FUNCTION funct_load_disciplina (filter json) RETURNS TABLE("ID" numeric, "COD" character varying, "NAME" character varying)
	LANGUAGE plpgsql
AS $$
  DECLARE
    i RECORD;
  BEGIN
    for i in (
      SELECT *
        from disciplina dd
    ) LOOP

      "ID" := i.disc_id;
      "COD" := i.disc_codigo;
      "NAME" := i.disc_name;

      RETURN NEXT;
    END LOOP;
  END;
$$
