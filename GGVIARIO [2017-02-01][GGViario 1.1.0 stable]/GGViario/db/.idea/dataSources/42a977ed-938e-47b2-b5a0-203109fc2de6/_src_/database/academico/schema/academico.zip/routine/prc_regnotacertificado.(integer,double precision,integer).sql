CREATE FUNCTION prc_regnotacertificado (idinsc integer, nota double precision, id_disc_nucl integer) RETURNS result
	LANGUAGE plpgsql
AS $$
  BEGIN
    INSERT INTO notacertificado
    (
      nt_insc_id,
      nt_nota,
      nt_dicnu_id
    )
    VALUES
      (
        idInsc,
        nota,
        id_disc_nucl
      );
    RETURN '(true,null)'::result;
  END

  
$$
