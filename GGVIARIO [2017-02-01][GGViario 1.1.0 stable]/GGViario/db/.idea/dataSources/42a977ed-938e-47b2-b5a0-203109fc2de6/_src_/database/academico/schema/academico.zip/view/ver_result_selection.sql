CREATE VIEW ver_result_selection AS
SELECT ca.candr_id AS "ID",
    v.vaga_id AS "VAGA.ID",
    al.alu_id AS "ALUNO.ID",
    al.alu_name AS "NAME",
    al.alu_surname AS "SURNAME",
    age((al.alu_dtnasc)::timestamp with time zone) AS "AGE",
    s.sexo_desc AS "SEXO",
    c.cur_name AS "CURSO",
    c.cur_id AS "CURSO.ID",
    ca.candr_valuecandidate AS "VALOR",
    concat(ca.candr_position, '/', v.vaga_numero) AS "POSICAO",
    concat(ca.candr_option, 'ª') AS "OPCAO",
        CASE
            WHEN (ca.candr_state = (0)::numeric) THEN 'SUPLENTE'::text
            WHEN (ca.candr_state = (1)::numeric) THEN 'SELECIONADO'::text
            WHEN (ca.candr_state = (2)::numeric) THEN 'PENDENTE'::text
            WHEN (ca.candr_state = ('-1'::integer)::numeric) THEN 'REMOVIDO'::text
            ELSE 'ELSE'::text
        END AS "RESULTADO",
    ca.candr_alocation AS alocation
   FROM ((((candidature ca
     JOIN alunocandidato al ON ((ca.candr_alu_id = al.alu_id)))
     JOIN vaga v ON ((ca.candr_vaga_id = v.vaga_id)))
     JOIN curso c ON ((v.vaga_cur_id = c.cur_id)))
     JOIN sexo s ON ((al.alu_sexo_id = s.sexo_id)))
  ORDER BY ca.candr_id