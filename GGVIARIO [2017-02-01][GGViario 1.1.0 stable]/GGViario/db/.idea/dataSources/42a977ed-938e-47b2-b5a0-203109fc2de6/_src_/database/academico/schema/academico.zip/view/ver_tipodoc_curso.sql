CREATE VIEW ver_tipodoc_curso AS
SELECT cd.curdoc_id AS "ID",
    cd.curdoc_desc AS "TIPO DOCUMENTO"
   FROM cursodocumento cd