CREATE FUNCTION funct_create_menu (cod character varying, menuname character varying, pagetitle character varying, link character varying, domainkey character varying, menucodesuper character varying, uselink boolean) RETURNS result
	LANGUAGE plpgsql
AS $$
DECLARE
  mnSuperId INTEGER DEFAULT NULL ;
  domainId INTEGER;
  iCount INTEGER;
  iCountSuper INTEGER DEFAULT 0;
  superLevel INTEGER DEFAULT -1;
  superRaiz CHARACTER VARYING DEFAULT '';
  ttRaiz INTEGER;
  raiz CHARACTER VARYING;
  menuLeve INTEGER DEFAULT 0;
  rRaiz character varying;


BEGIN

  select count(*) into iCount
  from menu m
  where m.mn_code = cod;

  select count(*) into iCountSuper
  from menu m
  where m.mn_code = menuCodeSuper;

  if iCount = 0
     AND  (menuCodeSuper IS NULL OR (iCountSuper = 1)) then


    select count(*) into ttRaiz
    from menu m
    where m.mn_mn_id IS NULL;

    if menuCodeSuper IS NOT NULL THEN
      select m.mn_id,
        concat(m.mn_raiz,'.'),
        m.mn_level
      into mnSuperId,
        superRaiz,
        superLevel
      from menu m
      WHERE upper(m.mn_code) = upper(menuCodeSuper);

      select count(*) into ttRaiz
      from menu m
      where m.mn_mn_id = mnSuperId;

    END IF;

    rRaiz := ttRaiz||'';
    if length(rRaiz) = 1 then rRaiz := '0'||rRaiz; end if;
    raiz := concat(superRaiz,rRaiz);
    menuLeve := superLevel +1;


    SELECT udomain.udom_id into domainId
    from userdomain udomain
    WHERE upper(udomain.udom_usertype) = upper(domainKey);

    INSERT into menu(
      mn_name,
      mn_code,
      mn_link,
      mn_mn_id,
      mn_udom_id,
      mn_level,
      mn_raiz,
      mn_uselink,
      mn_pagetitle
    )VALUES(
      menuName,
      cod,
      link,
      mnSuperId,
      domainId,
      menuLeve,
      raiz,
      useLink,
      pageTitle
    );
    return '(true,null)'::result;
  else
    return '(false,null)'::result;
  end if;
END
$$
