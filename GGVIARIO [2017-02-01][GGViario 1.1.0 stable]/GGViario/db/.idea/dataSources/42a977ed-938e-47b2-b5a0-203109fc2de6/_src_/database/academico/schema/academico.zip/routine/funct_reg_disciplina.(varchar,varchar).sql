CREATE FUNCTION funct_reg_disciplina (codigo character varying, name character varying) RETURNS result
	LANGUAGE plpgsql
AS $$
  BEGIN
    IF (CODIGO=(SELECT disc_codigo FROM disciplina D WHERE D.disc_codigo=CODIGO))THEN
        RETURN '(false,"Já existe disciplina com este código")'::result;
    ELSEIF (NAME=(SELECT disc_name FROM disciplina DD WHERE UPPER(DD.disc_name)=NAME)) THEN
        return '(false,"Já existe disciplina com este nome."'::result;
    ELSE
        INSERT INTO disciplina(disc_codigo,
                               disc_name)VALUES(CODIGO,
                                                NAME);
        RETURN '(true,null)'::result;
    END IF;
  END;
$$
