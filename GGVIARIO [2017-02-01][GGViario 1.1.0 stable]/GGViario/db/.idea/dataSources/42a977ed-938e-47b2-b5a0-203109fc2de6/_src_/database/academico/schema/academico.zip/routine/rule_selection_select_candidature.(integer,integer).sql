CREATE FUNCTION rule_selection_select_candidature (idcandidatu integer, idvaga integer) RETURNS result
	LANGUAGE plpgsql
AS $$
  
  BEGIN

    update candidature
    set candr_state = 1
    where candr_alu_id = idCandidatu
          and candr_vaga_id = idVaga;
  END
  
  
$$
