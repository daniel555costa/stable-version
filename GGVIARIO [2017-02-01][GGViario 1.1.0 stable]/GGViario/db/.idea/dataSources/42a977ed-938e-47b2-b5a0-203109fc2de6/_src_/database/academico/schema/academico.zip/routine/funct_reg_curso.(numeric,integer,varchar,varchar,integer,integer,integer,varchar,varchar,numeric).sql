CREATE FUNCTION funct_reg_curso (iduser numeric, id_departamento integer, curso_name character varying, saidas_proficionais character varying, id_grau_academico integer, codigo_curso integer, duracao integer, objectivo character varying, curso_continuidade character varying, tp_documento numeric) RETURNS result
	LANGUAGE plpgsql
AS $$
  BEGIN
  IF (CURSO_NAME=(SELECT cur_name FROM curso C WHERE UPPER(cur_name)=UPPER(CURSO_NAME))) THEN
    RETURN '(false,Já existe curso com este nome.)'::result;
  ELSE
    INSERT INTO curso(
      cur_dep_id,
      cur_name,
      cur_saidasproficionais,
      cur_gacademico_id,
      cur_cursocontinuidade,
      cur_objetivo,
      cur_codigo,
      cur_duracao,
      cur_curdoc_id,
      cur_user_id
    )VALUES(
       ID_DEPARTAMENTO,
       CURSO_NAME,
       SAIDAS_PROFICIONAIS,
       ID_GRAU_ACADEMICO,
       CURSO_CONTINUIDADE,
       OBJECTIVO,
       CODIGO_CURSO,
       DURACAO,
       tp_documento,
      idUser
    );
    return '(true,null)'::result;
  END IF;
END
$$
