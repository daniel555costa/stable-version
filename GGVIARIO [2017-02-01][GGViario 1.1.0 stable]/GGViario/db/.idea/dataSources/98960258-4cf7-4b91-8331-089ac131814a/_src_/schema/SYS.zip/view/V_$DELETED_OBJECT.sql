create view V_$DELETED_OBJECT as
select "RECID","STAMP","TYPE","OBJECT_RECID","OBJECT_STAMP","OBJECT_DATA","SET_STAMP","SET_COUNT" from v$deleted_object
