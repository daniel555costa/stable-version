create PACKAGE "PACK_VALIDATE" IS
-- Essa funcao serve para validar um numero de apolice em relacao ao 
        --utilizador que esta a uzala, o tempo gerado e o seguro usado
    FUNCTION apoliceNumber (userId NUMBER, 
                                    codigoApolice VARCHAR2, 
                                    idSeguro NUMBER) RETURN PACK_TYPE.Resultado;
    
    -- true  -> Esta valido
    -- flase -> Ja exite
    FUNCTION apoliceExist(numApolice VARCHAR2) RETURN VARCHAR2;
    
    
    -- Retorno 1 - Esta valido
    -- Retorno 0 - Esta invalido
    FUNCTION isValidApolice(numApolice VARCHAR2, idSeguroo NUMBER) RETURN NUMBER;
                                    
                                    
    FUNCTION dadosContrato(ID_SEGURO NUMBER, -- Aqui deve ser um nuber
                            ID_CLIENTE NUMBER,
                            NUMERO_APOLICE VARCHAR2,
                            CODIGO_CONTRATO VARCHAR2, 
                            INICIO DATE, -- Aqui deve ser um DATE(A data do inicio)
                            FIM DATE,--, -- Aqui deve ser um DATE  (A DATA Do FIM)
                            DATA_CONTRATO DATE, -- Aqui deve ser um DATA (DATA do contrato)
                            DATA_RENOVACAO DATE, -- Aqui deve ser um DATA (DATA de Renovacao)
                            PREMIO_BRUTO FLOAT,  --  Aqui deve ser Um FLOAT
                            PRIMEIRO_PREMIO FLOAT,  --  Aqui deve ser Um FLOAT
                            MENOS FLOAT,  --  Aqui deve ser Um FLOAT
                            LIQUIDO_PAGAR FLOAT,  --  Aqui deve ser Um FLOAT,
                            TOTAL_SEGURADO FLOAT,  --  Aqui deve ser Um FLOAT
                            PREMIO_ANUAL FLOAT,  --  Aqui deve ser Um FLOAT
                            TAXA_ADICIONAR FLOAT,  --  Aqui deve ser Um FLOAT
                            EXECESSO FLOAT, --,  --  Aqui deve ser Um FLOAT
                            OBSERVACAO CLOB, --,  --  Aqui deve ser Um Clod
                            numeroRegistroExterno VARCHAR2) RETURN VARCHAR2;
                            
    
   FUNCTION getMissingAccountOperaction(idSeguro NUMBER, operaction CHARACTER VARYING) RETURN CHARACTER VARYING;
                                    
END;