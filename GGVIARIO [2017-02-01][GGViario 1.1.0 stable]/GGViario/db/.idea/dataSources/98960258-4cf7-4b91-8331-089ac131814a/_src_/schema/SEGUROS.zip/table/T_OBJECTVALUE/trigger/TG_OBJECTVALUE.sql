create trigger TG_OBJECTVALUE
	after insert or update or delete
	on T_OBJECTVALUE
	for each row
DECLARE
  num NUMBER;
BEGIN

   -- Depois que as infromações na entiodade value for atulizada entao devera ser atulizada a materilizede view devera ser atulizada
   PRC_REFRESH_MVIEWS('OBJECT_VALUES');
END;