create trigger TG_NEXT_LOGIN
	before insert
	on T_LOGIN
	for each row
begin  
   if inserting then 
      if :NEW."LOG_ID" is null then 
         select SEQ_LOGIN.nextval into :NEW."LOG_ID" from dual; 
      end if; 
   end if; 
end;