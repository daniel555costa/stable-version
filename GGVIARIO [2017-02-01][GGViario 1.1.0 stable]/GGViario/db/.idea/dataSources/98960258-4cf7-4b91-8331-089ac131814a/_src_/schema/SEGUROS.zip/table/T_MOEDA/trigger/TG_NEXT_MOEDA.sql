create trigger TG_NEXT_MOEDA
	before insert
	on T_MOEDA
	for each row
begin  
   if inserting then 
      if :NEW."MOE_ID" is null then 
         select SEQ_MOEDA.nextval into :NEW."MOE_ID" from dual; 
      end if; 
   end if; 
end;