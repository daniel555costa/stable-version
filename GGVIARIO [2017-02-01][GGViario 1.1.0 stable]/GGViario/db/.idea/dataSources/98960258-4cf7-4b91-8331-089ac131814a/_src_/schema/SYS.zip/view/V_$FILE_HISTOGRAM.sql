create view V_$FILE_HISTOGRAM as
select "FILE#","SINGLEBLKRDTIM_MILLI","SINGLEBLKRDS" from v$file_histogram
