create TYPE           "TP_ACCESS_MENU"                                          IS OBJECT
(
    ID NUMBER,
    MENU VARCHAR(50),
    LINCK VARCHAR2(300)
)NOT FINAL;