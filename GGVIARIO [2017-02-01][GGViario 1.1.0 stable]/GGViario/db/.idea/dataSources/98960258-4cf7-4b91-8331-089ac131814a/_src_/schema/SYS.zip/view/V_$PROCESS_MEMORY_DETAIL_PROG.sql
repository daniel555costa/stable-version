create view V_$PROCESS_MEMORY_DETAIL_PROG as
select "PID","SERIAL#","STATUS" from v$process_memory_detail_prog
