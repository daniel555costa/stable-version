create view V_$OSSTAT as
select "STAT_NAME","VALUE","OSSTAT_ID","COMMENTS","CUMULATIVE" from v$osstat
