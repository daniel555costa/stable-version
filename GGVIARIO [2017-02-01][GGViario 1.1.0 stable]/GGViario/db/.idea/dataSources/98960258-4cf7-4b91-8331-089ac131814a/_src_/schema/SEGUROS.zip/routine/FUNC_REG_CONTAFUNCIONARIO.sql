create FUNCTION "FUNC_REG_CONTAFUNCIONARIO" 
(
    USER_ID NUMBER,
     ID_FUNCIONARIO NUMBER,
    ID_BANCO NUMBER,
    NIB VARCHAR2
)
RETURN VARCHAR2
IS
    TT NUMBER;
  
  
BEGIN
    -- VERIFICAR A EXISTENCIA DOS NIFS
    SELECT COUNT(*) INTO TT FROM T_ACCOUNT WHERE UPPER(NIB) = UPPER(COUNT_NIB);
    IF TT != 0 THEN RETURN 'NIB existente!'; END IF;
    
    -- Desabilitar a antiga conta do funcionario
    UPDATE T_ACCOUNT CT
       SET CT.COUNT_STATE = 0
       WHERE CT.COUNT_FUNC_ID = ID_FUNCIONARIO
          AND CT.COUNT_STATE = 1;
    
    -- Criar a nova conta para o funcionario
    INSERT INTO T_ACCOUNT(COUNT_FUNC_ID,
                        COUNT_USER_ID,
                        COUNT_BK_ID,
                        COUNT_NIB) VALUES (ID_FUNCIONARIO,
                                            USER_ID,
                                            ID_BANCO,
                                            NIB);
    RETURN 'true';                              
    
END;