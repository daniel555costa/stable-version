create PACKAGE PACK_CONTA AS

   TYPE taxa IS TABLE OF T_TAXA%ROWTYPE;
   
   TYPE cheque IS RECORD ("ID" NUMBER, "INICO" VARCHAR2(30), "FIM" VARCHAR2(30), "TOTAL" NUMBER, "DESTRIBUIDO" NUMBER, "REGISTRO" VARCHAR2(30), "TERMINO" VARCHAR2(30), "ESTADO" VARCHAR2(30));
   TYPE listCheque IS TABLE OF cheque;
   
   TYPE moviment IS RECORD("ID" NUMBER, "VALOR" VARCHAR2(120), "TIPO MOVIMENTO" VARCHAR2(50), "OUTRA CONTA" VARCHAR2(120), "INFORMACAO" VARCHAR2(200), "REGISTRO" VARCHAR2(20));
   TYPE listMoviment IS TABLE OF moviment;
   
   TYPE comisao IS RECORD ("ID" NUMBER, "ID CONTRATO" NUMBER, "ID FUNCIONARIO" NUMBER, "DATA" CHARACTER VARYING(20), "FUNCIONARIO" CHARACTER VARYING(200), "SEGURO" CHARACTER VARYING(200), "CONTRATO" CHARACTER VARYING(100), "VALOR" CHARACTER VARYING(200), "   TYPE ListComisao IS TABLE OF  PACK_CONTA.comisao;
   
   TYPE EstruturaSalarial IS RECORD
   (
      "CATEGORIA" CHARACTER VARYING(200),
      "NIVEL 1" CHARACTER VARYING(150),
      "NIVEL 2" CHARACTER VARYING(150),
      "NIVEL 3" CHARACTER VARYING(150),
      "NIVEL 4" CHARACTER VARYING(150),
      "NIVEL 5" CHARACTER VARYING(150),
      "NIVEL 6" CHARACTER VARYING(150),
      "NIVEL 7" CHARACTER VARYING(150),
      "TOTAL" CHARACTER VARYING (150)
   );
   TYPE ListEstrutura IS TABLE OF EstruturaSAlarial;
   
   FUNCTION loadPrestacaoContrato (idContrato NUMBER) RETURN PACK_TYPE.filterPrestacao PIPELINED;
   
   FUNCTION toSTD (moneyValue FLOAT, idMoeda NUMBER) RETURN VARCHAR2;
   
   FUNCTION fromSTD (stdValue FLOAT, idMoeda NUMBER) RETURN VARCHAR2;
   
   -- RETORNO{1 - SIGUIFICA QUE EXISTE TAXA | O - SIGUINIFICA QUE NAO EXISTE TAXA}
   FUNCTION hasTaxaTOMoney(idMoeda number) RETURN NUMBER;
   
   FUNCTION nextPaymentCod(idModoPaymet NUMBER) RETURN NUMBER;
   
   FUNCTION func_reg_accountpayment(idUser NUMBER,
                                    codAccount VARCHAR2,
                                    descricao VARCHAR2)RETURN VARCHAR2;
   
   -- TimePayment {1 - new payment | 0 - old payment}
   FUNCTION func_reg_payemnt (idUser NUMBER,
                              idAccount NUMBER,
                              datePayment DATE,
                              valueTotal FLOAT,
                              idModPayment NUMBER,
                              idFormaPayment NUMBER,
                              numDocumentPayment VARCHAR2,                              
                              codPayment VARCHAR2,
                              timePayment NUMBER,
                              numChequeRange CHARACTER VARYING) RETURN VARCHAR2;
                              
   FUNCTION func_reg_itempayment(idUser NUMBER,
                                 idPayment NUMBER,
                                 idContaPayment NUMBER,
                                 numeroDocumento VARCHAR,
                                 beneficiario VARCHAR2,
                                 quantity NUMBER,
                                 itenValue FLOAT,
                                 obs VARCHAR2,
                                 typeOperation NUMBER) RETURN VARCHAR2;
                                 
    FUNCTION func_end_payment(idPayment NUMBER,
                              idUser NUMBER) RETURN CHARACTER VARYING;
                                 
    FUNCTION func_reg_chequeconta (idUser NUMBER,
                                   idAccount NUMBER,
                                   sequenceInicio VARCHAR2,
                                   sequenceFim VARCHAR2,
                                   ttCheques NUMBER)RETURN VARCHAR2;
                                   
   FUNCTION funcGetNumCheque(accountId NUMBER)  RETURN VARCHAR2;
   
   
   FUNCTION validateNumCheque (accountId NUMBER, numDocumento CHARACTER VARYING, numCheque VARCHAR) RETURN VARCHAR2;
   
   
   FUNCTION regMovimentation (idUser NUMBER,
                              idAccountSource NUMBER,
                              idAccountDestination NUMBER,
                              idTypeMoviment NUMBER,
                              valueMovimentation FLOAT,
                              descrision VARCHAR2) RETURN VARCHAR2;
                              
   FUNCTION getTaxaDay(dateTaxa TIMESTAMP, idMoeda NUMBER) RETURN PACK_CONTA.TAXA PIPELINED;
   
   FUNCTION getTaxaMoney(dateTaxa TIMESTAMP, idMoedaBase NUMBER, idMoeda NUMBER) RETURN PACK_CONTA.TAXA PIPELINED;
   
   FUNCTION functLoadItemPayment(idPayment NUMBER) RETURN PACK_TYPE.filterItemPayment PIPELINED;
   
   FUNCTION functLoadChequesAccount (idAccount NUMBER) RETURN PACK_CONTA.listCheque PIPELINED;
   
   -- tipoMovimento {null - Todos os movimento | 1 -3}
   FUNCTION functLoadMoviment(idAccount NUMBER, idTipoMovimento NUMBER) RETURN listMoviment PIPELINED;
   
   FUNCTION funcRegNewPercentagem(idUser NUMBER, idImposto NUMBER, percentage FLOAT, valorMaximo FLOAT) RETURN CHARACTER VARYING;
    
   FUNCTION funcRegComisao(idUser NUMBER, idFuncionario NUMBER, idContrato NUMBER, valorPercentagem FLOAT, dataComisao DATE) RETURN CHARACTER VARYING;
   
   FUNCTION funcUpdateAccount(idAccount NUMBER, idUser NUMBER, newDesiginacao CHARACTER VARYING)  RETURN CHARACTER VARYING;

   FUNCTION functLoadEstrutura RETURN ListEstrutura PIPELINED;
   
   FUNCTION functLoadComisao RETURN ListComisao PIPELINED;
   
   -- novoEstado {-1 Anular} 
   FUNCTION functAlterStatePayment(idUser NUMBER, idPayment INTEGER, novoEstado NUMBER, observacao CHARACTER VARYING) RETURN CHARACTER VARYING;

   FUNCTION getNumConta (idCount NUMBER) RETURN CHARACTER VARYING;
   
   -- RETURNS {1 - Igual | 0  - Diferente}
   FUNCTION equalsMoney(idMoeda1 NUMBER, idMoeda2 NUMBER) RETURN BOOLEAN;
END PACK_CONTA;