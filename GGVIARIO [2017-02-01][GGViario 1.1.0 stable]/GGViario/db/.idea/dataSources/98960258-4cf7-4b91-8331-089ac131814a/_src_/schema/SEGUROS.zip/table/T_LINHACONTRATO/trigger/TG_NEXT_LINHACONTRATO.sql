create trigger TG_NEXT_LINHACONTRATO
	before insert
	on T_LINHACONTRATO
	for each row
begin  
   if inserting then 
      if :NEW."LCTT_ID" is null then 
         select SEQ_LINHACONTRATO.nextval into :NEW."LCTT_ID" from dual; 
      end if; 
   end if; 
end;