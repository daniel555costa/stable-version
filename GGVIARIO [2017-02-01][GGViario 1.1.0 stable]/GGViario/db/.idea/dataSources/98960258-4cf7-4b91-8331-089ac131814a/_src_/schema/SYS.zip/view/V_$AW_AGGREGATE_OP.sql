create view V_$AW_AGGREGATE_OP as
select "NAME","LONGNAME","DEFAULT_WEIGHT" from v$aw_aggregate_op
