create view GV_$TYPE_SIZE as
select "INST_ID","COMPONENT","TYPE","DESCRIPTION","TYPE_SIZE" from gv$type_size
