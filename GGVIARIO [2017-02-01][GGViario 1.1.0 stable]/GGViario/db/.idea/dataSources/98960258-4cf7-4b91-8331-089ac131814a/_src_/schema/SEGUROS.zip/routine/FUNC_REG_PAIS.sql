create FUNCTION "FUNC_REG_PAIS" 
(
    USER_ID NUMBER,
    NOME VARCHAR2,
    ISO2 VARCHAR2,
    ISO3 VARCHAR2
)
RETURN VARCHAR2

IS
TT NUMBER;
BEGIN
      SELECT 
          count(*) INTO TT  
          FROM T_PAIS WHERE UPPER (PAIS_NOME) =UPPER (NOME)  
              OR UPPER(PAIS_ISO2) = UPPER(ISO2) 
              OR UPPER(PAIS_ISO3) = UPPER(ISO3) ;
      IF TT != 0 THEN
          RETURN 'NOME OU ISO2 OU ISO3 JA EXISTE REGISTADO';
      END IF;
    
      INSERT INTO T_PAIS(PAIS_NOME,
                          PAIS_ISO2,
                          PAIS_ISO3)
                          VALUES(NOME,
                                  ISO2,
                                  ISO3);
      RETURN 'true';
END;