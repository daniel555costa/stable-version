create view V_$MEMORY_TARGET_ADVICE as
select "MEMORY_SIZE","MEMORY_SIZE_FACTOR","ESTD_DB_TIME","ESTD_DB_TIME_FACTOR","VERSION" from v$memory_target_advice
