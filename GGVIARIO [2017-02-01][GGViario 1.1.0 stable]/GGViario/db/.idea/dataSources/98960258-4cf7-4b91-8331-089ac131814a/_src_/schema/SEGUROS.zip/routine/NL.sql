create FUNCTION "NL" RETURN VARCHAR2
IS
  -- Funcao para criar quebras de linhas no texo
    --Deve retornar um carater da tecla enter
  quebar VARCHAR2(1) := '
';
BEGIN
  
    RETURN quebar;
END;