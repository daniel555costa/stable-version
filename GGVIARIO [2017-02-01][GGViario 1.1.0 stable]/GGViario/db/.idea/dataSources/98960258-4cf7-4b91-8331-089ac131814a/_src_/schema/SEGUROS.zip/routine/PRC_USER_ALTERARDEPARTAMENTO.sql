create PROCEDURE PRC_USER_ALTERARDEPARTAMENTO 
(
   idUser NUMBER,  -- ID utilizador 
   idFuncionario NUMBER, -- ID de funcionario a ser alterado
   idNewDepartamento NUMBER
)IS
BEGIN
    UPDATE T_FUNCIONARIO F
       SET F.FUNC_DEP_ID = idNewDepartamento 
       WHERE F.FUNC_ID = idFuncionario;
END;