create view VER_CONTA_PAYMENT as
SELECT AC.ID AS "ID",
          AC.COD AS "COD",
          CASE
             WHEN AC.TP = 'P' THEN AC."NAME"
             ELSE AC."DESC" 
          END AS "DESC",
          AC."CREDITO SF" AS "CREDITO",
          AC."DEBITO SF" AS "DEBITO",
          AC.TP
      FROM VER_ALL_ACCOUNT AC
      WHERE AC.TP IN ('B', 'P')
