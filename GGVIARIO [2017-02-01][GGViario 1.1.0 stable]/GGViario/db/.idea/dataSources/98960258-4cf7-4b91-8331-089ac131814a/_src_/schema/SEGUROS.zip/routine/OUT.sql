create PROCEDURE out(argment CLOB)
IS
BEGIN
  INSERT into output VALUES (argment);
END;