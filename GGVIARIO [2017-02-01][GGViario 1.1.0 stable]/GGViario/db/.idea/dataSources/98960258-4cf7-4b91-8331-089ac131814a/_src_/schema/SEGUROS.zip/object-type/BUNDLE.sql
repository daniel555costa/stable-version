create TYPE BUNDLE IS OBJECT
(

   items BUNDLE_LIST,
   i_iterator NUMBER,
   
   FMT_DATE CHARACTER VARYING(16),
   FMT_TIMESTAMP CHARACTER VARYING(32),
   FMT_NUMBER CHARACTER VARYING(1024),
  
  -- Inicialize empty bundle
  CONSTRUCTOR FUNCTION BUNDLE RETURN SELF AS RESULT,
  
  MAP MEMBER FUNCTION to_string RETURN CHARACTER VARYING,
  
  -- Put the value into bundle
  MEMBER PROCEDURE put(SELF IN OUT BUNDLE, key CHARACTER VARYING, value CHARACTER VARYING),
  
  -- Get de value into bundle
  MEMBER FUNCTION get(key CHARACTER VARYING) RETURN CHARACTER VARYING,
  
  -- get the index value into bundle
  MEMBER FUNCTION index_of(key CHARACTER VARYING) RETURN NUMBER,
  
  -- get the value converting to number
  MEMBER FUNCTION asnumber(key CHARACTER VARYING) RETURN NUMBER,
  
  -- get the value converting to date
  MEMBER FUNCTION asdate (key CHARACTER VARYING) RETURN DATE,
  
  -- get the value converting to time stamp
  MEMBER FUNCTION astimestamp(key CHARACTER VARYING) RETURN TIMESTAMP,
  
  -- get count of all value into bundle
  MEMBER FUNCTION count RETURN NUMBER,
  
  -- remove one value into bundle
  MEMBER FUNCTION remove(SELF IN OUT BUNDLE, key CHARACTER VARYING) RETURN CHARACTER VARYING,
  
  -- clear all value into bunlde
  MEMBER PROCEDURE clear(SELF IN OUT BUNDLE),
  
  -- replace one value into bundle
  MEMBER PROCEDURE replace(key CHARACTER VARYING, value CHARACTER VARYING),
  
  -- Verify if bundle contains one key
  MEMBER FUNCTION contains(key CHARACTER VARYING) RETURN BOOLEAN,
  
  -- Verify id bundle is empty
  MEMBER FUNCTION isEmpty RETURN BOOLEAN,
  
  -- Start or restar iterator by  first value
  MEMBER PROCEDURE iterator(SELF IN OUT BUNDLE),
  
  -- start or restar itertator by last value
  MEMBER PROCEDURE iterator_end(SELF IN OUT BUNDLE),
  
  MEMBER PROCEDURE iterator_in(iterator_index NUMBER),
  
  -- get next value into iterator
  MEMBER FUNCTION next(SELF IN OUT BUNDLE) RETURN BUNDLE_ITEM,
  
  -- get preview value in iterator
  MEMBER FUNCTION preview(SELF IN OUT BUNDLE)  RETURN BUNDLE_ITEM,
  
  MEMBER FUNCTION has_next RETURN BOOLEAN,
  
  MEMBER FUNCTION has_preview RETURN BOOLEAN

)FINAL;