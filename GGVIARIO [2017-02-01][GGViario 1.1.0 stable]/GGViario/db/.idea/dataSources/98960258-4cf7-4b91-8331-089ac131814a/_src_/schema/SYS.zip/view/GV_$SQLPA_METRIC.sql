create view GV_$SQLPA_METRIC as
select "INST_ID","METRIC_NAME" from gv$sqlpa_metric
