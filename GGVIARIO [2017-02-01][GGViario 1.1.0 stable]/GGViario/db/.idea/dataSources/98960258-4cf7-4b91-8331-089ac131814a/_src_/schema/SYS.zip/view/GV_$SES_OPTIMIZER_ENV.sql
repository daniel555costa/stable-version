create view GV_$SES_OPTIMIZER_ENV as
select "INST_ID","SID","ID","NAME","SQL_FEATURE","ISDEFAULT","VALUE" from gv$ses_optimizer_env
