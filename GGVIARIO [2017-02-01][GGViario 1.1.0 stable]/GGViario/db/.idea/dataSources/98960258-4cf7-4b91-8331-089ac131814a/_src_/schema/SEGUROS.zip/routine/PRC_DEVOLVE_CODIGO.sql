create PROCEDURE "PRC_DEVOLVE_CODIGO" 
(
    CODIGO VARCHAR2, -- O codigo a ser devolvido
    ENTIDADE VARCHAR2, -- O nome da entidade
    USER_ID NUMBER -- O utilizador a devolver o codigo
)

IS
BEGIN
    -- Funcao para devolver o codido de um seguro requisitado devolta a base de dadso
    NULL;
END;