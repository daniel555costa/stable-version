create FUNCTION FUNC_REG_CONTACONTABIL 
(
   idUser NUMBER,
   idBanco NUMBER,
   tipoConta NUMBER,  -- {T_TYPEACCOUNT}
   numContaBanco VARCHAR2,  -- AS numConta
   idMoeda NUMBER,
   codigoContaContabil VARCHAR2, -- AS descri
   idTypeMovimento NUMBER  --{VER_TIPOCONTA}
)RETURN VARCHAR2
IS
   tt NUMBER;
   exist NUMBER;
BEGIN

   SELECT COUNT(*) INTO tt
      FROM T_ACCOUNT AC
      WHERE AC.COUNT_BK_ID = idBanco
         AND AC.COUNT_MOE_ID = idMoeda
         AND AC.COUNT_OBJT_SUBTPCOUNT = idTypeMovimento
         AND AC.COUNT_STATE = 1;
         
   IF tt != 0 THEN
      RETURN 'false;'||FUNC_ERROR('TYPE ACCOUNT ALERED IN BANK');
   END IF;
   
   SELECT COUNT(*) INTO exist
         FROM VER_ALL_ACCOUNT
         WHERE COD = codigoContaContabil;
         
      IF exist != 0 THEN 
          RETURN 'false;'||FUNC_ERROR('COD ACCOUNT ALERED EXIST');
      END IF;
      
      
   SELECT COUNT(*) INTO tt
      FROM T_ACCOUNT AC
      WHERE AC.COUNT_DESC = numContaBanco
        AND AC.COUNT_STATE = 1
        AND AC.COUNT_TCOUNT_ID = 3;
        
        
  IF tt != 0 THEN
     RETURN 'false;'||FUNC_ERROR('NUM BANKARIO ALERED EXIST');
  END IF;
   
   INSERT INTO T_ACCOUNT (COUNT_USER_ID,
                          COUNT_BK_ID,
                          COUNT_NIB,
                          COUNT_TCOUNT_ID,
                          COUNT_MOE_ID,
                          COUNT_DESC,
                          COUNT_OBJT_SUBTPCOUNT)
                          VALUES(idUser,
                                 idBanco,
                                 codigoContaContabil,
                                 tipoConta,
                                 idMoeda,
                                 numContaBanco,
                                 idTypeMovimento);
  RETURN 'true';
END;