create view GV_$ROWCACHE_SUBORDINATE as
select "INST_ID","INDX","HASH","ADDRESS","CACHE#","SUBCACHE#","SUBCACHE_NAME","EXISTENT","PARENT","KEY" from gv$rowcache_subordinate
