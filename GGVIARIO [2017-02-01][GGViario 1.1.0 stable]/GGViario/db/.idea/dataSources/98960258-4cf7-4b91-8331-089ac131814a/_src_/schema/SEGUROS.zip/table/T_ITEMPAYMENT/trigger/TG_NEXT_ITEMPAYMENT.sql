create trigger TG_NEXT_ITEMPAYMENT
	before insert
	on T_ITEMPAYMENT
	for each row
begin  
   if inserting then 
      if :NEW."IPAY_ID" is null then 
         select SEQ_ITEMPAYMENT.nextval into :NEW."IPAY_ID" from dual; 
      end if; 
   end if; 
end;