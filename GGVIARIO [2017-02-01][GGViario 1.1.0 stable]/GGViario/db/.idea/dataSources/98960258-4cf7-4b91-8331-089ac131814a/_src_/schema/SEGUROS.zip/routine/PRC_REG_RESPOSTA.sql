create PROCEDURE PRC_REG_RESPOSTA 
(
   idUser NUMBER,
   idContrato NUMBER,
   idPergunta NUMBER,
   valueResposta VARCHAR2,
   valueExpecificacao VARCHAR2
)IS

BEGIN
  -- Criar a resposta para a pergunta requisitada
  INSERT INTO T_RESPOSTA(RESP_PER_ID,
                         RESP_CTT_ID,
                         RESP_USER_ID,
                         RESP_RESPOSTA,
                         RESP_EXPECIFICACAO)
                         VALUES(idPergunta,
                                idContrato,
                                idUser,
                                valueResposta,
                                valueExpecificacao);
END PRC_REG_RESPOSTA;