create PROCEDURE "PRC_REG_GRAUPARENTESCO" (
USER_ID NUMBER,
NOME VARCHAR2

 )
IS 
BEGIN
INSERT INTO T_OBJECTYPE( OBJT_T_ID,
                                OBJT_USER_ID,
                                OBJT_DESC)
                              VALUES(11,
                                  USER_ID,
                                  NOME);
                                    
END;