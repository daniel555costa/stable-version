create view V_$SQL_BIND_METADATA as
select "ADDRESS","POSITION","DATATYPE","MAX_LENGTH","ARRAY_LEN","BIND_NAME" from v$sql_bind_metadata
