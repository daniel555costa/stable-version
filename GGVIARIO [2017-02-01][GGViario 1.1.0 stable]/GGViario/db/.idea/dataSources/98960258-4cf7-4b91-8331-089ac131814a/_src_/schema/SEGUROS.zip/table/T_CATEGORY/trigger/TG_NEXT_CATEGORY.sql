create trigger TG_NEXT_CATEGORY
	before insert
	on T_CATEGORY
	for each row
begin  
   if inserting then 
      if :NEW."CAT_ID" is null then 
         select SEQ_CATEGORY.nextval into :NEW."CAT_ID" from dual; 
      end if; 
   end if; 
end;