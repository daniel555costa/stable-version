create view V_$LOCK_ACTIVITY as
select "FROM_VAL","TO_VAL","ACTION_VAL","COUNTER" from v$lock_activity
