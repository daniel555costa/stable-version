CREATE VIEW ver_estadocivil AS
SELECT estadocivil.civil_id AS "ID",
    estadocivil.civil_desc AS "DESC"
   FROM estadocivil