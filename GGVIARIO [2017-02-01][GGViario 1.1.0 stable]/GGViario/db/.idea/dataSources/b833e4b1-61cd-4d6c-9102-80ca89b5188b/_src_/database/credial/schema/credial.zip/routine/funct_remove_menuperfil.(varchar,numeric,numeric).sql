CREATE FUNCTION funct_remove_menuperfil ("idUser" character varying, "idAgencia" numeric, "idMenuPerfil" numeric) RETURNS "Result"
	LANGUAGE sql
AS $$
  update menuperfil
    set menuperf_state = 0
    where menuperf_id = "idMenuPerfil"
      and menuperf_state = 1
  ;

  select ('true', 'Sucesso')::"Result";

$$
