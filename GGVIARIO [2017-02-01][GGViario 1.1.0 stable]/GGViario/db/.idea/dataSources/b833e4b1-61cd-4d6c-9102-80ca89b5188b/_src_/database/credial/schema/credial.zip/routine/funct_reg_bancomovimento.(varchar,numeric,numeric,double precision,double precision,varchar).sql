CREATE FUNCTION funct_reg_bancomovimento ("idUser" character varying, "idAgencia" numeric, "idBanco" numeric, debito double precision, credito double precision, libele character varying) RETURNS result
	LANGUAGE plpgsql
AS $$
DECLARE
  vBanco record;
  valCredito double precision := credito;
  valDebito double precision := debito;
  res result;
BEGIN

  res.result:= false;
  if credito is null then valCredito := 0.0; end if;
  if debito is null then valDebito := 0.0; end if;

  -- Garrantir que a operacao seja do debito ou do credito apenas
  -- Isso significa que para o debito apenas o valor do debito deve ser maior que zero
  -- para o credito apenas o valor do credito deve ser maior que zero
  if valCredito = 0.0 and valDebito = 0.0 then
    res.message:= message('DEBITO AND CREDITO CAN NOT 0');
    return res;
  elsif valCredito != 0.0 and valDebito != 0.0 then
    res.message:= message('DEBITO AND CREDITO CANNOT != 0');
    return res;
  END IF;

  -- carregar as informacoes do banco
  select * into vBanco
  from banco bc
  where bc.banco_id = "idBanco";

  -- quando o valor do debito maior que zero - sigunifica que o saldo no banco ira diminuir
  -- nesse caso validar que o saldo no banco cubra as despesa do debitp
  if valDebito > 0  and valDebito > vBanco.banco_saldo then
    res.message := message('SALDO INSUFICIENTE');
    return res;
  end if;

  insert into bancomovimento (
    bancomov_user_id,
    bancomov_banco_id,
    bancomov_age_id,
    bancomov_debito,
    bancomov_credito,
    bancomov_libele
  ) values (
    "idUser",
    "idBanco",
    "idAgencia",
    valDebito,
    valCredito,
    libele
  );

  res.result := TRUE ;
  res.message:= 'Sucesso';
  return res;
END;
$$
