CREATE FUNCTION export_bytea (filepath text, filedata bytea) RETURNS integer
	LANGUAGE plpgsql
AS $$
  DECLARE
    vOidKey oid;
    vResult integer;
  BEGIN
    vOidKey := lo_from_bytea(-1, fileData);
    vResult :=  lo_export(vOidKey, filePath);
    
    raise NOTICE  'result of lo_export is % ', vResult;
    vResult := lo_unlink(vOidKey);
    RETURN  vResult;
  END;
$$
