CREATE FUNCTION message (cod character varying, message text, typemessage rule."TypeMessage" DEFAULT 'I'::rule."TypeMessage", source text DEFAULT NULL::text) RETURNS character varying
	LANGUAGE plpgsql
AS $$
   declare 
      tt numeric;
   begin
      select count(*) into tt
         from rule.message
         where upper(message_cod) = upper(cod);

      if tt >0 then
         return 'false';
      end if;

      insert into rule.message values(
          upper(cod),
          message,
          typeMessage,
          source);
      return 'true';
   end;
$$
