CREATE VIEW ver_agencia AS
SELECT agencia.age_id AS "ID",
    agencia.age_name AS "NOME"
   FROM agencia
  WHERE (agencia.age_state = (1)::numeric)