CREATE FUNCTION funct_load_taxa ("idUser" numeric, "idAgencia" numeric, idtipocredito numeric, estado character varying DEFAULT 'T'::character varying) RETURNS TABLE("ID" numeric, "VALOR" character varying, "PERIODO" numeric, "TIPO CREDITO" character varying, "DATA INICIO" character varying, "DATA FIM" character varying, "ESTADO" character varying)
	LANGUAGE sql
AS $$
  select tx.taxa_id,
    lib.money(tx.taxa_value),
    tx.taxa_periodo,
    o.obj_desc,
    to_char(tx.taxa_dtinicio, 'DD-MM-YYYY'),
    case when tx.taxa_dtfim is null then '' else to_char(tx.taxa_dtfim, 'DD-MM-YYYY') end,
    case
    when tx.taxa_state = 1 then  'Ativo'
    else 'Inativo'
    end
  from taxa tx
    inner join objecto o on tx.taxa_obj_tipocredito = o.obj_id
  where (idTipoCredito = tx.taxa_obj_tipocredito or idtipocredito =-1)
        AND (
          estado = 'T'
          or (estado = 'D' and tx.taxa_state = 0)
          or (estado = 'A' and tx.taxa_state = 1)
        )
  order by tx.taxa_dtreg desc
$$
