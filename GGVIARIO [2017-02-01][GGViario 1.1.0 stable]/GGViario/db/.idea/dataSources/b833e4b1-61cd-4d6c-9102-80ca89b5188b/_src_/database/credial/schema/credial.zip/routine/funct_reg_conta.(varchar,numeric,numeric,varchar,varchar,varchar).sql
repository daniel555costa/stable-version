CREATE FUNCTION funct_reg_conta ("idUser" character varying, "idAgencia" numeric, "idBanco" numeric, "numeroConta" character varying, "codAgencia" character varying, descricao character varying) RETURNS result
	LANGUAGE plpgsql
AS $$
DECLARE
  res result;
  accountHasRegistrede numeric;
BEGIN
  res.result := 'false';

  select count(*) into accountHasRegistrede
  from conta ct
  where ct.conta_banco_id = "idBanco"
        and ct.conta_agenciacod = "codAgencia"
        and ct.conta_numero = "numeroConta";

  if accountHasRegistrede != 0 then
    res.message:= message('CONTA.EXIST');
    return res;
  END IF;

  insert into conta(
    conta_numero,
    conta_banco_id,
    conta_age_id,
    conta_user_id,
    conta_agenciacod,
    conta_desc
  ) values (
    "numeroConta",
    "idBanco",
    "idAgencia",
    "idUser",
    "codAgencia",
    "descricao"
  );

  res.message := 'Sucesso';
  res.result := TRUE;
  return res;
END;
$$
