CREATE FUNCTION getObject ("idObjecto" numeric) RETURNS objecto
	LANGUAGE sql
AS $$
  select *
    from objecto o 
    where o.obj_id = "idObjecto";
$$
