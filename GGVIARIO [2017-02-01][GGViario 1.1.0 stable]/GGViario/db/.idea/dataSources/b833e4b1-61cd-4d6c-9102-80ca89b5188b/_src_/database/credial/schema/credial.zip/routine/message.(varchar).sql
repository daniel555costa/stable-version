CREATE FUNCTION message (cod character varying) RETURNS text
	LANGUAGE sql
AS $$
   select m.message_message
      from rule.message m
      where upper(m.message_cod) = upper(cod);
$$
