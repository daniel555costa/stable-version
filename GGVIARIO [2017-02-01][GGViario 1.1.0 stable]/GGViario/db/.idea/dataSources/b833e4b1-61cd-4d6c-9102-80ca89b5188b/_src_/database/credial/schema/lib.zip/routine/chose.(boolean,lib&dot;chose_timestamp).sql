CREATE FUNCTION chose (boolean, lib.chose_timestamp) RETURNS timestamp without time zone
	LANGUAGE sql
AS $$
  select case when $1 then $2.left_val else $2.right_val end; 
$$
