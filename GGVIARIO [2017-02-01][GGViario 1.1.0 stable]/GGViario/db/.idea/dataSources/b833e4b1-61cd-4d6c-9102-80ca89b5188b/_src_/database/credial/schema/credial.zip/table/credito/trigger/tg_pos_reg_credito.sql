CREATE TRIGGER tg_pos_reg_credito
AFTER INSERT ON credito
FOR EACH STATEMENT EXECUTE PROCEDURE functg_pos_reg_credito()