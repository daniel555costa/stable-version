CREATE FUNCTION funct_load_filter ("idUser" character varying, "idAgencia" integer, "reportName" character varying) RETURNS TABLE(cod character varying, name character varying, type character varying, contents json)
	LANGUAGE sql
AS $$
  select
      fi.filter_cod,
      fi.filter_name,
      fi.filter_type,
      fi.filter_contents
    from report.filter fi
      INNER JOIN report.reportefilter r  ON fi.filter_cod = r.repfilter_filter_cod
    WHERE lower(r.repfilter_report) = lower("reportName");
  
$$
