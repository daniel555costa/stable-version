CREATE FUNCTION funct_reg_agencia ("idUser" character varying, "idAgencia" numeric, "idLocalidade" numeric, name character varying) RETURNS TABLE("RESULT" character varying, "MESSAGE" character varying)
	LANGUAGE plpgsql
AS $$

   DECLARE
      tt numeric;
   BEGIN

      "RESULT" := 'false';
      -- Para as agencia o seu nume dever ser unico
      select count(*) into tt
         from agencia ag
         where upper(ag.age_name) = upper(name);

      if tt > 0 then
         "MESSAGE" := message('AGENCIA NAME ALERED EXIST');
      ELSE 
         insert into agencia(
            age_user_id, 
            age_local_id,
            age_name,
            age_age_id
         ) values (
            "idUser",
            "idLocalidade",
            name,
            "idAgencia"
         );
         
         "RESULT" := 'true';
         "MESSAGE" := 'Sucesso';
      END IF;
     
     return next;
   END;
$$
