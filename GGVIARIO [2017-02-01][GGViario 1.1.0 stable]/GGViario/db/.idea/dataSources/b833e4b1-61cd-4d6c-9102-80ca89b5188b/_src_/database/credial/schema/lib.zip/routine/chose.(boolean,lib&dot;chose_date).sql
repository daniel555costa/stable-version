CREATE FUNCTION chose (boolean, lib.chose_date) RETURNS date
	LANGUAGE sql
AS $$
  select case when $1 then $2.left_val else $2.right_val end; 
$$
