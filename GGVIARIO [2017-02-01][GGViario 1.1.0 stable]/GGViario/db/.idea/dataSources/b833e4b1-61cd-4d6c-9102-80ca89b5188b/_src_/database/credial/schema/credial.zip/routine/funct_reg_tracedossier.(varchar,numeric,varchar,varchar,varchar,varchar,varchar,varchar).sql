CREATE FUNCTION funct_reg_tracedossier ("idUser" character varying, "idAgencia" numeric, "nifClinet" character varying, "numCapa" character varying, mes character varying, ano character varying, letra character varying, sequencia character varying) RETURNS SETOF "Result"
	LANGUAGE plpgsql
AS $$
   DECLARE
      res "Result";
      tt numeric;
   BEGIN
      res."RESULT" := 'false;';

      -- desativar os antigos trace dossier do cliente
      UPDATE  tracedossier
         set trado_state = 0
         where trado_dos_nif = "nifClinet";

      -- crear o nvo tradossier para  clinet
      INSERT into tracedossier (
         trado_dos_nif,
         trado_user_id,
         trado_age_id,
         trado_numcapa,
         trado_mes,
         trado_ano,
         trado_letra,
         trado_sequencia
      ) VALUES (
         "nifClinet",
         "idUser",
         "idAgencia",
         "numCapa",
         mes,
         ano,
         letra,
         sequencia
      );

      res."RESULT" := 'true';
      res."MESSAGE" := 'Sucesso';

      RETURN next res;
   END;
$$
