CREATE FUNCTION funct_load_menuperfil ("idUser" character varying, "idAgencia" numeric, "idPerfil" numeric) RETURNS TABLE("ID" numeric, "COD" character varying, "NAME" character varying, "LEVEL" numeric, "LINK" character varying, "IN PERFIL" boolean, "SUPER.ID" numeric, "SUPER.COD" character varying)
	LANGUAGE sql
AS $$

  select vms."ID",
      vms."COD",
      vms."NAME",
      vms."LEVEL",
      vms."LINK",
      mp.menuperf_id is NOT null and mp.menuperf_tperf_id = "idPerfil",
      vms."SUPER.ID",
      vms."SUPER.COD"
    from ver_menu_structure vms
      left join menuperfil mp on vms."ID" = mp.menuperf_menu_id
$$
