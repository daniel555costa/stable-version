CREATE FUNCTION getUser ("idUser" character varying) RETURNS "user"
	LANGUAGE sql
AS $$
  select *
    from "user" 
    where "user".user_id = "idUser";
$$
