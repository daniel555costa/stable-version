CREATE FUNCTION verifySaldoBank (id numeric, "ammountRequire" double precision, "idOfEntity" character varying DEFAULT 'B'::character varying) RETURNS "ResultValidator"
	LANGUAGE plpgsql
AS $$
  DECLARE
  -- idOfEntity indica que entidade deve o id pertencte {C - cheque | B - Banco}
    idBanco numeric;
    res "ResultValidator";
    resRes "Result";
    tt numeric;
  BEGIN
    res."VALID" := false;
    resRes."RESULT" := 'false';

    -- carregar o veridadeiro id do banco
    if "idOfEntity" = 'B' then
      idBanco := id;
    elsif "idOfEntity" = 'C' then
      select cheq_banco_id into idBanco
        from chequempresa
        WHERE  cheq_id = id;
    END IF;

    -- verificar o baco possui o saldo soficiente para cobrir a requisisa
    select count(*) into tt
      from  banco bc
      where bc.banco_saldo >= "ammountRequire"
        and bc.banco_id = idBanco;

    if tt = 0 then
      resRes."RESULT" := message('SALDO INSUFICIENTE');
    else
      resRes."RESULT" := 'true';
      resRes."MESSAGE" := message('EXISTE SALDO');
      res."VALID" := true;
    END IF;
    res."RESULT" := resRes;
    return res;
  END;
$$
