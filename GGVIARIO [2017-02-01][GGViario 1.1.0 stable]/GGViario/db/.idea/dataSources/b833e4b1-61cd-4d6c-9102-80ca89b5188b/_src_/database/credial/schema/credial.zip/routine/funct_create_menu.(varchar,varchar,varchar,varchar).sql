CREATE FUNCTION funct_create_menu (cod character varying, "menuName" character varying, "menuSuperCod" character varying DEFAULT NULL::character varying, link character varying DEFAULT NULL::character varying) RETURNS "Result"
	LANGUAGE plpgsql
AS $$
 
   DECLARE
     res "Result";
     superMenu menu;
     accept boolean DEFAULT TRUE;
     tt numeric;
     menuLevel numeric default 0;
     raiz character varying;
     totalRaiz numeric;
     numCharLengthRaiz character varying(2) default '00';
     maxSubMenu numeric default 99;
   BEGIN 
     res."RESULT" := 'false';
     
     if rule."hasMenuCod"(cod) THEN
       res."MESSAGE" := message('MENU.COD.EXEIST');
       return res;
     end if;
     
     if "menuSuperCod" is not null and not rule."hasMenuCod"("menuSuperCod") THEN 
       res."MESSAGE" := message('MENU.PARENT.NFOUND');
       return res;
     END IF;
     
     if "menuSuperCod" is not null then
       select * into superMenu
         from menu m
         where upper(m.menu_cod) = upper("menuSuperCod");
       
       select count (*) into totalRaiz
         from menu me
         where me.menu_menu_id = superMenu.menu_id;
       raiz := superMenu.menu_raiz||'.'||trim(to_char(totalRaiz, numCharLengthRaiz));
       menuLevel := superMenu.menu_level +1;
       
     ELSE 
       select count (*) into totalRaiz
         from menu me
         where me.menu_menu_id is null;
       
       -- Quando exeder a quantidade de sub menu maximo em um menu entao abortar a operacao emitindo uma message de eroo
       
       if totalRaiz > maxSubMenu then 
         res."MESSAGE" := message('MENU.MAX.EXCEEDED');
       END IF;
       raiz := trim(to_char(totalRaiz, numCharLengthRaiz));
     end if;
     
     insert into menu(
        menu_menu_id, 
        menu_name, 
        menu_link,
        menu_cod,
        menu_level,
        menu_raiz
     ) values (
        superMenu.menu_id,
        "menuName",
        link,
        cod,
        menuLevel,
        raiz
     );
     res."RESULT" := 'true';
     res."MESSAGE" := 'Sucesso';
      
      return res;
   END;
$$
