CREATE FUNCTION funct_load_object ("idTypeObject" numeric) RETURNS TABLE("ID" numeric, "DESCRICAO" character varying)
	LANGUAGE sql
AS $$
  select ob.obj_id,
      ob.obj_desc
    from objecto ob
    where ob.obj_tobj_id = "idTypeObject"
      and ob.obj_state = 1
    ORDER BY obj_desc ASC;
$$
