CREATE VIEW ver_menu_active AS
SELECT m."ID",
    m."COD",
    m."NAME",
    m."LEVEL",
    m."LINK",
    m."ICON",
    m."STATE",
    m."SUPER.ID",
    m."SUPER.COD",
    m."RAIZ"
   FROM ver_menu_structure m
  WHERE (m."STATE" = (1)::numeric)