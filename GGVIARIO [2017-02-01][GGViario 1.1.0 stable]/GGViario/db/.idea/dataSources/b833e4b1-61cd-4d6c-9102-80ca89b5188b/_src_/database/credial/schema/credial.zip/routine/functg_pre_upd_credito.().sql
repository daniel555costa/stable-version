CREATE FUNCTION functg_pre_upd_credito () RETURNS trigger
	LANGUAGE plpgsql
AS $$
  declare
    -- TG_WHEN {BEFORE, AFTER, or INSTEAD OF}
    -- TG_EVENT {INSERT, UPDATE, DELETE, TRUNCATE}
    -- TG_LEVEL {ROW, STATEMENT}

    vNew credito;
    vOld credito;
    isLiquidado BOOLEAN;
  begin
    if TG_WHEN = 'BEFORE'
      -- AND TG_EVENT = 'UPDATE'
      and new is of (credito)
    then

      vNew := new;
      vOld := old;
      isLiquidado := (vNew.credi_numprestacaofalta = vOld.credi_numprestacao
                        and vNew.credi_valuepago = vOld.credi_valuecredito);

      if isLiquidado then
        vNew.credi_state := 0;
        vNew.credi_creditostate := 0;
        vNew.credi_dtfim = now();
      END IF;

      new := vNew;

      return new;
    end if;
  end;
$$
