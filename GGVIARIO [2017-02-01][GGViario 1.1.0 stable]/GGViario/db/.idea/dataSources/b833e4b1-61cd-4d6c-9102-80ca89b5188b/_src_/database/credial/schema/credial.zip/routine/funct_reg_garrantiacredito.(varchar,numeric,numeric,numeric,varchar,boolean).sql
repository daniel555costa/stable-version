CREATE FUNCTION funct_reg_garrantiacredito ("idUser" character varying, "idAgencia" numeric, "idCredito" numeric, "objectoGarantia" numeric, "descricaoGarrantia" character varying, forceregister boolean DEFAULT false) RETURNS "Result"
	LANGUAGE sql
AS $$
   insert into garrantiacredito(
      garcredi_user_id,
      garcredi_credi_id,
      garcredi_obj_garrantia,
      garcredi_age_id,
      garcredi_desc
   ) values (
      "idUser",
      "idCredito",
      "objectoGarantia",
      "idAgencia",
      "descricaoGarrantia"
   );

 select '(true,Sucesso)'::"Result" limit 1;
$$
