CREATE FUNCTION funct_reg_objecto ("idUser" character varying, "idAgencia" numeric, "idTypeObject" numeric, "descricaoObjecto" character varying) RETURNS "Result"
	LANGUAGE plpgsql
AS $$
  declare
    tt numeric;
    res "Result";
  begin
    res."RESULT" := 'false';
    select count(*) into tt
      from objecto oo
      where oo.obj_tobj_id = "idTypeObject"
        and upper(oo.obj_desc) = upper("descricaoObjecto");
    
    if tt != 0 then 
      update objecto
        set obj_state = 1
        where obj_tobj_id = "idTypeObject"
          and upper(obj_desc) = upper("descricaoObjecto");
    else
      insert into objecto(
        obj_tobj_id,
        obj_user_id,
        obj_age_id,
        obj_desc
      ) values (
        "idTypeObject",
        "idUser",
        "idAgencia",
        "descricaoObjecto"
      );
      
    end if;
    
    res."RESULT" := 'true';
    res."MESSAGE" := 'Sucesso';
    return res;
  end;
$$
