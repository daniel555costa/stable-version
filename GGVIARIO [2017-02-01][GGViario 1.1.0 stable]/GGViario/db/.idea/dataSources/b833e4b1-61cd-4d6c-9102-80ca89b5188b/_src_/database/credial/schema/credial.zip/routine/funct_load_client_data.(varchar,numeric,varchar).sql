CREATE FUNCTION funct_load_client_data ("idUser" character varying, "idAgencia" numeric, "nifCliente" character varying) RETURNS TABLE("NIF" character varying, "SEXO" character varying, "SEXO ID" numeric, "NUM DOSSIER" character varying, "NAME" character varying, "SURNAME" character varying, "DATA NASCIMENTO" character varying, "DATA NASCIMENTO DATE" date, "ESTADO CIVIL" character varying, "ESTADO CIVIL ID" numeric, "LOCALIDADE" character varying, "LOCALIDADE ID" numeric, "PROFISAO" character varying, "PROFISSAO ID" numeric, "LOCAL TRABALHA" character varying, "LOCAL TRABALHA ID" numeric, "MORADA" character varying, "TELE FIXO" character varying, "TELE MOVEL" character varying, "TELE SERVICO" character varying, "MAIL" character varying, "TRADOSSIER NUMERO DE CAPA" character varying, "TRADOSSIER MES" character, "TRADOSSIER ANO" character varying, "TRADOSSIER LETRA" character, "TRADOSSIER SEQUENCIA" character, "CLIENTE SALARIO" character varying, "CLIENTE SALARIO DOUBLE" double precision, "REGISTRO CLINETE" timestamp without time zone, "REGUSTRO LAST SALARIO" timestamp without time zone, "REGISTRO LAST HISTORICO" timestamp without time zone, "REGISTRO LAST TRADOSSIER" timestamp without time zone)
	LANGUAGE sql
AS $$
  select
    dos.dos_nif,
    gen.gen_desc,
    gen.gen_id,
    dos.dos_numdos,
    dos.dos_name,
    dos.dos_surname,
    to_char(dos.dos_dtnasc, 'DD-MM-YYYY'),
    dos.dos_dtnasc,
    cv.civil_desc,
    cv.civil_id,
    loca.local_desig,
    loca.local_id,
    profisao.obj_desc,
    profisao.obj_id,
    localtrabalho.obj_desc,
    localtrabalho.obj_id,
    his.hisdos_morada,
    his.hisdos_telfixo,
    his.hisdos_telmovel,
    his.hisdos_telservico,
    his.hisdos_mail,
    tra.trado_numcapa,
    tra.trado_mes,
    tra.trado_ano,
    tra.trado_letra,
    tra.trado_sequencia,
    sal.sal_value::character varying,
    sal_value,
    dos.dos_dtreg,
    sal.sal_dtreg,
    his.hisdos_dtreg,
    tra.trado_dtreg
    from dossiercliente dos
      inner join gender gen on dos.dos_gen_id = gen.gen_id
      left join historicocliente his on (dos.dos_nif = his.hisdos_dos_nif and hisdos_state = 1)
      left join salario sal on (dos.dos_nif = sal.sal_dos_nif and sal.sal_state = 1)
      left join tracedossier tra on (dos.dos_nif = tra.trado_dos_nif and tra.trado_state = 1)
      left join estadocivil cv on his.hisdos_civil_id = cv.civil_id
      left join localidade loca on hisdos_local_id = loca.local_id
      left join objecto profisao on his.hisdos_obj_profisao = profisao.obj_id
      left join objecto localtrabalho on his.hisdos_obj_localtrabalho = localtrabalho.obj_id
    where dos.dos_nif = "nifCliente";
$$
