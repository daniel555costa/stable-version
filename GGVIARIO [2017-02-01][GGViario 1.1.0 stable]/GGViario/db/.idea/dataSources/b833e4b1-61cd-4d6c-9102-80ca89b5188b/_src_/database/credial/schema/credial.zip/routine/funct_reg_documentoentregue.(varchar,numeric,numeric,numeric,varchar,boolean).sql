CREATE FUNCTION funct_reg_documentoentregue ("idUser" character varying, "idAgencia" numeric, "idCredito" numeric, "idTipoDocumento" numeric, "numeroDoDocumentoEntrege" character varying, force boolean DEFAULT false) RETURNS "Result"
	LANGUAGE sql
AS $$
  insert into documentoentregue (
    docentre_obj_tipodocumento,
    docentre_credi_id,
    docentre_user_id,
    docentre_age_id,
    docentre_desc
  ) values (
      "idTipoDocumento",
      "idCredito",
      "idUser",
      "idAgencia",
      "numeroDoDocumentoEntrege"
  );
  
  select '(true,Sucessso)'::"Result";
$$
