CREATE FUNCTION build_chose (left_val boolean, right_val boolean) RETURNS lib.chose_boolean
	LANGUAGE plpgsql
AS $$
  DECLARE 
    val lib.chose_boolean;
  BEGIN 
    val.left_val := left_val;
    val.right_val := right_val;
    return val;
  END;
$$
