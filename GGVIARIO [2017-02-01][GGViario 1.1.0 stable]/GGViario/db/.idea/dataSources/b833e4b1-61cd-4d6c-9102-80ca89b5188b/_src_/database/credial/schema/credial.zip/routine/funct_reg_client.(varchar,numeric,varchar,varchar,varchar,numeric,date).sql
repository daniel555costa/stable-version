CREATE FUNCTION funct_reg_client (userid character varying, useragencia numeric, clientnif character varying, clientname character varying, clientsurname character varying, clientgender numeric, clientdatanascimento date) RETURNS TABLE("RESULT" character varying, "MESSAGE" character varying, "ID" numeric, "NUM DOSSIER" character varying)
	LANGUAGE plpgsql
AS $$
DECLARE
  tt               NUMERIC;
  resp             CHARACTER VARYING;
  idClient         NUMERIC;
  numDossierClient CHARACTER VARYING := rule."generateNumClient"();
BEGIN

  -- caso existe o cliente emite uma messagen de atencao
  IF rule."hasClientNif"(clientnif) THEN
    "RESULT" := 'false';
    "MESSAGE" :=  message('nif client exist');
  ELSE

    INSERT INTO dossiercliente (
      dos_nif,
      dos_gen_id,
      dos_user_id,
      dos_age_id,
      dos_numdos,
      dos_name,
      dos_surname,
      dos_dtnasc
    ) VALUES (
      clientNif,
      clientGender,
      userId,
      userAgencia,
      numDossierClient,
      clientName,
      clientSurname,
      clientDataNascimento
    )
    RETURNING
      dos_id
      INTO idClient;

    "RESULT" := 'true';
    "MESSAGE" := 'Sucesso';
    "ID" := idClient;
    "NUM DOSSIER" := numDossierClient;
  END IF;

  RETURN NEXT;
END;
$$
