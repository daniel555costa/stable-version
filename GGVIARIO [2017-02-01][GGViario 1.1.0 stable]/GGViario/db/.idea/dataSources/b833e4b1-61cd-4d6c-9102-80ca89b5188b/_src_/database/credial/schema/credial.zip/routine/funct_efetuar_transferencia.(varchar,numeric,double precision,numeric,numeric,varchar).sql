CREATE FUNCTION funct_efetuar_transferencia ("idUser" character varying, "idAgencia" numeric, "valorTransferir" double precision, "idBancoRetirar" numeric, "idBancoReceber" numeric, "descricaoOperacao" character varying) RETURNS "Result"
	LANGUAGE plpgsql
AS $$
declare
  vBanco banco;
  res "Result";
  tranfer boolean;
begin
  res."RESULT" := 'false';
  if "idBancoRetirar" = "idBancoReceber" then
    res."MESSAGE" := message('TRANS.BANKs.EQUALS');
    return res;
  end if;


  -- funct_reg_bancomovimento("idUser", "idAgencia", "idBanco", debito, credito, libe)
  res := funct_reg_bancomovimento("idUser", "idAgencia", "idBancoRetirar", "valorTransferir", 0.0,  "descricaoOperacao");

  -- Caso da operacao nao dar sucesso entao abortar a operacao
  if res."RESULT" != 'true' then return res; end if;
  res := funct_reg_bancomovimento("idUser", "idAgencia", "idBancoReceber", 0.0, "valorTransferir", "descricaoOperacao");
  return res;
end;
$$
