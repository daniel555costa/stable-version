CREATE FUNCTION funct_load_insurance ("idUser" numeric, "idAgencia" numeric) RETURNS TABLE("ID" numeric, "VALOR" character varying, "ESTADO" character varying)
	LANGUAGE sql
AS $$
    select
      seg.seg_id,
      lib.money(seg.seg_value),
      case when seg.seg_state = 1 THEN 'Ativo'
           else 'Inativo'
      end
      from seguro seg
      ORDER BY seg.seg_dtreg DESC
  
$$
