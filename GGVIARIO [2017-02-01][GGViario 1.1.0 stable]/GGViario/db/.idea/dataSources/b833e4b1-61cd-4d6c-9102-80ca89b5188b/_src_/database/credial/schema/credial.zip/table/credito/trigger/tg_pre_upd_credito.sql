CREATE TRIGGER tg_pre_upd_credito
BEFORE UPDATE ON credito
FOR EACH ROW EXECUTE PROCEDURE functg_pre_upd_credito()