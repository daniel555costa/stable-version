CREATE FUNCTION import_bytea (p_path text) RETURNS bytea
	LANGUAGE plpgsql
AS $$
declare
  l_oid oid;
  r record;
  bytea_result bytea;
begin
  bytea_result := '';
  select lo_import(p_path) into l_oid;
  for r in ( select data
             from pg_largeobject
             where loid = l_oid
             order by pageno ) loop
    bytea_result = bytea_result || r.data;
  end loop;
  perform lo_unlink(l_oid);
  
  return bytea_result;
end;
$$
