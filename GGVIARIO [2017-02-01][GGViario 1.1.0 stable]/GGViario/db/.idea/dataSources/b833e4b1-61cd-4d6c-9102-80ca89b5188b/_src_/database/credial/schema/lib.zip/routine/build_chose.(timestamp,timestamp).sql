CREATE FUNCTION build_chose (left_val timestamp without time zone, right_val timestamp without time zone) RETURNS lib.chose_boolean
	LANGUAGE plpgsql
AS $$
  DECLARE 
    val lib.chose_timestamp;
  BEGIN 
    val.left_val := left_val;
    val.right_val := right_val;
    return val;
  END;
$$
