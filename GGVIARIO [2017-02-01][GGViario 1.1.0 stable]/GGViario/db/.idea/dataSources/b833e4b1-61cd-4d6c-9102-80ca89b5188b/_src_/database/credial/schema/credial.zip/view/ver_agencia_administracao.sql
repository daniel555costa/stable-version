CREATE VIEW ver_agencia_administracao AS
SELECT ag.age_id AS "ID",
    ag.age_name AS "NOME AGENCIA",
    loca.local_desig AS "LOCALIDADE",
    ( SELECT count(*) AS count
           FROM trabalha tr
          WHERE (tr.trab_age_agencia = ag.age_id)) AS "TOTAL DE TRABALHADORES",
    ( SELECT count(*) AS count
           FROM dossiercliente dos
          WHERE (dos.dos_age_id = ag.age_id)) AS "TOTAL CLIENTES REGISTRADOS"
   FROM (agencia ag
     JOIN localidade loca ON ((ag.age_local_id = loca.local_id)))