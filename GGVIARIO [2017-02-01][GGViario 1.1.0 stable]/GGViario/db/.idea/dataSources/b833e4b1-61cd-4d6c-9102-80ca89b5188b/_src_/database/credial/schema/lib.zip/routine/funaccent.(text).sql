CREATE FUNCTION funaccent (text) RETURNS text
	LANGUAGE sql
AS $$
  SELECT public.unaccent('public.unaccent', $1) -- schema-qualify function and dictionary
$$
