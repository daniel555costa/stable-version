CREATE FUNCTION funct_reg_menuser_grant ("idUser" character varying, "idAgencia" numeric, "userMenuGrant" character varying, "idMenu" numeric, "dataInicio" timestamp without time zone) RETURNS TABLE("RESULT" character varying, "MESSAGE" text)
	LANGUAGE plpgsql
AS $$
   DECLARE
      tt numeric;
      inicio timestamp default "dataInicio";
   BEGIN
      if "dataInicio" is null then
         inicio := now();
      END IF;
      -- verificar se o menu ja esta alocado a utilizador
      select count(*) into tt
         from menuser mu
         where mu.muser_user_user = "userMenuGrant"
            and mu.muser_menu_id = "idMenu"
            and mu.muser_state = 1;

      IF tt = 0 THEN
         insert into menuser (
            muser_menu_id,
            muser_user_id,
            muser_user_user,
            muser_age_id,
            muser_dtinicio
         ) values (
            "idMenu",
            "idUser",
            "userMenuGrant",
            "idAgencia",
            inicio);
      END IF;

      "RESULT" := 'true';
      "MESSAGE" := 'Sucesso';
      return NEXT ;
   END;
$$
