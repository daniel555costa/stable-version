CREATE VIEW ver_localidade AS
SELECT localidade.local_id AS "ID",
    localidade.local_desig AS "DESC"
   FROM localidade
  WHERE (localidade.local_state = (1)::numeric)