CREATE FUNCTION funct_disable_object ("idUser" character varying, "idAgencia" numeric, "idObjecto" numeric) RETURNS result
	LANGUAGE plpgsql
AS $$
  declare
    vObjecto objecto;
    res result;
  begin
    res.result := false;
    vObjecto := rule."getObject"("idObjecto");

    if vObjecto.obj_state = 0 then
      res.message := message('OBJECT.STATE.INABLE');
      return res;
    END IF;

    update objecto
      set obj_state = 0
      where obj_id = "idObjecto";

    return '(true,Sucesso)'::result;
  END;
$$
