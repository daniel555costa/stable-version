CREATE FUNCTION funct_reg_seguro ("idUser" numeric, "idAgencia" numeric, "seguroValue" double precision) RETURNS "Result"
	LANGUAGE plpgsql
AS $$
  declare
    res "Result";
  -- Fechar o seguro atual que esta aberto
  begin
    res."RESULT" := 'false';
    update seguro
      set seg_state = 0
      where seg_state = 1;

    insert into seguro (
      seg_age_id,
      seg_user_id,
      seg_value
      ) values (
        "idAgencia",
        "idUser",
        "seguroValue"
      );
    
    res."RESULT" := 'true';
    res."MESSAGE" := 'Sucesso';
    
    return res;
  end;
$$
