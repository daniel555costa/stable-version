CREATE FUNCTION generateNumCredit ("idUser" character varying, "idAgencia" numeric, "nifClient" character varying, "numCheque" character varying) RETURNS "Result"
	LANGUAGE plpgsql
AS $$
  DECLARE
    lengthCheque integer := length("numCheque");
    indexStartChaque integer;
    lastDisgitsCheques character varying(6); -- is 6 last digits of cheques
    bankDigits character varying (2); -- is parte of banck and agenia
    dinamicRandom character varying(5); -- is dinamick parte generated whithic random
    "numCredito" character varying(12);
    res credial."Result";
    nBanck character varying(1);
    nAgencia character varying(1);
    tt numeric;
    tentativas numeric default 9999;
  BEGIN
    res."RESULT" := 'false';
    
    -- 0000
    -- 1234
    nBanck := substring("numCheque", 4, 1);
    if nBanck is null or length(nBanck) = 0 then
      nBanck := '0';
    END IF;

    nAgencia := substring("numCheque", 8, 1);
    if nAgencia is null or length(nAgencia) = 0 then
      nAgencia := '0';
    END IF;

    bankDigits := nBanck||nAgencia;
    indexStartChaque := lengthCheque-6;

     -- pegar os ultimos 6 digitos do cheque
    lastDisgitsCheques := substring("numCheque", indexStartChaque, 6::integer);
    "numCredito" := null;

    while
      "numCredito" is null
        and tentativas > 0
    loop
      dinamicRandom := trim(to_char(((random()*10000)::integer), '0000'));
      "numCredito" := bankDigits||dinamicRandom||lastDisgitsCheques;

      select count(*) into tt
        from credito ce 
        where ce.credi_numcredito = "numCredito";
      
      if tt > 0 then 
        "numCredito" := null; 
      end if;
      tentativas := tentativas -1;
      -- return res;
    end loop;

    -- quando cossegir criar o numero de credito entao
    if "numCredito" is not null then
      res."RESULT" := 'true';
      res."MESSAGE" := "numCredito";
    ELSE
      -- para o caso de nao poder criar os numeros de creditos
      -- devera ser emitido uma messagem de informacao para contacta o administrador
      -- isso nao pode  isso deve sobre tudo a quandtiade do cheque que ja foram destribuido pro esse banco
      -- o angoritimos de criacao do numero de cidito nao conseguira dar suporte ao
      res."MESSAGE" := message('LOW NUM CREDITO')||' total equal '||tentativas;
    END IF;

    return res;
  END;
$$
