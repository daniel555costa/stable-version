CREATE FUNCTION funct_load_banco_simulacao ("idUser" character varying, "idAgencia" numeric, "valorRequisicao" double precision) RETURNS TABLE("ID" numeric, "NAME" character varying, "SIGLA" character varying)
	LANGUAGE sql
AS $$
  select bc.banco_id as "ID",
          bc.banco_name as "NAME",
          bc.banco_sigla as "SIGLA"
    from banco bc
      inner join chequempresa ch on bc.banco_id = ch.cheq_banco_id
    where ch.cheq_state = 1
      and ch.cheq_age_owner = "idAgencia"
      and bc.banco_saldo >= "valorRequisicao"
$$
