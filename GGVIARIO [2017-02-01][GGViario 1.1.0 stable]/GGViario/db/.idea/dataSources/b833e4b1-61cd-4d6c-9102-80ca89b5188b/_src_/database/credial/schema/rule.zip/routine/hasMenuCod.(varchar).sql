CREATE FUNCTION hasMenuCod ("codMenu" character varying) RETURNS boolean
	LANGUAGE plpgsql
AS $$
  declare
    tt numeric;
  begin
    select count(*) into tt
      from menu m 
      where upper(m.menu_cod) = upper("codMenu");
    
    return tt > 0;
  END;
$$
