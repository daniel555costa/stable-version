CREATE FUNCTION hasClientNif ("nifClient" character varying) RETURNS boolean
	LANGUAGE plpgsql
AS $$
  declare
    tt numeric;
  begin
    select count(*) into tt
      from dossiercliente dos
      where dos.dos_nif = "nifClient";
    
    RETURN  tt>0;
  END;
$$
