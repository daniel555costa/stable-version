CREATE FUNCTION funct_reg_historicoclient (iduser character varying, idagencia numeric, nifclinet character varying, idstatecivil numeric, idlocalidade numeric, idprofissao numeric, idlocaltrabalho numeric, morada character varying, telfone character varying, telmovel character varying, telservico character varying, mail character varying) RETURNS TABLE("RESULT" character varying, "MESSAGE" character varying)
	LANGUAGE plpgsql
AS $$
  DECLARE
    clientInfo RECORD;
  BEGIN

    "RESULT" := 'false';
    -- carregar as informacao atuais do cliente
    select * into clientInfo
      from dossiercliente doc
      WHERE  doc.dos_nif = nifClinet;

    -- desativar as antiga linha do cliente
    update historicocliente
      set hisdos_state = 0
      where hisdos_dos_nif = nifClinet
         and hisdos_state = 1;


    -- criar a nova linha do clinet
    insert into historicocliente(
      hisdos_dos_nif,
      hisdos_user_id,
      hisdos_civil_id,
      hisdos_local_id,
      hisdos_obj_profisao,
      hisdos_obj_localtrabalho,
      hisdos_age_id,
      hisdos_morada,
      hisdos_telfixo,
      hisdos_telmovel,
      hisdos_telservico,
      hisdos_mail
    ) values (
          nifClinet,
          idUser,
          idStateCivil,
          idLocalidade,
          idProfissao,
          idLocalTrabalho,
          idAgencia,
          morada,
          telfone,
          telmovel,
          telServico,
          mail
      );
    
    "RESULT" := 'true';
    "MESSAGE" := 'Sucesso';
    
    return next;
  END;
$$
