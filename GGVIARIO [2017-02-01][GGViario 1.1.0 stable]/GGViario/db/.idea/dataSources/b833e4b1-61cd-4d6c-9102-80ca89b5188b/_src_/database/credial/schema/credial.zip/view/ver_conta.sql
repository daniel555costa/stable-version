CREATE VIEW ver_conta AS
SELECT ct.conta_id AS "ID",
    ct.conta_numero AS "NUMERO",
    bc.banco_cod AS "BANCO",
    ct.conta_agenciacod AS "AGENCIA",
    (((bc.banco_cod)::text || (ct.conta_agenciacod)::text) || (ct.conta_numero)::text) AS "NIB",
    ct.conta_desc AS "DESCRICAO",
    bc.banco_sigla AS "SIGLA BANCO",
    bc.banco_name AS "NOME BANCO"
   FROM (conta ct
     JOIN banco bc ON ((ct.conta_banco_id = bc.banco_id)))