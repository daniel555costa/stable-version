CREATE VIEW ver_client_simple AS
SELECT mver_client_simple."NIF",
    mver_client_simple."NAME",
    mver_client_simple."SURNAME",
    mver_client_simple."DOSSIER",
    mver_client_simple."TELE",
    mver_client_simple."ID AGENCIA",
    mver_client_simple."QUANTIDADE DE CREDITO",
    mver_client_simple."S_NAME",
    mver_client_simple."S_SURNAME"
   FROM filter.mver_client_simple