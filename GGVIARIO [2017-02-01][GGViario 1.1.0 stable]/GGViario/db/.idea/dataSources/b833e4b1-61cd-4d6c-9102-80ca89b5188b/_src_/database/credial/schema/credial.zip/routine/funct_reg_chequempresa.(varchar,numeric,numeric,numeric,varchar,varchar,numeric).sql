CREATE FUNCTION funct_reg_chequempresa ("idUser" character varying, "idAgencia" numeric, "idBanco" numeric, "idAgenciaPropetariaDoCheque" numeric, "sequenciaChequeInicial" character varying, "sequenciaChequeFinal" character varying, "totalChequesEmpresa" numeric) RETURNS "Result"
	LANGUAGE plpgsql
AS $$
  declare
    vValidate "ValidateResult";
    res "Result";
  begin
    -- o idBanco correspnde ao id-da-conta 
    res."RESULT" := 'false';
    -- Validar os numeros das sequencia do cheque
    vValidate := rule."validateSequenciaCheque"("sequenciaChequeInicial", "sequenciaChequeFinal");
    if not vValidate."RESULT" then
      res."RESULT" := 'false';
      res."MESSAGE" := vValidate."MESSAGE";
    END IF;

    -- Desativar a titiga carteira do banco na agencia
    update chequempresa
      set cheq_state = 0
      where cheq_banco_id  = "idBanco"
        and cheq_age_owner = "idAgenciaPropetariaDoCheque"
        and cheq_state = 1;

    insert into chequempresa(
      cheq_age_owner,
      cheq_age_id,
      cheq_conta_id,
      cheq_user_id,
      cheq_sequenceinicio,
      cheq_sequencefim,
      cheq_total
    ) values (
      "idAgenciaPropetariaDoCheque",
      "idAgencia",
      "idBanco",
      "idUser",
      "sequenciaChequeInicial",
      "sequenciaChequeFinal",
      "totalChequesEmpresa"
    );

    res."RESULT" := 'true';
    res."MESSAGE" := 'Sucess0';
    return res;
  end;
$$
