CREATE FUNCTION increment (INOUT argment double precision) RETURNS double precision
	LANGUAGE plpgsql
AS $$
   BEGIN
      argment := argment + 1;
      raise notice 'kdfmngfk %', argment;
   END;
  
$$
