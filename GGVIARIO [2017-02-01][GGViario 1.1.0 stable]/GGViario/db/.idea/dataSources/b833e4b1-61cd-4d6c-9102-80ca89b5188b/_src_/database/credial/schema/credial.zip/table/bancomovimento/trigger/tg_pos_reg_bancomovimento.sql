CREATE TRIGGER tg_pos_reg_bancomovimento
AFTER INSERT ON bancomovimento
FOR EACH ROW EXECUTE PROCEDURE functg_pos_reg_bancomovimento()