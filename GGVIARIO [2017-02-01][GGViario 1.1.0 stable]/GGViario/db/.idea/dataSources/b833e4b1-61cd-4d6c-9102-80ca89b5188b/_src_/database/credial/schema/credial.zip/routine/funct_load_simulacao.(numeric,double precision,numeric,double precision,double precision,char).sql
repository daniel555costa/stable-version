CREATE FUNCTION funct_load_simulacao ("numDias" numeric, "valorSimulacao" double precision, "tipoCredito" numeric, "descontoSimulacao" double precision, correcao double precision, opcao character) RETURNS TABLE("RESULT" character varying, "MESSAGE" text, "TAXA" double precision, "PERIODO" numeric, "CAPITAL" double precision, "TAXA SEM DESCONTO" double precision, "TAXA COM DESCONTO" double precision, "TOTAL PAGAR" double precision, "PRESTACAO" numeric, "REEMBOLSO/PRESTACAO" double precision, "SEGURO" double precision, "NUMERO SEMANA MES" numeric, "ID TAXA INFERIOR" numeric)
	LANGUAGE plpgsql
AS $$
  DECLARE
    -- NUMERO SEMANA MES AS 'NSEMANAMES' in old verisio oracle


    -- OS SIMULARVALORES >31 CORESPONDE A MESES
    -- OS SIMULARVALORES <= 30 CORREESPONDEM A SEMANAS
    -- UMA SEMANA CORESPONDE A 7 DIA E CORESPONDE A UM PERIODO
    -- DUAS SEMANAS CORESPONDE A 15 DIAS 2 PERIODOS
    -- 3 SEMANS CORESPONDE A 21 DIAS 3 PERIODOS
    -- 4 SEMANS CORESPONDE A 30 DIAS 4 PERIODO
    -- OS SIMULARVALORES > 30 A MESES 31 CORESPINDE A 1 MES E NESTE CASO UM PERIODO
    -- 60 MESES 2 PERIODSO, 90  3 MESES 3 PERIODOS, 120 DIAS 4 MESES 4 PERIODOS, ECT
    pos numeric default 0;
    numPeriodo integer default 0;
    numSemanas integer default 0;
    restoDivisao numeric default 0;
    vSeguro seguro;

    taxaInferior taxa;
    taxaSuperior taxa;
  BEGIN
    
    --definindo o valor default do seguro
    vSeguro.seg_value := 0;
    
    -- GARANTIR QUE O DIA E O SIMULARVALOR SEJAM MAIORES QUE ZEROS
    if "numDias" <= 0 or "valorSimulacao" <= 0 then
      pos := pos +1;
      "RESULT" := 'false';
      "MESSAGE" := message('REQUIRE SIMULA.VALOR >0');
    else
      if "numDias" < 30 then
        numPeriodo := 1; -- semanas de 7 dias
      else
        numSemanas := 30;
        numPeriodo :=trunc("numDias" / numSemanas);
        restoDivisao := mod("numDias", numSemanas);
      END IF;

      if restoDivisao >= 1 then
        numPeriodo := numPeriodo +1;
      ELSEIF restoDivisao = 0 then
        numPeriodo := numPeriodo;
      END IF;

      if numPeriodo >= 4 and numSemanas = 7 then
        numPeriodo := 4;
      ELSIF numPeriodo >= 2 and numSemanas = 30 then
        -- carregar o valor do seguro ativo
        vSeguro := rule."getSeguroAtivo"();
      END IF;

      -- Carregar a taxa para o periodo inferior
      taxaInferior := rule."getTaxaPeriodoInferior"("numDias", "tipoCredito");
    
      -- Carregar a taxa para o periodo superior
      taxaSuperior := rule."getTaxaPeriodoSuperior"("numDias", "tipoCredito");

      -- Quando nao houver a taxa inferior devera usar a taxa superior no lugar da taxa inferior
      if taxaInferior.taxa_id is null or taxaInferior.taxa_id = -1 then
        taxaInferior := taxaSuperior;
      end if;

      -- QUANDO HOUVER AS TAXA SUPERIOR null e que deve ser feita as operacao
      -- -- Caso contrario a administracao devera colocar as taxa para o dia para
      if taxaSuperior.taxa_id != -1 then
        if taxaSuperior.taxa_value >= 1 then
          "RESULT" := 'true';
          "TAXA" :=  taxaSuperior.taxa_value;
          "PERIODO" := numPeriodo;
          "CAPITAL" := "valorSimulacao";


          DECLARE
            nTaegSuperior numeric default 0;
            nTaegInferior numeric default 0;
            nDiasMais numeric default 0;
            nTaegDiferenca numeric default 0;
            xDiario numeric default 0;

            taegSemDescontoSimula numeric default 0;
            taegComDescontoSimula numeric default 0;
            descontoSimulaCorecaoTotal numeric default 0;
            totalPagar double precision default 0;
            descontoSimulacaoCorrecaoTotal double precision default 0;
          BEGIN
            
            -- X1 CALCULO DE TAEG SUPERIOR
            nTaegSuperior := "valorSimulacao" * (taxaSuperior.taxa_value / 100);

            -- X2 CALCULO DE TAEG INFERIOR
            nTaegInferior := "valorSimulacao" * (taxaInferior.taxa_value / 100);

             -- D1 - D2 INF DIAS DO PERIODOP MENOS O PERIODO DA TAGE INFERIOR
            nDiasMais := "numDias" - taxaInferior.taxa_periodo;

            -- X2 - X1 DIFERENCA ENTRE A TAEG SUPERIRO E INFERIOR
            nTaegDiferenca := nTaegSuperior - nTaegInferior;

            -- DIARIO = (X1 - X2)/DLIMSUP - D2LIMINF
            if ((taxaSuperior.taxa_periodo - taxaInferior.taxa_periodo) = 0)
              or ((nTaegSuperior - nTaegInferior) = 0 ) then
              xDiario := 0;
            ELSE
              xDiario := ((nTaegSuperior - nTaegInferior) / (taxaSuperior.taxa_periodo - taxaInferior.taxa_periodo));
            END IF;

            taegSemDescontoSimula := (nTaegInferior + (xDiario * nDiasMais));
            "TAXA SEM DESCONTO" := taegSemDescontoSimula;

            taegComDescontoSimula := (taegSemDescontoSimula - (taegSemDescontoSimula * ("descontoSimulacao" / 100)));
            "TAXA COM DESCONTO" := taegComDescontoSimula;

            totalPagar := ("valorSimulacao" + taegComDescontoSimula + vSeguro.seg_value + descontoSimulaCorecaoTotal);
            
            -- Aplicar a corecao
            totalPagar := (case when opcao = 'A' then totalPagar + correcao else totalPagar - correcao end);

            "TOTAL PAGAR" := totalPagar;

            "PRESTACAO" := ("valorSimulacao" / numPeriodo);

            "REEMBOLSO/PRESTACAO" := (("valorSimulacao" + taegComDescontoSimula + vSeguro.seg_value + descontoSimulacaoCorrecaoTotal) / numPeriodo);

            "SEGURO" := vSeguro.seg_value;
            "NUMERO SEMANA MES" := numSemanas;
            "ID TAXA INFERIOR" := taxaInferior.taxa_id;
          END;
          "RESULT" := 'true';
          "MESSAGE" := 'Sucesso';
        ELSE
          pos := pos + 1;
          "RESULT" := 'false';
          "MESSAGE" := message('CONTT ADM PUT TAXA');

        END IF;
      ELSE
        "RESULT" := 'false';
        "MESSAGE" := message('CONTT ADM PUT TAXA');
      END IF;
    END IF;

    -- publicar o resultado da simulacao
    return next;
  END;


$$
