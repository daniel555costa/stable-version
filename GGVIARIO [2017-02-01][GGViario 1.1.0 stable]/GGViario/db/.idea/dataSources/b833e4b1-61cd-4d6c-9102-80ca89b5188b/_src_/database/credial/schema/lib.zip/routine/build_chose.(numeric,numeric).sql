CREATE FUNCTION build_chose (left_val numeric, right_val numeric) RETURNS lib.chose_boolean
	LANGUAGE plpgsql
AS $$
  DECLARE 
    val lib.chose_numeric;
  BEGIN 
    val.left_val := left_val;
    val.right_val := right_val;
    return val;
  END;
$$
