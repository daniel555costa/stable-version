CREATE FUNCTION funct_reg_trabalhagencia ("idUser" character varying, "idAgancia" numeric, "userForTrabalha" character varying, "agenciaForTrabalha" numeric, "dataInicio" timestamp without time zone) RETURNS TABLE("RESULT" character varying, "MESSAGE" text)
	LANGUAGE plpgsql
AS $$
   DECLARE
      inicio timestamp := "dataInicio";
   BEGIN

      "RESULT" := 'false';

      if "dataInicio" is null then
         inicio := now();
      END IF;

      -- primeiramente deve ser desativados o ultimo local do traablho do utilizador
      update trabalha
         set trab_dtfim = now(),
             trab_state = 0
         where trab_user_user = "userForTrabalha"
           and trab_state = 1;

      insert into trabalha (
         trab_user_id,
         trab_user_user,
         trab_age_id,
         trab_age_agencia,
         trab_dtinicio
      ) values (
         "idUser",
         "userForTrabalha",
         "idAgancia",
         "agenciaForTrabalha",
         inicio
      );

      "RESULT" := 'true';
      "MESSAGE" := 'Sucesso';

      return next;
   END;
$$
