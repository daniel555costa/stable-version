create PACKAGE BODY "PACK_LIB" AS

  FUNCTION calcIdade(OLD_DATE DATE) RETURN NUMBER AS
      new_date DATE  := to_char(CURRENT_TIMESTAMP, 'YYYY-MM-DD');
      
      idade_char varchar(10) := trunc((months_between(new_date, OLD_DATE))/12);
  BEGIN
    RETURN to_number(idade_char); 
  END calcIdade;

  FUNCTION money (VALOR FLOAT, SIGLA VARCHAR2) RETURN VARCHAR2 AS 
    moeda VARCHAR(100);
    sSigla VARCHAR2 (30):= CASE WHEN SIGLA IS NULL OR SIGLA = '' THEN '' ELSE ' '||SIGLA END;
  BEGIN 

      --                             FM999G999G999 E A MASCAR UASADA PARA FORMATAR OS VALORES
    
      IF valor IS NULL THEN RETURN '0,00'; END IF;
      moeda := TO_CHAR(VALOR, 'FM999G999G999G999G999G999G999G999G999G999G999G999G999G990D90')||sSigla;
      moeda := REPLACE(REPLACE(moeda, ',', ' '), '.', ',')||SIGLA;
      
      
      return moeda;
  END MONEY;
  
  FUNCTION money (VALOR BINARY_DOUBLE) RETURN VARCHAR2
  IS
  BEGIN
     RETURN money(valor, '')||'';
  END;
  

  FUNCTION asTime (DATE_PARAM TIMESTAMP) RETURN VARCHAR2 AS 
  BEGIN
    
    RETURN TO_CHAR(DATE_PARAM, 'HH24:MM:SS');
  END asTime;

  FUNCTION asDDMMYYYY (DATE_PARAM TIMESTAMP) RETURN VARCHAR2 AS
  BEGIN
    -- TODO: Implementation required for FUNCTION LIB.AS_DDMMYYYY
    RETURN TO_CHAR(DATE_PARAM, 'DD-MM-YYYY');
  END asDDMMYYYY;

  FUNCTION asYYYYMMDD (DATE_PARAM TIMESTAMP) RETURN VARCHAR2 AS
  BEGIN
    
    RETURN TO_CHAR(DATE_PARAM, 'YYYY-MM-DD');
  END asYYYYMMDD;
  
  
  FUNCTION state(ENTIDADE VARCHAR, COD NUMBER)RETURN VARCHAR2 AS
      TT NUMBER;
      VALOR VARCHAR(50);
  BEGIN
      --VERIFICAR A EXISTENCIA DE ESTADO 
      SELECT COUNT (*) INTO TT FROM T_DEFSTATE WHERE UPPER(ENTIDADE) =UPPER(DSTT_DTB_PREFIXO) AND COD = DSTT_KEY;

      IF TT = 0  THEN RETURN NULL; END IF ;
      SELECT DSTT_VALUE   INTO VALOR FROM T_DEFSTATE WHERE UPPER(ENTIDADE) =UPPER(DSTT_DTB_PREFIXO) AND COD = DSTT_KEY;
      RETURN VALOR ;   
  END STATE ;
  
  
    FUNCTION getCurrentYear RETURN VARCHAR2 IS
    BEGIN
        RETURN TO_CHAR(CURRENT_TIMESTAMP, 'YYYY');
    END;
  

  
    FUNCTION complet (ARGMENT IN VARCHAR2, COMPLETION IN CHAR, FINAL_LENGTH IN NUMBER, FRIST IN BOOLEAN) RETURN VARCHAR2 IS
        CURRENT_LOCATION NUMBER;
        RESUATADO VARCHAR2(4000) := ARGMENT;
    BEGIN
        IF LENGTH(ARGMENT) < FINAL_LENGTH THEN
            IF FRIST THEN RETURN PACK_LIB.COMPLET(COMPLETION||ARGMENT, COMPLETION, FINAL_LENGTH, FRIST);
            ELSE RETURN PACK_LIB.COMPLET(ARGMENT||COMPLETION, COMPLETION, FINAL_LENGTH, FRIST);
            END IF;
        ELSE RETURN ARGMENT;
        END IF;
    END;
   
   
    FUNCTION isNumber (argment VARCHAR2) RETURN NUMBER IS
      n number;
    begin
      n :=  to_number(argment);
      RETURN 1;
      exception when others then
        RETURN 0;
    END;
   
   
   
   
    FUNCTION splitNotNull (argment VARCHAR2, splitCase VARCHAR2) RETURN TB_ARRAY_STRING
    IS
        mascara VARCHAR(500) DEFAULT '[^'||splitCase||']+';
        res TB_ARRAY_STRING := TB_ARRAY_STRING();
    BEGIN
        FOR i IN(SELECT 
                      regexp_substr(argment, mascara, 1, level) AS piece 
                    FROM DUAL 
                      CONNECT BY level <= LENGTH(regexp_substr(argment, mascara, 1, level))
                    ) LOOP
            IF i.piece IS NOT NULL THEN
                res.EXTEND; res(res.COUNT) := i.piece;
            END IF;
        END LOOP;
        RETURN res;
    END;
    
    
    
    
    FUNCTION splitAll (argment VARCHAR2, splitCase VARCHAR2) RETURN TB_ARRAY_STRING
    IS
        indexPiece INTEGER;
        piece VARCHAR2(4000) := argment;
        res TB_ARRAY_STRING := TB_ARRAY_STRING();
    BEGIN
        LOOP
          indexPiece := instr(piece, splitCase);
          IF indexPiece > 0 then
              res.EXTEND; res(res.COUNT) := substr(piece, 1,indexPiece-1);
              piece := substr(piece, indexPiece + length(splitCase));
          ELSE
              res.EXTEND; res(res.COUNT) := piece;
              EXIT;
          END IF;
        END LOOP;
        RETURN res;
    END;
    
    
    FUNCTION charAt(argment VARCHAR2, charIndex INTEGER) RETURN CHAR
    IS
    BEGIN
        RETURN substr(argment, charIndex, 1);
    END;
    
    
    FUNCTION tableLength(tableName VARCHAR2) RETURN  NUMBER
    IS
      queryy VARCHAR2(300) := 'SELECT COUNT(*) FROM '||tableName;
      ttLent NUMBER;
    BEGIN
       EXECUTE IMMEDIATE queryy INTO ttLent;
       RETURN ttLent;
       
       EXCEPTION
         WHEN OTHERS THEN
           DBMS_OUTPUT.PUT_LINE (SQLERRM);
           RETURN NULL;
    END;
    
    
    FUNCTION getValues(tableName VARCHAR2, tableCollId VARCHAR2, tableCollValue VARCHAR2, valueId VARCHAR2, comparator VARCHAR2, toString NUMBER) RETURN TB_ARRAY_STRING
    IS
       listResult TB_ARRAY_STRING := TB_ARRAY_STRING();
       stmt VARCHAR2 (1000);
    BEGIN
       
       stmt := 'SELECT '||tableCollValue||' FROM '||tableName;
       -- toString Saber ser veira todo para string ou nao {1 = SIM}
       
       --Quando for para efectuar o toString entao
       IF toString = 1 AND tableCollId IS NOT NULL AND valueId IS NOT NULL AND comparator IS NOT NULL THEN
          stmt := stmt||' WHERE '||tableCollId||'||'''' '||comparator||' '||valueId||'||''''';
       -- Quando nao ser nessecario o to String entao
       ELSIF toString != 1 AND tableCollId IS NOT NULL AND valueId IS NOT NULL AND comparator IS NOT NULL THEN 
          stmt := stmt||' WHERE '||tableCollId||' '||comparator||' '||valueId;
       END IF;
       
       IF valueId IS NOT NULL THEN
           EXECUTE IMMEDIATE stmt BULK COLLECT INTO listResult;
       ELSE listResult(listResult.COUNT) := NULL;
       END IF;
       
       RETURN listResult;
       
       EXCEPTION WHEN OTHERS THEN
           listResult.EXTEND;
           listResult(listResult.COUNT) := stmt;
           RETURN listResult;
    END;
    
    
    FUNCTION getVall(tableName VARCHAR2, tableCollId VARCHAR2, tableCollVAlue VARCHAR2, valueId VARCHAR2, comparator VARCHAR2, toString NUMBER ) RETURN VARCHAR2
    IS
       listValues TB_ARRAY_STRING := getValues(tableName, tableCollId, tableCollVAlue, valueId, comparator, toString);
    BEGIN
       IF valueId IS NULL OR tableName IS NULL OR tableCollId IS NULL THEN
          RETURN NULL;
       END IF;
       
       IF listValues.COUNT = 1 THEN RETURN listValues(1);
       ELSIF listValues.COUNT = 0 THEN  RETURN '<NO DATA FOUND>';--||listValues(listValues.COUNT);
       ELSE RETURN 'Much value QUERE('||listValues.COUNT||') = '||listValues(listValues.COUNT);
       END IF;
    END;
    
    FUNCTION getVallView(tableName VARCHAR2, tableCollId VARCHAR2, tableCollVAlue VARCHAR2, valueId VARCHAR2, comparator VARCHAR2, toString NUMBER ) RETURN VARCHAR2
    IS
       listValues TB_ARRAY_STRING := getValues(tableName, tableCollId, tableCollVAlue, valueId, comparator, toString);
    BEGIN
       IF valueId IS NULL OR tableName IS NULL OR tableCollId IS NULL THEN
          RETURN NULL;
       END IF;
       
       IF listValues.COUNT = 1 THEN RETURN listValues(1);
       ELSIF listValues.COUNT = 0 THEN  RETURN NULL;--||listValues(listValues.COUNT);
       ELSE RETURN 'Much value QUERE('||listValues.COUNT||') = '||listValues(listValues.COUNT);
       END IF;
    END;
    
    
    
    FUNCTION getFreeId(tableName VARCHAR2, tableId VARCHAr2) RETURN NUMBER
    IS
        minId NUMBER;
        maxId NUMBER;
        tt NUMBER;
        idFree NUMBER;
        sqlMaxMin VARCHAR2(3000) := 'SELECT MAX('||tableId||'), MIN('||tableId||') FROM '||tableName;
        sqlFree VARCHAR2(3000) := 'SELECT COUNT(*) FROM '||tableName||' WHERE '||tableId||' = :a';
    BEGIN
        -- capturar o maximo id e o minimo id
        EXECUTE IMMEDIATE sqlMaxMin INTO maxId, minId;
        FOR I IN  (minId+1)..(maxId-1) LOOP
           -- verificar 
           EXECUTE IMMEDIATE sqlFree  INTO tt USING I;
           
           IF tt = 0 THEN -- Siguinifica que esse id esta liver
              idFree := I;
              EXIT;
           END IF;
        END LOOP;
        RETURN idFree;
        /*
        EXCEPTION WHEN OTHERS THEN
           RETURN NULL;*/
    END;
    
    
    FUNCTION betweenDate(currentDate TIMESTAMP, intiDate TIMESTAMP, endDate TIMESTAMP) RETURN NUMBER
    IS
    BEGIN
        RETURN (CASE
                  WHEN intiDate IS NOT NULL AND endDate IS NOT NULL AND currentDate BETWEEN intiDate AND endDate THEN 1
                  WHEN intiDate IS NULL AND endDate IS NULL THEN 1
                  WHEN intiDate IS NOT NULL AND endDate IS NULL AND TO_CHAR(currentDate, 'DD-MM-YYYY') = TO_CHAR(intiDate, 'DD-MM-YYYY') THEN 1
                  WHEN endDate IS NOT NULL AND intiDate IS NULL AND TO_CHAR(currentDate, 'DD-MM-YYYY') = TO_CHAR(endDate, 'DD-MM-YYYY') THEN 1
                  ELSE 0
                END);
    END betweenDate;
    
    
    FUNCTION charValue(argment DATE) RETURN CHARACTER VARYING
    IS
    BEGIN
       RETURN TO_CHAR(argment, 'YYYY-MM-DD');
    END;
    
    
    
    FUNCTION charValue(argment TIMESTAMP) RETURN CHARACTER VARYING
    IS
    BEGIN
       RETURN TO_CHAR(argment, 'YYYY-MM-DD HH24:MI:SS FF3');
    END;
    
    
  
    FUNCTION getIntervalNumber (arg1 DATE, arg2 DATE) RETURN NUMBER
    IS 
    BEGIN
          RETURN arg1 - arg2;
    END;
    
    
        FUNCTION NO_ACCENT(argment CHARACTER VARYING) RETURN CHARACTER VARYING
    IS
    BEGIN
       RETURN utl_raw.cast_to_varchar2(nlssort(argment, 'nls_sort=binary_ai'));
    END;
    
    
    FUNCTION NO_ACCENT_UPPER(argment CHARACTER VARYING) RETURN CHARACTER VARYING
    IS
    BEGIN
       RETURN UPPER(NO_ACCENT(argment));
    END;

END PACK_LIB;