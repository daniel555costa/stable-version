create view VER_ROUBO as
SELECT
    OB.obj_id AS REALID,
    OB.OBJ_SEQUENCE AS ID,
    OB.OBJ_ROUBO.PROP_QUANTIDAEE as QUANTIDADE,
    OB.OBJ_ROUBO.PROP_MODELO  as MODELO,
    OB.OBJ_ROUBO.PROP_VALOR as VALOR,
    OB.OBJ_ROUBO.PROP_DESCRICAO as DESCRINCAO,
    CAST( pack_lib.asddmmyyyy(ob.obj_dtreg) AS VARCHAR2(10)) as "registo",
    CAST(pack_lib.STATE('obj',ob.obj_state) AS VARCHAR2(50)) as estado,
    fc.func_accessname as username
  FROM t_objecto ob
     INNER JOIN  t_funcionario fc on fc.func_id = OB.OBJ_USER_ID
  where OB.OBJ_ROUBO IS NOT NULL
