create trigger TG_NEXT_LANCAMENTOACCOUNT
	before insert
	on T_LANCAMENTOACCOUNT
	for each row
begin  
   if inserting then 
      if :NEW."LANCACOUNT_ID" is null then 
         select SEQ_LANCAMENTOACCOUNT.nextval into :NEW."LANCACOUNT_ID" from dual; 
      end if; 
   end if; 
end;

