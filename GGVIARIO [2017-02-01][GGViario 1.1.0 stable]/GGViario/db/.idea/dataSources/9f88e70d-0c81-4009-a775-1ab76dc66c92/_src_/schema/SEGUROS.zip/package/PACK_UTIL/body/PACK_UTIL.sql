create PACKAGE BODY PACK_UTIL IS

  FUNCTION FUNC_ACTIVADESACTIVA_CATEGORIA (NOME VARCHAR2,
                                          USER_ID VARCHAR2
                                        )
    RETURN VARCHAR2
    
    IS
     ACT_STATE NUMBER;
    BEGIN
      UPDATE T_OBJECTYPE
        SET OBJT_STATE = (CASE WHEN OBJT_STATE = 0 THEN 1 ELSE 0 END)
        WHERE UPPER(OBJT_DESC)= UPPER(NOME)AND (OBJT_T_ID)= 10;
      
      SELECT OBJT_STATE INTO ACT_STATE 
        FROM T_OBJECTYPE 
          WHERE UPPER( OBJT_DESC)= UPPER(NOME) 
      AND (OBJT_T_ID)= 10;
      
      IF ACT_STATE  = 0 THEN RETURN 'DESACTIVO';
        ELSE  RETURN 'ACTIVADO';
      END IF;
    END;
    
    
    
    FUNCTION FUNC_ACTDESACT_COBERTURA(ID_CONTRATO NUMBER,
                                    identificacao_segurado NUMBER,
                                    USER_ID NUMBER
                                     ) RETURN VARCHAR2
    -- Funcao para cativar e desativara as cubertura de um segurado em um contrato
   
    IS
      ACT_STATE NUMBER;
      ID_OBJ NUMBER;
    BEGIN
    -- Alterar o estado da cibertura {caso esta cobrindo entao retirara a cubertura | Se nao estiver a cubrinte entao cubrir}
        UPDATE T_ASSEGURA ASS
          SET ASS.ASE_STATE =  (CASE WHEN  ASS.ASE_STATE = 0 THEN 1 ELSE 0 END)
          WHERE(ASS.ASE_OBJ_ID)=(identificacao_segurado)
        AND ASS.ASE_CTT_ID = ID_CONTRATO;
        
        --Obter o actual estado da cubertura {1 Cubrindo |  0 Nao esta a cubrindo}
        SELECT 
        ASS.ASE_STATE  INTO ACT_STATE 
          FROM T_ASSEGURA ASS
          WHERE(ASS.ASE_OBJ_ID)=(identificacao_segurado)
        AND ASS.ASE_CTT_ID = ID_CONTRATO;
        
        IF ACT_STATE = 0 THEN RETURN 'DESACTIVO';
         ELSE RETURN 'ACTIVO';
        END IF;
        
        
    
    END;   

    FUNCTION FUNC_ACTDESACT_DEPENDENTE( USER_ID NUMBER,
                                    ID_DEP VARCHAR2 )
   
    RETURN VARCHAR2
    IS
       ACT_STATE NUMBER;
    BEGIN
      UPDATE T_DEPENDENTE 
        SET DEP_STATE = ( CASE WHEN DEP_STATE = 0 THEN 1 ELSE 0 END)
        WHERE UPPER(DEP_ID)= UPPER(ID_DEP);
        
      SELECT DEP_STATE INTO ACT_STATE 
        FROM T_DEPENDENTE
        WHERE UPPER(DEP_ID)= UPPER(ID_DEP);
        
      IF ACT_STATE = 0 THEN RETURN' DESACTIVO';
         ELSE RETURN 'ACTIVO';
      END IF;
      
    END;
    
    
  FUNCTION FUNC_ACTIVADESACTIVA_CONTA( NIB VARCHAR2,
                                    USER_ID VARCHAR2)
                                
  RETURN VARCHAR2
  IS
    ACT_STATE NUMBER;
  BEGIN
    /*UPDATE T_CONTA
        SET COUNT_STATE = (CASE WHEN COUNT_STATE = 0 THEN 1 ELSE 0 END)
        WHERE UPPER(COUNT_NIB)= UPPER(NIB);
    SELECT COUNT_STATE INTO ACT_STATE
      FROM T_CONTA
      WHERE  UPPER(COUNT_NIB)= UPPER(NIB);
    
    IF ACT_STATE = 0 THEN RETURN' DESACTIVO'; 
      ELSE RETURN 'ACTIVO';
    END IF;
    */
    RETURN 'true';
  END;







    FUNCTION FUNC_ACTIVADESACTIVA_BANK( sigla VARCHAR2,
                                    USER_ID VARCHAR2)
    RETURN VARCHAR2  
    IS
      ACT_STATE NUMBER;
    BEGIN
      UPDATE T_BANK
        SET BK_STATE = (CASE WHEN BK_STATE = 0 THEN 1 ELSE 0 END)
        WHERE UPPER(BK_sigla)= UPPER(sigla);
      
      SELECT BK_STATE INTO ACT_STATE 
        FROM T_BANK 
        WHERE UPPER(BK_sigla)= UPPER(sigla);
      
      IF ACT_STATE = 0 THEN RETURN' DESACTIVO';
      ELSE RETURN 'ACTIVO';
      END IF;
      
      RETURN 'true';
    END;
    
    
    
    FUNCTION FUNC_ACTIVADESATIVA_PAIS(idUser NUMBER,
                                       idPais NUMBER)
    RETURN VARCHAR2
    IS
      ACT_STATE NUMBER;
    BEGIN
      UPDATE T_PAIS
        SET PAIS_STATE =( CASE WHEN PAIS_STATE= 0 THEN 1 ELSE  0 END)
        WHERE  PAIS_ID  = idPais;
    
      SELECT PAIS_STATE INTO ACT_STATE 
        FROM T_PAIS 
        WHERE PAIS_ID = idPais;
        
      IF ACT_STATE = 0 THEN  RETURN 'Desativo';
      ELSE RETURN 'Activo';
      END IF;
    END;
    

    FUNCTION FUNC_ACTIVARDESATIVAR_PERGUNTA
    (
        USER_ID NUMBER,
        ID_PERGUNTA NUMBER
    )RETURN VARCHAR2
    IS 
      ACT_STATE NUMBER;
    BEGIN
    -- DESATIVAR A PERGUNTA REQUISITADA
      UPDATE T_PERGUNTA
        SET PER_STATE = (CASE WHEN PER_STATE = 0 THEN 1 ELSE 0 END)
        WHERE PER_ID = ID_PERGUNTA;
      
      SELECT PER_STATE INTO ACT_STATE 
        FROM T_PERGUNTA 
        WHERE PER_ID = ID_PERGUNTA;
      
        IF ACT_STATE = 0 THEN RETURN 'Desativado!';
        ELSE RETURN 'Activado';
        END IF;
    END;
    
    
    FUNCTION FUNC_ACTIVADESACTIVA_MOEDA
    ( idUtilizador NUMBER,
      ID_MOE NUMBER 
    )RETURN VARCHAR2
    
    IS 
      ACT_STATE NUMBER;
    BEGIN
    
      UPDATE T_MOEDA
        SET MOE_STATE = (CASE WHEN MOE_STATE = 0 THEN 1 ELSE 0 END)
        WHERE MOE_ID = ID_MOE;
      
      SELECT MOE_STATE INTO ACT_STATE
        FROM T_MOEDA 
        WHERE MOE_ID = ID_MOE;
      
      IF ACT_STATE = 0 THEN RETURN 'Desativado!';
      ELSE RETURN 'Activado';
      END IF;
    END; 
    
    
        
    PROCEDURE PRC_REG_OBJECTYPE (
        ID_USER  NUMBER ,
        ID_SUPER NUMBER ,
        DESC_OBJT VARCHAR,
        ID_TYPE NUMBER
    )
    IS
        TYPE ListObject IS TABLE OF T_OBJECTYPE%ROWTYPE;
        listValues ListObject := ListObject();
    BEGIN
      -- Carregar caso exista o obecto a lista dos objecto
      SELECT * BULK COLLECT INTO listValues
         FROM T_OBJECTYPE O
         WHERE UPPER(O.OBJT_DESC) = UPPER(DESC_OBJT)
            AND O.OBJT_T_ID = ID_TYPE;
      
      IF listValues.COUNT = 0
         OR (listValues(1).OBJT_T_ID IS NOT NULL 
                AND ID_TYPE IS NOT NULL 
                AND listValues(1).OBJT_T_ID != ID_TYPE) 
         THEN 
           INSERT INTO T_OBJECTYPE (OBJT_USER_ID,
                                OBJT_OBJT_ID,
                                OBJT_DESC,
                                OBJT_T_ID)
                                 VALUES(ID_USER ,
                                        ID_SUPER ,
                                        DESC_OBJT,
                                        ID_TYPE );
      ELSE 
         -- Atualizar as infoamacoes do antigo objecto
         UPDATE T_OBJECTYPE O
            SET O.OBJT_DESC = DESC_OBJT,
                O.OBJT_OBJT_ID = CASE WHEN ID_SUPER IS NULL THEN OBJT_T_ID ELSE ID_SUPER END,
                O.OBJT_STATE = 1
            WHERE O.OBJT_ID = listValues(1).OBJT_ID;
      END IF;
            
      
            
            
            
      
      
                                
    END;
    
    PROCEDURE PRC_DISABLE_OBJECTYPE
    (
        idUser NUMBER,
        idobjtdisable  NUMBER
    )
    IS
    BEGIN
      UPDATE T_OBJECTYPE O
        SET O.OBJT_STATE = 0
        WHERE O.OBJT_ID =  idobjtdisable; 
       
    END;
    
    
    procedure prc_update_informacao (idInformacao NUMBER, idUser NUMBER, idCobertura NUMBER, textInformacao VARCHAR2)
    IS
       linhaInfoaramcao T_INFORMACAO%ROWTYPE;
    BEGIN
       IF idInformacao IS NOT NULL THEN
           -- Pegar todas as infoacoes do contarto
           SELECT * INTO linhaInfoaramcao
              FROM T_INFORMACAO INFO
              WHERE INFO.INFO_ID = idInformacao;
          
          -- Desabilitar a antiga infoamcao
          UPDATE T_INFORMACAO i
              SET I.INFO_STATE = 0
              WHERE I.INFO_ID = idInformacao;
          
           linhaInfoaramcao.INFO_ID := NULL;
           linhaInfoaramcao.INFO_INFORMACAO := textInformacao;
           
           INSERT INTO T_INFORMACAO  VALUES linhaInfoaramcao;
       ELSE 
          INSERT INTO T_INFORMACAO (INFO_USER_ID, 
                                    INFO_COBRE_ID,
                                    INFO_INFORMACAO)
                                    VALUES (idUser,
                                            idCobertura,
                                            textInformacao);
          
       END IF;
    END;
    
    procedure prc_disableEnpresa (idUser NUMBER, idEmpresa NUMBER)
    IS
    BEGIN
       UPDATE T_EMPRESA E
          SET E.EMP_STATE = 0
          WHERE E.EMP_ID =idEmpresa;
    END;
    
    
    
    
    
    
    
      
    Function FUNC_ALTERAPRECARIO( precsegid number,
                                  precuserid number,
                                  precdiamini number,
                                  precdiamax number,
                                  total float,
                                  precpremiAlterar float
                                ) Return VARCHAR2
                                
    IS
     TT NUMBER;
     ttInicio NUMBER;
     ttFim NUMBER;
    
    BEGIN
    
       -- Desativar o que for encontrado nesse dia inicio e nesse dia fi
       UPDATE T_PRECARIO P
          SET P.PREC_STATE = 0
          WHERE 
            P.PREC_SEG_ID = precsegid 
            and P.PREC_DIAMIN = precdiamini
            and P.PREC_DIAMAX = precdiamax
            AND P.PREC_STATE = 1;
    
        -- Virificar se o dia inici entra em conflito com algum interalo ja definido
        SELECT COUNT(*) INTO ttInicio
           FROM T_PRECARIO p
           WHERE precdiamini BETWEEN p.PREC_DIAMIN AND p.PREC_DIAMAX
              AND p.PREC_STATE = 1
              AND p.PREC_SEG_ID = precsegid;
           
        -- Verificar se o dia fim entra em conflito com algum intervalo ja definido
        SELECT COUNT(*) INTO ttFim
           FROM T_PRECARIO p
           WHERE precdiamax BETWEEN p.PREC_DIAMIN AND p.PREC_DIAMAX
              AND p.PREC_STATE = 1
              AND p.PREC_SEG_ID = precsegid;
           
        IF ttInicio != 0 THEN 
           RETURN FUNC_ERROR('CONFLIT DIA MIN');
        ELSIF ttFim != 0 THEN
           RETURN FUNC_ERROR('CONFLIT DIA MAX');
        END IF;
                
        INSERT INTO T_PRECARIO (PREC_SEG_ID,
                                PREC_USER_ID,
                                PREC_DIAMIN,
                                PREC_DIAMAX,
                                PREC_TOTAL,
                                PREC_PREMINOOBJ)
                                VALUES( precsegid ,
                                        precuserid ,
                                        precdiamini,
                                        precdiamax,
                                        total,
                                        precpremiAlterar);
        RETURN 'true';
    END;
    
    
    FUNCTION FUNC_SET_TAXA (nomeMoedaBase CHARACTER VARYING, moneyName VARCHAR2, idUser NUMBER, valorCompra FLOAT, valorVenda FLOAT) RETURN VARCHAR2
    IS
       countMoedas NUMBER := 0;
    BEGIN
       -- Verificar todas as moedas desse nome que estao activas
       FOR M IN (SELECT *
                    FROM T_MOEDA M
                    WHERE UPPER(moneyName) = UPPER(M.MOE_NOME)
                    AND M.MOE_STATE = 1)
       LOOP
         FOR BASE IN (SELECT *
                        FROM T_MOEDA M
                        WHERE UPPER(nomeMoedaBase) = UPPER(M.MOE_NOME)
                        AND M.MOE_STATE = 1)
         LOOP
              -- Desativar as antigas taxas da moeda
              -- em relacao a moeda base
              UPDATE T_TAXA TAX
                 SET TAX.TX_STATE = 0,
                     TAX.TX_DTFIM = SYSTIMESTAMP
                 WHERE TAX.TX_MOE_ID = M.MOE_ID
                    AND TAX.TX_MOE_BASE = BASE.MOE_ID;
                 
              --Criar  as novas taxas para essas moedas
              INSERT INTO T_TAXA (TX_MOE_ID,
                                  TX_COMPRA,
                                  TX_VENDA,
                                  TX_USER_ID,
                                  TX_MOE_BASE)
                                  VALUES(M.MOE_ID,
                                         valorCompra,
                                         valorVenda,
                                         idUser,
                                         BASE.MOE_ID);
              countMoedas := countMoedas + 1;
          END LOOP;
             
       END LOOP;
       
       RETURN 'true;'||countMoedas;
    END;
    

    
END PACK_UTIL;