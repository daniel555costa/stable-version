create FUNCTION "FUNC_CTTINF_RESPONSAPUBLICA" 
(
    idUser NUMBER,
    idContrato NUMBER,
    
    SALARIO_DET_COLABORADORES FLOAT,
   SALARIOA_SUB_EMPRETEIROS FLOAT,
   EDIFICIO_EST_CONSERVACAO NUMBER, -- 1 Bom | 0 - Mau
   listaCobertura TB_ARRAY_STRING
)
RETURN VARCHAR2
IS
    -- Criar a instacia de um bjecto CTT_RESPONSABILIDADE
   arraySplit TB_ARRAY_STRING;
   idCobertura NUMBER;
   taxa FLOAT;
   valor FLOAT;
   premio FLOAT;
   detalhes VARCHAR(500);
   message VARCHAR2(4000);
   parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
BEGIN
                               
    PRC_ADD_LISTVALUE(parsValues, null, 'salarioColaboradores', SALARIO_DET_COLABORADORES);
    PRC_ADD_LISTVALUE(parsValues, null, 'salarioSubEmpreteiros', SALARIOA_SUB_EMPRETEIROS);
    PRC_ADD_LISTVALUE(parsValues, null, 'estadoConservacaoEdificio', EDIFICIO_EST_CONSERVACAO);
    
    -- Essa funcao serve para criar um objecto do tipo ctt_responsabilidade publica e armazenala na entidade contrato
    
    PACK_REGRAS.REGOBJECTVALUES(idUser, null, idContrato, 14, parsValues);

    RETURN 'true';
END;