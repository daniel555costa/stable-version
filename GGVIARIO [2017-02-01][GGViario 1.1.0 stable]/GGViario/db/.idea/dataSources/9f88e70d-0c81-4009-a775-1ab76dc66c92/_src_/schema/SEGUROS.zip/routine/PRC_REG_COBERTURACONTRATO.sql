create PROCEDURE PRC_REG_COBERTURACONTRATO 
(
    idCobertura NUMBER,
    idContrato NUMBER,
    idUser NUMBER,
    valor FLOAT,
    taxa FLOAT,
    premio FLOAT
)IS
BEGIN
   INSERT INTO T_COBERTURASEGURADO(COBREASE_COBRE_ID,
                                    COBREASE_CTT_ID,
                                    COBREASE_USER_ID,
                                    COBREASE_VALOR,
                                    COBREASE_TAXA,
                                    COBREASE_PREMIO)
                                    VALUES (idCobertura,
                                            idContrato,
                                            idUser,
                                            valor,
                                            taxa, 
                                            premio);
END;