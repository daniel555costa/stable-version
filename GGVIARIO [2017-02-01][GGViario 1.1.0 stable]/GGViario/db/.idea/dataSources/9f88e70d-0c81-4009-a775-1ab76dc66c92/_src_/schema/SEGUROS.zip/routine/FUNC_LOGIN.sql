create FUNCTION "FUNC_LOGIN" 
(
    nomeAcesso VARCHAR2,
    PWD VARCHAR2
)
RETURN TP_USER
IS
    RES TP_USER;
    KK INTEGER := 1;
BEGIN
    -- (NOME VARCHAR2(50), NIF VARCHAR2(9), ACCESSNAME VARCHAR(30), STATE NUMBER, PHOTO BLOB);
    FOR FU IN (SELECT * 
                  FROM VER_USER FU 
                  WHERE FU.ACCESSNAME = nomeAcesso 
                    AND (PWD = (SELECT F.FUNC_PWD 
                                  FROM T_FUNCIONARIO F 
                                  WHERE F.FUNC_ID = FU.ID_USER)))
    LOOP
        INSERT INTO T_LOGIN (LOG_USER_ID) VALUES(FU.ID_USER);
        
        RES := NEW TP_USER(FU.ID_USER,
                            FU.NOME,
                            FU.NIF,
                            FU.ACCESSNAME,
                            FU.STATE,
                            FU.PHOTO);
        -- RES(1) := FU;
    END LOOP;
    
    RETURN RES;
END;