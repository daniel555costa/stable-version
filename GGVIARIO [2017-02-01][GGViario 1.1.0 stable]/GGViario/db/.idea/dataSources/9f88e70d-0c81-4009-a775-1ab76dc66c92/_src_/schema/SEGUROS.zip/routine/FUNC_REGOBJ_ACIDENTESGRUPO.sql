create FUNCTION "FUNC_REGOBJ_ACIDENTESGRUPO" 
(
    USER_ID NUMBER,
    ID_CONTRATO NUMBER,
    NOME VARCHAR2,
    CATEGORIA VARCHAR2,
    PROFISSAO VARCHAR2,
    DATANASCIMENTO DATE,
    
    --<cuber turas>
    MORTE FLOAT,
    MORTE_TAXA FLOAT,
    DESPESA_MEDICA FLOAT,
    DESPESA_MEDICA_TAXA FLOAT,
    INCAPACIDADE_TOTAL_TEMPORARIA FLOAT,
    INCAPACIDADE_TEMPORARIA_TAXA FLOAT,
    INCAPACIDADE_TOTAL FLOAT, -- permanente
    INCAPACIDADE_TOTAL_TAXA FLOAT, -- permanete
    --<\Cuberturas>
    
    --<informacao>
    DEFEITO_FISICO_MENTAIS VARCHAR,
    ACIDENTES_3ANOS VARCHAR2,
    --<\ionforamcao>
    
    -- <Cuberturas>
    CUSTO_COM_REPATRIAMENTO FLOAT,
    CUSTO_REPRATIAMENTO_TAXA FLOAT
    --<\Cuberturas>
  )


RETURN VARCHAR2
IS 
    res PACK_TYPE.Resultado;
    valor FLOAT;
    taxa FLOAT;
    idAssegurado NUMBER;
    parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
    partes TB_ARRAY_STRING;
BEGIN

    
    
    -- REGISTRAR O OBJECTO
    res := PACK_REGRAS.REG_OBJECTO(USER_ID,  ID_CONTRATO, 41, 1);
    partes := PACK_LIB.SPLITALL(res.message, ';');
    IF partes(1) != 'true' THEN RETURN 'false;O objecto não foi registrado'; END IF;
    
    -- Mapiar os atributos do segurado
    PRC_ADD_LISTVALUE(parsValues, null, 'nome', NOME);
    PRC_ADD_LISTVALUE(parsValues, null, 'categoria', CATEGORIA);
    PRC_ADD_LISTVALUE(parsValues, null, 'profissao', profissao);
    PRC_ADD_LISTVALUE(parsValues, null, 'dataNascimento', PACK_LIB.CHARVALUE(dataNascimento));
    IF DEFEITO_FISICO_MENTAIS IS NOT NULL THEN
       PRC_ADD_LISTVALUE(parsValues, null, 'defeitosFisicosMentais', DEFEITO_FISICO_MENTAIS);
    END IF;
    
    IF ACIDENTES_3ANOS IS NOT NULL THEN
       PRC_ADD_LISTVALUE(parsValues, null, 'acidente3Anos', ACIDENTES_3ANOS);
    END IF;
    
    --Registrar os atributos do segurado
    PACK_REGRAS.REGOBJECTVALUES(USER_ID, res.resultado, null, 5, parsValues);
    
    idAssegurado := partes(2);
    -- Registrar as cuberturas para o segurado de acidente grupo
    FOR I IN(SELECT *
                FROM T_COBERTURA CB
                  WHERE CB.COBRE_SEG_ID = 1 -- Seguro de GPA
                    AND CB.COBRE_NCOBRE_ID = 2 -- Nivel de cubertura opcional
                    AND CB.COBRE_STATE = 1) LOOP -- Que estiverem activa
        valor := null;
        
        IF (I.COBRE_ID = 23 AND MORTE IS NOT NULL) THEN -- Quando for morte 
          valor := MORTE;
          taxa := MORTE_TAXA;
          
        ELSIF (I.COBRE_ID = 24 AND DESPESA_MEDICA IS NOT NULL) THEN -- O quando for Despesa medica
          valor := DESPESA_MEDICA;
          taxa := DESPESA_MEDICA_TAXA;
          
        ELSIF (I.COBRE_ID = 25 AND INCAPACIDADE_TOTAL_TEMPORARIA IS NOT NULL) THEN -- Ou quando for Incapacidade total temporaria
          valor := INCAPACIDADE_TOTAL_TEMPORARIA;
          taxa := INCAPACIDADE_TEMPORARIA_TAXA;
          
        ELSIF (I.COBRE_ID = 26 AND INCAPACIDADE_TOTAL IS NOT NULL) THEN -- Incapacidade total
          valor := INCAPACIDADE_TOTAL;
          taxa := INCAPACIDADE_TOTAL_TAXA;
          
        ELSIF (I.COBRE_ID = 27 AND CUSTO_COM_REPATRIAMENTO IS NOT NULL) THEN -- Custo com repatreamento
          valor := CUSTO_COM_REPATRIAMENTO;
          taxa := CUSTO_REPRATIAMENTO_TAXA;
        END IF;
      
        -- Quando o valor nao for nulo siguinifica que a cobertura foi aceite e que deve ser acessiado a esse asegurado
        IF valor IS NOT NULL THEN
            -- Associar esse segurada a cubertura disponivel
            INSERT INTO T_COBERTURASEGURADO (COBREASE_COBRE_ID,
                                              COBREASE_ASE_ID,
                                              COBREASE_USER_ID,
                                              COBREASE_VALOR,
                                              COBREASE_TAXA)
                                              VALUES(I.COBRE_ID,
                                                     idAssegurado,
                                                     USER_ID,
                                                     valor,
                                                     taxa);
        END IF;
      
    END LOOP;
    RETURN res.message;
END;