create FUNCTION FUNC_REG_PRESTACAO (CONTRATO_ID NUMBER,
                                             USER_ID NUMBER,
                                             VALOR FLOAT,
                                              DATAPRAZO DATE
 )                                                 
RETURN VARCHAR2
IS
BEGIN
  INSERT INTO T_PRESTACAO(PREST_CTT_ID,
                          PREST_USER_ID,
                          PREST_VALOR,
                          PREST_DTPRAZO)
                  VALUES(CONTRATO_ID ,
                          USER_ID,
                          VALOR,
                            DATAPRAZO);
                        
  RETURN 'true';
                          
END;