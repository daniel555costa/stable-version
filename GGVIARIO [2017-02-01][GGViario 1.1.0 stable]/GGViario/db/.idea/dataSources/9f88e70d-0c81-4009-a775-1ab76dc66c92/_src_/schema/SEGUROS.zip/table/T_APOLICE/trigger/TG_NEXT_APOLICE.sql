create trigger TG_NEXT_APOLICE
	before insert
	on T_APOLICE
	for each row
begin  
   if inserting then 
      if :NEW."APOLICE_ID" is null then 
         select SEQ_APOLICE.nextval into :NEW."APOLICE_ID" from dual; 
      end if; 
   end if; 
end;
