create view VER_RESPOSTA as
SELECT
        r.RESP_ID AS ID,
        ct.CTT_ID AS CONTRATO, 
        se.SEG_NOME AS SEGURO,
        ct.CTT_NUMAPOLICE AS APOLICE,
        p.PER_ID AS "ID PERGUNTA",
        p.PER_QUESTAO AS "QUESTAO", 
        ( 
            CASE /* 1 | 2 | 3 | 4 | 5 | 6 | -- Iniciar a validacao da resposta
                  ======== TIPOS DE PERGUNTAS =====
                    1	SIM/NAO DESCRICAO
                    2	COMPOSTO -- Algumas respostas podem responder deretamente a esse tipo de pergunta
                    3	SIMPLES
                    4	SIM/NÃO
                    5	NÃO/SIM DESCRIÇÃO
                    6	CHEQUE
                    7	OPC   -- Nenhumha resposta deve responder a essa pergunta e somente uma respona para as perguntas compostas
                    8	CHEQUE DESC
                */
               WHEN tp.ID = 2 THEN -- QUANDO FOR PERGUNTA CONPOSTA BUSCAR A OPCAO SELECIONADA
                    (SELECT p1.PER_QUESTAO FROM T_PERGUNTA p1 WHERE p1.PER_ID||'' = r.RESP_RESPOSTA AND p1.PER_PER_ID = p.PER_ID)
                    
              WHEN (tp.ID = 1 OR tp.ID = 4 OR tp.ID = 5) THEN -- SE FOR ADS PERGUNTAS DO TIPO SIM NAO 
                    CASE WHEN UPPER(r.RESP_RESPOSTA ) = 'Y' THEN 'SIM' -- SE a resposta para as perguntas do tipo sim nao for 1 isso siguinifica que foi um sim || caso contrario siginifica um nao
                    ELSE 'NAO'
                    END
              WHEN tp.ID = 3 THEN -- QUANDO A pergunta for do tipo 3 -- pergunta simples entao apenas mandar apresentar a resposta escrita
                    r.RESP_RESPOSTA
              WHEN ( tp.ID = 6 OR tp.ID = 8) THEN  -- Quando a pergutan for do tipo cheque virifique as sequintes situacoes
                    CASE WHEN r.RESP_RESPOSTA||'' = 1||''  THEN-- Caso a resposta for 1 siguenifica que a caixa foi seliecionada nese caso desa apresentar um Aciete | em outro caso siguinifica que nao foi aceite
                        'ACEITE'
                    ELSE 'REJEITADO'
                    END
                ELSE 'Desconhecida'
              END -- Fim da validacao da resposta
              
        ) AS RESPOSTA,
        
        ( -- Para as descrincoes deve ser analizado os seguintes aspectos
            CASE -- Validar a expecificacao
                WHEN tp.ID = 1 AND UPPER(r.RESP_RESPOSTA) = 'N' THEN -- Quando for SIM/NAO DESCRICAO diguinificaca que se a resposta for nao(N) deve ter numa descrincao
                    CASE WHEN r.RESP_EXPECIFICACAO IS NULL THEN 'Não expecificado'
                    ELSE r.RESP_EXPECIFICACAO
                    END
                WHEN tp.ID = 5 AND UPPER(r.RESP_RESPOSTA) = 'Y' THEN -- Quando for NÃO/SIM DESCRIÇÃO Esse caso e oposto do caso acima isso siguinifica de se for selecionado o opcao sim(Y) entao deve ter uma expecificacao
                    CASE WHEN r.RESP_EXPECIFICACAO IS NULL THEN 'Não expecificado'
                    ELSE r.RESP_EXPECIFICACAO
                    END
                WHEN tp.ID = 8 AND UPPER(r.RESP_RESPOSTA) = '1' THEN -- Quando for CHEQUE DESC Nesse caso se for aceite(1) o cheque entao tera que ter uma expecificacao
                    CASE WHEN r.RESP_EXPECIFICACAO IS NULL THEN 'Não expecificado'
                    ELSE r.RESP_EXPECIFICACAO
                    END
                ELSE 'NAO NESSECERIA' -- Em outros caso siguinefica que nao e nessecario nenhuma especificacao
            END -- Fim de validacao da expecificacao
        ) AS EXPECIFICACAO,
        
        PACK_LIB.STATE('RESP', r.RESP_STATE) AS ESTADO,
        PACK_LIB.asDDMMYYYY(r.RESP_DTREG) AS REGISTRO
    FROM T_RESPOSTA r
        INNER JOIN T_PERGUNTA p ON r.RESP_PER_ID = p.PER_ID
        INNER JOIN VER_TIPOPERGUNTA tp ON p.PER_TPER_ID = tp.REALID
        INNER JOIN T_CONTRATO ct ON r.RESP_CTT_ID = ct.CTT_ID
        INNER JOIN T_SEGURO se ON (se.SEG_ID = p.PER_SEG_ID AND se.SEG_ID = ct.CTT_SEG_ID)
        -- Numca deve haver nenhuma  resposta para as perguntas do tipo 7
    WHERE tp.ID != 7
