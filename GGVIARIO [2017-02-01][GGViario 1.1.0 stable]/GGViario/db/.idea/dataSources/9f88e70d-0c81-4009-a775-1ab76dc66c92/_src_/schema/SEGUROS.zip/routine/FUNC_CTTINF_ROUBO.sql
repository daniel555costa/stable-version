create FUNCTION  FUNC_CTTINF_ROUBO 
(
    ID_USER NUMBER,
    ID_CONTRATO NUMBER,
    EDIFICIO_TIPO VARCHAR2, -- {VER_TIPOEDIFICIO}
    EDIFICIO_ENDERECO VARCHAR2,
    EDIFICIO_TEMPOCUPACAO VARCHAR2,
    EDIFICIO_DATAOCUPACAO VARCHAR2,
    CROFE_VALOR FLOAT,
    CROFE_MARCA VARCHAR2,
    CROFE_DATAQUISICAO DATE
)RETURN VARCHAR2
IS
    idTipoEdificio NUMBER;
    descriTipoVeiculo VARCHAR2(100);
    splitTable TB_ARRAY_STRING := PACK_LIB.SPLITALL(EDIFICIO_TIPO, ';');
    parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES(); 
BEGIN
    idTipoEdificio := splitTable(1);
    descriTipoVeiculo := splitTable(2);
    
    PRC_ADD_LISTVALUE(parsValues, null, 'tipoEdificio', idTipoEdificio);
    PRC_ADD_LISTVALUE(parsValues, null, 'descricaoTipoVeiculo', descriTipoVeiculo);
    PRC_ADD_LISTVALUE(parsValues, null, 'enderecoEdificio', EDIFICIO_ENDERECO);
    PRC_ADD_LISTVALUE(parsValues, null, 'tempoOcupacao', EDIFICIO_TEMPOCUPACAO);
    PRC_ADD_LISTVALUE(parsValues, null, 'dataExpiracao', EDIFICIO_DATAOCUPACAO);
    PRC_ADD_LISTVALUE(parsValues, null, 'valorCrofe', CROFE_VALOR);
    PRC_ADD_LISTVALUE(parsValues, null, 'marcaCrofe', CROFE_MARCA);
    PRC_ADD_LISTVALUE(parsValues, null, 'dataAquisicaoCrofe', PACK_LIB.CHARVALUE(CROFE_DATAQUISICAO));
    
    PACK_REGRAS.REGOBJECTVALUES(ID_USER, null, ID_CONTRATO, 16, parsValues);
   
   RETURN 'true';
END FUNC_CTTINF_ROUBO;