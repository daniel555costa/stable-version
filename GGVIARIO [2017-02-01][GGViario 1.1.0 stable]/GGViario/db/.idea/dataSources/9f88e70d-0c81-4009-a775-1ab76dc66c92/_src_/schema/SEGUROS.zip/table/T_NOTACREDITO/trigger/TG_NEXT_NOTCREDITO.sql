create trigger TG_NEXT_NOTCREDITO
	before insert
	on T_NOTACREDITO
	for each row
begin  
   if inserting then 
      if :NEW."NCRED_ID" is null then 
         select SEQ_NOTCREDITO.nextval into :NEW."NCRED_ID" from dual; 
      end if; 
   end if; 
end;

