create PACKAGE PACK_PESQUISA is
  
  
  FUNCTION pesqClienteCampo(CAMPO VARCHAR, VALOR VARCHAR) return PACK_TYPE.filterCliente PIPELINED;
  
  FUNCTION pesqContrato return PACK_TYPE.filterContrato PIPELINED;
  
  FUNCTION pesqContratoSeguro(codSeguro VARCHAR2) RETURN PACK_TYPE.filterContrato PIPELINED;
  
  FUNCTION pesqContrato(tipo VARCHAR2, CAMPO VARCHAR,VALOR VARCHAR) return PACK_TYPE.filterContrato PIPELINED;
  
  FUNCTION pesqContratoGold (quantidade NUMBER)  RETURN PACK_TYPE.filterContrato PIPELINED;
  
  
  -- tipos{GOLD, MCARO, ATRASADO, TPAGOS}
  FUNCTION pesqContratoType(typePesquisa CHARACTER VARYING)  RETURN PACK_TYPE.filterContrato PIPELINED;
  
  -- pesquisar todos os contratos que um cliente tem
  FUNCTION pesqContratoCliente (idCliente NUMBER) RETURN PACK_TYPE.filterContratoCliente PIPELINED;
  
  -- Pesquisar todos os contratos que um cliente tem em um dado seguro
  FUNCTION pesqContratoClineteSeguro(idCliente NUMBER, idSeguro NUMBER) RETURN PACK_TYPE.filterContratoCliente PIPELINED;
  
  
  -- Carregara o estado do cliente dependendo do seguro
  FUNCTION pesqStateClienteSeguro (ID_CLIENTE NUMBER, ID_SEGURO NUMBER) RETURN PACK_TYPE.InformacaoUtilCliente PIPELINED;
  
  
  -- Carregar os clientes que tem um dado tipo de seguro
  FUNCTION pesqClienteBySeguro (ID_SEGURO NUMBER) RETURN PACK_TYPE.filterCliente PIPELINED;
  
  -- Proucurar os clientes a partir de um atributo
  FUNCTION pesqClienteByColumn (columnName VARCHAR2, columnValues VARCHAR2) RETURN PACK_TYPE.filterCliente PIPELINED;
  
  
  FUNCTION loadModelo (nomeMarca VARCHAR2) RETURN PACK_TYPE.filterModelo PIPELINED;
  

  FUNCTION getFrequenteSeguroCliente(idCliente NUMBER) RETURN VARCHAR2;
  -- pesquisar informacoes do contrato
  FUNCTION pesqcontratoinformacao (IDCTT NUMBER) RETURN PACK_TYPE.filtercontratoinformacao PIPELINED;
  
  --========================= FUNÇÕES PARA CARREGAR RELATORIO ============================--- 
  
  FUNCTION reportClient (dataInicio DATE, dataFim DATE) RETURN PACK_TYPE.filterReportClient PIPELINED;
  
  FUNCTION functLoadAtributoSegurado(idClassType NUMBER, atributeNameRequest CHARACTER VARYING) RETURN TB_ARRAY_STRING PIPELINED;
  
  
  TYPE ItemPar IS RECORD ("KEY" CHARACTER VARYING(100), "VALUE" CHARACTER VARYING(4000), "ID VALUE" CHARACTER VARYING(1000));
  TYPE HasMap IS TABLE OF ItemPar;
  FUNCTION functLoadObjectByAttribute (idClassObject NUMBER, attributeName VARCHAR2, valueObject VARCHAR2) RETURN PACK_PESQUISA.HasMap PIPELINED;

end;