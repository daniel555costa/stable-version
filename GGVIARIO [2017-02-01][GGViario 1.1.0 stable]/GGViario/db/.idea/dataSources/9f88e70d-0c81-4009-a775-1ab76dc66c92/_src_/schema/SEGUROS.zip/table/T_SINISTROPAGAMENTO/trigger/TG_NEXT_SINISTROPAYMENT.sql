create trigger TG_NEXT_SINISTROPAYMENT
	before insert
	on T_SINISTROPAGAMENTO
	for each row
begin  
   if inserting then 
      if :NEW."SINPAY_ID" is null then 
         select SEQ_SINISTROPAYMENT.nextval into :NEW."SINPAY_ID" from dual; 
      end if; 
   end if; 
end;
