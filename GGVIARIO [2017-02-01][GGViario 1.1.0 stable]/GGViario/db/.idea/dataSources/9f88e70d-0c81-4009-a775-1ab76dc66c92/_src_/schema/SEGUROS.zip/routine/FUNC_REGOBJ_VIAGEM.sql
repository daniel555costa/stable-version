create FUNCTION "FUNC_REGOBJ_VIAGEM" 
(
  idUser number,
  idContrato VARCHAR2,
  nomePassageiro VARCHAR2,
  idTipoDocumento NUMBER, -- O tipo do documento utilizado <Deve Referenciar ao Objetype {Tipo documento}>
  numeroDocumento VARCHAR2, -- O Numero do documento utilizado
  dataNascimento DATE, --  A data do nascimento
  dataEmissao DATE, -- A data de imicao
  localEmisao VARCHAR2, -- O
  
  localNascimento VARCHAR2, 
  localResidencia VARCHAR2,
  idGenero NUMBER,-- O genero do segurado
  telefone VARCHAR2,
  outrasInformacoes VARCHAR2,
  apolice CHARACTER VARYING,
  zonaDestino CHARACTER VARYING,
  cidadeDestino CHARACTER VARYING,
  objectivoViagem CHARACTER VARYING,
  paisDestino CHARACTER VARYING,
  dataInicio DATE,
  dataFim DATE,
  nacionalidade NUMBER,
  idTaxaNc NUMBER,
  tipoViagem NUMBER
  
  )  RETURN VARCHAR2
IS
    idLocalEmisao NUMBER := PACK_REGRAS.GET_RESIDENCE(localEmisao, idUser);
    idLocalNascimento NUMBER := PACK_REGRAS.GET_RESIDENCE(localNascimento, idUser);
    idLocalResidencia NUMBER := PACK_REGRAS.GET_RESIDENCE(localResidencia, idUser);
    res PACK_TYPE.Resultado;
    --CRIANDO UMA INSTANCIA PARA VIAGEM

                                                      
     parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
     objPassageiro PACK_TYPE.mapaValues;
     linhaTaxaAplicar VER_TAXAS_IMPOSTAS%ROWTYPE;
     netOutFax FLOAT := 0;
     niconComisao FLOAT;
     premio FLOAT;
     impostoConsumo FLOAT;
     impostoSelo FLOAT;
     numDias FLOAT;
     totalPremio FLOAT;
     tt NUMBER;
     array TB_ARRAY_STRING;
     idSegurado FLOAT;
BEGIN
    
    
    -- Com o imposto patra a viagem
    SELECT *
          INTO linhaTaxaAplicar
       FROM TABLE(FUNCT_GET_VALORESEGURADO(dataInicio, dataFim, tipoViagem)) TIM
       WHERE TIM.FGA IS NULL;
        
    niconComisao := linhaTaxaAplicar.NC;
    premio := linhaTaxaAplicar.SUBTOTAL;
    impostoConsumo := linhaTaxaAplicar.CONSUMO;
    impostoSelo :=  linhaTaxaAplicar.SELO;
    numDias := linhaTaxaAplicar.DIAS;
    
    PRC_ADD_LISTVALUE(parsValues, null, 'nomePessoaSegurada', nomePassageiro);
    PRC_ADD_LISTVALUE(parsValues, null, 'tipoDoc', idTipoDocumento);
    PRC_ADD_LISTVALUE(parsValues, null, 'numDoc', numeroDocumento);
    PRC_ADD_LISTVALUE(parsValues, null, 'dataNasc', PACK_LIB.CHARVALUE(dataNascimento) );
    PRC_ADD_LISTVALUE(parsValues, null, 'dataEmissao', PACK_LIB.CHARVALUE(dataEmissao));
    PRC_ADD_LISTVALUE(parsValues, null, 'localNascimento', idLocalNascimento);
    PRC_ADD_LISTVALUE(parsValues, null, 'localEmisao', idLocalEmisao);
    PRC_ADD_LISTVALUE(parsValues, null, 'endereco', idLocalResidencia);
    PRC_ADD_LISTVALUE(parsValues, null, 'sexo', idGenero);
    PRC_ADD_LISTVALUE(parsValues, null, 'telefone', telefone);
    PRC_ADD_LISTVALUE(parsValues, null, 'outrasInformacao', outrasInformacoes);
    PRC_ADD_LISTVALUE(parsValues, null, 'numApolice', apolice);
    PRC_ADD_LISTVALUE(parsValues, null, 'zonaDestino', zonaDestino);
    PRC_ADD_LISTVALUE(parsValues, null, 'cidadeDestino', cidadeDestino);
    PRC_ADD_LISTVALUE(parsValues, null, 'objetivoViagem', objectivoViagem);
    PRC_ADD_LISTVALUE(parsValues, null, 'paisDestino', paisDestino);
    PRC_ADD_LISTVALUE(parsValues, null, 'dataInicio', PACK_LIB.CHARVALUE(dataInicio));
    PRC_ADD_LISTVALUE(parsValues, null, 'dataFim', PACK_LIB.CHARVALUE(dataFim));
    PRC_ADD_LISTVALUE(parsValues, null, 'nacionalidade', nacionalidade);
    PRC_ADD_LISTVALUE(parsValues, null, 'idTaxaNc', idTaxaNc);
    
    -- 1 Viagem Simples | 2 Mult-Viagem
    PRC_ADD_LISTVALUE(parsValues, null, 'tipoViagem', tipoViagem);
    
    PRC_ADD_LISTVALUE(parsValues, null, 'numDias', numDias );
    PRC_ADD_LISTVALUE(parsValues, null, 'impostoConsumo', impostoConsumo);
    PRC_ADD_LISTVALUE(parsValues, null, 'niconComisao', niconComisao);
    PRC_ADD_LISTVALUE(parsValues, null, 'premio', premio);
    PRC_ADD_LISTVALUE(parsValues, null, 'impostoSelo', impostoSelo);
    -- PRC_ADD_LISTVALUE(parsValues, null, 'netOutFax', netOutFax);
    PRC_ADD_LISTVALUE(parsValues, null, 'totalPremio', totalPremio);
    PRC_ADD_LISTVALUE(parsValues, null, 'idTaxaViagem', linhaTaxaAplicar.ID);
    
    res :=  PACK_REGRAS.REG_OBJECTO(idUser, idContrato, 119, 1);
    array := PACK_LIB.SPLITALL(res.message, ';');
    
    IF array(1) = 'true' THEN
    
        -- Criara os valores do objecto
        PACK_REGRAS.REGOBJECTVALUES(idUser, res.resultado, null , 3, parsValues);
        idSegurado := array(2);
        
    END IF;
    RETURN res.message;
END;