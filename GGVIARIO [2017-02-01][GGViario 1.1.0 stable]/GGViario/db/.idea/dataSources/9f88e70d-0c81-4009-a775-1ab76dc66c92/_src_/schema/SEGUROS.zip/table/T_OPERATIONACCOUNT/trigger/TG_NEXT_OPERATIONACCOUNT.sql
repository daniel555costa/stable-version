create trigger TG_NEXT_OPERATIONACCOUNT
	before insert
	on T_OPERATIONACCOUNT
	for each row
begin  
   if inserting then 
      if :NEW."OPRCOUNT_ID" is null then 
         select SEQ_OPERATIONACCOUNT.nextval into :NEW."OPRCOUNT_ID" from dual; 
      end if; 
   end if; 
end;

