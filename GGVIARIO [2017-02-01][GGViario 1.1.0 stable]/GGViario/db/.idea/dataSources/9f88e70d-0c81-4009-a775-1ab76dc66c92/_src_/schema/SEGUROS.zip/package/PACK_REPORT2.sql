create PACKAGE PACK_REPORT2 IS

   
    FUNCTION FUNCT_REPORT_SINISTRO(dateInicio DATE, dateFim date) RETURN PACK_TYPE.filterReportSinistro PIPELINED;
    
    
    FUNCTION FUNCT_REPORT_PROVISAO (dataInicio DATE, dateFim date, idSeguro NUMBER) RETURN PACK_TYPE.filterReportProvisao PIPELINED;
    
    
    FUNCTION reportMovimentacaoConsumivel(dataInicio DATE, dataFim DATE) RETURN PACK_TYPE.filterMovimentacaoConsumivel PIPELINED;

    FUNCTION reportFuncionario RETURN PACK_TYPE.filterReportFuncionario PIPELINED;
    
    FUNCTION reportBalancete (dateInicio DATE, dateFim DATE) RETURN pack_type.filterBalancete PIPELINED;
    
    FUNCTION reportSalario (idProcess NUMBER) RETURN PACK_TYPE.FilterReportSalario PIPELINED;
    
    FUNCTION reportSalarioTaxa(dataProcess DATE) RETURN PACK_TYPE.FilterReportSalarioTaxa PIPELINED;

END;