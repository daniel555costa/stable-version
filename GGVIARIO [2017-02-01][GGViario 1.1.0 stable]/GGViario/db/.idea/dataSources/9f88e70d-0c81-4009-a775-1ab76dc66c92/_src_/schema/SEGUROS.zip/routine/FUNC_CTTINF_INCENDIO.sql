create FUNCTION FUNC_CTTINF_INCENDIO 
(
    idUser NUMBER,
    idContrato NUMBER,
    CONDICAO VARCHAR2,
    FONTE_AGUA_DISPONIVEL VARCHAR2,
    EQUI_COMBATE_INCENDIO VARCHAR2,
    ENDERECO_EDIFICIO VARCHAR, -- Endereco completo do edificio
    
    NUMERO_ANDARES NUMBER,
    ANO NUMBER,
    DISTANCIA_COM_BOMBEIRO VARCHAR2,
    
    usoEdificio NUMBER,  --uso {VER_USO_EDIFICIO}
    usoDescrincao VARCHAR2,
    processoFabricacao VARCHAR2, -- {NULL - nao checado | descrincoa caso checado
    
    listaAtributos TB_ARRAY_STRING -- {1 -Baro | 2 - Mármore | 3 - Azuleijo | 4 - Cerramica  | 5- Betão}	
    -- TETOS TB_ARRAY_STRING,  -- { 1- Telha | 2 - chapa Zinco | 3 - chapa fibrocimento | 4 - Placa betão}
    -- PAREDE TB_ARRAY_STRING, -- {1 - Tijolo | 2 - Betao}
    
    -- COBERTURAS TB_ARRAY_STRING -- A lista das cuberturas selecionadas ID; VALOR; TAXA; PREMIO
)RETURN VARCHAR2
IS
   idResidenciaEdificio NUMBER := PACK_REGRAS.GET_RESIDENCE(ENDERECO_EDIFICIO,IDUSER);
   resp VARCHAR2(100);
   
  arraySplit TB_ARRAY_STRING;
  parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
BEGIN
                               
    PRC_ADD_LISTVALUE(parsValues, null, 'condicao', CONDICAO);
    PRC_ADD_LISTVALUE(parsValues, null, 'fonteAguaDisponivel', FONTE_AGUA_DISPONIVEL);
    PRC_ADD_LISTVALUE(parsValues, null, 'equipaCombateIncendio', EQUI_COMBATE_INCENDIO);
    PRC_ADD_LISTVALUE(parsValues, null, 'numeroAndares', NUMERO_ANDARES );
    PRC_ADD_LISTVALUE(parsValues, null, 'ano', ANO);
    PRC_ADD_LISTVALUE(parsValues, null, 'distanciaComBombeiro', DISTANCIA_COM_BOMBEIRO);
    PRC_ADD_LISTVALUE(parsValues, null, 'usoEdificio', usoEdificio);
    PRC_ADD_LISTVALUE(parsValues, null, 'descricaoUsoEdificio', usoDescrincao);
    PRC_ADD_LISTVALUE(parsValues, null, 'processoFabricacao', processoFabricacao);
    
    PACK_REGRAS.REGOBJECTVALUES(idUser, null, idContrato, 6, parsValues);
    
    -- For para registas a contrucao da residencia
       -- Parede, Teto e Pavimento
    FOR i IN 1 .. listaAtributos.COUNT LOOP
        arraySplit := PACK_LIB.SPLITALL(listaAtributos(i), ';');
        PRC_REG_RESPOSTA(idUser, idContrato, arraySplit(1), arraySplit(2), NULL);
    END LOOP;
    
    -- Registrar as coberturas do incendio
    -- PACK_REGRAS.ADDCOBERTURACONTRATOASSEGURA(idUser, idContrato, null, coberturas);
  
  RETURN 'true';
END FUNC_CTTINF_INCENDIO;