create PROCEDURE PRC_USER_DESATIVE 
(
    idUserAdm VARCHAR2, -- o nif do adiministrador 
    idUserDesative VARCHAR2, -- O id do utilizador que serra forcado a alterar a palavra pada
    pwdAccess VARCHAR2,
    newState VARCHAR2, -- D - Desativar estado do utilizador | F - forcar alterar senha para ativas, A - Ativar estado do funcionario
    tipoEstado VARCHAR2 -- U - SIGUINIFICA UTILIZADOR , OP SIGUNIFICA OPERARIO (FUNCIONARIO)
)
IS
BEGIN
   IF tipoEstado  = 'U' THEN
     UPDATE T_FUNCIONARIO U
       SET U.FUNC_ACCESS = (CASE 
                               WHEN UPPER(newState) ='D' THEN 0
                               ELSE 2
                            END), 
           U.FUNC_PWD = (CASE WHEN newState = 'F' THEN pwdAccess ELSE U.FUNC_PWD END)
       WHERE U.FUNC_ID = idUserDesative;
    ELSIF tipoEstado = 'OP' THEN
       UPDATE T_FUNCIONARIO U
          SET U.FUNC_STATE  = (CASE 
                               WHEN UPPER(newState) ='A' THEN 1
                               ELSE 0
                            END),
           U.FUNC_ACCESS = 0
       WHERE U.FUNC_ID = idUserDesative;
    END IF;
END;