create view VER_VEICULO as
SELECT 
      OO.OBJECTO_ID AS "ID",
      OO.CONTENT.get('numeroMatricula') AS "MATRICULA",
      OO.CONTENT.get('marca') AS "MARCA",
      OO.CONTENT.get('modelo') AS "MODELO",
      OO.CONTENT.get('numMotor') AS "MOTOR",
      OO.CONTENT.get('chassi') AS "CHASSI",
      OO.CONTENT.get('anoFabrico') AS "ANO FABRICO",
      OO.CONTENT.get('anoCompra') AS "ANO COMPRA",
      OO.CONTENT.get('valorCompra') AS "VALOR COMPRA",
      OO.CONTENT.get('valorAtual') AS "VALOR ATUAL",
      OO.CONTENT.get('capacidade') AS "CAPACIDADE",
      OO.CONTENT.get('certificado') AS " CERTIFICADO"
  FROM MVER_OBJECT_CONTENT OO
  WHERE OO.CLASS_DESC = 'VEICULO'
