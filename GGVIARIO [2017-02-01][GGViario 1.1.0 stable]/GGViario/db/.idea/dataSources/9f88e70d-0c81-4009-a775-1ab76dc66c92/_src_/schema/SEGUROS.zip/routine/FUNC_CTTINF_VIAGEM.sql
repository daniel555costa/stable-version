create FUNCTION "FUNC_CTTINF_VIAGEM" 
(
    userId NUMBER,
    idContrato NUMBER,
    objectivoViagem VARCHAR,
    idPaisDestino NUMBER,
    dataInicio DATE,
    dataFim DATE,
    totalsegurado Number,
    tipoViagem NUMBER
)
RETURN VARCHAR2
IS
    -- niconComisao FLOAT;
    -- premio FLOAT;
    -- numDias NUMBER;
    -- impostoConsumo FLOAT;
    impostoSelo FLOAT;
    netOutFax FLOAT ;
    -- totalPremio FLOAT; -- TOTAL DE PREMIO AS SUM PREMIO DOS SEGURADOS
    -- linhaTaxaAplicar VER_TAXAS_IMPOSTAS%ROWTYPE;
    tt NUMBER;
    parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
    idViagem NUMBER;
BEGIN
    
    
    -- Com o imposto patra a viagem
    /*SELECT *
          INTO linhaTaxaAplicar
       FROM TABLE(FUNCT_GET_VALORESEGURADO(dataInicio, dataFim, tipoViagem)) TIM
       WHERE TIM.FGA IS NULL;
       */
        
    -- niconComisao := linhaTaxaAplicar.NC;
    -- premio := linhaTaxaAplicar.SUBTOTAL;
    -- impostoConsumo := linhaTaxaAplicar.CONSUMO;
    -- impostoSelo :=  linhaTaxaAplicar.SELO;
    -- numDias := linhaTaxaAplicar.DIAS;
    -- totalPremio := totalsegurado * premio;
    netOutFax := 0;
    
    -- criar o pacote da viagem que vai ser registrada
    idViagem := PACK_REGRAS.REGOBJVALL(userId, 'VIAGEM', 'VIAGEM', null, 4, null, idContrato);
  
    PRC_ADD_LISTVALUE(parsValues, idViagem, 'objetivoViagem', objectivoViagem);
    PRC_ADD_LISTVALUE(parsValues, idViagem, 'dataInicio', PACK_LIB.CHARVALUE(dataInicio));
    PRC_ADD_LISTVALUE(parsValues, idViagem, 'dataFim', PACK_LIB.CHARVALUE(dataFim));
    -- PRC_ADD_LISTVALUE(parsValues, idViagem, 'numDias', numDias );
    -- PRC_ADD_LISTVALUE(parsValues, idViagem, 'impostoConsumo', impostoConsumo);
    
    PRC_ADD_LISTVALUE(parsValues, idViagem, 'idPaisDestino', idPaisDestino);
    -- PRC_ADD_LISTVALUE(parsValues, idViagem, 'niconComisao', niconComisao);
    -- -- PRC_ADD_LISTVALUE(parsValues, idViagem, 'premio', premio);
    PRC_ADD_LISTVALUE(parsValues, idViagem, 'impostoSelo', impostoSelo);
    PRC_ADD_LISTVALUE(parsValues, idViagem, 'netOutFax', netOutFax);
    -- PRC_ADD_LISTVALUE(parsValues, idViagem, 'totalPremio', totalPremio);
    PRC_ADD_LISTVALUE(parsValues, idViagem, 'totalsegurado', totalsegurado);
    -- PRC_ADD_LISTVALUE(parsValues, idViagem, 'idTaxaViagem', linhaTaxaAplicar.ID);
    
    -- 1 Viagem Simples | 2 Mult-Viagem
    PRC_ADD_LISTVALUE(parsValues, idViagem, 'tipoViagem', tipoViagem);
    
    PACK_REGRAS.REGOBJECTVALUES(userID, null, idContrato , 4, parsValues);
    
    
      SELECT COUNT(*) INTO tt
      FROM T_COBERTURASEGURADO  CC
      WHERE CC.COBREASE_CTT_ID = idContrato;
    
    -- caso nao tenha registrado nenhuma cobertura para o seguro
    IF tt = 0 THEN 
    
      FOR COB IN (SELECT * 
                  FROM T_COBERTURA COB
                  WHERE COB.COBRE_STATE = 1 -- Quando o contrato seguro estiver activo
                     AND  COB.COBRE_SEG_ID = 3 -- Seguro de viagem
                     AND COB.COBRE_NCOBRE_ID = 1 -- Nivel de cobertura obrigatoria
                     AND COB.COBRE_STATE = 1
                     AND COB.COBRE_AMBITO = 2
                )LOOP
                
         -- Criar as cuberturas para esse segurado   
           -- O premio sera a o SUBTOTAL
           -- O VALOR sera a Comisao de Nico
           -- A taxa sera desconhecida
           
         INSERT INTO T_COBERTURASEGURADO (COBREASE_COBRE_ID,
                                          COBREASE_CTT_ID,
                                          COBREASE_USER_ID,
                                          COBREASE_PREMIO,
                                          COBREASE_VALOR,
                                          COBREASE_TAXA)
                                          VALUES(COB.COBRE_ID,
                                                  idContrato,
                                                  userId,
                                                  null,
                                                  null,
                                                  NULL);
                                                  
      END LOOP;
    END IF;
    RETURN 'true';
END;