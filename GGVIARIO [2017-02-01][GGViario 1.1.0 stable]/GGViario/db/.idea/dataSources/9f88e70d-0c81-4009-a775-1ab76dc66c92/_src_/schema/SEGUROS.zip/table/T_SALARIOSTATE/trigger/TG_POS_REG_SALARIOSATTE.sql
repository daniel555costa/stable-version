create trigger TG_POS_REG_SALARIOSATTE
	after insert
	on T_SALARIOSTATE
	for each row
DECLARE
   stt NUMBER := :NEW.SALSTATE_NEWSTATE;
BEGIN
  
   -- ALTERAR O ESTADO DO PROCESSO
   UPDATE T_PROCESSALARY P
      SET P.PROSAL_STATE = :NEW.SALSTATE_NEWSTATE
      WHERE P.PROSAL_ID = :NEW.SALSTATE_PROSAL_ID;
   
   -- Quando o processamento do salario for anulado Reustaurar os avancos e as comisoes aplicadas aquele 
   IF stt  IN (-1, 0) THEN 
      FOR linhaSalario IN (SELECT *
                              FROM T_SALARIO SAL
                              WHERE SAL.SAL_PROSAL_ID =  :NEW.SALSTATE_PROSAL_ID
                              )
      LOOP
         UPDATE T_COMISAO COM
            SET COM.COMISAO_STATE = (CASE WHEN stt = -1 THEN 1 ELSE 0 END)
            WHERE (COM.COMISAO_ID = linhaSalario.SAL_COMISAO_ID
                      OR COM.COMISAO_COMISAO_ID = linhaSalario.SAL_COMISAO_ID)
                      ;
               
         -- Fechar o avanco salarial do funcionario
         UPDATE T_SALARIOAVANCO SAL
            SET SAL.SALAVANCO_STATE = (CASE WHEN stt = -1 THEN 1 ELSE 0 END)
            WHERE SAL.SALAVANCO_ID = linhaSalario.SAL_AVANCO_ID
               OR SAL.SALAVANCO_SALAVANCO_ID = linhaSalario.SAL_AVANCO_ID
               ;
      END LOOP;
    END IF;
END;
