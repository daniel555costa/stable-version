create FUNCTION "FUNC_REGOBJ_VEICULO" 
(
    USER_ID NUMBER,
    ID_CONTRATO VARCHAR,
    interMATRICULA VARCHAR,
    MARCA VARCHAR2,
    MODELO VARCHAR2,
    NUMERO_MOTOR VARCHAR,
    NUMERO_CHASSI VARCHAR,
    ANO_FABRICO VARCHAR2, -- 9
    ANO_COMPRA VARCHAR2,  -- 10
    CAPACIDADE VARCHAR,  -- 
    VALOR_COMPRA FLOAT,  -- 12
    VALOR_ACTUAL FLOAT,
    ID_COBERTURA Number,
    VALOR_PREMIO FLOAT,
    taxa FLOAT,
    certificado CHARACTER VARYING
)
 
RETURN VARCHAR2
IS 
    res PACK_TYPE.Resultado;
    -- Criando uma instacia de objecto veiculo

  idAssegurado NUMBER;
  tt NUMBER; 
  -- MAcra dos veiculos corresponde ao tipo com id = 1
  -- Modelos dos veiculos corresponde ao tipo com id = 3
  
  idMarca NUMBER := PACK_REGRAS.GETOBJECTID(MARCA, 1, 1, null,  null);
  idModelo NUMBER := PACK_REGRAS.GETOBJECTID(MODELO, 1, 3, MARCA, 1);
  
  parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
  objVeiculo PACK_TYPE.mapaValues;
  existVeuculo NUMBER;
  idVeiculo CHARACTER VARYING(100);
BEGIN   
    SELECT COUNT(*) INTO tt
       FROM TABLE(PACK_PESQUISA.functLoadAtributoSegurado(2, 'numeroMatricula'))
       WHERE COLUMN_VALUE = UPPER(interMATRICULA);
       
    IF tt != 0 THEN
       SELECT TRIM("VALUE") INTO idVeiculo
       FROM TABLE(PACK_PESQUISA.functLoadObjectByAttribute(2, 'numeroMatricula', UPPER(interMATRICULA))) 
       WHERE "KEY" = 'OBJECT.ID'
          AND ROWNUM <= 1;
       objVeiculo('OBJ.*') := idVeiculo;
    END IF;
       
    -- Mapear os atributos todos com a aplicacao
    PRC_ADD_LISTVALUE(parsValues, null, 'numeroMatricula', UPPER(interMATRICULA));
    PRC_ADD_LISTVALUE(parsValues, null, 'marca', idMarca);
    PRC_ADD_LISTVALUE(parsValues, null, 'modelo', idModelo);
    PRC_ADD_LISTVALUE(parsValues, null, 'numMotor', NUMERO_MOTOR );
    PRC_ADD_LISTVALUE(parsValues, null, 'chassi', NUMERO_CHASSI);
    PRC_ADD_LISTVALUE(parsValues, null, 'anoFabrico', ANO_FABRICO);
    PRC_ADD_LISTVALUE(parsValues, null, 'anoCompra', ANO_COMPRA);
    PRC_ADD_LISTVALUE(parsValues, null, 'valorCompra', VALOR_COMPRA);
    PRC_ADD_LISTVALUE(parsValues, null, 'valorAtual', VALOR_ACTUAL);
    PRC_ADD_LISTVALUE(parsValues, null, 'capacidade', CAPACIDADE);
    PRC_ADD_LISTVALUE(parsValues, null, 'certificado', certificado);
    
    
    -- Caso nao exista registro desse veiculo na base de dados então criar o registro do veiculo
    IF tt = 0  THEN
      -- Registrar o veiculo
      res := PACK_REGRAS.REG_OBJECTO(USER_ID, ID_CONTRATO , 22, 0);
      objVeiculo('OBJ.*') := res.resultado;
    ELSE
        -- Remover o veiculo dos contratos anteriores
        UPDATE T_ASSEGURA  ASS
          SET ASS.ASE_STATE = 0,
             ASE_DTFIM = SYSTIMESTAMP
          WHERE ASS.ASE_STATE = 1
              AND ASS.ASE_OBJ_ID = objVeiculo('OBJ.*');
        res.resultado :=  objVeiculo('OBJ.*');
    END IF;
    
    -- Criara os valores do objecto
    PACK_REGRAS.REGOBJECTVALUES(USER_ID, objVeiculo('OBJ.*'), null, 2, parsValues);
    
    
    
    IF ID_CONTRATO IS NOT NULL THEN
        -- Criar a cubertura para o contrato actual  
        INSERT INTO T_ASSEGURA (ASE_CTT_ID, 
                                ASE_OBJ_ID, 
                                ASE_USER_ID)
                                VALUES(ID_CONTRATO,
                                       TRIM(objVeiculo('OBJ.*')),
                                       USER_ID)RETURNING ASE_ID INTO idAssegurado;
        
        -- O custo e a taxa serao definida pusteriormente(NAO SABE AINDA COMO IMPLEMENTAR A REGRA DE CUSTO E TAXA)
        PRC_REG_COBERTURASEGURADO(ID_COBERTURA, idAssegurado, USER_ID, 0.0 , taxa, VALOR_PREMIO);
        -- Se o objecto foi regitrado com sucesso entao retornar true
        IF res.resultado != -1 THEN res.message := 'true;Sucess';
        ELSE res.message := 'Falha ao registrar o objecto'||nl||'Falha: '||res.message;
        END IF;
    END IF;
    
    IF ID_CONTRATO IS NOT NULL 
       AND res.resultado != -1 THEN
      
       res.message := 'true;Sucess'; 
    END IF;
    
    IF ID_CONTRATO IS NULL AND idVeiculo IS NOT NULL THEN RETURN 'true'; END IF;
    
    RETURN res.message;
END;