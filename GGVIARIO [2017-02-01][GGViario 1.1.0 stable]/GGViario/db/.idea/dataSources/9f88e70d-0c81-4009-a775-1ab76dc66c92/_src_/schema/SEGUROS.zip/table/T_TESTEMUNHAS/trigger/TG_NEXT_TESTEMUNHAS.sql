create trigger TG_NEXT_TESTEMUNHAS
	before insert
	on T_TESTEMUNHAS
	for each row
begin  
   if inserting then 
      if :NEW."TEST_ID" is null then 
         select SEQ_TESTEMUNHAS.nextval into :NEW."TEST_ID" from dual; 
      end if; 
   end if; 
end;
