create trigger TG_TEST
	after insert or update
	on T_TEST
	for each row
DECLARE
     l_job number;
BEGIN
    -- DBMS_MVIEW.REFRESH('MVIEW2');
    dbms_job.submit( l_job, 'dbms_mview.refresh( ''MVIEW2'' );' );
END;
