create trigger TG_NEXT_LINHAPAYMENT
	before insert
	on T_LINHAPAYMENT
	for each row
begin  
   if inserting then 
      if :NEW."LPAY_ID" is null then 
         select SEQ_LINHAPAYMENT.nextval into :NEW."LPAY_ID" from dual; 
      end if; 
   end if; 
end;

