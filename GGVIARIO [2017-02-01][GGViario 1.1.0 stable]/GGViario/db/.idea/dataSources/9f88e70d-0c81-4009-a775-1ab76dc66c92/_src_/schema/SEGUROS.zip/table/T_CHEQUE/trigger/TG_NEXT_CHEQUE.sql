create trigger TG_NEXT_CHEQUE
	before insert
	on T_CHEQUE
	for each row
begin  
   if inserting then 
      if :NEW."CHEQUE_ID" is null then 
         select SEQ_CHEQUE.nextval into :NEW."CHEQUE_ID" from dual; 
      end if; 
   end if; 
end;
