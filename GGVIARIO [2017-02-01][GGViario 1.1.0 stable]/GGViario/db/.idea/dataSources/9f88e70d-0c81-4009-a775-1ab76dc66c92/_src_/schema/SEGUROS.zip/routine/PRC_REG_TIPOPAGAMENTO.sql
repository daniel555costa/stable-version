create PROCEDURE PRC_REG_TIPOPAGAMENTO 
(
   idUser NUMBER,
   descricaoPagamento VARCHAR2
)IS
BEGIN
   INSERT INTO T_OBJECTYPE (OBJT_USER_ID,
                            OBJT_T_ID,
                            OBJT_DESC)
                            VALUES(idUser,
                                   8,
                                   descricaoPagamento);
END;