create trigger TG_NEXT_LANCAMENTO
	before insert
	on T_LANCAMENTO
	for each row
begin  
   if inserting then 
      if :NEW."LANCA_ID" is null then 
         select SEQ_LANCAMENTO.nextval into :NEW."LANCA_ID" from dual; 
      end if; 
   end if; 
end;

