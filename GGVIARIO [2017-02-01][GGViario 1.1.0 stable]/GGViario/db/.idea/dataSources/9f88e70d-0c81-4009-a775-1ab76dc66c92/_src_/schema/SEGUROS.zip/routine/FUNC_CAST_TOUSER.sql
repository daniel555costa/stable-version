create FUNCTION FUNC_CAST_TOUSER 
(
   idUser NUMBER,
   idFuncionario NUMBER,
   accessName VARCHAR2,
   pwd VARCHAR2,
   userLevel NUMBER
)
RETURN VARCHAR2
IS
   tt NUMBER;
   linhaFuncionario T_FUNCIONARIO%ROWTYPE;
BEGIN
   
   SELECT * INTO linhaFuncionario
      FROM T_FUNCIONARIO F
      WHERE F.FUNC_ID = idFuncionario;
      
   IF linhaFuncionario.FUNC_ACCESS != 0 THEN  RETURN 'O funcionario ja esta como utilizador.'; END IF;
   
   UPDATE T_FUNCIONARIO F
      SET F.FUNC_NVUSER_ID = userLevel,
          F.FUNC_ACCESSNAME = accessName,
          F.FUNC_PWD = pwd,
          F.FUNC_ACCESS = 2
      WHERE F.FUNC_ID = idFuncionario;
      
   RETURN 'true';
END;