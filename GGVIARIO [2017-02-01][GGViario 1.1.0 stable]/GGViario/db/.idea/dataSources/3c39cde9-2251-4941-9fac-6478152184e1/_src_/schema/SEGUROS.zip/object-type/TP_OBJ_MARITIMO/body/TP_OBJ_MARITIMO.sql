create TYPE BODY           "TP_OBJ_MARITIMO" AS

  CONSTRUCTOR FUNCTION TP_OBJ_MARITIMO(
                                          BANDEIRA_PAIS_ID VARCHAR2,
                                          USO_NAVIO VARCHAR2,
                                          CLASSE_ESTATUTO_RENOVACAO VARCHAR2,
                                          POTENCIA_MOTOR VARCHAR2,
                                          COMBUSTIVEL_OBJ_ID VARCHAR2,
                                          QUANTIDADE_PESO FLOAT,
                                          NUMERO_MOTOR VARCHAR2,
                                          MARCA_MOTOR VARCHAR2,
                                          NUMERO_TRIPULANTE NUMBER, 
                                          NOME_NAVIO VARCHAR2,
                                          MARCA_MODELO VARCHAR2,
                                          NUMERO_CHASSI VARCHAR2,
                                          IDADE_NAVIO NUMBER,
                                          TIPO_NAVIO VARCHAR2,
                                          EXPERIENCIA_RECLAMACAO char,
                                          NAVEGACAO_INSTALADA  VARCHAR2,
                                          AREA_OPERACAO  VARCHAR2,
                                          TIPO_CONSTRUCAO_NAVIO VARCHAR2,
                                          CONDICAO_NAVIO VARCHAR2)RETURN SELF AS RESULT IS
                                          TT NUMBER;
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_OBJ_MARITIMO.TP_OBJ_MARITIMO
    SELF.BANDEIRA_PAIS_ID := BANDEIRA_PAIS_ID;
    SELF.USO_NAVIO :=  USO_NAVIO;
    SELF.CLASSE_ESTATUTO_RENOVACAO := CLASSE_ESTATUTO_RENOVACAO;
    SELF.POTENCIA_MOTOR := POTENCIA_MOTOR;
    SELF. COMBUSTIVEL_OBJ_ID  :=  COMBUSTIVEL_OBJ_ID ;
    SELF.QUANTIDADE_PESO := QUANTIDADE_PESO;
    SELF.NUMERO_MOTOR := NUMERO_MOTOR;
    SELF.MARCA_MOTOR  :=  MARCA_MOTOR ;
    SELF.NUMERO_CHASSI := NUMERO_CHASSI;
    SELF.IDADE_NAVIO :=  IDADE_NAVIO;
    SELF.TIPO_NAVIO :=  TIPO_NAVIO;
    SELF.EXPERIENCIA_RECLAMACAO := EXPERIENCIA_RECLAMACAO;
    SELF.NAVEGACAO_INSTALADA  := NAVEGACAO_INSTALADA ;
   
    SELF.AREA_OPERACAO :=  AREA_OPERACAO;
    SELF.TIPO_CONSTRUCAO_NAVIO :=  TIPO_CONSTRUCAO_NAVIO;
    SELF.CONDICAO_NAVIO := CONDICAO_NAVIO;
    SELF.STATE := 0;
    RETURN ;
  END TP_OBJ_MARITIMO;

  STATIC FUNCTION INSTANCEOF RETURN NUMBER AS
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_OBJ_MARITIMO.INSTANCEOF
    RETURN 3;
  END INSTANCEOF;
  
END;