create trigger TG_NEXT_ASSEGURA
	before insert
	on T_ASSEGURA
	for each row
begin  
   if inserting then 
      if :NEW."ASE_ID" is null then 
         select SEQ_ASSEGURA.nextval into :NEW."ASE_ID" from dual; 
      end if; 
   end if; 
end;
