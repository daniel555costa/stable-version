create FUNCTION           "FUNCT_LOAD_USERS" 
RETURN PACK_TYPE.UserTable PIPELINED
IS
    
BEGIN
    -- Carregar todos os utilizadores
    FOR I IN (SELECT * FROM VER_USER) LOOP
      PIPE ROW (I);
    END LOOP;
END;