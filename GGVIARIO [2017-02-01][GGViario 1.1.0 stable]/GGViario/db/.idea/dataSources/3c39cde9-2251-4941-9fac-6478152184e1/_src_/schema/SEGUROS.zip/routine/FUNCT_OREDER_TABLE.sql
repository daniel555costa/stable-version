create FUNCTION           "FUNCT_OREDER_TABLE" 
RETURN TB_ARRAY_STRING PIPELINED
IS
   allTable TB_ARRAY_STRING := TB_ARRAY_STRING();
   expOrder TB_ARRAY_STRING := TB_ARRAY_STRING();
   countBreak NUMBER := 0;
   currTable VARCHAR2(30);
   referencedTable VARCHAR2(30);
   ttExist  NUMBER;
   ttAdd NUMBER;
   nextIndex NUMBER:= 1;
   ttTotal NUMBER;
   
   FUNCTION existsTable (tableName VARCHAR2) RETURN NUMBER
   IS
       ext NUMBER := 0;
   BEGIN
      FOR I IN 1..expOrder.COUNT LOOP
         IF expOrder(I) = tableName THEN
           ext := 1;
           EXIT;
         END IF;
      END LOOP;
      RETURN ext;
   END;
   
   FUNCTION REFERE_MY(tableMy VARCHAR2, tableRefere VARCHAR2) RETURN NUMBER
   IS
      tt NUMBER := 0;
   BEGIN
        FOR I IN (SELECT I.CONSTRAINT_NAME, I.CONSTRAINT_TYPE, I.TABLE_NAME, I.R_CONSTRAINT_NAME
                   FROM USER_CONSTRAINTS I
                   WHERE I.CONSTRAINT_TYPE = 'R'
                      AND I.TABLE_NAME = tableRefere)
        LOOP
           SELECT U.TABLE_NAME INTO referencedTable 
              FROM USER_CONSTRAINTS U
              WHERE U.CONSTRAINT_NAME = I.R_CONSTRAINT_NAME;
           IF referencedTable = tableMy THEN 
              tt := 1;
              EXIT;
           END IF;
        END LOOP;
        
        return tt;
   END;
   
BEGIN
   
   SELECT I.TABLE_NAME
           BULK  COLLECT INTO allTable
      FROM USER_TABLES I;
      
   ttTotal := allTable.COUNT;
      
   
   WHILE expOrder.COUNT < ttTotal AND countBreak < 10000 LOOP
      currTable := allTable(nextIndex);
      --PRT.PRINT('Curr Table = '|| currTable);
      ttAdd := 0;
      ttExist := 0;
      FOR I IN (SELECT I.CONSTRAINT_NAME, I.CONSTRAINT_TYPE, I.TABLE_NAME, I.R_CONSTRAINT_NAME
                   FROM USER_CONSTRAINTS I
                   WHERE I.CONSTRAINT_TYPE = 'R'
                      AND I.TABLE_NAME = currTable )
      LOOP
         SELECT U.TABLE_NAME INTO referencedTable 
            FROM USER_CONSTRAINTS U
            WHERE U.CONSTRAINT_NAME = I.R_CONSTRAINT_NAME;
            
         IF existsTable(referencedTable) = 1 THEN
            ttAdd := ttAdd + 1;
         ELSIF  REFERE_MY(currTable, referencedTable) = 1 THEN
            ttAdd := ttAdd + 1;
         END IF;
         
         ttExist := ttExist  + 1;
         
      END LOOP;
      -- allTable.DELETE(1);
      IF ttAdd = ttExist THEN
         expOrder.EXTEND;
         expOrder(expOrder.COUNT) := allTable(nextIndex);
      ELSE 
         allTable.EXTEND;
         allTable(allTable.COUNT) := currTable;
      END IF;
      
      countBreak := countBreak + 1;
      nextIndex := nextIndex + 1;
   END LOOP;
   
   FOR I IN 1..expOrder.COUNT 
   LOOP
      PIPE ROW(expOrder(I));
   END LOOP;
   
END;