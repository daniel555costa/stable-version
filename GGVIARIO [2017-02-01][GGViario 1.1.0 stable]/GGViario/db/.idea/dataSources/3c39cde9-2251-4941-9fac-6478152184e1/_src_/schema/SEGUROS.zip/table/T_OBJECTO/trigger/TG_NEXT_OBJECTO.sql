create trigger TG_NEXT_OBJECTO
	before insert
	on T_OBJECTO
	for each row
begin  
   if inserting then 
      if :NEW."OBJ_ID" is null then 
         select SEQ_OBJECTO.nextval into :NEW."OBJ_ID" from dual; 
      end if;
      
     
      SELECT OBJT_SEQUENCE INTO :NEW.OBJ_SEQUENCE FROM T_OBJECTYPE WHERE OBJT_ID = :NEW.OBJ_TOBJ_ID;
      
      -- SE A SEQUENCIA RETORNOR O RESULTADO NULO ENTAO INICIAR DE ZERO
      IF :NEW.OBJ_SEQUENCE IS NULL THEN
         :NEW.OBJ_SEQUENCE := 1;
      END IF;

      -- INCRMENTAR O VALOR A SEQUENCIA
      UPDATE  T_OBJECTYPE
        SET OBJT_SEQUENCE = :NEW.OBJ_SEQUENCE + 1  
        WHERE OBJT_ID = :NEW.OBJ_TOBJ_ID;  
        
      
   end if; 
end;
