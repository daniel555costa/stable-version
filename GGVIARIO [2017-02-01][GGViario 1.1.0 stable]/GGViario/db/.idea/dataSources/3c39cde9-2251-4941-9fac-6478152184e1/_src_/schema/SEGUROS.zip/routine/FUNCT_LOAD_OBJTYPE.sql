create FUNCTION           "FUNCT_LOAD_OBJTYPE" 
(
    IDENTIDADE NUMBER,
    idSuper NUMBER
) 
RETURN PACK_TYPE.filterObjectoType PIPELINED 

IS
   super NUMBER := CASE WHEN idSuper = -1 THEN NULL ELSE idSuper END;
BEGIN
   FOR I IN (SELECT *
              FROM VER_OBJECTYPE V
              WHERE V."ID ENTIDADE"=  IDENTIDADE
                 AND 1 = (CASE
                             WHEN super IS NULL THEN 1
                             WHEN super = V."ID SUPER" THEN 1
                             ELSE 0
                          END)
                 )
   LOOP
     PIPE ROW(I);
   END LOOP;
END;