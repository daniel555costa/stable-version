create TYPE BODY           "TP_CTT_CARGAVEICULO" AS

  CONSTRUCTOR FUNCTION TP_CTT_CARGAVEICULO(conservacao_noite CHAR, -- {Y - Yes | N - NO}
                                              numRegistro VARCHAR2,
                                              veiculoRegistrado VARCHAR2,
                                              valorCarregamento FLOAT,
                                              marca FLOAT,
                                              valorMaxCarregamnto FLOAT,
                                              valorMaxVeiculo FLOAT,
                                              usoDescolacaoComer NUMBER, --Usado para deslocação comercial {0 NOT Chequed, 1 Chequed}
                                              possTranca NUMBER -- Possibilidade de trancar {0 NOT Chequed, 1 Chequed}
                                              )RETURN SELF AS RESULT AS
  BEGIN    
    SELF.conservacao_noite := conservacao_noite; -- {Y - Yes | N - NO}
    SELF.numRegistro := numRegistro;
    SELF.veiculoRegistrado := veiculoRegistrado;
    SELF.valorCarregamento := valorCarregamento;
    SELF.marca := marca;
    SELF.valorMaxCarregamnto := valorMaxCarregamnto;
    SELF.valorMaxVeiculo := valorMaxVeiculo;
    SELF.usoDescolacaoComer := usoDescolacaoComer; --Usado para deslocação comercial {0 NOT Chequed, 1 Chequed}
    SELF.possTranca := possTranca;
    SELF.STATE := 1;
    SELF.INSTANCE_OF := TP_CTT_CARGAVEICULO.INSTANCEOF();
    RETURN;
  END TP_CTT_CARGAVEICULO;

  STATIC FUNCTION INSTANCEOF RETURN NUMBER AS
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_CTT_CARGAVEICULO.INSTANCEOF
    RETURN NULL;
  END INSTANCEOF;

END;