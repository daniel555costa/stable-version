create trigger TG_NEXT_INFORMACAO
	before insert
	on T_INFORMACAO
	for each row
begin  
   if inserting then 
      if :NEW."INFO_ID" is null then 
         select SEQ_INFORMACAO.nextval into :NEW."INFO_ID" from dual; 
      end if; 
   end if; 
end;
