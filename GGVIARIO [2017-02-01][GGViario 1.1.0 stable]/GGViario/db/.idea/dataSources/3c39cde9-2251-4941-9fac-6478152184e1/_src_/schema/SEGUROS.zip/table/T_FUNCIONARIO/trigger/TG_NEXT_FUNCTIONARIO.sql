create trigger TG_NEXT_FUNCTIONARIO
	before insert
	on T_FUNCIONARIO
	for each row
begin  
   if inserting then 
      if :NEW."FUNC_ID" is null then 
         select SEQ_FUNCTIONARIOS.nextval into :NEW."FUNC_ID" from dual; 
      end if; 
   end if; 
end;
