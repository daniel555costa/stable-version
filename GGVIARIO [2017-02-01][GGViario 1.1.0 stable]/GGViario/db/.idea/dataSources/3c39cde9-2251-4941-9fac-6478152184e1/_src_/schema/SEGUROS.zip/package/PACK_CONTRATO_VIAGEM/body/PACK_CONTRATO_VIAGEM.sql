create PACKAGE BODY           "PACK_CONTRATO_VIAGEM" AS

  FUNCTION CALC_NICON_COMISION(idPrecario NUMBER, dateCalc TIMESTAMP) RETURN FLOAT AS
     nicomComision FLOAT;
     aux FLOAT;
     PR T_PRECARIO%ROWTYPE;
     tt NUMBER;
     taxaNaoMotor FLOAT := 105.6; -- O valor da taxa nao motor por default e de 105.6%
     
  BEGIN
     SELECT * INTO PR
        FROM T_PRECARIO PR 
        WHERE PR.PREC_ID = idPrecario;
        
      SELECT COUNT(*) INTO tt
         FROM (SELECT * 
                  FROM T_IMPOSTOS IMPS
                     INNER JOIN T_IMPOSTOTAXA TAXA ON IMPS.IMP_ID = TAXA.IMPTAX_IMP_ID
                  WHERE IMPS.IMP_NAME = 'NMOTOR'
                     AND TAXA.IMPTAX_DTREG <= dateCalc
                  ORDER BY TAXA.IMPTAX_DTREG DESC)
         WHERE ROWNUM <= 1;
         
      --Se tiver uma taxa definada a na epoca dada entao devera calculara o nc baseando da taxa da epoci         
      IF tt = 0 THEN
         SELECT TA.IMPTAX_PERCENTAGEM INTO taxaNaoMotor
           FROM (SELECT TAXA.IMPTAX_PERCENTAGEM
                     FROM T_IMPOSTOS IMPS
                        INNER JOIN T_IMPOSTOTAXA TAXA ON IMPS.IMP_ID = TAXA.IMPTAX_IMP_ID
                     WHERE IMPS.IMP_NAME = 'NMOTOR'
                        AND TAXA.IMPTAX_DTREG <= dateCalc
                     ORDER BY TAXA.IMPTAX_DTREG DESC) TA
            WHERE ROWNUM <= 1;
      END IF;        
     
     aux := PR.PREC_TOTAL - PR.PREC_PREMINOOBJ;
     nicomComision := aux/(taxaNaoMotor/100);
     
     RETURN nicomComision;
  END CALC_NICON_COMISION;

END PACK_CONTRATO_VIAGEM;