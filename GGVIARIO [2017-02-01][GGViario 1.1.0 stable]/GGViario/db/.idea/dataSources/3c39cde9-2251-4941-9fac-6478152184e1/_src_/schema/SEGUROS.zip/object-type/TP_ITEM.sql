create TYPE           "TP_ITEM"                                          IS OBJECT
(
   ITEM_KEY CHARACTER VARYING(4000),
   ITEM_VALUE CLOB
);