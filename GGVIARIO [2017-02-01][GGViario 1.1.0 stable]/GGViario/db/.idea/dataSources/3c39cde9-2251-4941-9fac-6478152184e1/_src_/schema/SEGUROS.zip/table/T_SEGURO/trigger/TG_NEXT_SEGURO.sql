create trigger TG_NEXT_SEGURO
	before insert
	on T_SEGURO
	for each row
begin  
   if inserting then 
      if :NEW."SEG_ID" is null then 
         select SEQ_SEGURO.nextval into :NEW."SEG_ID" from dual; 
      end if; 
   end if; 
end;
