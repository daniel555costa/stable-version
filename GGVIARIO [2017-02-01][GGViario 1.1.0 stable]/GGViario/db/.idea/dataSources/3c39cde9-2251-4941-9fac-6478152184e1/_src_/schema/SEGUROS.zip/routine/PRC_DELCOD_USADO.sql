create PROCEDURE PRC_DELCOD_USADO 
(
   numeroApoliceCodigo VARCHAR2, -- Numero de 
   idSeguro NUMBER -- A sequencia
)
IS
BEGIN
   ---Serve para depois de registrar um seguro remover o codigo usado
    -- Depois de utilizado o codigo no conrato deve ser removido o mesmo do grupo de codigo requisitado
  DELETE FROM T_DEFCODLOST d
    WHERE UPPER(d.DCODL_COD) = numeroApoliceCodigo
    AND d.DCODL_SEG_ID = idSeguro;
END;