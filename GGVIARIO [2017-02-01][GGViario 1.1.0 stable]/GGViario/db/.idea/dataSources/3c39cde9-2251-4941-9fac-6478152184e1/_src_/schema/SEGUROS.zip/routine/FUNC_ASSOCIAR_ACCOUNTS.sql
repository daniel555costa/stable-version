create FUNCTION           "FUNC_ASSOCIAR_ACCOUNTS" (
  idUser NUMBER,
  idAccount NUMBER,
  idAccountBank NUMBER
) RETURN CHARACTER VARYING AS 
  BEGIN
    UPDATE T_ACCOUNTACCOUNTBANK aab 
      set aab.AACCOUNTBANK_STATE = 0,
          aab.AACOUNTBANK_DTFIM = systimestamp
      where aab.AACOUNTBANK_ACCOUNTBANK_ID = idAccountBank
        or aab.AACOUNTBANK_ACCOUNT_ID = idAccount   
    ;
    
    INSERT  INTO T_ACCOUNTACCOUNTBANK(
      AACOUNTBANK_ACCOUNT_ID,
      AACOUNTBANK_ACCOUNTBANK_ID,
      AACOUNTBANK_USER_ID
    )  VALUES (
      idAccount,
      idAccountBank,
      idUser
    );
    
    RETURN 'true;success';
  END;