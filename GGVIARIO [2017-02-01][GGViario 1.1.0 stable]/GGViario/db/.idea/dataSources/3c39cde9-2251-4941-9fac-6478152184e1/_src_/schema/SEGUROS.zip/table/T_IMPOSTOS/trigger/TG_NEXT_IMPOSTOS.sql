create trigger TG_NEXT_IMPOSTOS
	before insert
	on T_IMPOSTOS
	for each row
begin  
   if inserting then 
      if :NEW."IMP_ID" is null then 
         select SEQ_IMPPOSTOS.nextval into :NEW."IMP_ID" from dual; 
      end if; 
   end if; 
end;
