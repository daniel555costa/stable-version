create PROCEDURE           "OUT_CLEAR" 
IS
BEGIN
  DELETE from output;
END;