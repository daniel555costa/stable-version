create TYPE           "TP_OBJ_ROUBO"                                          UNDER TP_OBJ
(
  -- PROP >> Corresponde a Propiedades a serem seguradas
  PROP_QUANTIDAEE NUMBER,
  PROP_MODELO VARCHAR2(50),
  PROP_VALOR FLOAT,
  PROP_DESCRICAO VARCHAR2(150),
  CONSTRUCTOR FUNCTION TP_OBJ_Roubo(PROP_QUANTIDAEE NUMBER,
                                    PROP_MODELO VARCHAR2,
                                    PROP_VALOR FLOAT,
                                    PROP_DESCRICAO VARCHAR2)RETURN SELF AS RESULT,
    
    STATIC FUNCTION INSTANCEOF RETURN NUMBER
)FINAL;