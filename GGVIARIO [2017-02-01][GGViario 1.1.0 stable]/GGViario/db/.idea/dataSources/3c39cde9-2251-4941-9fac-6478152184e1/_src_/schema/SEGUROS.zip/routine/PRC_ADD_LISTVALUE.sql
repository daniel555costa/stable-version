create PROCEDURE           "PRC_ADD_LISTVALUE" 
(
    listaAttribute IN OUT TB_OBJECT_VALUES,
    idSuper NUMBER,
    attributeName VARCHAR2,
    attributeValue VARCHAR2
)IS
BEGIN 
   listaAttribute.EXTEND;
   listaAttribute(listaAttribute.COUNT) := TP_OBJECT_VALUES(idSuper, attributeName, attributeValue);
END;