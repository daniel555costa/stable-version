create PROCEDURE           "PRC_USER_ALTERARLEVEL" 
(
  idUserSuper IN VARCHAR2, -- O utilizador que esta a alterar(Administrador)
  idUserAlterar IN VARCHAR2, -- O itilizador que tera o perfil alterado
  idLevel NUMBER, -- O novo perfil para o utilizador
  idDepartamento NUMBER
) AS 
BEGIN
    -- Altrar o perfil do utilizador
    -- UPDATE USER PROFILE
    UPDATE T_FUNCIONARIO U
       SET U.FUNC_NVUSER_ID = CASE WHEN  idLevel IS NULL THEN FUNC_NVUSER_ID ELSE  idLevel END,
           U.FUNC_DEP_ID = CASE WHEN  idDepartamento IS NULL THEN FUNC_DEP_ID ELSE  idDepartamento END
       WHERE U.FUNC_ID = idUserAlterar;
END PRC_USER_ALTERARLEVEL;