create PROCEDURE           "PRC_REG_TIPOCOMBUSTIVEL" 
(
   idUser NUMBER,
   descricaoCombustivel VARCHAR2
)IS
BEGIN
    INSERT INTO T_OBJECTYPE (OBJT_USER_ID,
                             OBJT_T_ID,
                             OBJT_DESC)
                             VALUES(idUser,
                                    6,
                                    descricaoCombustivel);
END;