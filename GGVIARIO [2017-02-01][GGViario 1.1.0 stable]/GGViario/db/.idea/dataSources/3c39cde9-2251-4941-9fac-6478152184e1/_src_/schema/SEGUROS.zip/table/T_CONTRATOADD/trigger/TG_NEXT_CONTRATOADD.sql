create trigger TG_NEXT_CONTRATOADD
	before insert
	on T_CONTRATOADD
	for each row
BEGIN
  IF inserting AND :new.CTTAD_ID IS NULL THEN
    :new.CTTAD_ID := SEQ_CONTRATOADD.NEXTVAL; 
  END IF;
END;
