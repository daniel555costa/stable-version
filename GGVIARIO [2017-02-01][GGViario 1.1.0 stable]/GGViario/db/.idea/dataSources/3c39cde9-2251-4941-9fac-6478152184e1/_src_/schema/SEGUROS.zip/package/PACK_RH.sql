create PACKAGE           "PACK_RH" AS

   TYPE AvancoSalarial IS RECORD("ID" NUMBER, "DATA" CHARACTER VARYING(16), "FUNCIONARIO" CHARACTER VARYING(4000),"VALOR" CHARACTER VARYING (128), "DOCUMENTO" CHARACTER VARYING(32), "OBSERVACAO" CHARACTER VARYING(256) ,"REGISTRO" CHARACTER VARYING(16), "ES   TYPE AvancoSalarialFuncionario IS TABLE OF AvancoSalarial;
   
   TYPE verTaxasImpostas IS TABLE OF VER_IMPOSTOS_TAXAS%ROWTYPE;
   
   /*CAT_ID
CAT_USER_ID
CAT_NUMDIAS
CAT_BASESALARY
CAT_HOUSESUBVENTION
CAT_LUNCHSUBVENTION
CAT_TRANSPORTSUBVENTION
CAT_DTREG
CAT_STATE
CAT_ALMOCOBONUS
CAT_OBJT_TYPECATEGORY*/

   TYPE Salario IS RECORD
   (
        "SALARIO.RESULT" CHARACTER VARYING(100),
        "SALARIO.MESSAGE" CHARACTER VARYING(4000),
        "FUNCIONARIO.ID" NUMBER,
        "FUNCIONARIO.NAME" CHARACTER VARYING(200),
        "ESTRUTURA.ID" NUMBER,
        "ESTRUTURA.TYPE_ID" NUMBER,
        "ESTRUTURA.TYPE_DESC" CHARACTER VARYING(300),
        "ESTRUTURA.LEVEL_ID" NUMBER,
        "ESTRUTURA.LEVEL_DESC" CHARACTER VARYING(300),
        "ESTRUTURA.BASE" FLOAT,
        "ESTRUTURA.ALOJAMENTO" FLOAT,
        "ESTRUTURA.LANCHE" FLOAT,
        "ESTRUTURA.TRANSPORTE" FLOAT,
        "ESTRUTURA.BONUSALMOCO" FLOAT,
        "ESTRUTURA.SALARIO" FLOAT,
        "SALARIO OUT BONUS ALMOCO" FLOAT, -- ALIAS AS TRIBUTADO
        "ID SS FUNCIONARIO" NUMBER,
        "ID SS EMPRESA" NUMBER,
        "% SS FUNCIONARIO" FLOAT,
        "% SS EMPRESA" FLOAT,
        "SS FUNCIONARIO" FLOAT,
        "SALARIO OUT SS FUNCIONARIO" FLOAT,
        "ID COMISAO" NUMBER,
        "VALOR COMISAO" FLOAT,
        "SALARIO COM COMISAO" FLOAT,
        "COTRATOS COMISAO" NUMBER,
        "ID IRS" NUMBER,
        "% IRS" FLOAT,
        "IRS PARCELA BATER" FLOAT,
        "IRS" FLOAT,
        "IRS APURADO" FLOAT,
        "ID SITUACAO FAMILIAR" NUMBER,
        "NUMERO FILHOS" NUMBER,
        "VALOR SITUACAO FAMILIAR" FLOAT,
        "ID SALARIO BASE NACIONAL" NUMBER,
        "VALOR SALARIO BASE NACIONAL" FLOAT,
        "SIUACAO FAMILIAR TOTAL" FLOAT,
        "IRS LIQUIDO" FLOAT,
        "SALARIO MES" FLOAT,
        "ID AVANCO SALARIAL" NUMBER,
        "VALOR AVANCO SALARIAL" FLOAT,
        "SALARIO FINAL MES" FLOAT,
        "SS EMPRESA" FLOAT,
        "SALARIO IMPOSTO EMPRESA" FLOAT -- AS SEGURANCA SOCIAL FUNCIONARIO
    );
        
   TYPE salarioResult IS TABLE OF Salario;
   
   function funcRegCategori (idUser NUMBER,
                             idTypeCategory VARCHAR2,
                             idLevelCAtegory NUMBER,
                             numDIas NUMBER,
                             baseSalary FLOAT,
                             houseSubvention FLOAT,
                             lunchSubvention FLOAT,
                             transportSubventiion FLOAT,
                             bonusAlmoco FLOAT,
                             tipoOperacacao NUMBER
                             )
                             RETURN VARCHAR2;
                             
   function funcRegItem (idUser NUMBER,
                         nomeCategoria CHARACTER VARYING,
                         nameItem CHARACTER VARYINg,
                         descrision CHARACTER VARYING,
                         idItemEdit NUMBER
                         ) RETURN VARCHAR2;
                         
                         
   function funcRegItemMovimentation(idUser NUMBER,
                                     idItem NUMBER,
                                     idFuncionarioResponsavel NUMBER,
                                     idTipoMovimento number, -- VER_TYPE_MOVIMENTITEM
                                     quantity number,
                                     estimatedCost float,
                                     sourceDestination CHARACTER VARYING,
                                     observation CHARACTER VARYING
                                     )RETURN CHARACTER VARYING;
                                     
                                     
    
    -- novoEstado {0 - siginifica demitir | 2 - seginifica suspende}
    FUNCTION funcSuspenderFuncionario (idUser NUMBER, idFuncionario NUMBER, descrincao character varying, novoEstado NUMBER) RETURN CHARACTER VARYING;
    
    
    FUNCTION funcFeriarFuncionario (idUser NUMBER, idFuncionario NUMBER, dateInicio DATE, dateFim DATE) RETURN CHARACTER VARYING;
    
    FUNCTION getDiasRestante(idUser NUMBER, idFuncionario NUMBER) RETURN NUMBER;
    
    FUNCTION regProcessSalary (idUser NUMBER, ano NUMBER, mes NUMBER) RETURN VARCHAR2;
    
    -- Essa funcao sever para efetuar o processamento de salario
    FUNCTION funcProcessSalario(idUser NUMBER, idFuncionario NUMBER, idProcesso NUMBER) RETURN VARCHAR2;
    
    FUNCTION funcEndProcess(idProcess NUMBER) return character varying;
    
    -- ESA FUNCAO SERVE PARA ADEFINIR O SALARIO BASE NACIONAL
    FUNCTION funcDefinirSalarioBaseNacional (valorSalario FLOAT, idUser NUMBER) RETURN CHARACTER VARYING;
    
    -- ESSA FUNCAO SERVER PARA REGISTRA O AVANCO SALARIAL
    FUNCTION funcRegAvancoSalarial (idUser NUMBER, idFuncionario NUMBER, numDocumento CHARACTER VARYING, observacao CHARACTER VARYING, valor FLOAT, dataAvanco DATE) RETURN CHARACTER VARYING; 

    FUNCTION loadAvancoSalarial(idFuncionario NUMBER, dataInicio DATE, dataFim DATE) RETURN avancoSalarialFuncionario PIPELINED;
    
    FUNCTION funcCanselAvancoSalarial(iduser NUMBER, idAvanco NUMBER) RETURN VARCHAR2;
    
    FUNCTION funcRegSituacaoFamiliar(idUser NUMBER, numeroFilhos NUMBER, percentagem FLOAT) RETURN VARCHAR2;
    
    FUNCTION loadSalarioBaseNacional(idUser NUMBER) RETURN FLOAT;
    
    FUNCTION funcRegImpostoxTaxas(idImposto NUMBER, idUser NUMBER, percentagem FLOAT, valorMinimo FLOAT, valorMaximo FLOAT, parcelaBater FLOAT) RETURN VARCHAR2;
    
    
    -- TipoTaxa {1 IRS | 2 - Segurança Social | 3 outras}
    FUNCTION funcLoadImpostosTaxa(tipoTaxa NUMBER) RETURN verTaxasImpostas PIPELINED;
    
    
    FUNCTION functPreviexProcessSalario (idUser NUMBER, idFuncionario NUMBER) RETURN PACK_RH.salarioResult PIPELINED;
    
    TYPE SalarioOld IS RECORD ("ID" NUMBER, "DATA" CHARACTER VARYING(20), "CODIGO PROCESSO" CHARACTER VARYING (200), "MONTANTE" CHARACTER VARYING(120), "ESTADO" CHARACTER VARYING(100), "REGISTRO" CHARACTER VARYING (100));
    TYPE ListSalarioOld IS TABLE OF PACK_RH.SalarioOld;
    FUNCTION functLoadProcessSalario (ano NUMBER, mes NUMBER) RETURN  ListSalarioOld PIPELINED;
    
    -- state {-1 ANULAR | 0 APROVAR}
    FUNCTION funcAlterSatateProcessSalario (idProcesso NUMBER, idUser NUMBER, newState NUMBER, descricao CHARACTER VARYING) RETURN VARCHAR2;
    
END PACK_RH;