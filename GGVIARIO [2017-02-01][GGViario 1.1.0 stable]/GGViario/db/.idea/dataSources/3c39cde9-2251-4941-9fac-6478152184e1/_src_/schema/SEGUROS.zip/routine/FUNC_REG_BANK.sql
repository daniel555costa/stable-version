create FUNCTION           "FUNC_REG_BANK" 
(
   USER_ID NUMBER,
  NOME IN VARCHAR2, 
  SIGLA IN VARCHAR2 
  
) 
  RETURN VARCHAR2
     IS
        TT NUMBER(3);  
     BEGIN
        --GARANTIR A INEXISTENCIA DO BANCO COM OS DADOS DO PARAMETRO
        SELECT 
           COUNT(*) INTO TT 
           FROM T_BANK WHERE UPPER(BK_SIGLA) = UPPER(SIGLA);
        IF TT = 0 THEN
           INSERT INTO T_BANK(BK_NOME,BK_SIGLA)
              VALUES( NOME, SIGLA);
              
            RETURN 'true';
         ELSE
            RETURN'A SIGLA EXISTE';
        END IF;
  END;