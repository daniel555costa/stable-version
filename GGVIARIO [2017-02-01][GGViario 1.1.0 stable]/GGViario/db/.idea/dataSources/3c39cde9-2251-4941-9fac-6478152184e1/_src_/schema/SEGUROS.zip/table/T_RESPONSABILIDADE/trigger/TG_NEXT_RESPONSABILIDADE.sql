create trigger TG_NEXT_RESPONSABILIDADE
	before insert
	on T_RESPONSABILIDADE
	for each row
begin  
   if inserting then 
      if :NEW."RESPO_ID" is null then 
         select SEQ_RESPONSABILIDADE.nextval into :NEW."RESPO_ID" from dual; 
      end if; 
   end if; 
end;
