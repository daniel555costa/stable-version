create trigger TG_NEXT_SALARIONACIONAL
	before insert
	on T_SALARIONACIONAL
	for each row
begin  
   if inserting then 
      if :NEW."SALNACIO_ID" is null then 
         select SEQ_SALARIONACIONAL.nextval into :NEW."SALNACIO_ID" from dual; 
      end if; 
   end if; 
end;
