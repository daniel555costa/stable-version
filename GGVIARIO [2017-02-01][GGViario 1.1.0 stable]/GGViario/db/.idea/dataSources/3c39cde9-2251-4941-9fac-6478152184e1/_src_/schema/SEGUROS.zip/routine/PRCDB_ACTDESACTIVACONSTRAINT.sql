create PROCEDURE           "PRCDB_ACTDESACTIVACONSTRAINT" 
( 
   state VARCHAR2
)
is 
    correntstate VARCHAR2(30):= case  when upper(state )= upper ('e') then 'DISABLED' else 'ENABLED' end ;
    newstate VARCHAR2 (30):= case  when upper(state )= upper ('e') then 'ENABLE' else 'DISABLE' end ;
    command VARCHAR2(2000);
BEGIN

 
 -- procedimento para activar e desactivar os constragimento da tabela
  -- Se o state for 'e' significa que os constragimento serao activo caso contrario sera desactivo
  -- Desativar todas os constrangimento 
  DBMS_OUTPUT.PUT_LINE(newstate||'ing OS CONSTRAGIMENTO');
  IF newstate = 'DISABLE' THEN
      FOR c IN  
          (SELECT 
                c.owner, 
                c.table_name,
                c.constraint_name
             FROM user_constraints c, user_tables t
               WHERE c.table_name = t.table_name
                 AND upper( c.status) = upper(correntstate)
               ORDER BY c.constraint_type DESC)
          LOOP
            command := 'alter table "' || c.owner || '"."' || c.table_name || '" '||newstate||' constraint ' || c.constraint_name;
            DBMS_OUTPUT.PUT_LINE(command);
            dbms_utility.exec_ddl_statement(command);
          END LOOP;
    ELSE
        FOR c IN  
          (SELECT 
                c.owner, 
                c.table_name,
                c.constraint_name
             FROM user_constraints c, user_tables t
               WHERE c.table_name = t.table_name
                 AND upper( c.status) = upper(correntstate)
               ORDER BY c.constraint_type ASC)
          LOOP
            command := 'alter table "' || c.owner || '"."' || c.table_name || '" '||newstate||' constraint ' || c.constraint_name;
            DBMS_OUTPUT.PUT_LINE(command);
            dbms_utility.exec_ddl_statement(command);
          END LOOP;
    END IF;
  
  
  
  
  
  -- Desativar todos os triger
  DBMS_OUTPUT.PUT_LINE(newstate||'ing OS TRIGERES');
  FOR TG IN (SELECT * 
              FROM USER_TRIGGERS TG
              WHERE TG.STATUS = correntstate) LOOP
      
      -- CRIAR UM COMANDO COM A SEGUINTE SINTAX <SINTAX>alter trigger "USER"."TRIGERNAME" newState</SINTAX>     
      command := 'alter trigger '||'"'|| TG.TABLE_OWNER ||'"."'||TG.TRIGGER_NAME || '" '|| newstate;
      DBMS_OUTPUT.PUT_LINE(command);
    dbms_utility.exec_ddl_statement(command);
  END LOOP;
END;