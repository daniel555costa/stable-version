create trigger TG_NEXT_USA
	before insert
	on T_USA
	for each row
begin  
   if inserting then 
      if :NEW."USA_ID" is null then 
         select SEQ_USA.nextval into :NEW."USA_ID" from dual; 
      end if; 
   end if; 
end;
