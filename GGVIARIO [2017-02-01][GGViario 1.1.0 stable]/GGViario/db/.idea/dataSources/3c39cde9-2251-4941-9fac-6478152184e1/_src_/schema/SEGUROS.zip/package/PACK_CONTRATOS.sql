create PACKAGE           "PACK_CONTRATOS" AS

   PROCEDURE pLoadGeneric (idContrato NUMBER, listResult IN OUT TB_LOAD_CONTRATO);
   -- Procedimento para adicionar na lista
   PROCEDURE pAddList(listResult IN OUT TB_LOAD_CONTRATO, idRow NUMBER, categoria VARCHAR2, categoriaCod VARCHAR2, valueCod VARCHAR2, valueRow VARCHAR2);   

   
   PROCEDURE pAddCobertura(listOut IN OUT TB_LOAD_CONTRATO, idContrato NUMBER, idAssegurado NUMBER, codAssegura NUMBER);
   
   PROCEDURE pAddRespostas(listOut IN OUT TB_LOAD_CONTRATO, idContrato NUMBER);
   
   FUNCTION fGet(tableName VARCHAR2, columnName VARCHAR2, whereCondicion VARCHAR2) RETURN VARCHAR2;
   
   -- Carregar o numero de apolice
   FUNCTION funcLoadNumeroApolice(idCliente NUMBER, idSeguro NUMBER) RETURN CHARACTER VARYING;
   
   FUNCTION funcRegReseguro(idUser NUMBER, idTipoReseguro NUMBER, idContrato NUMBER, inicion DATE, fim DATE, descrincao CHARACTER VARYING, deducao FLOAT, limite FLOAT, apolice CHARACTER VARYING, tipoCobertura CHARACTER VARYING, idMoeda NUMBER, premioGrosso   
   FUNCTION funcResponsabilidade (idUser NUMBER, idEmpresa NUMBER, idReseguro NUMBER, precentagen FLOAT, premio FLOAT, risco FLOAT) RETURN CHARACTER VARYING;
   
   FUNCTION funcEndReseguro (idReseguro NUMBER) RETURN CHARACTER VARYING;
   
   FUNCTION funcRegNotCredito 
   (
      idUser NUMBER,
      idContrato NUMBER,
      codRegistro CHARACTER VARYING,
      beneficiary CHARACTER VARYING,
      sendAddress CHARACTER VARYING,
      observation CHARACTER VARYING,
      premioGross FLOAT,
      deducao FLOAT,
      total FLOAT
   )RETURN CHARACTER VARYING;

END PACK_CONTRATOS;