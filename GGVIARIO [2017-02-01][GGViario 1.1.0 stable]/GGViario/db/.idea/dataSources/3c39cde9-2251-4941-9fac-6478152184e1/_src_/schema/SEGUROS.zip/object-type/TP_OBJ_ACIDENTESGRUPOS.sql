create TYPE           "TP_OBJ_ACIDENTESGRUPOS"                                          UNDER TP_OBJ
(
   NOME VARCHAR2(60),
   CATEGORIA VARCHAR2(40),
   PROFISSAO VARCHAR2(50),
   DATANASCIMENTO VARCHAR2(30),
   DEFEITO_FISICO_MENTAIS VARCHAR(200),
   ACIDENTES_3ANOS VARCHAR2(200),
   
   CONSTRUCTOR FUNCTION TP_OBJ_ACIDENTESGRUPOS(NOME VARCHAR2,
                                               CATEGORIA VARCHAR2,
                                               PROFISSAO VARCHAR2,
                                               DATANASCIMENTO DATE,
                                               DEFEITO_FISICO_MENTAIS VARCHAR,
                                               ACIDENTES_3ANOS VARCHAR2)RETURN SELF AS RESULT,
    STATIC FUNCTION INSTANCEOF RETURN NUMBER
    
  )FINAL;