create FUNCTION           "FUNC_REG_FUNCTIONARIO" 
(
-- DADOS FIXO DO FUNCIONARIO
   ID_USER IN NUMBER ,
   ID_GENERO NUMBER,
   NOME IN VARCHAR2,
   NIF IN VARCHAR2,
   DTNASC IN DATE,
   DATAENTRADA DATE,
   -- PHOTO BLOB,
   codigoSeguradora VARCHAR2,
   apelido VARCHAR2
   
   
-- DADOS DO HISTÓRICO DO FUNCIONARIO  
, RESIDENCIA IN VARCHAR2 
, ID_CATEGORIA IN NUMBER  
, ID_ESTADO_CIVIL IN NUMBER
, MOVEL IN VARCHAR2 
, PHONE IN VARCHAR2, -- Aceita null
  mailFuncionario IN VARCHAR2,
  idDepartamento NUMBER,
  numFilhos NUMBER,
  idNivelCategoriaSalarial NUMBER
)
RETURN VARCHAR2
IS
    ID_RESIDENCIA NUMBER := PACK_REGRAS.GET_RESIDENCE(RESIDENCIA,ID_USER);
    TT NUMBER;
    idFuncionario NUMBER;
BEGIN
  
    --GARANTIR QUE NAO EXISTE NENHUM FUNCIONARIO COMO O NOME DE ACCESSO REQUISITADO

     -- EFECTUANDOO REGISTRO DO FUNCIONARIO
     INSERT INTO T_FUNCIONARIO(FUNC_USER_ID,
                               FUNC_GEN_ID,
                               FUNC_NOME,
                               FUNC_NIF,
                               FUNC_DTNASC,
                               FUNC_DTENTRADA,
                              -- FUNC_PHOTO, 
                               FUNC_CODSEGURADORA,
                               FUNC_APELIDO,
                               FUNC_MAIL,
                               FUNC_DEP_ID,
                               FUNC_OBJT_LEVELCATEGORY)
                               VALUES(ID_USER,
                                      ID_GENERO,
                                      NOME,
                                      NIF,
                                      DTNASC,
                                      DATAENTRADA,
                                     -- PHOTO,
                                      codigoSeguradora,
                                      apelido,
                                      mailFuncionario,
                                      idDepartamento,
                                      idNivelCategoriaSalarial) RETURNING FUNC_ID INTO idFuncionario;
      
            
      
      -- REGITRAR O PRIMEIR HISTORICO DO FUNCIONARIO     
      PRC_UPD_FUNCIONARIO(ID_USER,
                          1,
                          idFuncionario,
                          RESIDENCIA,
                          ID_CATEGORIA,
                          ID_ESTADO_CIVIL,
                          MOVEL,
                          (CASE WHEN PHONE = MOVEL THEN NULL ELSE PHONE END),
                          numFilhos,
                          null,
                          null,
                          null,
                          null,
                          null,
                          null,
                          null,
                          idNivelCategoriaSalarial);
                          
      RETURN 'true;'||idFuncionario; 
END;