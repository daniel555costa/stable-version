create trigger TG_NEXT_RISCASSUMIDO
	before insert
	on T_RISCOASSUMIDO
	for each row
begin  
   if inserting then 
      if :NEW."RISC_ID" is null then 
         select SEQ_RISCOASSUMIDO.nextval into :NEW."RISC_ID" from dual; 
      end if; 
   end if; 
end;
