create trigger TG_NEXT_CONTRATO
	before insert
	on T_CONTRATO
	for each row
begin  
   if inserting then 
      if :NEW."CTT_ID" is null then 
         select SEQ_CONTRATO.nextval into :NEW."CTT_ID" from dual; 
      end if; 
   end if; 
end;
