create FUNCTION FUBCT_VER_ACCOUNTBANK(
   dataAssociaccion TIMESTAMP,
   idAccount NUMBER,
   idAccountBanck NUMBER
) RETURN PACK_TYPE.BanckAccount PIPELINED
IS
  -- vAccountBanck VER_ACCOUNTBANK%ROWTYPE;
BEGIN

  FOR I IN (
    SELECT *
      FROM (
        SELECT VAC.*
          FROM T_ACCOUNT ac
            INNER JOIN T_ACCOUNTACCOUNTBANK abc ON ac.ACCOUNT_ID = abc.AACOUNTBANK_ACCOUNT_ID
            INNER JOIN T_ACCOUNTBANK ab ON abc.AACOUNTBANK_ACCOUNTBANK_ID = ab.ACCOUNTBANK_ID
            INNER JOIN T_BANK bk ON ab.ACCOUNTBANK_BANK_ID = bk.BK_ID
            INNER JOIN T_MOEDA md ON ab.ACCOUNTBANK_MOE_ID = md.MOE_ID
            INNER JOIN T_OBJECTYPE O ON ab.ACCOUNTBANK_OBJ_TYPEACCOUT = O.OBJT_ID
            INNER JOIN VER_ACCOUNTBANK VAC ON VAC.ID_ID = abc.AACOUNTBANK_ID
          WHERE abc.AACCOUNTBANK_DTREG <= dataAssociaccion
            AND (abc.AACOUNTBANK_ACCOUNT_ID = idAccount OR idAccount IS NULL)
            AND (abc.AACOUNTBANK_ACCOUNTBANK_ID = idAccountBanck OR idAccountBanck IS NULL)
          ORDER BY abc.AACCOUNTBANK_DTREG DESC
      ) ACC
      WHERE ROWNUM <= 1
  ) LOOP
--     vAccountBanck.ID := I.AACOUNTBANK_ID;
--     vAccountBanck."ACCOUNT DESC" := I.ACCOUNT_DESC;
--     vAccountBanck."ACCOUNT NUMBER" := I.ACCOUNT_RAIZ||I.ACCOUNT_NUMBER;
--     vAccountBanck.BANK := I.BK_SIGLA;
--     vAccountBanck.MOEDA := I.MOE_SIGLA;
--     vAccountBanck.NAME := I.BK_SIGLA||' '||I.MOE_SIGLA||' '||I.OBJT_DESC;
--     vAccountBanck.TYPE := I.OBJT_DESC;
    PIPE ROW (i);
    -- RETURN NULL;
  END LOOP;

  -- */
END;