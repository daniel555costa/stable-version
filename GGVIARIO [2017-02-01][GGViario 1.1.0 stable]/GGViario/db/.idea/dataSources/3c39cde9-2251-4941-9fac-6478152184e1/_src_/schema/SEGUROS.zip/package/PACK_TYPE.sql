create PACKAGE           "PACK_TYPE" IS


    --============================= TYPE RECORDES ====================================---

    -- Recorde para o codigo da sequencia
    TYPE SequenceCodigo IS RECORD (cod VARCHAR2(20), -- O codigo criado pela sequencia
                                    seq1 NUMBER,   -- O valor da sequencia 1
                                    seq2 NUMBER,  --  Valor da sequencia 2
                                    dtReg TIMESTAMP, -- A data em que o codigo foi criada
                                    dtLast TIMESTAMP, -- A data que sofreu a ultima atualizacao
                                    userReg NUMBER, -- O utilizador que requisitou o codigo
                                    seqId NUMBER  -- A identificacao da sequencia na qual pertence o codigo
                                    );

    TYPE Resultado IS RECORD (resultado NUMBER, -- resultado de autenticacao
                                              message VARCHAR2(4000) -- Mensagem de informacao
                                              );




   --============================ TYPE TABLES ==========================================--

   -- Tipo tabela da visao utilizadoe
    TYPE UserTable IS TABLE OF VER_USER%ROWTYPE;

    -- Tipo tabela dos veiculos
    -- TYPE VeiculoTable IS TABLE OF VER_VEICULO%ROWTYPE;

    -- Tipo tabela das perguntas
    TYPE TypePerguntas IS TABLE OF VER_TIPOPERGUNTA%ROWTYPE;

    -- Tipo tabela as taxas a ser imposta para os objecto segurado
    
    
    -- TODO COMMENTED FOR WORK CHEK AFETER 
    TYPE TaxasImpostaSegurado IS TABLE OF VER_TAXAS_IMPOSTAS%ROWTYPE;

    -- -
    TYPE InformacaoUtilCliente IS TABLE OF VER_STATUS_CLIENTE%ROWTYPE;

    -- -
    TYPE filterCliente is TABLE OF ver_cliente%rowtype;

    --
    TYPE filterContrato IS TABLE OF VER_CONTRATO%ROWTYPE;

    -- -
    TYPE filterContratoCliente IS TABLE OF VER_CONTRATO_CLIENTE%ROWTYPE;

    -- -
    TYPE filterObjectoType IS TABLE OF VER_OBJECTYPE%ROWTYPE;


    TYPE filterModelo IS TABLE OF VER_VEICULO_MODELO%ROWTYPE;

    TYPE mapaValues IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR(60);

    TYPE reportClients IS RECORD(ID NUMBER, CLIENTE VARCHAR2(120), "SEGURO FREQ" VARCHAR2(100), "PRIMEIRO CONTRATO" VARCHAR2(10), "QUANT. CONTRATO" NUMBER, "TOTAL PREMIO" VARCHAR2(120));
    TYPE filterReportClient IS TABLE OF reportClients;

    TYPE reportClient IS RECORD ("SEGURO" VARCHAR2(70), "PRIMEIRO CONTRATO" VARCHAR2(10), "QUANTIDADE" NUMBER, "PREMIO" VARCHAR2(120));
    TYPE filterReportStatuClient IS TABLE OF reportClient;

    TYPE reportSeguro IS RECORD (SEGURO VARCHAR2(120), CLIENTES NUMBER, "CLIENTE FREQ." VARCHAR2(120), "PREMIO" VARCHAR2(120));
    TYPE filterReportSeguro IS TABLE OF reportSeguro;

    TYPE reportTime IS RECORD ("DATA" VARCHAR2(25), "NOVOS CLIENTES" NUMBER, "TOTAL CLIETES" NUMBER, "NOVOS CONTRATOS" NUMBER, "TOTAL CONTRATOS" NUMBER, "PREMIO" VARCHAR2(120), "TOTAL" VARCHAR2(120), "SEGURO EPOCA" VARCHAR2(100));
    TYPE filterReportCrescentTime IS TABLE OF reportTime;

    TYPE reportproducao IS RECORD ("DATA" VARCHAR(25),"NUM APOLICE" VARCHAR(30), "NUMERO DEBITO" CHARACTER VARYING(32), CLIENTE VARCHAR(120),"SEGURO" VARCHAR(70),"MOEDA" VARCHAR2(3),"PREMIO" VARCHAR(120),"IMPOSTO CONSUMO"varchar2(120),"IMPOSTO SELO" varcha    TYPE filterReportproducao IS TABLE OF reportproducao;

    TYPE reportCresentSeguro IS RECORD("DATA" VARCHAR2(25), "NOVOS ADERENTE" NUMBER, "TODOS ADERENTES"  NUMBER, "NOVOS CONTRATOS" NUMBER, "TODOS CONTRATOS" NUMBER,"PREMIO EPOCA" VARCHAR(120),"PREMIO" VARCHAR(120));
    TYPE filtereportCresentSeguro IS TABLE OF reportCresentSeguro;


    TYPE filterSeguros IS TABLE OF VER_SEGURO%ROWTYPE;

    TYPE taxas IS RECORD ("MOEDA" VARCHAR2(64), "VALOR COMPRA" VARCHAR2(128),  "VALOR VENDA" VARCHAR2(120), "REGISTRO" VARCHAR2(20), "ESTADO" VARCHAR2(20));
    TYPE filterTaxas IS TABLE OF taxas;

    TYPE prestacao IS RECORD ("ID" NUMBER, "VALOR" VARCHAR2(120), "DATA" VARCHAR2(30), "VALOR_SF" FLOAT, "PAGO" VARCHAR2(120), "PAGO_SF" FLOAT, "ESTADO" VARCHAR2(15));
    TYPE filterPrestacao IS TABLE OF prestacao;

    TYPE itemPayment IS RECORD("ID" NUMBER, "CONTA" VARCHAR2(30), "DOCUMENTO" VARCHAR2(30), "BENEFICIARIO" VARCHAR2(160), "QUANTIDADE" FLOAT, "VALOR" VARCHAR2(120), "OBSERVACAO" VARCHAR2(200), REGISTRO VARCHAR2(100)) ;
    TYPE filterItemPayment IS TABLE OF itemPayment;


    TYPE reportRecebimento IS RECORD("DATA" VARCHAR2(20), "CODIGO" VARCHAR2(32), "RECIBO" VARCHAR2(20), "FORMA PAGAMENTO" VARCHAR2(50),"BANCO" VARCHAR2(100), "BENEFICIARIO" VARCHAR2(200), "DESCRICAO" VARCHAR2(1000), "VALOR" VARCHAR2(120));
    TYPE filterRecebimento IS TABLE OF reportRecebimento;

    TYPE reportPayment IS RECORD("DATA" VARCHAR2(20), "CODIGO" VARCHAR2(32),  "FORMA PAGAMENTO" VARCHAR2(50), "BANCO" VARCHAR2(50), "PAGAMENTO" VARCHAR2(124), "BENEFICIARIO" VARCHAR2(200), "DESCRICAO" VARCHAR2(1000), "VALOR" VARCHAR2(120));
    TYPE filterPayment IS TABLE OF reportPayment;

    TYPE reportProducaoConta IS RECORD ("DATA" VARCHAR2(10), "CLIENTE" VARCHAR2(160), "SEGURO" CHARACTER VARYING(120),"APOLICE" VARCHAR2(50), "DEBITO" VARCHAR2(30), "BANCO" VARCHAR2(100), "STD" VARCHAR2(120), "USD" VARCHAR2(120), "EUR" VARCHAR2 (120));
    TYPE filterProducaoConta IS TABLE OF reportProducaoConta;


    TYPE reportBalancete IS RECORD ("CONTA" VARCHAR(30), "DESIGNACAO" VARCHAR2(100), "DEBITO" VARCHAR2(130), "CREDITO" VARCHAR2(130), "DEVEDOR" VARCHAR2(130), "CREDOR" VARCHAR2(130));
    TYPE filterBalancete IS TABLE OF reportBalancete;

    TYPE reportContaMovimento IS RECORD("TIPO" VARCHAR2(30), "CONTA" VARCHAR2(30), "DESCRICAO" VARCHAR2(100), "CREDITO" VARCHAR2(125), "DEBITO" VARCHAR2(125));
    TYPE filterReportContaMovimento IS TABLE OF reportContaMovimento;


    TYPE reportTaxaProducao IS RECORD("CATEGORIA" CHARACTER VARYING(30), "VALOR TOTAL" CHARACTER VARYING (125), "VALOR LIQUIDO" CHARACTER VARYING(125), "FGA" CHARACTER VARYING(125), "CONSUMO" CHARACTER VARYING (125), "SELO" CHARACTER VARYING (125));
    TYPE filterReportTaxaProducao IS TABLE OF reportTaxaProducao;


    TYPE reportSinistro IS RECORD("ID" NUMBER, "REGISTRO" VARCHAR2(25), "CODIGO" CHARACTER VARYING(32), "SEGURO"VARCHAR2(60), "APOLICE" VARCHAR(30) , "CLIENTTE" VARCHAR(120), "DATA" CHARACTER VARYING(20), "LOCAL OCORENCIA" VARCHAR(50), "LOCAL INSPENSAO" VA    TYPE filterReportSinistro IS TABLE OF reportSinistro;


    TYPE reportProvisao IS RECORD("ID" NUMBER, "NUMERO DEBITO" CHARACTER VARYING(50), "SEGURADO" CHARACTER VARYING (160), "PREMIO LIQUIDO" CHARACTER VARYING(120), "DATA INICIO" CHARACTER VARYING(20), "DATA FIM" CHARACTER VARYING(20), "PROVISAO 10%" CHARACT    TYPE filterReportProvisao IS TABLE OF reportProvisao;

    TYPE contratoinformacao IS RECORD ("APOLICE"VARCHAR(30),"DATA INICIO" DATE ,"DATA FIM" DATE,"CLIENTE" NUMBER,"VALOR SEGURADO" FLOAT ,"VALOR PREMIO BRUTO" FLOAT,"VALOR EXCESSO" FLOAT,"ESTADO CONTRATO" NUMBER,"ESTADO PAGAMENTO"FLOAT);
    TYPE  filtercontratoinformacao IS TABLE OF contratoinformacao;

    TYPE reportMovimentacaoConsumivel IS RECORD ("ID" NUMBER, "DATA" CHARACTER VARYING (20), "CONSUMIVEL" CHARACTER VARYING(150), "TIPO MOVIMENTACAO" CHARACTER VARYING(50), "QUANTIDADE" NUMBER, "ORIGEM/DESTINO" CHARACTER VARYING(200), "FUNCIONARIO" CHARACT    TYPE filterMovimentacaoConsumivel IS TABLE OF reportMovimentacaoConsumivel;


    TYPE reportFuncionario IS RECORD ("ID" NUMBER,"CODIGO" CHARACTER VARYING(60), "NOME" CHARACTER VARYING(200), "FUNCAO" CHARACTER VARYING(150), "DEPARTAMENTO" CHARACTER VARYING(120), "CONTACTO" CHARACTER VARYING(200), "CONTA" CHARACTER VARYING(30), "BANC    TYPE filterReportFuncionario IS TABLE OF reportFuncionario;


    TYPE ReportSalario IS RECORD ("ID" NUMBER, "ID FUNCIONARIO" NUMBER, "BANCO" CHARACTER VARYING(300), "CODIGO" VARCHAR2(100), "NOME" CHARACTER VARYING(200), "DIAS" NUMBER, "S.BASE" VARCHAR2(150), "S.ALOJAMENTO" CHARACTER VARYING(150), "S.TRANSPORTE" CHAR    TYPE FilterReportSalario IS TABLE OF reportSalario;
    
    TYPE ReportSalarioTaxa IS RECORD("TIPO TAXA" CHARACTER VARYING (100), "NOME" CHARACTER VARYING(100), "VALOR" CHARACTER VARYING(300));
    TYPE FilterReportSalarioTaxa IS TABLE OF ReportSalarioTaxa;
    
    
END;