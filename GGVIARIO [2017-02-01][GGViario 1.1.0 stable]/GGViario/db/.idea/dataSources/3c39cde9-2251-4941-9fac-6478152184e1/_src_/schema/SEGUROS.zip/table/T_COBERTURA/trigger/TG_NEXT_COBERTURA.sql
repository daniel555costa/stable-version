create trigger TG_NEXT_COBERTURA
	before insert
	on T_COBERTURA
	for each row
begin  
   if inserting then 
      if :NEW."COBRE_ID" is null then 
         select SEQ_COBERTURA.nextval into :NEW."COBRE_ID" from dual; 
      end if; 
   end if; 
end;
