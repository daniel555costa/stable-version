create FUNCTION "FUNC_REG_SEGURO" (
    id_user VARCHAR2,
    codigo VARCHAR2,
    nome VARCHAR2,
    numero1 NUMBER,
    numero2 NUMBER
)
return varchar2
is
tt number;
begin
    -- Verificar a existencia do seguroo com o codigo requisitado
    select  count(*) into tt from t_seguro where codigo = seg_codigo;
    if tt != 0 then
      return 'Codigo existente';
    else 
        -- Registrando o novo seguro
        insert into t_seguro (seg_USER_id,seg_codigo,seg_nome)
        values(id_user,codigo,nome);
        return 'true';
    end if;       
end;