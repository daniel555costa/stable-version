create PROCEDURE PRC_UPD_TAXA (
ID_USER NUMBER,
NOME_MOEDA VARCHAR2,
COMPRA NUMBER,
VENDA NUMBER
)
IS

BEGIN

        update T_TAXA
             SET TX_STATE = 0
             where tx_state = 1 
                  and tx_moe_id in (select MOE_ID
                                  from T_MOEDA 
                                  where moe_nome =NOME_MOEDA)  ; 
                
      for i in (select *
                  from T_MOEDA 
                  where moe_nome =NOME_MOEDA and moe_state = 1 )loop
              
         insert into t_taxa (tx_compra,
                        tx_venda,
                        tx_moe_id)
                        values(COMPRA,
                              venda,
                              i.moe_id);                        
                               
      end loop;               
END;