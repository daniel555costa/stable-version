create trigger TG_NEXT_LINHACLINETE
	before insert
	on T_LINHACLIENTE
	for each row
begin  
   if inserting then 
      if :NEW."LCLI_ID" is null then 
         select SEQ_LINHACLIENTE.nextval into :NEW."LCLI_ID" from dual; 
      end if; 
   end if; 
end;
