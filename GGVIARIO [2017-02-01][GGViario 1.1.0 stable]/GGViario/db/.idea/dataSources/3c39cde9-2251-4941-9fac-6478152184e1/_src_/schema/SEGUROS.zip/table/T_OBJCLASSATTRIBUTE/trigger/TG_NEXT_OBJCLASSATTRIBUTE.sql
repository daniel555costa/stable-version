create trigger TG_NEXT_OBJCLASSATTRIBUTE
	before insert
	on T_OBJCLASSATTRIBUTE
	for each row
begin  
   if inserting then 
      if :NEW."CLASSATB_ID" is null then 
         select SEQ_OBJCLASSATTRIBUTE.nextval into :NEW."CLASSATB_ID" from dual; 
      end if; 
   end if; 
end;
