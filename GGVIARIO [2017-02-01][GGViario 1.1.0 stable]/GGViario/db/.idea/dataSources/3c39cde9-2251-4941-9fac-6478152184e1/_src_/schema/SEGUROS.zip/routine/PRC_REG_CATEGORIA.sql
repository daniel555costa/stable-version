create PROCEDURE           "PRC_REG_CATEGORIA" (
NOME VARCHAR2,
USER_ID VARCHAR
)
IS
TT NUMBER;

BEGIN
    SELECT COUNT(*) INTO TT FROM T_OBJECTYPE WHERE  UPPER(OBJT_DESC)= UPPER(NOME) AND OBJT_T_ID = 10;
    IF TT = 0 THEN 
        INSERT INTO T_OBJECTYPE(OBJT_T_ID,
                                OBJT_USER_ID,
                                OBJT_DESC)
                                          VALUES(10,
                                                  USER_ID,
                                                  NOME);       
    ELSE 
        UPDATE T_OBJECTYPE  
            SET OBJT_STATE = 1 ,
                OBJT_DESC = NOME
            WHERE UPPER(OBJT_DESC)= UPPER(NOME)AND UPPER(OBJT_T_ID)= UPPER(10);

    END IF;  
END;