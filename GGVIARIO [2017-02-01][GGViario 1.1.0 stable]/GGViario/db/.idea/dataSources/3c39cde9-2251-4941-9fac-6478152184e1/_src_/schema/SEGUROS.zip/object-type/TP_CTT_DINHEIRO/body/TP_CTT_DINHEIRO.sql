create TYPE BODY           "TP_CTT_DINHEIRO" AS

  CONSTRUCTOR FUNCTION TP_CTT_DINHEIRO (distanciaBanco VARCHAR2,
                                         distanciaCoreio VARCHAR2,
                                         distanciaOutra VARCHAR2,
                                         
                                         transpDinheiro VARCHAR2,
                                         preocupacao VARCHAR2,
                                         tempoPermanencio VARCHAR2,
                                         dinheiroPaga CHAR-- {Y - Sim  | N- Nao}
                                         ) RETURN SELF AS RESULT AS
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_CTT_DINHEIRO.TP_CTT_DINHEIRO
    SELF.distanciaBanco := distanciaBanco;
    SELF.distanciaCoreio := distanciaCoreio;
    SELF.distanciaOutra := distanciaOutra;
     
    SELF.transpDinheiro := transpDinheiro;
    SELF.preocupacao := preocupacao;
    SELF.tempoPermanencio := tempoPermanencio;
    SELF.dinheiroPaga := dinheiroPaga;
    RETURN;
  END TP_CTT_DINHEIRO;

END;