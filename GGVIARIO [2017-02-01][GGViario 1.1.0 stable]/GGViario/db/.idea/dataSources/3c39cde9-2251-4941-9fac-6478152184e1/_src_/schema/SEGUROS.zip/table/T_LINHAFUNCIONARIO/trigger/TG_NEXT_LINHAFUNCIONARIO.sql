create trigger TG_NEXT_LINHAFUNCIONARIO
	before insert
	on T_LINHAFUNCIONARIO
	for each row
begin  
   if inserting then 
      if :NEW."LFUNC_ID" is null then 
         select SEQ_LINHAFUNCIONARIO.nextval into :NEW."LFUNC_ID" from dual; 
      end if; 
   end if; 
end;
