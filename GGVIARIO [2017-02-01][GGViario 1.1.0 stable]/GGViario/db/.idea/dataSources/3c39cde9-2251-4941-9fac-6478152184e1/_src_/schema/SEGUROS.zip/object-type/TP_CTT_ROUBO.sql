create TYPE           "TP_CTT_ROUBO"                                          UNDER TP_CTT
(
   -- Tipo de edifico
  EDIFICIO_TIPO VARCHAR2(100), -- Coresponde ao tipoo de edificio {1 - Fabrica | 2- Armanzem | 3 - Loga | <!> Outro}
  EDIFICIO_RES_EDENDERECO NUMBER(8), -- Endereoco do edificio
  EDIFICIO_TEMPOCUPACAO VARCHAR2(50), -- O tempo em que o edificio e ocupado
  EDIFICIO_DATAOCUPACAO VARCHAR2(150), -- A data em que o edificio foi ocupada
  CROFE_VALOR FLOAT, -- O valor no crof
  CROFE_MARCA VARCHAR2(100), -- A marca do crofe
  CROFE_DATAQUISICAO VARCHAR2(50), -- A data em que o  crof foi adiquirido
  
  CONSTRUCTOR FUNCTION TP_CTT_ROUBO( EDIFICIO_TIPO VARCHAR2,
                                     EDIFICIO_RES_IDENDERECO NUMBER,
                                     EDIFICIO_TEMPOCUPACAO VARCHAR2,
                                     EDIFICIO_DATAOCUPACAO VARCHAR2,
                                     CROFE_VALOR FLOAT,
                                     CROFE_MARCA VARCHAR2,
                                     CROFE_DATAQUISICAO DATE) RETURN SELF AS RESULT,
  
  STATIC FUNCTION INSTANCEOF RETURN NUMBER
);