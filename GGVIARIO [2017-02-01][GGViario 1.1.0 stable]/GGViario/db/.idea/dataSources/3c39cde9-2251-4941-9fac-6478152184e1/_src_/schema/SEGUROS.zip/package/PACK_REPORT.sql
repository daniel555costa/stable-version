create PACKAGE           "PACK_REPORT" IS
    
    TYPE filterProducaoTravel IS TABLE OF VER_PRODUCAO_TRAVEL%ROWTYPE;
    
    FUNCTION reportClient (idSeguro NUMBER,dataInicio DATE, dataFim DATE
                            )RETURN PACK_TYPE.filterReportClient PIPELINED;



     FUNCTION reportCrescentTime (dataInicio DATE, dataFim DATE,tipo NUMBER -- 1 - DIA | 2 - MES | 3 - ANO
                                      
                                  )RETURN PACK_TYPE.filterReportCrescentTime PIPELINED;
    
    
    
    
      FUNCTION reportproducao( dataInicio DATE,dataFim DATE
                            ) RETURN PACK_TYPE.filterReportproducao PIPELINED;
      
    
    
    
     FUNCTION REPORTSEGURO (dataInicio DATE, dataFim DATE
                          ) RETURN PACK_TYPE.filterReportSeguro PIPELINED;
  
     
     
     
     FUNCTION repostStatusCliente(idCliente NUMBER, dataInicio DATE,dataFim date
                                  )RETURN PACK_TYPE.filterReportStatuClient PIPELINED;
                                  
                                  
                                  
    FUNCTION  reportproducaotipo(dataInicio DATE,dataFim DATE,ID NUMBER, idSeguro NUMBER 
              )RETURN PACK_TYPE.filterReportProducao PIPELINED;
              
              
           
    FUNCTION reportCresentSeguro (dataInicio DATE,dataFim DATE, typeDate NUMBER,idSeguro NUMBER
              )RETURN PACK_TYPE.filtereportCresentSeguro PIPELINED ;  
              
              
    FUNCTION reportSegurosCompras (dataInicio DATE, dataFim DATE) RETURN PACK_TYPE.filterSeguros PIPELINED ;
    
    FUNCTION reportTaxas (nomeMoeda VARCHAR2) RETURN PACK_TYPE.filterTaxas PIPELINED;
    
    
    
    FUNCTION reportRecebimento (dataInicio DATE, dataFim DATE) RETURN PACK_TYPE.filterRecebimento PIPELINED;
    
    FUNCTION reportPagamento(dataInicio DATE, dataFim DATE) RETURN PACK_TYPE.filterPayment PIPELINED;
    
    
    FUNCTION reportProducaoContaNotTravel (dateInicio DATE, dateFim DATE, idCaracteristica NUMBER) RETURN PACK_TYPE.filterProducaoConta PIPELINED;
    
    FUNCTION reportProducaoTravel (dateInicio date, dateFIm date) return PACK_REPORT.filterProducaoTravel pipelined;
    
    
    FUNCTION reportContaMoviment (dateInicio DATE, dateFim DATE, listConta tb_array_string) RETURN PACK_TYPE.filterReportContaMovimento PIPELINED;
     
    /*
        O valorNicon corresponde ao somatorio de todos o nicon seguro 
        -> Esse somatorio e por causa da impatibilidade de caracter de numero de oracle em relacao a java
    */
    FUNCTION reportTaxaProducao(dataInicio DATE, dataFim DATE, valorNicon FLOAT) RETURN PACK_TYPE.filterReportTaxaProducao PIPELINED;
    
    TYPE listValueContrato IS TABLE OF CHARACTER VARYING(120);
    FUNCTION reportTaxaNicon(dataInicio DATE, dataFim DATE) RETURN listValueContrato PIPELINED;
    
END;