create trigger TG_NEXT_PERCENTAGEIMPOSTO
	before insert
	on T_IMPOSTOTAXA
	for each row
begin  
   if inserting then 
      if :NEW."IMPTAX_ID" is null then 
         select SEQ_PERCENTAGEMIMPOSTO.nextval into :NEW."IMPTAX_ID" from dual; 
      end if; 
   end if; 
end;
