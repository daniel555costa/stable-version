create trigger TG_NEXT_PAIS
	before insert
	on T_PAIS
	for each row
begin  
   if inserting then 
      if :NEW."PAIS_ID" is null then 
         select SEQ_PAIS.nextval into :NEW."PAIS_ID" from dual; 
      end if; 
   end if; 
end;
