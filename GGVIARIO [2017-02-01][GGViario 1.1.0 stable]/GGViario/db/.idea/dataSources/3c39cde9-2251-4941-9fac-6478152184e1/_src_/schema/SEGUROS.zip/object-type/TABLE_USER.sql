create TYPE           "TABLE_USER"                                          AS
TABLE OF TYPE_USER;