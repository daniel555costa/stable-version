create TYPE           "TP_PAGAMENTO"                                          
  IS
  OBJECT (NIF VARCHAR2(9),
          DOCUMENTO VARCHAR2(50),
          NOME VARCHAR2(50),
          APELIDO VARCHAR2(50),
          CREDITO VARCHAR2(126),
          PAGAMENTO VARCHAR(126),
          BANCO VARCHAR2(60),
          VALOR VARCHAR2(126));