create FUNCTION           "FUNC_CTTINF_CARGAMARTIMA" 
(
  idUser NUMBER,
  idContrato NUMBER,

  pais_origem NUMBER,
  pais_destino NUMBER,
  portoCarga VARCHAR2,
  portoDescarga VARCHAR2,
  nomeNavio VARCHAR2,
  valorMaximoRisco  FLOAT, -- valor limite indenizaçao
  
  -- COBRE -- Ambito da cobertura
  escolha_cobertura NUMBER, -- {142 - Todos Riscos, 143 - Restrita, 144 - Mais Restrita}
  premioCobertura FLOAT, -- VAlor de premio cobertura selecionada
  taxa FLOAT,
  propositoSeguro VARCHAR2,
  
  -- VMAXRISCO >> Valor maximo em risco para
  qualquerNavio VARCHAR2,
  qualquerLocalizacao BINARY_DOUBLE,
  anualMercadoria VARCHAR, -- Anula para cada mercadoria
  
  --FSEND >> Forma de emvio
  escolha_formaEnvio NUMBER, -- {VER_FORMA_ENVIO}
  
  --OTHER >> Outros
  tempoNegocio NUMBER,
  custoPorto NUMBER, -- Custo do porto (10% 20%)
  
  
  -- Informacao do segurado 
  infoSeg_descMercadoria VARCHAR2,
  infoSeg_areaActividade VARCHAR2,
  infoSeg_segEfectuadoComp VARCHAR2,
  infoSeg_nameCompania VARCHAR2,
  
  -- MTRANS >> Mercadorias Transportadas
  lista_mercadoriaTransportada TB_ARRAY_STRING -- {VER_TIPOMERCADORIA}
)
RETURN VARCHAR2
IS
     resp VARCHAR2(100);
     parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();                                                                  

BEGIN
    -- Classe = 8 CTT INFO de carga maritima
    -- Essa funcao serve para criar um objecto do tipo TP_CTT_CARGAMARTIMA publica e armazenala na entidade contrato
    PRC_ADD_LISTVALUE(parsValues, null, 'paisOrigem', pais_origem);
    PRC_ADD_LISTVALUE(parsValues, null, 'paisDestino', pais_destino);
    PRC_ADD_LISTVALUE(parsValues, null, 'portoCarga', portoCarga);
    PRC_ADD_LISTVALUE(parsValues, null, 'portoDescarga', portoDescarga);
    PRC_ADD_LISTVALUE(parsValues, null, 'nomeNavio', nomeNavio);
    PRC_ADD_LISTVALUE(parsValues, null, 'propositoSeguro', propositoSeguro);
    PRC_ADD_LISTVALUE(parsValues, null, 'qualquerNavio', qualquerNavio);
    PRC_ADD_LISTVALUE(parsValues, null, 'qualquerLocalizacao', qualquerLocalizacao);
    PRC_ADD_LISTVALUE(parsValues, null, 'anualMercadoria', anualMercadoria);
    PRC_ADD_LISTVALUE(parsValues, null, 'formaEnvio', escolha_formaEnvio);
    PRC_ADD_LISTVALUE(parsValues, null, 'tempoNegocio', tempoNegocio);
    PRC_ADD_LISTVALUE(parsValues, null, 'custoPorto', custoPorto);
    PRC_ADD_LISTVALUE(parsValues, null, 'descricaoMercadoria', infoSeg_descMercadoria);
    PRC_ADD_LISTVALUE(parsValues, null, 'areaActivid', infoSeg_areaActividade);
    PRC_ADD_LISTVALUE(parsValues, null, 'seguroEfectuadoCompanhia', infoSeg_segEfectuadoComp);
    PRC_ADD_LISTVALUE(parsValues, null, 'compainhaComEsseSeguro', infoSeg_nameCompania);
    
    PACK_REGRAS.REGOBJECTVALUES(idUser, null, idContrato, 8, parsValues);
    
    IF lista_mercadoriaTransportada.COUNT = 0 THEN
      FOR I IN 1..lista_mercadoriaTransportada.COUNT LOOP
          resp := FUNC_REG_RESPOSTA(idUser, idContrato, lista_mercadoriaTransportada(i), 1, NULL);
      END LOOP;
    END IF;
    
    
    
    PRC_REG_COBERTURACONTRATO(escolha_cobertura, idContrato, idUser, valorMaximoRisco, taxa, premioCobertura );
    
    
                                      
    RETURN 'true';
END FUNC_CTTINF_CARGAMARTIMA;