create trigger TG_NEXT_SALARIOAVANCO
	before insert
	on T_SALARIOAVANCO
	for each row
begin  
   if inserting then 
      if :NEW."SALAVANCO_ID" is null then 
         select SEQ_SALARIOAVANCO.nextval into :NEW."SALAVANCO_ID" from dual; 
      end if; 
   end if; 
end;
