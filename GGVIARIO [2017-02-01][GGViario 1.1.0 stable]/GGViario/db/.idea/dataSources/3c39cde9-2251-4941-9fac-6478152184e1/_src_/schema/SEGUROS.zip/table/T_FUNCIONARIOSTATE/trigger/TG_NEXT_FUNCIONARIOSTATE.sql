create trigger TG_NEXT_FUNCIONARIOSTATE
	before insert
	on T_FUNCIONARIOSTATE
	for each row
begin  
   if inserting then 
      if :NEW."FUNCSTATE_ID" is null then 
         select SEQ_FUNCIONARIOSTATE.nextval into :NEW."FUNCSTATE_ID" from dual; 
      end if; 
   end if; 
end;
