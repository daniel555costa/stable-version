create TYPE           "TP_OBJ_CARGAMARITIMA"                                          UNDER TP_OBJ
   (
     INTERESE VARCHAR(100),
     CONSIGNACOES VARCHAR(100),
     MODO_DE_EMBALAGEM VARCHAR(100),
     CONSTRUCTOR FUNCTION TP_OBJ_CARGAMARITIMA( 
                                                INTERESE VARCHAR,
                                                CONSIGNACOES VARCHAR,
                                                MODO_DE_EMBALAGEM VARCHAR)RETURN SELF AS RESULT,
    STATIC FUNCTION INSTANCEOF RETURN NUMBER
                                                
   )FINAL;