create PACKAGE BODY           "PACK_RH" IS

  function funcRegCategori ( idUser NUMBER,
                             idTypeCategory VARCHAR2,
                             idLevelCAtegory NUMBER,
                             numDIas NUMBER,
                             baseSalary FLOAT,
                             houseSubvention FLOAT,
                             lunchSubvention FLOAT,
                             transportSubventiion FLOAT,
                             bonusAlmoco FLOAT,
                             tipoOperacacao NUMBER
                            )
                             RETURN VARCHAR2 
  IS
     tt NUMBER;
  BEGIN
     SELECT COUNT(*) INTO tt
         FROM T_CATEGORY CA
         WHERE CA.CAT_OBJT_LEVELCAT = idLevelCAtegory
           AND CA.CAT_OBJT_TYPECATEGORY = idTypeCategory
           AND CA.CAT_STATE = 1;
     
     IF tipoOperacacao = 1 AND tt != 0 THEN  
        RETURN 'false;'|| FUNC_ERROR('EXTRUCT ALERED EXIST');
     END IF;
     
     -- Fechar a categoria antirior que esta ligado a essa categoria
     UPDATE T_CATEGORY CA
        SET CA.CAT_STATE = 0
        WHERE CA.CAT_OBJT_LEVELCAT = idLevelCAtegory
           AND CA.CAT_OBJT_TYPECATEGORY = idTypeCategory
           AND CA.CAT_STATE = 1;
     
     INSERT INTO T_CATEGORY(CAT_OBJT_LEVELCAT,
                            CAT_USER_ID,
                            CAT_OBJT_TYPECATEGORY,
                            CAT_NUMDIAS,
                            CAT_BASESALARY, 
                            CAT_HOUSESUBVENTION,
                            CAT_LUNCHSUBVENTION,
                            CAT_TRANSPORTSUBVENTION,
                            CAT_ALMOCOBONUS)
                            VALUES(idLevelCAtegory,
                                   idUser,
                                   idTypeCategory,
                                   numDIas,
                                   baseSalary,
                                   houseSubvention,
                                   lunchSubvention,
                                   transportSubventiion,
                                   bonusAlmoco);
      RETURN 'true;Sucesso!';
  END funcRegCategori;
  
  
  function funcRegItem (idUser NUMBER,
                         nomeCategoria CHARACTER VARYING,
                         nameItem CHARACTER VARYINg,
                         descrision CHARACTER VARYING,
                         idItemEdit NUMBER
                         ) RETURN VARCHAR2
  IS 
     idItem NUMBER;
     idCategoria NUMBER;
     -- 26	Categoria Consumiveis	1	1
  BEGIN
     idCategoria := PACK_REGRAS.getObjectID(nomeCategoria, idUser, 26, NULL, NULL);
     
     
     --
     IF idItemEdit IS NOT NULL THEN
         UPDATE T_ITEM IT
            SET IT.ITEM_OBJT_CATEGORYITEM = idCategoria,
                IT.ITEM_NAME = nameItem
            WHERE IT.ITEM_ID = idItemEdit;
         RETURN 'true;UPDATED';
     END IF;
     
     -- Varificar a duplição do item
     SELECT COUNT(*) into idItem
        FROM T_ITEM i
        WHERE UPPER(i.ITEM_NAME) =  UPPER(nameItem);
        
     -- Quando existir um item com o novo nome então abortar a operaca
     IF idItem != 0 THEN
        RETURN 'false;'||FUNC_ERROR('ITEM NAME EXIST');
     END IF;
     
     
     
     
     -- Caso coontrario registrar o item o obter o seu id
     INSERT INTO T_ITEM(ITEM_USER_ID,
                        ITEM_OBJT_CATEGORYITEM,
                        ITEM_NAME,
                        ITEM_DESC)
                        VALUES (idUser,
                                idCategoria,
                                nameItem,
                                descrision)
                        RETURNING ITEM_ID INTO idItem;
     RETURN 'true;'||idItem;
  END;
  
  
 
  
  
  function funcRegItemMovimentation(idUser NUMBER,
                                     idItem NUMBER,
                                     idFuncionarioResponsavel NUMBER,
                                     idTipoMovimento number, -- VER_TYPE_MOVIMENTITEM
                                     quantity number,
                                     estimatedCost float,
                                     sourceDestination CHARACTER VARYING,
                                     observation CHARACTER VARYING
                                     )RETURN CHARACTER VARYING
  IS 
  BEGIN
     INSERT INTO T_ITEMOVIMENTATION (ITEMOV_ITEM_ID,
                                     ITEMOV_USER_ID,
                                     ITEMOV_FUNC_ID,
                                     ITEMOV_TITEMOV_ID,
                                     ITEMOV_QUANTITY,
                                     ITEMOV_ESTIMATIVECOST,
                                     ITEMOV_SOURCEDESTIANTION,
                                     ITEMOV_OBS)
                                     VALUES (idItem,
                                             idUser,
                                             idFuncionarioResponsavel,
                                             idTipoMovimento,
                                             quantity,
                                             estimatedCost,
                                             sourceDestination,
                                             observation);
     RETURN 'true;Sucesso';
  END;
  
  
  
  -- novoEstado {0 - siginifica demitir | 2 - seginifica suspende}
  FUNCTION funcSuspenderFuncionario (idUser NUMBER, idFuncionario NUMBER, descrincao character varying, novoEstado NUMBER) RETURN CHARACTER VARYING
  IS 
  BEGIN
     -- fechar o antigo estado do funcionario
     UPDATE T_FUNCIONARIOSTATE FU
        SET FU.FUNCSTATE_STATE = 0,
            FU.FUNCSTATE_DTOUT = SYSTIMESTAMP
        WHERE FU.FUNCSTATE_FUNC_ID = idFuncionario;
        
    -- Desabilitar o funcionario do sistema
    UPDATE T_FUNCIONARIO F
       SET F.FUNC_STATE  = (CASE 
                               WHEN novoEstado = 0 THEN -1
                               ELSE 0
                            END)
       WHERE F.FUNC_ID = idFuncionario;
        
     INSERT INTO T_FUNCIONARIOSTATE (FUNCSTATE_USER_ID,
                                     FUNCSTATE_FUNC_ID,
                                     FUNCSTATE_OBS,
                                     FUNCSTATE_NEWSTATE)
                                     VALUES(idUser,
                                            idFuncionario,
                                            descrincao,
                                            novoEstado);
     RETURN 'true';
  END;
  
  
  FUNCTION funcFeriarFuncionario (idUser NUMBER, idFuncionario NUMBER, dateInicio DATE, dateFim DATE) RETURN CHARACTER VARYING
  IS
  BEGIN
      -- fechar o antigo estado do funcionario
     UPDATE T_FUNCIONARIOSTATE FU
        SET FU.FUNCSTATE_STATE = 0,
            FU.FUNCSTATE_DTOUT = SYSTIMESTAMP
        WHERE FU.FUNCSTATE_FUNC_ID = idFuncionario;
        
    -- Desabilitar o funcionario do sistema
    UPDATE T_FUNCIONARIO F
       SET F.FUNC_STATE  = 0
       WHERE F.FUNC_ID = idFuncionario;
       
     INSERT INTO T_FUNCIONARIOSTATE (FUNCSTATE_USER_ID,
                                     FUNCSTATE_FUNC_ID,
                                     FUNCSTATE_NEWSTATE,
                                     FUNCSTATE_DTINICIO,
                                     FUNCSTATE_DTFIM)
                                     VALUES(idUser,
                                            idFuncionario,
                                            3,
                                            dateInicio,
                                            dateFim);
     RETURN 'true;Sucess';
  END;
  
  
  
  FUNCTION getDiasRestante(idUser NUMBER, idFuncionario NUMBER) RETURN NUMBER
  IS
     currentYear NUMBER := TO_NUMBER(TO_CHAR(SYSDATE, 'YYYY'));
     startWorkYear NUMBER;
     funcionario T_FUNCIONARIO%ROWTYPE;
     linhasFerias T_FUNCIONARIOSTATE%ROWTYPE;
     hasFeria NUMBER;
     restanteFerias NUMBER := 0;
     dateFim DATE;
  BEGIN
     SELECT * INTO funcionario
        FROM T_FUNCIONARIO  FUNC
        WHERE FUNC.FUNC_ID = idFuncionario;
      
    startWorkYear := TO_NUMBER(TO_CHAR(funcionario.FUNC_DTREG, 'YYYY'));
    
    FOR I IN startWorkYear..currentYear LOOP
       restanteFerias := restanteFerias + 30;
       SELECT COUNT(*) INTO hasFeria
          FROM T_FUNCIONARIOSTATE FUNSTATE 
          WHERE FUNSTATE.FUNCSTATE_FUNC_ID = idFuncionario 
             AND FUNSTATE.FUNCSTATE_NEWSTATE = 3
             AND TO_NUMBER(TO_CHAR(FUNSTATE.FUNCSTATE_DTREG, 'YYYY')) = I;
             
       IF hasFeria != 0 THEN
          SELECT * INTO linhasFerias
              FROM T_FUNCIONARIOSTATE fstate 
              WHERE fstate.FUNCSTATE_FUNC_ID = idFuncionario
                 AND fstate.FUNCSTATE_NEWSTATE =3
                 AND TO_NUMBER(TO_CHAR(fstate.FUNCSTATE_DTREG, 'YYYY')) = I;
       
          IF linhasFerias.FUNCSTATE_STATE = 0 THEN
              dateFim := TO_DATE(TO_CHAR(linhasFerias.FUNCSTATE_DTOUT, 'YYYY-MM-DD'), 'YYYY-MM-DD');
          ELSIF linhasFerias.FUNCSTATE_STATE = 1 AND SYSDATE >= linhasFerias.FUNCSTATE_DTINICIO THEN
              dateFim := SYSDATE;
          ELSE dateFim := linhasFerias.FUNCSTATE_DTFIM;
          END IF;
          restanteFerias := restanteFerias - (TO_DATE(TO_CHAR(linhasFerias.FUNCSTATE_DTINICIO, 'YYYY-MM-DD'), 'YYYY-MM-DD') - dateFIm);
       END IF;
    END LOOP;
    
    
    RETURN restanteFerias;
    
  END;
  
  FUNCTION regProcessSalary (idUser NUMBER, ano NUMBER, mes NUMBER) RETURN VARCHAR2
  IS
     linhaProcess T_PROCESSALARY%ROWTYPE;
     dataSalario DATE;
     tt NUMBER;
     codProcess CHARACTER VARYING (32);
     idLastProcess NUMBER;
  BEGIN
     dataSalario := TO_DATE(ano||'-'||mes||'-01', 'YYYY-MM-DD');
     
     SELECT COUNT(*) INTO tt
        FROM T_PROCESSALARY PSAL
        WHERE TO_CHAR(PSAL.PROSAL_DATA, 'YYYY-MM') = TO_CHAR(dataSalario, 'YYYY-MM')
           AND PSAL.PROSAL_STATE != -1;
           
          
      IF tt != 0 THEN 
         RETURN 'false;'||FUNC_ERROR('PROCESS SALARI IN MONTH ALERED PROCESSED');
      END IF;
      
        
      codProcess := TO_CHAR(dataSalario, 'MMYYYY')||TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFF3');
      
      INSERT INTO T_PROCESSALARY (PROSAL_USER_ID,
                                  PROSAL_DATA,
                                  PROSAL_COD,
                                  PROSAL_TOTAL)
                                  VALUES(idUser,
                                         dataSalario,
                                         codProcess,
                                         0) RETURNING PROSAL_ID INTO idLastProcess;
                                         
      RETURN 'true;'||idLastProcess;
  END;
  
  
  FUNCTION funcProcessSalario(idUser NUMBER, idFuncionario NUMBER, idProcesso NUMBER) RETURN VARCHAR2
  IS
     salarioFuncionario PACK_RH.Salario;
     hasProcessed NUMBER;
     sMes CHARACTER VARYING(10);
     dataSalario DATE;
  BEGIN
  
    SELECT * 
         INTO salarioFuncionario
       FROM TABLE(PACK_RH.functPreviexProcessSalario(idUser, idFuncionario)) SAL;
       
    -- Verificar se o salario foi realmete processado
    IF salarioFuncionario."SALARIO.RESULT" = 'false' THEN
       RETURN salarioFuncionario."SALARIO.MESSAGE";
    END IF;
    
    SELECT COUNT(*) INTO hasProcessed
       FROM T_SALARIO SAL
          INNER JOIN T_PROCESSALARY PSAL ON SAL.SAL_PROSAL_ID = PSAL.PROSAL_ID
       WHERE PSAL.PROSAL_DATA = dataSalario
          AND SAL.SAL_STATE IN (1, 0)
          AND SAL.SAL_FUNC_ID = idFuncionario
       ;
    
    IF hasProcessed > 0 THEN
       RETURN 'false;'||FUNC_ERROR('SALARY HAS PROCESSED IN CURRENT MONTH');
    END IF;
    
    INSERT INTO T_SALARIO (SAL_USER_ID,
                           SAL_FUNC_ID,
                           SAL_CAT_ID,
                           SAL_IMPTAX_FUNCIONARIO,
                           SAL_IMPTAX_EMPRESA,
                           SAL_IMPTAX_IRS,
                           SAL_COMISAO_ID,
                           SAL_SITUA_ID,
                           SAL_AVANCO_ID,
                           SAL_VALORFIANL,
                           SAL_TOTAL,
                           SAL_SALNACIO_ID,
                           SAL_PROSAL_ID)
                           VALUES(idUser,
                                  idFuncionario,
                                  salarioFuncionario."ESTRUTURA.ID",
                                  salarioFuncionario."ID SS FUNCIONARIO",
                                  salarioFuncionario."ID SS EMPRESA",
                                  salarioFuncionario."ID IRS",
                                  salarioFuncionario."ID COMISAO",
                                  salarioFuncionario."ID SITUACAO FAMILIAR",
                                  salarioFuncionario."ID AVANCO SALARIAL",
                                  salarioFuncionario."SALARIO FINAL MES",
                                  salarioFuncionario."SALARIO IMPOSTO EMPRESA",--  salarioImpostoEmpresa,
                                  salarioFuncionario."ID SALARIO BASE NACIONAL", -- salarioBaseNacional.SALNACIO_ID);
                                  idProcesso
                                  );
     RETURN 'true;Sucess';
  END;
  
  
   FUNCTION funcEndProcess(idProcess NUMBER) return character varying
   IS
   BEGIN
       UPDATE T_PROCESSALARY P
          SET P.PROSAL_STATE = 1
          WHERE P.PROSAL_ID = idProcess;
       RETURN 'true;Sucess';
   END;
  
  
  FUNCTION funcDefinirSalarioBaseNacional (valorSalario FLOAT, idUser NUMBER) RETURN CHARACTER VARYING
  IS 
  BEGIN
      -- DESABILITAR O SALARIO NACIONAL
      UPDATE T_SALARIONACIONAL SALN
         SET SALN.SALNACIO_STATE = 0 
         WHERE SALN.SALNACIO_STATE = 1;
         
      -- Criar a nova taxa de salario base
      INSERT INTO T_SALARIONACIONAL(SALNACIO_VALOR,
                                    SALNACIO_USER_ID)
                                    VALUES(valorSalario,
                                           idUser);
      RETURN 'true;Sucesso';
  END;
  
  -- ESSA FUNCAO SERVER PARA REGISTRA O AVANCO SALARIAL
    FUNCTION funcRegAvancoSalarial (idUser NUMBER, idFuncionario NUMBER, numDocumento CHARACTER VARYING, observacao CHARACTER VARYING, valor FLOAT, dataAvanco DATE) RETURN CHARACTER VARYING
    IS 
       salarioAvanco T_SALARIOAVANCO%ROWTYPE;
       exist NUMBER;
    BEGIN
    
        SELECT COUNT(*) INTO exist
            FROM T_SALARIOAVANCO SALA 
            WHERE UPPER(SALA.SALAVANCO_NUMDOC) = UPPER(numDocumento);
            
        IF exist != 0 THEN
           RETURN 'false;'||FUNC_ERROR('SALARIO.AVANCO COD DOC ALERED EXIST');
        END IF;
            
        -- VERIFICAR SE EXISTE ALGUM AVANCO SALARIAL PACOTE
        SELECT COUNT(*) INTO exist
           FROM T_SALARIOAVANCO SAL
           WHERE  SAL.SALAVANCO_FUNC_ID  = idFuncionario
              AND SAL.SALAVANCO_STATE = 1
              AND SAL.SALAVANCO_SALAVANCO_ID IS NULL 
              AND SAL.SALAVANCO_NUMDOC IS NULL
              AND SAL.SALAVANCO_DATA IS NULL;
              
        IF exist  = 0 THEN
            -- CRIAR O PACOTE DE AVANCO SALARIAL
            INSERT INTO T_SALARIOAVANCO (SALAVANCO_FUNC_ID,
                                         SALAVANCO_USER_ID)
                                         VALUES(idFuncionario,
                                                idUser);
        END IF;
        
        
        SELECT * INTO salarioAvanco
           FROM T_SALARIOAVANCO SAL
           WHERE SAL.SALAVANCO_FUNC_ID  = idFuncionario
              AND SAL.SALAVANCO_STATE = 1
              AND SAL.SALAVANCO_SALAVANCO_ID IS NULL 
              AND SAL.SALAVANCO_NUMDOC IS NULL
              AND SAL.SALAVANCO_DATA IS NULL;
              
        INSERT INTO T_SALARIOAVANCO (SALAVANCO_FUNC_ID,
                                     SALAVANCO_USER_ID,
                                     SALAVANCO_VALOR,
                                     SALAVANCO_OBS,
                                     SALAVANCO_SALAVANCO_ID,
                                     SALAVANCO_DATA,
                                     SALAVANCO_NUMDOC)
                                     VALUES(idFuncionario,
                                            idUser,
                                            valor,
                                            observacao,
                                            salarioAvanco.SALAVANCO_ID,
                                            dataAvanco,
                                            numDocumento);
                                            
        -- Incrementar o valor total do avanco salarial do funcionario                                
        UPDATE T_SALARIOAVANCO SAL
           SET SAL.SALAVANCO_VALOR = SAL.SALAVANCO_VALOR + salarioAvanco.SALAVANCO_VALOR
           WHERE SAL.SALAVANCO_ID =  salarioAvanco.SALAVANCO_ID;
           
        RETURN 'true;Sucess';
              
    END;
    
    
    FUNCTION funcCanselAvancoSalarial(iduser NUMBER, idAvanco NUMBER) RETURN VARCHAR2
    IS
       linhaAvancoSalario T_SALARIOAVANCO%ROWTYPE;
    BEGIN
       SELECT * INTO linhaAvancoSalario
          FROM T_SALARIOAVANCO AV
          WHERE AV.SALAVANCO_ID = idAvanco;
       
       IF linhaAvancoSalario.SALAVANCO_STATE != 1 THEN
          RETURN 'false;'||FUNC_ERROR('SALARIO.AVANCO IS FINICHED');
       END IF;
       
       UPDATE T_SALARIOAVANCO SALA
          SET SALA.SALAVANCO_STATE = -1
          WHERE SALA.SALAVANCO_ID = idAvanco;
          
       RETURN 'true';
    END;
    
    /*
    TYPE avancoSalarial IS RECORD("ID" NUMBER, "DATA" CHARACTER VARYING(16), "VALOR" CHARACTER VARYING (128), "DOCUMENTO" CHARACTER VARYING(32), "OBSERVACAO" CHARACTER VARYING(256) ,"REGISTRO" CHARACTER VARYING, "ESTADO" CHARACTER VARYING(32));
   
    */
    
    FUNCTION loadAvancoSalarial(idFuncionario NUMBER, dataInicio DATE, dataFim DATE) RETURN avancoSalarialFuncionario PIPELINED
    IS
       totalPendente FLOAT :=0;
       totalDescontado FLOAT :=0;
       avanco PACK_RH.avancoSalarial;
       
    BEGIN
       
      /*
      TYPE avancoSalarial IS RECORD("ID" NUMBER,
      "DATA" CHARACTER VARYING(16), 
      "VALOR" CHARACTER VARYING (128),
      "DOCUMENTO" CHARACTER VARYING(32),
      "OBSERVACAO" CHARACTER VARYING(256), 
      "REGISTRO" CHARACTER VARYING(16),
      "ESTADO" CHARACTER VARYING(32));
      TYPE avancoSalarialFuncionario IS TABLE OF avancoSalarial;
      */
      
      FOR SA IN(SELECT SA.SALAVANCO_ID,
                       TO_CHAR(SA.SALAVANCO_DATA, 'DD-MM-YYYY'),
                       FUNC.FUNC_NOME||' '||FUNC.FUNC_APELIDO AS "FUNCIONARIO",
                       SA.SALAVANCO_VALOR||'' AS "VALOR",
                       SA.SALAVANCO_NUMDOC,
                       SA.SALAVANCO_OBS,
                       TO_CHAR(SA.SALAVANCO_DTRGE, 'DD-MM-YYYY'),
                       CASE 
                          WHEN SA.SALAVANCO_STATE = 1 THEN 'Pendente'
                          WHEN SA.SALAVANCO_STATE = 0 THEN  'Descontando'
                          ELSE 'Anulado'
                       END AS "ESTADO"
                  FROM T_SALARIOAVANCO SA
                     INNER JOIN T_FUNCIONARIO FUNC ON SA.SALAVANCO_FUNC_ID = FUNC.FUNC_ID
                  WHERE SA.SALAVANCO_STATE IN (1, 0)
                     AND SA.SALAVANCO_SALAVANCO_ID IS NOT NULL -- Quando tiver detro de
                     AND 1= (CASE WHEN idFuncionario IS NULL OR  idFuncionario = FUNC.FUNC_ID THEN 1 ELSE 0 END)
                     AND 1 =(CASE WHEN dataInicio IS NULL OR dataFim IS NULL OR SA.SALAVANCO_DATA BETWEEN dataInicio AND dataFim THEN 1 ELSE 0 END)
                  ORDER BY SA.SALAVANCO_DATA ASC
                  )
      LOOP
         IF SA."ESTADO" = 'Pendente' THEN
             totalPendente := totalPendente + SA."VALOR";
         ELSIF SA."ESTADO" = 'Descontado' THEN 
            totalDescontado := totalDescontado + SA."VALOR";
         END IF;
         
         SA."VALOR" := PACK_LIB.MONEY(SA."VALOR");
         PIPE ROW(SA);
      END LOOP;
      
      /*
      avanco."DATA" := 'TOTAL PENDENTE';
      avanco."VALOR" := PACK_LIB.MONEY(totalPendente);
      PIPE ROW(avanco);
      */
      
      avanco."DATA" := 'TOTAL';
      avanco."VALOR" := PACK_LIB.MONEY(totalPendente + totalDescontado);
      PIPE ROW(avanco);
      
    END;
    
    
    FUNCTION funcRegSituacaoFamiliar(idUser NUMBER, numeroFilhos NUMBER, percentagem FLOAT) RETURN VARCHAR2
    IS
    BEGIN
       UPDATE T_SITUACAOFAMILIAR SIT
          SET SIT.SITUA_STATE = 0
          WHERE SIT.SITUA_STATE = 1
             AND SIT.SITUA_NUMFILHOS = numeroFilhos;
          
       INSERT INTO T_SITUACAOFAMILIAR(SITUA_USER_ID,
                                      SITUA_NUMFILHOS,
                                      SITUA_VALORPAGAR)
                                      VALUES(idUser,
                                             numeroFilhos,
                                             percentagem);
                                             
       RETURN 'true;Sucesso';
          
    END;
    
    
     FUNCTION loadSalarioBaseNacional(idUser NUMBER) RETURN FLOAT
     IS 
        currentSalario FLOAT;
     BEGIN
        SELECT SAL.SALNACIO_VALOR INTO currentSalario
           FROM T_SALARIONACIONAL SAL
           WHERE SAL.SALNACIO_STATE = 1;
           
        RETURN currentSalario;
        
        EXCEPTION
           WHEN OTHERS THEN RETURN 0;
     END;
     
     
     
     FUNCTION funcRegImpostoxTaxas(idImposto NUMBER, idUser NUMBER, percentagem FLOAT, valorMinimo FLOAT, valorMaximo FLOAT, parcelaBater FLOAT) RETURN VARCHAR2
     IS
     BEGIN
        UPDATE T_IMPOSTOTAXA IPTAX
           SET IPTAX.IMPTAX_STATE = 0
           WHERE IPTAX.IMPTAX_STATE = 1
              AND IPTAX.IMPTAX_IMP_ID = idImposto
              AND 1 = (CASE
                          WHEN valorMaximo IS NULL OR valorMinimo IS NULL THEN 1
                          WHEN valorMaximo = IPTAX.IMPTAX_MAXVALOR THEN 1
                          ELSE 0
                      END);
                      
        INSERT INTO T_IMPOSTOTAXA(IMPTAX_USER_ID,
                                  IMPTAX_IMP_ID,
                                  IMPTAX_MAXVALOR,
                                  IMPTAX_PERCENTAGEM,
                                  IMPTAX_PARCELABATER,
                                  IMPTAX_MIXVALOR)
                                  VALUES(idUser,
                                         idImposto,
                                         valorMaximo,
                                         percentagem,
                                         parcelaBater,
                                         valorMinimo);
                                         
        RETURN 'true;Sucesso';
     END;
     
     
     -- TipoTaxa {1 IRS | 2 - Segurança Social | 3 outras}
    FUNCTION funcLoadImpostosTaxa(tipoTaxa NUMBER) RETURN verTaxasImpostas PIPELINED
    IS
    BEGIN
       FOR I IN (SELECT *
                    FROM VER_IMPOSTOS_TAXAS TAX
                    WHERE 
                       1 = (CASE 
                               WHEN tipoTaxa = 1 AND TAX.NOME = 'IRS' THEN 1
                               WHEN tipoTaxa = 2 AND UPPER(TAX.NOME) IN ('FUNCIONARIO', 'EMPRESA') THEN 1
                               WHEN tipoTaxa = 3 AND UPPER(TAX.NOME) NOT IN ('IRS', 'FUNCIONARIO', 'EMPRESA') THEN 1
                               ELSE 0
                            END))
       LOOP
          PIPE ROW(I);
       END LOOP;
    END;
    
    
    
    FUNCTION functPreviexProcessSalario (idUser NUMBER, idFuncionario NUMBER) RETURN PACK_RH.salarioResult PIPELINED
    IS 
     exist NUMBER;
     funcionarioRow T_FUNCIONARIO%ROWTYPE;
     linhaFuncionarioRow T_LINHAFUNCIONARIO%ROWTYPE;
     -- Estrutura salarial para o funcionario
     estruturaSalarial T_CATEGORY%ROWTYPE;
     salarioEstruturado FLOAT; -- CORRESPONDE AO SOMATORIO DE TODOS OS SALARIO DA ESTRUTURA DO SALARIO DO FUNCIONARIO
     bonusAlmoco FLOAT;  -- Corresponde a parte de salario que não se aplica imposto
     salarioSemBonus FLOAT;  -- Corresponde ao salario retirado a parte do bonus | ALIAS AS TRIBUTADO
     percentImpotoFuncionario FLOAT; -- Corresponde a percentagem do imposto do funcionario
     percentImpostoEmpresa FLOAT;  -- A percentagem do imposto que deve ser aplicado a empresa
     impAssisteSocialFuncionario FLOAT; -- Imposto que o funcionario deve pagar a assistencia social
     salarioImpostoFuncionario FLOAT;  -- O salario aplicado o impostod o funcionario
     
     idAssistenciaFuncionario NUMBER;
     idAssistenciaEmpresa NUMBER;
     
     /*COMISAO MENSAL DO FUNCIONARIO*/
     
     comisaoRow T_COMISAO%ROWTYPE;
     comisao FLOAT := 0; -- O valor da comisao do funcionario
     salarioComComisao FLOAT; -- Corresponde ao salario somado a comisao do mes do funcionario
     irsSalarioComisao T_IMPOSTOTAXA%ROWTYPE;  -- O IRS que sera aplicado ao funcionario
     percentagemIRS FLOAT; -- Corresponde a percentagem do irs que sera aplicado
     parcelaBaterIRS FLOAT; -- A parcela a bater do IRS a ser aplicado
     impostoIRS FLOAT; -- O valor do imposto do IRS que o funcionario devera pagar
     irsApurado FLOAT; -- Corresponde ao valor do IRS apurado (que sera o imposto do IRS retirandi a parcela a bater
     situacaoFamiliar T_SITUACAOFAMILIAR%ROWTYPE;
     salarioBaseNacional T_SALARIONACIONAL%ROWTYPE;
     valorSituacaoFamiliar FLOAT :=0; -- Corresponde ao valor da situação familiar
     irsLiquido FLOAT;
     salarioLiquido FLOAT; -- Corresponde ao salario aplicado as taxas do IRS
     
     salarioAvanco T_SALARIOAVANCO%ROWTYPE;
     avancoSalarial FLOAT :=0; -- Corresponde ao salario que o funcionario tera direito ao
     salarioFinal FLOAT; -- Correspinde oa real salario que o funcionario tem direito
     impAssisteSocialEmpresa FLOAT; -- Corresponde ao assistencia social da empresa
     salarioImpostoEmpresa FLOAT; -- COrresponde ao imposto da empresa
     
     process Salario;
     existFuncionario NUMBER;
     
  BEGIN
     process."SALARIO.RESULT" := 'false';
     -- CARREGAR AS INFORMACOES DO FUNCIONARIO O QUAL PRETENDE-SE CARREGAR AS SUAS INFORMACOES
     
     
     SELECT COUNT(*) INTO existFuncionario
        FROM T_FUNCIONARIO FUNC
           INNER JOIN T_LINHAFUNCIONARIO LFUN ON FUNC.FUNC_ID  = LFUN.LFUNC_FUNC_ID
        WHERE FUNC.FUNC_ID = idFuncionario
           AND LFUN.LFUNC_STATE = 1;
        
        
    IF existFuncionario != 0 THEN
      SELECT * INTO funcionarioRow
          FROM T_FUNCIONARIO FUNC
          WHERE FUNC.FUNC_ID = idFuncionario;
          
      process."FUNCIONARIO.ID" := funcionarioRow.FUNC_ID;
      process. "FUNCIONARIO.NAME" := funcionarioRow.FUNC_NOME||' '||funcionarioRow.FUNC_APELIDO;
      
      -- Carregar os seus dados da linha mais atualizados
      SELECT * INTO linhaFuncionarioRow
         FROM T_LINHAFUNCIONARIO LFUNC
         WHERE LFUNC.LFUNC_FUNC_ID = idFuncionario
            AND LFUNC.LFUNC_STATE = 1;
            
            
       -- Carregar a estrutura salarial
      SELECT COUNT(*) INTO exist
          FROM T_FUNCIONARIO FUN
             INNER JOIN T_LINHAFUNCIONARIO LFUN ON FUN.FUNC_ID = LFUN.LFUNC_FUNC_ID
             INNER JOIN T_CATEGORY CAT ON (CAT.CAT_OBJT_LEVELCAT = FUN.FUNC_OBJT_LEVELCATEGORY AND CAT.CAT_OBJT_TYPECATEGORY = LFUN.LFUNC_CAT_ID)
          WHERE LFUN.LFUNC_STATE = 1
             AND CAT.CAT_STATE = 1
             AND FUN.FUNC_ID = idFuncionario;
    END IF;
        
    
           
      IF exist  = 0  OR existFuncionario = 0 THEN
         process."SALARIO.MESSAGE" := FUNC_ERROR('NO ESTRUTURA SALARIO FOUND');
         PIPE ROW (process);
      ELSE
           
         -- Carregar a estrutura salarial
         SELECT 
                CAT.*
                   INTO estruturaSalarial
            FROM T_FUNCIONARIO FUN
               INNER JOIN T_LINHAFUNCIONARIO LFUN ON FUN.FUNC_ID = LFUN.LFUNC_FUNC_ID
               INNER JOIN T_CATEGORY CAT ON (CAT.CAT_OBJT_LEVELCAT = FUN.FUNC_OBJT_LEVELCATEGORY AND CAT.CAT_OBJT_TYPECATEGORY = LFUN.LFUNC_CAT_ID)
            WHERE LFUN.LFUNC_STATE = 1
               AND CAT.CAT_STATE = 1
               AND FUN.FUNC_ID = idFuncionario
               AND LFUN.LFUNC_STATE = 1
               AND CAT.CAT_STATE = 1
               AND ROWNUM <= 1;
               
          process."ESTRUTURA.ID" := estruturaSalarial.CAT_ID;
          process."ESTRUTURA.TYPE_ID" := estruturaSalarial.CAT_OBJT_TYPECATEGORY;
          process."ESTRUTURA.TYPE_DESC" := PACK_REGRAS.GETOBJECTTYPEVALUE(estruturaSalarial.CAT_OBJT_TYPECATEGORY);
          process."ESTRUTURA.LEVEL_ID" := estruturaSalarial.CAT_OBJT_LEVELCAT;
          process."ESTRUTURA.LEVEL_DESC" :=PACK_REGRAS.GETOBJECTTYPEVALUE(estruturaSalarial.CAT_OBJT_LEVELCAT);
          process."ESTRUTURA.BASE" := estruturaSalarial.CAT_BASESALARY;
          process."ESTRUTURA.ALOJAMENTO" := estruturaSalarial.CAT_HOUSESUBVENTION;
          process."ESTRUTURA.LANCHE" := estruturaSalarial.CAT_LUNCHSUBVENTION;
          process."ESTRUTURA.TRANSPORTE" := estruturaSalarial.CAT_TRANSPORTSUBVENTION;
          process."ESTRUTURA.BONUSALMOCO" := estruturaSalarial.CAT_ALMOCOBONUS;
          
         -- Calcular o somatorio da estrutura salarial do funcionario
         salarioEstruturado := estruturaSalarial.CAT_BASESALARY + estruturaSalarial.CAT_HOUSESUBVENTION
                                + estruturaSalarial.CAT_LUNCHSUBVENTION + estruturaSalarial.CAT_TRANSPORTSUBVENTION;
                                
         process."ESTRUTURA.SALARIO"  := salarioEstruturado;                     
        
         -- Obter o valor que estara livre do imposto             
         bonusAlmoco := estruturaSalarial.CAT_ALMOCOBONUS;
         IF bonusAlmoco IS NULL THEN 
            bonusAlmoco := 0;
         END IF;
         
         
         -- Retirar a parte do almoco do salario
         salarioSemBonus := salarioEstruturado - bonusAlmoco;
         process."SALARIO OUT BONUS ALMOCO" := salarioSemBonus;
         
         /** Impostos Cadastrados no sistemas **
            1	FUNCIONARIO   0
            2	EMPRESA	      0
            3	IRS	      1
         **/
         
       
        FOR I IN(SELECT I.IMP_NAME, TAX.IMPTAX_PERCENTAGEM, TAX.IMPTAX_ID
                  FROM T_IMPOSTOS I
                     INNER JOIN T_IMPOSTOTAXA TAX ON I.IMP_ID = TAX.IMPTAX_IMP_ID
                     WHERE UPPER(I.IMP_NAME) IN ('FUNCIONARIO', 'EMPRESA'))
        LOOP
            
            IF UPPER(I.IMP_NAME) = 'FUNCIONARIO' THEN
                 percentImpotoFuncionario := I.IMPTAX_PERCENTAGEM;
                 idAssistenciaFuncionario := I.IMPTAX_ID;
            ELSIF UPPER(I.IMP_NAME) = 'EMPRESA' THEN 
                percentImpostoEmpresa := I.IMPTAX_PERCENTAGEM;
                idAssistenciaEmpresa := I.IMPTAX_ID;
            END IF;
        END LOOP;
        
        process."% SS FUNCIONARIO" := percentImpotoFuncionario;
        process."ID SS FUNCIONARIO" := idAssistenciaFuncionario;
        process."% SS EMPRESA" := percentImpostoEmpresa;
        process."ID SS EMPRESA" := idAssistenciaEmpresa;
        
        
        
        impAssisteSocialFuncionario := (percentImpotoFuncionario/100) * salarioSemBonus;
        salarioImpostoFuncionario := salarioSemBonus - impAssisteSocialFuncionario;
        
        process."SS FUNCIONARIO" := impAssisteSocialFuncionario;
        process."SALARIO OUT SS FUNCIONARIO" := salarioImpostoFuncionario;
        
        
       
        
         -- Verificar se existe a comisao do tipo pacote registrada
         SELECT COUNT(*) INTO exist
            FROM T_COMISAO COM 
            WHERE COM.COMISAO_FUNC_ID = idFuncionario
               AND COM.COMISAO_COMISAO_ID IS NULL
               AND COM.COMISAO_CTT_ID IS NULL
               AND COM.COMISAO_DATA IS NULL
               AND COM.COMISAO_PERCENTAGEM IS NULL
               AND COM.COMISAO_STATE = 1;
               
          IF exist != 0 THEN
              SELECT * INTO comisaoRow
                FROM T_COMISAO COM 
                WHERE COM.COMISAO_FUNC_ID = idFuncionario
                   AND COM.COMISAO_COMISAO_ID IS NULL
                   AND COM.COMISAO_CTT_ID IS NULL
                   AND COM.COMISAO_DATA IS NULL
                   AND COM.COMISAO_PERCENTAGEM IS NULL
                   AND COM.COMISAO_STATE = 1;
                   
              comisao := comisaoRow.COMISAO_VALOR;
          ELSE 
              comisao := 0;
          END IF;
          
         
          
        salarioComComisao := salarioImpostoFuncionario + comisao;
        process."ID COMISAO" := comisaoRow.COMISAO_ID;
        process."VALOR COMISAO" := comisao;
        process."SALARIO COM COMISAO" := salarioComComisao;
        
        -- CARREGAR O VALOR DO IRS QUE MELHOR EQUADRA AO SALARIO COM COMISAO DO FUNCIONARIO
           -- O IRS QUE COM O MAIOR VALOR QUE PODE SER IGUAL OU MENOR QUE O salario com comisao
        
        SELECT COUNT(*) INTO exist 
           FROM (SELECT TAX.*
                    FROM T_IMPOSTOS IMP
                       INNER JOIN T_IMPOSTOTAXA TAX ON IMP.IMP_ID = TAX.IMPTAX_IMP_ID
                    WHERE IMP.IMP_NAME = 'IRS'
                        AND(salarioComComisao <= TAX.IMPTAX_MAXVALOR
                             AND salarioComComisao > TAX.IMPTAX_MIXVALOR)
                           OR ((TAX.IMPTAX_MAXVALOR IS NULL OR TAX.IMPTAX_MAXVALOR = 0)
                                AND salarioComComisao > TAX.IMPTAX_MIXVALOR)
                    ORDER BY IMP.IMP_HASVALOR DESC) IMPO
           WHERE ROWNUM <= 1;
           
        IF exist  = 0 THEN 
           process."SALARIO.MESSAGE" := FUNC_ERROR('IRS NOT FOUND FOR THIS SALARY');
           PIPE ROW(process);
        ELSE
            SELECT IMPO.* INTO irsSalarioComisao
               FROM (SELECT TAX.*
                        FROM T_IMPOSTOS IMP
                           INNER JOIN T_IMPOSTOTAXA TAX ON IMP.IMP_ID = TAX.IMPTAX_IMP_ID
                        WHERE IMP.IMP_NAME = 'IRS'
                           AND(salarioComComisao <= TAX.IMPTAX_MAXVALOR
                             AND salarioComComisao > TAX.IMPTAX_MIXVALOR)
                           OR ((TAX.IMPTAX_MAXVALOR IS NULL OR TAX.IMPTAX_MAXVALOR = 0)
                                AND salarioComComisao > TAX.IMPTAX_MIXVALOR)
                        ORDER BY IMP.IMP_HASVALOR DESC) IMPO
               WHERE ROWNUM <= 1;
            
            -- Obter a percentagem e o valor de parcela a bater do funcionario
            parcelaBaterIRS := irsSalarioComisao.IMPTAX_PARCELABATER;
            percentagemIRS := irsSalarioComisao.IMPTAX_PERCENTAGEM;
            
            impostoIRS := salarioComComisao * (percentagemIRS/100);
            irsApurado := impostoIRS - parcelabaterIRS;
            
            process."ID IRS" := irsSalarioComisao.IMPTAX_ID;
            process."% IRS" := percentagemIRS;
            process."IRS PARCELA BATER" := parcelaBaterIRS;
            process."IRS" := impostoIRS;
            process."IRS APURADO" := irsApurado;
            
            
            -- CARREGAR A SITUACAO FAMILIAR ADEQUADA A ESSE FUNCIONARIO
            SELECT COUNT(*) INTO exist
               FROM T_SITUACAOFAMILIAR SITU
               WHERE SITU.SITUA_NUMFILHOS = linhaFuncionarioRow.LFUNC_NUMFILHOS
                  AND SITU.SITUA_STATE = 1;
                  
                  
            SELECT COUNT(*) INTO exist
               FROM T_SALARIONACIONAL SN
               WHERE SN.SALNACIO_STATE = 1
                  AND exist != 0;
                  
               
            IF exist != 0 THEN
               SELECT * INTO situacaoFamiliar
                  FROM T_SITUACAOFAMILIAR SITU
                  WHERE SITU.SITUA_NUMFILHOS = linhaFuncionarioRow.LFUNC_NUMFILHOS
                     AND SITU.SITUA_STATE = 1;
                     
               SELECT * INTO salarioBaseNacional
                  FROM T_SALARIONACIONAL SN
                     WHERE SN.SALNACIO_STATE = 1;
                     
                -- TODO aqui é para aplicar o calculo de obter o valor da situacao familiar em relacao ao numeros de filos
                valorSituacaoFamiliar := (situacaoFamiliar.SITUA_VALORPAGAR/100) * salarioBaseNacional.SALNACIO_VALOR;
                
            ELSE 
                valorSituacaoFamiliar := 0;
            END IF;
            
            process."ID SITUACAO FAMILIAR" := situacaoFamiliar.SITUA_ID;
            process."ID SALARIO BASE NACIONAL" :=  salarioBaseNacional.SALNACIO_ID;
            process."VALOR SITUACAO FAMILIAR" := situacaoFamiliar.SITUA_VALORPAGAR;
            process."VALOR SALARIO BASE NACIONAL" := salarioBaseNacional.SALNACIO_VALOR;
            process."SIUACAO FAMILIAR TOTAL" := valorSituacaoFamiliar;
               
            
              
            irsLiquido  := irsApurado - valorSituacaoFamiliar;
            salarioLiquido := salarioComComisao - irsLiquido + bonusAlmoco;
            
            process."IRS LIQUIDO" := irsLiquido;
            process."SALARIO MES" := salarioLiquido;
            
            
            SELECT COUNT(*) INTO exist
               FROM T_SALARIOAVANCO SAL
               WHERE SAL.SALAVANCO_FUNC_ID  = idFuncionario
                 AND SAL.SALAVANCO_STATE = 1
                 AND SAL.SALAVANCO_SALAVANCO_ID IS NULL 
                 AND SAL.SALAVANCO_NUMDOC IS NULL
                 AND SAL.SALAVANCO_DATA IS NULL;
            
            IF exist != 0 THEN -- Select * form t_funcionario where t_funcionario not empty
               SELECT * INTO salarioAvanco
                  FROM T_SALARIOAVANCO SAL
                  WHERE SAL.SALAVANCO_FUNC_ID  = idFuncionario
                    AND SAL.SALAVANCO_STATE = 1
                    AND SAL.SALAVANCO_SALAVANCO_ID IS NULL 
                    AND SAL.SALAVANCO_NUMDOC IS NULL
                    AND SAL.SALAVANCO_DATA IS NULL;
               avancoSalarial := salarioAvanco.SALAVANCO_VALOR;
            ELSE 
               avancoSalarial := 0;
            END IF;
            
            IF avancoSalarial IS NULL THEN
               avancoSalarial := 0;
            END IF;
            
            process."ID AVANCO SALARIAL" := salarioAvanco.SALAVANCO_ID;
            process."VALOR AVANCO SALARIAL" := avancoSalarial;
              
            salarioFinal := salarioLiquido - avancoSalarial;
            process."SALARIO FINAL MES" := salarioFinal;
            
            impAssisteSocialEmpresa := salarioSemBonus * (percentImpostoEmpresa/100);
            salarioImpostoEmpresa := salarioEstruturado + impAssisteSocialEmpresa;
            process."SS EMPRESA" := impAssisteSocialEmpresa;
            process."SALARIO IMPOSTO EMPRESA" := salarioImpostoEmpresa;
            
            process."SALARIO.RESULT" := 'true';
            process."SALARIO.MESSAGE" := 'Sucesso';
            
            PIPE ROW(process);
        END IF;    
      
      END IF;
    END;
    
    
    FUNCTION functLoadProcessSalario (ano NUMBER, mes NUMBER) RETURN  ListSalarioOld PIPELINED
    IS
        process PACK_RH.SalarioOld;
        totalProcess PACK_RH.SalarioOld;
        dMes CHARACTER VARYING(2);
        dDate CHARACTER VARYING (10);
        format CHARACTER VARYING(10);
    BEGIN
        totalProcess."MONTANTE" := 0;
        IF ano IS NULL THEN 
           dDate := NULL;
           format := NULL;
        ELSIF mes IS NULL THEN
           dDate := ano||'';
           format := 'YYYY';
        ELSE 
           dDate := ano||'-'||dMes;
           format := 'YYYY-MM';
        END IF;
        
        -- "ID" NUMBER, "DATA" CHARACTER VARYING(20), "CODIGO PROCESSO" CHARACTER VARYING (200), "MONTANTE" CHARACTER VARYING(120), "ESTADO" CHARACTER VARYING(100), "REGISTRO" CHARACTER VARYING (100)
        /*TYPE SalarioOld IS RECORD 
           -> "ID" NUMBER, 
           -> "DATA" CHARACTER VARYING(20),
           -> "FUNCIONARIO" CHARACTER VARYING (200),
           -> "MONTANTE" CHARACTER VARYING(120), 
           -> "ESTADO" CHARACTER VARYING(100),
           -> "BANCO" CHARACTER VARYING (100));*/
   
        
        FOR PRO IN (SELECT CASE PROC.PROSAL_STATE
                               WHEN -1 THEN -1
                               WHEN 0 THEN 1
                               WHEN 1 THEN 2
                               WHEN 2 THEN 3
                            END AS ORDER_STATE,
                           PROC.*
                            
                     FROM T_PROCESSALARY PROC
                     WHERE 1 = (CASE WHEN dDate IS NULL  OR TO_CHAR(PROC.PROSAL_DTREG, format) = dDate THEN 1 ELSE 0 END)
                        AND PROC.PROSAL_STATE IN(1, 2, 0, -1)
                     ORDER BY   ORDER_STATE DESC, 
                        PROC.PROSAL_DTREG DESC)
        LOOP
           process."ID" := PRO.PROSAL_ID;
           process."DATA" := TO_CHAR(PRO.PROSAL_DATA, 'MONTH YYYY');
           process."CODIGO PROCESSO" := PRO.PROSAL_COD;
           process."MONTANTE" := PACK_LIB.money(PRO.PROSAL_TOTAL)/*||' STD'*/;
           process."ESTADO" := CASE 
                                  WHEN PRO.PROSAL_STATE = 2 THEN 'Pendente'
                                  WHEN PRO.PROSAL_STATE = 1 THEN 'Processado'
                                  WHEN PRO.PROSAL_STATE = 0 THEN 'Validado'
                                  ELSE 'Anulado'
                               END;
           process."REGISTRO" := TO_CHAR(PRO.PROSAL_DTREG, 'DD-MM-YYYY');
          
           totalProcess."MONTANTE" := totalProcess."MONTANTE" + PRO.PROSAL_TOTAL;
           PIPE ROW(process);
        END LOOP;
        
        totalProcess."DATA" := 'TOTAL';
        totalProcess."MONTANTE" := PACK_LIB.money(totalProcess."MONTANTE")/*||' STD'*/;
        PIPE ROW(totalProcess);
        
    END functLoadProcessSalario;
    
    
    -- state {-1 ANULAR | 0 APROVAR}
    FUNCTION funcAlterSatateProcessSalario (idProcesso NUMBER, idUser NUMBER, newState NUMBER, descricao CHARACTER VARYING) RETURN VARCHAR2
    IS
       process T_PROCESSALARY%ROWTYPE;
    BEGIN
       SELECT * INTO process
          FROM T_PROCESSALARY P
          WHERE P.PROSAL_ID = idProcesso;
          
       IF process.PROSAL_STATE = -1 THEN
          RETURN 'false'||FUNC_ERROR('STATE PROCESS SALARI IS ANULADO');
       END IF;
       
       INSERT INTO T_SALARIOSTATE(SALSTATE_USER_ID,
                                   SALSTATE_PROSAL_ID,
                                   SALSTATE_DESC,
                                   SALSTATE_NEWSTATE)
                                   VALUES(idUser,
                                          idProcesso,
                                          descricao,
                                          newState);
      RETURN 'true;Sucess';
    END;
END PACK_RH;