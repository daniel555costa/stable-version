create FUNCTION           "FUNC_REGOBJ_CARGAMARITIMA" 
(
    USER_ID NUMBER,
    ID_CONTRATO VARCHAR,
    INTERESE VARCHAR2,
    MODO_DE_EMBALAGEM VARCHAR2  
)
RETURN VARCHAR2 
 IS
    res PACK_TYPE.Resultado;
    parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();
BEGIN
   -- classe = 7
   res := PACK_REGRAS.REG_OBJECTO(USER_ID, ID_CONTRATO, 238, 1);
   
   PRC_ADD_LISTVALUE(parsValues, null, 'interece', INTERESE);
   PRC_ADD_LISTVALUE(parsValues, null, 'modoEmbalagem', MODO_DE_EMBALAGEM);
    
   PACK_REGRAS.REGOBJECTVALUES(USER_ID, res.resultado, null, 7, parsValues);
   return res.message;
END;