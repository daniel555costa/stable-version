create trigger TG_NEXT_PRECARIO
	before insert
	on T_PRECARIO
	for each row
begin  
   if inserting then 
      if :NEW."PREC_ID" is null then 
         select SEQ_PRECARIO.nextval into :NEW."PREC_ID" from dual; 
      end if; 
   end if; 
end;
