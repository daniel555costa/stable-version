create FUNCTION FUNCT_REQ_TEST 
RETURN TB_REQ PIPELINED 
IS
BEGIN
    PIPE ROW(TP_REQ_CLIENTE(1, 'Daniel', 'Costa'));
    PIPE ROW( TP_REQ_CLIENTE(1, 'Maria', 'Assunção'));
    PIPE ROW(TP_REQ_CLIENTE(1, 'Marcia', 'Oliveira'));
END;