create FUNCTION           "FUNCT_GET_TYPEPERGUNTA" 
(
    idPergunta NUMBER
)
RETURN PACK_TYPE.TypePerguntas PIPELINED
IS
BEGIN
    FOR I IN (SELECT TP.*
                FROM VER_TIPOPERGUNTA TP 
                  INNER JOIN T_PERGUNTA P  ON TP.REALID = P.PER_TPER_ID
                WHERE P.PER_ID = idPergunta) LOOP
        PIPE ROW (I);
    END LOOP;
END;