create PROCEDURE           "PRC_REG_VEICULO_MODELO" 
(
   idUser NUMBER,
   idMarca NUMBER,
   nomeModelo VARCHAR2
)
IS
BEGIN
   INSERT INTO T_OBJECTYPE(OBJT_USER_ID, 
                            OBJT_T_ID,
                            OBJT_DESC,
                            OBJT_OBJT_ID)
                            VALUES(idUser,
                                    3,
                                    nomeModelo,
                                    idMarca);
END;