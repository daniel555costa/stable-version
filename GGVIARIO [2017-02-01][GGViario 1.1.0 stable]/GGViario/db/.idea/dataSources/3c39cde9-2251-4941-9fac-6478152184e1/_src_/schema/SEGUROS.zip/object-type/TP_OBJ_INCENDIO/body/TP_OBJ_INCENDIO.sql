create TYPE BODY           "TP_OBJ_INCENDIO" AS

  CONSTRUCTOR FUNCTION TP_OBJ_INCENDIO(
                                        CONDICAO VARCHAR2,
                                        FONTE_AGUA_DISPONIVEL VARCHAR2,
                                        EQUI_COMBATE_INCENDIO VARCHAR2,
                                        ENDERECO_RES_ID NUMBER, -- Endereco completo do edificio
                                        
                                        NUMERO_ANDARES NUMBER,
                                        ANO NUMBER,
                                        DISTANCIA_COM_BOMBEIRO VARCHAR2,
                                        
                                        usoEdificio NUMBER,  --uso {1 - Comercial | 2 - Residencial}
                                        usoDescrincao VARCHAR2,
                                        processoFabricacao VARCHAR2-- {NULL - nao checado | descrincoa caso checado}
                                        
                                        
                                          )RETURN SELF AS RESULT AS
  BEGIN
    SELF.CONDICAO := CONDICAO;
    SELF.FONTE_AGUA_DISPONIVEL := FONTE_AGUA_DISPONIVEL;
    SELF.EQUI_COMBATE_INCENDIO := EQUI_COMBATE_INCENDIO;
    SELF.ENDERECO_RES_ID := ENDERECO_RES_ID; -- Endereco completo do edificio
    
    SELF.NUMERO_ANDARES := NUMERO_ANDARES;
    SELF.ANO := ANO;
    SELF.DISTANCIA_COM_BOMBEIRO := DISTANCIA_COM_BOMBEIRO;
    
    SELF.usoEdificio := usoEdificio;  --uso {1 - Comercial | 2 - Residencial}
    SELF.usoDescrincao := usoDescrincao;
    SELF.processoFabricacao := processoFabricacao; -- {NULL - nao checado | descrincoa caso checado}
    
    RETURN;
  END TP_OBJ_INCENDIO;

  STATIC FUNCTION INSTANCEOF RETURN NUMBER AS
  BEGIN
    -- TODO: Implementation required for FUNCTION TP_CTT_INCENDIO.INSTANCEOF
    RETURN NULL;
  END INSTANCEOF;

END;