create PACKAGE           "PACK_REGRAS" IS

    -- TYPES IN PACKAGE
    TYPE BUNDLE IS TABLE OF VARCHAR2(4000) INDEX BY VARCHAR2(1000);
    --
    
    
    -- Essa funcoa recebe algo que seja do tipo Objecto (TP_OBJ) para poder ser armazenado na entidade Objecto e criar uma sequencia para o objecto registrado
    FUNCTION REG_OBJECTO(USER_ID NUMBER, ID_CONTRATO VARCHAR, TIPO_OBJECTO NUMBER, regAssegura NUMBER) RETURN PACK_TYPE.Resultado;
    
    -- Essa funcoa serve para registra os valores que um dado objecto possui
      -- Seja objecto segurado ou objecto do contrato
    PROCEDURE regObjectValues (idUser NUMBER, idObject NUMBER, idContrato NUMBER, typeClass NUMBER, listValues TB_OBJECT_VALUES);
    
            
    --Essa funcao serve para boter a identificacao de uma residencia.
      -- Caso ela nao encontra a residencia ela registra a residencia e retorna a sua identificacao
    FUNCTION GET_RESIDENCE (NAME_RESIDENCI IN CHARACTER VARYING, ID_USER NUMBER) RETURN NUMBER;
    
    -- objectValue - O valor do object
     -- idUser - O utilizador que esta aregistrar o object
     -- typeObject - tipo de objecto
     -- idSuperTypeObject - o objecto onde o objecto esta 
    FUNCTION getObjectID(objectValue VARCHAR2, idUser NUMBER, typeObject NUMBER, valueSuper VARCHAR2, typeSuper NUMBER) RETURN VARCHAR2;
    
    -- Esse procedimento serve para adicionar novas coberturas ao contrato e ou ao segurado
    PROCEDURE addCoberturaContratoAssegura (idUser NUMBER,
                                            idContrato NUMBER,
                                            idAssegura NUMBER,
                                            expecificaoaCobertura TB_ARRAY_STRING);
                                            
    -- Registrar um novo valor do atributo 
    -- Se nao encotrar o atributo ira registralo por padrao
    FUNCTION regObjVall(idUser NUMBER, attributVall VARCHAR2, attributeName VARCHAR2, super NUMBER, classTypeId NUMBER, idObjecto NUMBER, idContrato NUMBER) RETURN NUMBER;
    
    -- Funcoa para montar novamaete o bojecto disolvido na base de dados
      -- Essa funcao mapea cada atributo dos objecto em uma lista como o hasMap do java
    FUNCTION loadObjectByAttribute ( attributeName VARCHAR2, valueObject VARCHAR2, idClassObject NUMBER) RETURN PACK_TYPE.mapaValues;
    
    -- Essa funcao serve para montar no objecto dissolvido em varias linha
     -- O onbjecto e motado em diversas linhas da do resultado
    FUNCTION loadObjectById (idObject NUMBER, idContrato NUMBER) RETURN TB_OBJECT_VALUES;
    
    
    -- Registrar um novo attributo para a classe do objecto
    -- tipos dos atributos 0 - TEXT | 1 - VARCHAR | 2 - NUMBER | 3 - FLOAT | 4 - DATE | 5 - TIMESTAMP
    -- Nulavel 1 - YES | 0 - NO
    FUNCTION getAttributeClass(idUser NUMBER, nameAttribute VARCHAR2, classAttribute NUMBER, typeAttribute NUMBER, nullable NUMBER) RETURN T_OBJCLASSATTRIBUTE%ROWTYPE;
    
    
    
    -- FUNCTION GET_IMPOSTO_ACTIVO RETURN NUMBER; 
    
    
    FUNCTION GET_TAXA_DIA (dataTaxa DATE, idMoeda NUMBER) RETURN NUMBER;
    
    FUNCTION getObjectTypeValue(idObject NUMBER) RETURN CHARACTER VARYING;
    
    FUNCTION getValueObject(idObject NUMBER, idContrato NUMBER, nomeAtributo CHARACTER VARYING) RETURN CHARACTER VARYING;
END;