create trigger TG_NEXT_PROCESSALARY
	before insert
	on T_PROCESSALARY
	for each row
begin  
   if inserting then 
      if :NEW."PROSAL_ID" is null then 
         select SEQ_PROCESSALARY.nextval into :NEW."PROSAL_ID" from dual; 
      end if; 
   end if; 
end;
