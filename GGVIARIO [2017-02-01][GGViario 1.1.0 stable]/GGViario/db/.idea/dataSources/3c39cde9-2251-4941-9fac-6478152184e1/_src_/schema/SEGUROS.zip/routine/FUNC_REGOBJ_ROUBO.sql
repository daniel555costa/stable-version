create FUNCTION           "FUNC_REGOBJ_ROUBO" 
(
  USER_ID NUMBER,
  ID_CONTRATO VARCHAR2,
  PROP_QUANTIDAEE NUMBER,
  PROP_MODELO VARCHAR2,
  PROP_VALOR FLOAT,
  PROP_DESCRICAO VARCHAR2
  
 ) RETURN VARCHAR2
 IS
      res PACK_TYPE.Resultado;
      --CRIANDO UMA INSTANCIA PARA ROUBO
      parsValues TB_OBJECT_VALUES := TB_OBJECT_VALUES();     
  BEGIN
    -- Class = 10 -> Classe de objecto roubo
    
    res :=  PACK_REGRAS.REG_OBJECTO(USER_ID, Id_contrato, 124341, 1);
    
    
    PRC_ADD_LISTVALUE(parsValues, null, 'quantidade', PROP_QUANTIDAEE);
    PRC_ADD_LISTVALUE(parsValues, null, 'modelo', PROP_MODELO);
    PRC_ADD_LISTVALUE(parsValues, null, 'valor', PROP_VALOR);
    PRC_ADD_LISTVALUE(parsValues, null, 'descrincao', PROP_DESCRICAO);
    
    PACK_REGRAS.REGOBJECTVALUES(USER_ID, res.resultado, null, 10, parsValues);

    IF res.resultado != -1 THEN 
      RETURN 'true';
    ELSE RETURN res.message;
    END IF;
  END;