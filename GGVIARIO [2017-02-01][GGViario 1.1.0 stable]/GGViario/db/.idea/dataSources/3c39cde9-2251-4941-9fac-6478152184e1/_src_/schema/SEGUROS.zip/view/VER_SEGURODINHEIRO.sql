create view VER_SEGURODINHEIRO as
SELECT
      OB.OBJ_ID AS REALID,
      OB.OBJ_SEQUENCE AS ID,
      OB.OBJ_DINHEIRO.NOME_FABRICANTE as "FABRICANTE",
      OB.OBJ_DINHEIRO.NUMERO_FABRICANTE as "NUM. FABRICANTE",
      OB.OBJ_DINHEIRO.TAMANHO as tamanho,
      OB.OBJ_DINHEIRO.DETENTOR_CHAVES as "DETENTOR CHAVE",
      OB.OBJ_DINHEIRO.PESO as peso,
      OB.OBJ_DINHEIRO.ID_OBJTCONTROCOFRE as "CONSTRUCAO",
      OB.OBJ_DINHEIRO.estrutura as "ESTRUTURA",
      CAST(pack_lib.asddmmyyyy(ob.obj_dtreg) AS VARCHAR2(10)) AS "REGISTRO",
      CAST(pack_lib.STATE('obj',ob.obj_state) AS VARCHAR2(50)) AS ESTADO,
      fc.func_accessname as username
  from t_objecto ob
  inner join t_funcionario fc on fc.func_id = OB.OBJ_USER_ID
  where OB.OBJ_DINHEIRO IS NOT NULL
