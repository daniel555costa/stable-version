create TYPE           "TAXA_VIAGEM"                                          AS OBJECT
      (
         ID NUMBER,
         NC FLOAT,
         SUBTOTAL FLOAT,
         CONSUMO FLOAT,
         SELO FLOAT,
         FGA FLOAT,
         DIAMININO NUMBER,
         DIAMAX NUMBER,
         DIAS NUMBER
      );