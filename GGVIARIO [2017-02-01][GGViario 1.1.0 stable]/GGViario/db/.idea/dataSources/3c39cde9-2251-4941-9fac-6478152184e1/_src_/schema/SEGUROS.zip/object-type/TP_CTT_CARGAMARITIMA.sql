create TYPE           "TP_CTT_CARGAMARITIMA"                                          UNDER TP_CTT
(
  -- FLY >> Viagem
  fly_pais_origem NUMBER(3),
  fly_pais_destino NUMBER(3),
  fly_portoCarga VARCHAR2(100),
  fly_portoDescarga VARCHAR2(100),
  fly_nomeNavio VARCHAR2(50),
  fly_valorMaximoRisco  BINARY_DOUBLE,
  
  -- COBRE -- Ambito da cobertura
  cobre_escolha NUMBER(1), -- {1 - Todos Riscos, 2 - Restrita, 3 - Mais Restrita}
  cobre_valorEscolha BINARY_DOUBLE,
  cobre_propositoSeguro VARCHAR2(200),
  
  -- VMAXRISCO >> Valor maximo em risco para
  vMaxRisco_qualquerNavio VARCHAR2(100),
  vMaxRisco_qualquerLocalizacao BINARY_DOUBLE,
  vMaxRisco_anualMercadoria VARCHAR(100), -- Anula para cada mercadoria
  
  --FSEND >> Forma de emvio
  fsend_escolha NUMBER(8), -- {VER_FORMA_ENVIO}
  
  --OTHER >> Outros
  other_tempoNegocio NUMBER(8),
  other_custoPorto NUMBER(2), -- Custo do porto (10% %)
  
  
  -- Informacao do segurado 
  infoSeg_descMercadoria VARCHAR2(250),
  infoSeg_areaActividade VARCHAR2(100),
  infoSeg_segEfectuadoComp VARCHAR2(250),
  infoSeg_nameCompania VARCHAR2(250),
  
  
  
  
  CONSTRUCTOR FUNCTION TP_CTT_CARGAMARITIMA (fly_pais_origem NUMBER,
                                              fly_pais_destino NUMBER,
                                              fly_portoCarga VARCHAR2,
                                              fly_portoDescarga VARCHAR2,
                                              fly_nomeNavio VARCHAR2,
                                              fly_valorMaximoRisco  BINARY_DOUBLE,
                                              
                                              -- COBRE -- Ambito da cobertura
                                              cobre_escolha NUMBER, -- {1 - Todos Riscos, 2 - Restrita, 3 - Mais Restrita}
                                              cobre_valorEscolha BINARY_DOUBLE,
                                              cobre_propositoSeguro VARCHAR2,
                                              
                                              -- VMAXRISCO >> Valor maximo em risco para
                                              vMaxRisco_qualquerNavio VARCHAR2,
                                              vMaxRisco_qualquerLocalizacao BINARY_DOUBLE,
                                              vMaxRisco_anualMercadoria VARCHAR2, -- Anula para cada mercadoria
                                              
                                              --FSEND >> Forma de emvio
                                              fsend_escolha NUMBER, -- {1 - Maritimo, 2 - Aeio, 3 - Encomenda Postal, 4 - Correio}
                                              
                                              --OTHER >> Outros
                                              other_tempoNegocio NUMBER,
                                              other_custoPorto NUMBER, -- Custo do porto (10% %)
                                              
                                              
                                              -- Informacao do segurado 
                                              infoSeg_descMercadoria VARCHAR2,
                                              infoSeg_areaActividade VARCHAR2,
                                              infoSeg_segEfectuadoComp VARCHAR2,
                                              infoSeg_nameCompania VARCHAR2
                                              
                                              ) RETURN SELF AS RESULT,
    STATIC FUNCTION INSTANCEOF RETURN NUMBER
  );