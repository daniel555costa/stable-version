create trigger TG_NEXT_MOVIMENT
	before insert
	on T_MOVIMENT
	for each row
begin  
   if inserting then 
      if :NEW."MOV_ID" is null then 
         select SEQ_MOVIMENTO.nextval into :NEW."MOV_ID" from dual; 
      end if; 
   end if; 
end;
