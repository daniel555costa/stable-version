create TYPE           "SYS_PLSQL_20668_37_1"                                          as object ("REALID" NUMBER(8),
"ID" NUMBER(6),
"PERGUNTA" VARCHAR2(120),
"DESCRICAO" CHAR(1));