create FUNCTION "FUNC_REG_CHEQUEMPRESA" 
( USER_ID VARCHAR2,
  ID_BANCO            NUMBER,
  ID_AGENCIA_PARACHEQUE NUMBER,
  INICIO_DE_SEQUENCIA NUMBER,
  FIN_DE_SEQUENCIA    NUMBER,
  TOTAL_DE_CHEQUES    NUMBER,
  idAgenciaRegCheque NUMBER
)
  RETURN VARCHAR2
  IS
    TT NUMBER;
  BEGIN
    IF SUBSTR(INICIO_DE_SEQUENCIA, 1, 8) != SUBSTR(FIN_DE_SEQUENCIA, 1, 8) THEN
       RETURN 'Os numero bancario da sequencia inicial não se conscide com os da sequencia final';
    END IF;
    
    IF PACK_REGRAS.PFUNC_validateSequencia(INICIO_DE_SEQUENCIA, FIN_DE_SEQUENCIA, ID_BANCO) != 0 THEN
       RETURN 'Os numeros dessa carteira de cheque intercala com o numero de uma outra carteira';
    END IF;


    -- Desativar o antigo check da empresa
    UPDATE CHEQUEMPRESA c
      SET c.CHEQ_ESTADO = 0
      WHERE c.CHEQ_BANCO_ID = ID_BANCO
      AND c.CHEQ_AGE_ID = ID_AGENCIA_PARACHEQUE;


    INSERT INTO CHEQUEMPRESA (CHEQ_USER_ID, 
                              CHEQ_SEQUENCIAINICIO,
                              CHEQ_SEQUENCIAFIM,
                              CHEQ_TOTALCHEQUES,
                              CHEQ_BANCO_ID,
                              CHEQ_AGE_ID,
                              CHEQ_AGE_IDREG)
                              VALUES (USER_ID,
                                      INICIO_DE_SEQUENCIA,
                                      FIN_DE_SEQUENCIA,
                                      TOTAL_DE_CHEQUES,
                                      ID_BANCO,
                                      ID_AGENCIA_PARACHEQUE,
                                      idAgenciaRegCheque);
    RETURN 'true';

  END;