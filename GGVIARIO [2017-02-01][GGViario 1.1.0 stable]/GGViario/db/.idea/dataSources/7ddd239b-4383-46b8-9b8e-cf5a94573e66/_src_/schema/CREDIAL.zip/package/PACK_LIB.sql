create PACKAGE         PACK_LIB IS
   /*
       r - read text
       w - write texto
       a - add text
       rb - read mode byte
       WB - mode of gravation byte
       ab - Mode byte of add
    */
    
    
    ffreadText VARCHAR2(1) := 'r';
    fwriteText VARCHAR2(1) := 'w';
    faddText VARCHAR2(1) := 'a';
    freadModeType VARCHAR2(2) := 'rb';
    fgravationByteMode VARCHAR2(2) := 'WB';
    faddByteMode VARCHAR2(2) := 'ab';
    defaultDirSave VARCHAR2(1000) := 'd:/backupText';
    
       
    TYPE BkColumn IS RECORD 
    (
       /* Types Values
         DT - {Date, TIMESTAMP}
         TXT - {CHAR, VARCHAR, TEXT}
         NUM - {NUMBER, DOUBLE, FLOAT ...}
      */
      columnName VARCHAR2(20),
      valueText VARCHAR2(4000),
      typeColumn VARCHAR2(5)
    );
    
    TYPE TableBkColun IS TABLE OF BkColumn;
    
    
    
    -- ESPECIFICACAO
    
    -- OBTRE O NUMERO DO ESTADO A PARTIR DO NOME CORESPONDENTE
    FUNCTION GET_STATE(TABLE_NAME   VARCHAR2, STATE_VALUES VARCHAR2) RETURN NUMBER;
    
    -- OBTER O VALOR DO ESTADO A PARTIR DO NUMERO CORESPONDENTE
    FUNCTION STATE_VALUES(TABLE_NAME VARCHAR2, STATE NUMBER) RETURN VARCHAR2;
    
    -- Obter a cadia de carracter a direita 
    FUNCTION GET_RIGTH(argment VARCHAR2, lenth   NUMBER) RETURN VARCHAR2;
    
    -- Obter a cadeia de carracter a esquerda
    FUNCTION GET_LEFTH(argment VARCHAR2, lenth   NUMBER) RETURN VARCHAR2;

  -- ESSA FUNCAO SERVE PARA CALCULAR AS IDADE A PARTIR DE UMA DATA DADA
    FUNCTION calcIdade(OLD_DATE date) RETURN NUMBER; 
    
    -- CONVERTER UM VALOR NUMERICO EM UM FARMATO DE MOEDA
    FUNCTION money (VALOR NUMBER, SIGLA VARCHAR2) RETURN VARCHAR2;
    
    -- PEGAR HARA DO DE UMA DATA
    FUNCTION asTime (DATE_PARAM TIMESTAMP) RETURN VARCHAR2;
    
    -- COVERTER A DATA EM DIA MES ANO
    FUNCTION asDDMMYYYY (DATE_PARAM TIMESTAMP) RETURN VARCHAR2;
    
    -- CONVERTER A DATA EM ANO MES DIA
    FUNCTION asYYYYMMDD (DATE_PARAM TIMESTAMP) RETURN VARCHAR2; 
    
    -- Formatar a em dia mes ano
    FUNCTION asDDMONYYYY(dateArg TIMESTAMP) RETURN VARCHAR2; 
     
    
    -- OBTER O ANO ACTUAL
    FUNCTION getCurrentYear RETURN VARCHAR2;
    
    -- Verificar se uma cadeia de caracter e numerico
    FUNCTION isNumber (argment VARCHAR2) RETURN NUMBER;
    
    -- COMPLETAR UMA STRING COM O CARACTER ANTES OU DEPIS FRIST {TRUE=ANTES, FLASE=DEPOIS} 
    FUNCTION complet (ARGMENT IN VARCHAR2, COMPLETION IN CHAR, FINAL_LENGTH IN NUMBER, FRIST IN BOOLEAN) RETURN VARCHAR2;
    
    -- Calculara a diferenca dos anos
    FUNCTION calcDiferencaAno (dataAno DATE, diferenca NUMBER) RETURN DATE;
    
    FUNCTION calcIntervalDate(dateYear TIMESTAMP, operactor CHAR, countNumber NUMBER,  modo VARCHAR) RETURN TIMESTAMP;
    
    -- Funcao para encriptacoa de senha
    FUNCTION md5(senha VARCHAR2) RETURN VARCHAR2;
    
    -- Escrever um ficeheiro
    PROCEDURE writeFile (dirName VARCHAR2, fileName VARCHAR2, operationType VARCHAR2, lineWriter LONG);
    
    -- criar uma nova linha de backUp
      -- OPERATION TIPE 
         -- I - INSERT
         -- U - UPDATE
    PROCEDURE newBackUpLine (listData TB_BACKUP, tableNAME VARCHAR2, operactionType VARCHAR2);
    
    -- Convereter uma data em um timiStamp
    FUNCTION bkDt (dateArgs TIMESTAMP) RETURN VARCHAR2;
    
    -- Converter em um varchar 
    FUNCTION bkTxt (textArgs varchar2) RETURN VARCHAR2;
    
    
    -- Essa funcao devede um varcar nas fendas fornecida (splitCase) excluido as casas nulas ou que o tamnho seja zero 
      -- argment <O que se pretende separar>
      -- splitCase <Aonde deve ser separada>
    FUNCTION splitNotNull (argment VARCHAR2, splitCase VARCHAR2) RETURN TB_ARRAY_STRING;
    
    
    -- Essa fucao efectua um split mais rigoros incluido as casas nulas ou que o tamanho seja zero
      -- argment <O que se pretende separar>
      -- splitCase <Aonde deve ser separada>
    FUNCTION splitAll (argment VARCHAR2, splitCase VARCHAR2) RETURN TB_ARRAY_STRING;
    
    
    -- Essa funcao serve para obter um carater em um dado index de uma varchar
      -- argment e a varchar2 que se pretende obter o seu caracter
      -- charIndex o index do carater que se pretende
   FUNCTION charAt(argment VARCHAR2, charIndex INTEGER) RETURN CHAR;
   
   
   -- Função para obter o total do registro em uma entiade
      -- tableName O nome da tabela a contar os registro
    FUNCTION tableLength(tableName VARCHAR2) RETURN  NUMBER; 
    
    
   FUNCTION NO_ACCENT(argment CHARACTER VARYING) RETURN CHARACTER VARYING DETERMINISTIC;
   
   FUNCTION NO_ACCENT_UPPER(argment CHARACTER VARYING) RETURN CHARACTER VARYING DETERMINISTIC;
   
     
END;