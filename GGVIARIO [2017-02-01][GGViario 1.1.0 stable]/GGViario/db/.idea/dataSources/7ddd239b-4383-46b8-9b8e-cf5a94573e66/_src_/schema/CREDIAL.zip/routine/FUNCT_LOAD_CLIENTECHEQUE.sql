create FUNCTION FUNCT_LOAD_CLIENTECHEQUE 
(
   numCheque VARCHAR2,
   idAgencia NUMBER
)RETURN PACK_VIEW.FilterCliente PIPELINED
IS
BEGIN
   -- Buscar o cliente que ficou com um dado cheque
   FOR I IN (SELECT *
                FROM VER_HISTORICOCLIENTE I
                WHERE I.NIF = (SELECT CT.CREDI_DOS_NIF
                                  FROM CERDITO CT
                                  WHERE CT.CREDI_NUMCHEQUE = numCheque)
                  AND I."ID AGENCIA" = (CASE WHEN idAgencia IS NULL THEN I."ID AGENCIA" ELSE idAgencia  END )
                  ) LOOP
      I.SALARIO := PACK_LIB.money(I.SALARIO, '');
      PIPE ROW(I);
   END LOOP;
END;