create FUNCTION FUNCT_LOAD_REQ_CRED_DIVIDPRDOT 
(
    dataInicio DATE,
    dataFin DATE,
    localTrabalho VARCHAR2,
    agenciaUs NUMBER,
    deferencaAno NUMBER,
    tipoCredito NUMBER
)RETURN PACK_VIEW.FilterCreditoDividaProduto PIPELINED
IS
    somatorioAno VER_REQ_CREDITO_DIVIDA_PRODT%ROWTYPE;
    somatorioAnoPast VER_REQ_CREDITO_DIVIDA_PRODT%ROWTYPE;
    dataInicoPast DATE := PACK_LIB.CALCDIFERENCAANO(dataInicio, deferencaAno);
    dataFinPast DATE := PACK_LIB.CALCDIFERENCAANO(dataFin, deferencaAno);
BEGIN
   somatorioAno."CREDITO SOLICITADO" := 0;
   somatorioAno."MONTANTE TOTAL CREDITO" := 0;
   somatorioAno."VALOR JA PAGO" := 0;
   
   somatorioAnoPast."CREDITO SOLICITADO" := 0;
   somatorioAnoPast."MONTANTE TOTAL CREDITO" := 0;
   somatorioAnoPast."VALOR JA PAGO" := 0;
   
   -- Verificar todas as dividas do intervalo do tempo fornecido
     -- Aplicar o somatorio no intervalo para os valores {CREDITO SOLICITADO, MONTANTE CREDITO, VALO PAGO}
   -- Quando a agentia ou o tipo do credito equals -1 then siginifica que se pretende carregar todas as informacoes
   FOR I IN(SELECT I.*
              FROM VER_REQ_CREDITO_DIVIDA_PRODT I
              WHERE I.LOCAL_TRABALHO = localTrabalho
                  AND I.INICIO BETWEEN dataInicio AND dataFin
                  AND (agenciaUs = -1 OR agenciaUs = I.AGENCIA)
                  AND (tipoCredito = -1 OR tipoCredito = I."TIPO CREDITO")
   )LOOP
      somatorioAno."CREDITO SOLICITADO" :=  somatorioAno."CREDITO SOLICITADO" + I."CREDITO SOLICITADO";
      somatorioAno."MONTANTE TOTAL CREDITO" := somatorioAno."MONTANTE TOTAL CREDITO" + I."MONTANTE TOTAL CREDITO";
      somatorioAno."VALOR JA PAGO" := somatorioAno."VALOR JA PAGO" + I."VALOR JA PAGO";
      
      I."CREDITO SOLICITADO" := PACK_LIB.money(I."CREDITO SOLICITADO", '');
      I."MONTANTE TOTAL CREDITO" := PACK_LIB.money(I."MONTANTE TOTAL CREDITO", '');
      I."VALOR JA PAGO" := PACK_LIB.money(I."VALOR JA PAGO", '');
      
      PIPE ROW(I);
   END LOOP;
   -- Apresentar o somatorio do intervalo
   
   somatorioAno."CREDITO SOLICITADO" := PACK_LIB.money(somatorioAno."CREDITO SOLICITADO", '');
   somatorioAno."MONTANTE TOTAL CREDITO" := PACK_LIB.money(somatorioAno."MONTANTE TOTAL CREDITO", '');
   somatorioAno."VALOR JA PAGO" := PACK_LIB.money(somatorioAno."VALOR JA PAGO", '');
   PIPE ROW(somatorioAno);
   
   -- preparar o calculo para a diferenca do ano
   IF deferencaAno IS NOT NULL AND deferencaAno > 0 THEN
      -- Efetuar o somatorio no intervalo aplicando a diferenca do tempo
       FOR I IN(SELECT I.*
                  FROM VER_REQ_CREDITO_DIVIDA_PRODT I
                  WHERE I.LOCAL_TRABALHO = localTrabalho
                      AND I.INICIO BETWEEN dataInicoPast AND dataFinPast
                      AND (agenciaUs = -1 OR agenciaUs = I.AGENCIA)
                      AND (tipoCredito = -1 OR tipoCredito = I."TIPO CREDITO")
       ) LOOP
          somatorioAnoPast."CREDITO SOLICITADO" :=  somatorioAnoPast."CREDITO SOLICITADO" + I."CREDITO SOLICITADO";
          somatorioAnoPast."MONTANTE TOTAL CREDITO" := somatorioAnoPast."MONTANTE TOTAL CREDITO" + I."MONTANTE TOTAL CREDITO";
          somatorioAnoPast."VALOR JA PAGO" := somatorioAnoPast."VALOR JA PAGO" + I."VALOR JA PAGO";
          
        END LOOP;
        
        somatorioAnoPast."CREDITO SOLICITADO" := PACK_LIB.money(somatorioAnoPast."CREDITO SOLICITADO", '');
        somatorioAnoPast."MONTANTE TOTAL CREDITO" := PACK_LIB.money(somatorioAnoPast."MONTANTE TOTAL CREDITO", '');
        somatorioAnoPast."VALOR JA PAGO" := PACK_LIB.money(somatorioAnoPast."VALOR JA PAGO", '');
        PIPE ROW(somatorioAnoPast);
   ELSE
      PIPE ROW(somatorioAno);
   END IF;
END;