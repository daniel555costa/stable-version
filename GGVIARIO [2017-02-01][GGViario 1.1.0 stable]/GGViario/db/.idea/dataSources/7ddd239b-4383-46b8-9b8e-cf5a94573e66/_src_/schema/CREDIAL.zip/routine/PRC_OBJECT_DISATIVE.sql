create PROCEDURE PRC_OBJECT_DISATIVE 
(
    idUser NUMBER,
    -- idTipoObject NUMBER,
    idObject NUMBER
) IS
BEGIN
   -- Desativa o objecto 
   UPDATE OBJECTO ob
      SET ob.OBJ_STATE = 0 
      WHERE ob.OBJ_ID = idObject
         --AND ob.OBJ_TOBJ_ID = idTipoObject;
      ;
END;