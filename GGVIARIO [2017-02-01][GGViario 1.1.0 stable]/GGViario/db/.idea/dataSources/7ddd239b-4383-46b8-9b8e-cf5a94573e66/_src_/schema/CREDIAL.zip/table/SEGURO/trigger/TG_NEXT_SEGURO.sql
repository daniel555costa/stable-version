create trigger TG_NEXT_SEGURO
	before insert
	on SEGURO
	for each row
BEGIN
  IF inserting
  THEN
    IF :NEW."SEG_ID" IS NULL
    THEN
      SELECT SEQ_SEGURO.NEXTVAL
        INTO :NEW."SEG_ID"
        FROM dual;
    END IF;
  END IF;
END;
