create view VER_CHEQUES_DIPONIVEIS as
select ag.AGE_DESC as AGENCIA, bc.BANCO_SIGLA as BANCO, ch.CHEQ_TOTALCHEQUES as TOTAL, ch.CHEQ_TOTALDISTRIBUIDOS as DESTRIBUIDA
  from CHEQUEMPRESA ch
    inner join AGENCIA ag on ch.CHEQ_AGE_ID = ag.AGE_ID
    inner join BANCO bc on ch.CHEQ_BANCO_ID = bc.BANCO_ID
  where ch.CHEQ_ESTADO = 1
  order by ag.age_desc asc, bc.banco_sigla asc
