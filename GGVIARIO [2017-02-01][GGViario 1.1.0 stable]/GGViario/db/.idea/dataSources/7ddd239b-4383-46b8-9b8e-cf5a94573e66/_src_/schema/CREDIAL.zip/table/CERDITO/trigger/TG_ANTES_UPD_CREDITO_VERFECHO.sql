create trigger TG_ANTES_UPD_CREDITO_VERFECHO
	before update
	on CERDITO
	for each row
DECLARE 
   liquidado BOOLEAN DEFAULT(CASE 
                                  WHEN :NEW.CERDI_NUMPRESTAFALTA = :OLD.CERDI_NUMPRESTACOES
                                    AND :NEW.CERDI_VALORPAGO = :OLD.CREDI_VALORCREDITO
                                    THEN TRUE 
                                  ELSE FALSE 
                                END);
BEGIN
  -- Se for liquidado o credito todo entaco colocar o estado de credito a zero
  /*IF updating AND liquidado THEN
    :NEW.CERDI_ESTADO := 0;
    :NEW.CREDI_CREDITOESTADO := 0;
  END IF;*/
  NULL;
END;
