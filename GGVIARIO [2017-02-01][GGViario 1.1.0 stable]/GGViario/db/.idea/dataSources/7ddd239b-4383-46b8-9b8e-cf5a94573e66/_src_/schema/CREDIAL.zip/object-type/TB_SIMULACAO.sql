create TYPE           "TB_SIMULACAO"                                          AS
TABLE OF TP_SIMULACAO;