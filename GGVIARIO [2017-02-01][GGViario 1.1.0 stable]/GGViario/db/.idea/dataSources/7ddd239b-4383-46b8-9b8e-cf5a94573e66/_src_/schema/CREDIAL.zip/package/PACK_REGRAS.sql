create PACKAGE         PACK_REGRAS 
  IS

  -- RECOREDE PARA ARMAZENAR RESULTADOS DAS PESQUISAS DAS TAXAS
  TYPE PTP_RESULT_TAXA IS RECORD (
      ID      NUMBER,
      VALOR   BINARY_DOUBLE,
      ESTADO  NUMBER,
      PERIODO NUMBER
    );
  TYPE PTP_RandomCheck IS RECORD (
      idCheque     NUMBER,
      numSequencia VARCHAR2(31)
    );

  -- FUNCAO PARA OBTER O SEGURO ACTIVO
  FUNCTION PFUNC_GET_SEGURO_ACTIVO
    RETURN BINARY_DOUBLE;

  --OBRTER O PERIOD DA TAXA ACIMA
  FUNCTION PFUNC_GET_PERIODO_TAXA(PERIODO     NUMBER,
                                  CREDITO_REQ NUMBER) 
    RETURN PACK_REGRAS.PTP_RESULT_TAXA;

  -- OBTER A TAXA DO PERIODP A BAIXO
  FUNCTION PFUNC_GET_PERIODO_TAXA_INF(PERIODO     NUMBER,
                                      CREDITO_REQ NUMBER)
    RETURN PACK_REGRAS.PTP_RESULT_TAXA;

  PROCEDURE PPRC_UPD_PENALIDADE(valorPenalidade BINARY_DOUBLE,
                                idCredito       NUMBER,
                                NIFCredito      VARCHAR2);


  -- Funcao para caregar checques de um determindo banco
  FUNCTION PFUNC_GET_CHEQUEMPRESA_BANCK(idBanco NUMBER)
    RETURN TB_BANCOCHECK;


  -- Funcao para retirar ao acalhar um cheque de um cheque empresa

  FUNCTION PFUNC_GET_CHEQUE_RANDOM(userid          VARCHAR,
                                   idBanco         NUMBER,
                                   idAgencia       NUMBER,
                                   valorRequisicao BINARY_DOUBLE)
    RETURN PTP_RandomCheck;



  FUNCTION PFUNC_validateSequencia(inicio VARCHAR2,
                                   fim    VARCHAR2,
                                   idBanco NUMERIC)
    RETURN NUMBER;

  FUNCTION PFUNC_GET_DOSSIER_NUMBER
    RETURN VARCHAR2;


  FUNCTION PFUNC_GENERATE_NUMCRIDITO(clienteNIF VARCHAR2,
                                     numCheque  NVARCHAR2)
    RETURN VARCHAR2;

END;