create FUNCTION "FUNC_LOGAR" 
(
   ACCESSNAME VARCHAR2,
   PWD        VARCHAR2
)
RETURN TB_ARRAY_STRING
IS
  arrayData TB_ARRAY_STRING := TB_ARRAY_STRING();
  seletedUser VER_USER%ROWTYPE;
  tt  INTEGER;
BEGIN
    -- VERIFICAR SE O UTILIZADOR EXISTE
    SELECT COUNT(*) INTO tt
        FROM VER_USER FU
        WHERE FU.ESTADO != 0
          AND FU.NIF IN (SELECT US.USER_ID
                            FROM T_USER US
                            WHERE US.USER_ID = ACCESSNAME
                               AND US.USER_PWD = FUNC_MD5(PWD));
    
    IF tt = 1 THEN
       -- BUSCAR PELO UTILIZADOR
       SELECT * INTO seletedUser
          FROM VER_USER FU
          WHERE FU.ESTADO != 0
             AND FU.NIF IN (SELECT US.USER_ID
                               FROM T_USER US
                               WHERE US.USER_ID = ACCESSNAME
                                  AND US.USER_PWD = FUNC_MD5(PWD));
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'NOME;'||seletedUser.NOME;
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'NIF;'||seletedUser.NIF;
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'ESTADO;'||seletedUser.ESTADO;
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'AGENCIA;'||seletedUser.AGENCIA;
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'AGENCIA NOME;'||seletedUser."AGENCIA NOME";
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'PERFIL;'||seletedUser.PREFIL;
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'PERFIL NOME;'||seletedUser."PERFIL NOME";
       
       -- Criar o login da secao
       INSERT INTO LOGIN (LOGIN_USER_ID) VALUES (seletedUser.NIF) RETURNING LOGIN_ID INTO tt;
       arrayData.EXTEND;
       arrayData(arrayData.COUNT) := 'LOGIN;'||tt;
    END IF;
    RETURN arrayData;
END;