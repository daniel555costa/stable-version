create PACKAGE BODY PACK_FILTER_CLIENTE AS

  function filterClient(value character varying) return FilterClientSimple PIPELINED
  is
  begin
     for cls in (
         select DISTINCT *
           from (
              select * from  table(PACK_FILTER_CLIENTE.FILTERCLINETNIF(value))
              UNION (select * from table (PACK_FILTER_CLIENTE.FILTERCLINETNAME(value)))
              UNION (select * from table (PACK_FILTER_CLIENTE.FILTERCLINETDOCUMENTOPAY(value)))
              UNION (select * from table (PACK_FILTER_CLIENTE.FILTERCLINETGARRANTIA(value)))
              ) cls
           order by cls."NOME" asc, cls."APELIDO" asc
    ) loop 
       pipe row(cls);
    end loop;
        
  end filterClient;

  function filterCLinetNif(clientNif character varying) return FilterClientSimple PIPELINED AS
  BEGIN
    for cls in (
       SELECT CLS.*
              FROM VER_CLIENTE_SIMPLE CLS
              WHERE (CLS.NIF) LIKE ('%'||clientNif||'%')
    ) loop
       pipe row (cls);
    end loop;
  END filterCLinetNif;

  function filterCLinetName(clientName character varying) return FilterClientSimple PIPELINED 
  IS
     likeValue character varying(4000):= PACK_LIB.NO_ACCENT('%'||clientName||'%');
     client VER_CLIENTE_SIMPLE%ROWTYPE;
  BEGIN
     for cls in (
        SELECT CLS.*
            FROM MVER_CLIENT_SIMPLE_NOACCENT CLS
            WHERE CLS."NOME NO ACCENTE" LIKE likeValue
              OR CLS."APELIDO NO ACCENTE" LIKE likeValue
     )loop 
        client."NIF" := cls."NIF";
        client."DOSSIER" := cls."DOSSIER";
        client."NOME" := cls."NOME";
        client."APELIDO" := cls."APELIDO";
        client."ID AGENCIA" := cls."ID AGENCIA";
        pipe row(client);
     end loop;
  END filterCLinetName;

  function filterCLinetDocumentoPay(numDocumentoPagamento character varying) return FilterClientSimple PIPELINED 
  IS 
     likeKey CHARACTER VARYING (1000) := '%'||numDocumentoPagamento||'%';
  BEGIN
      for cls in (
         SELECT DISTINCT CLS.*
            FROM VER_CLIENTE_SIMPLE CLS
               LEFT JOIN CERDITO CT ON CLS.NIF = CT.CREDI_DOS_NIF
               LEFT JOIN PAGAMENTO PA ON CT.CREDI_ID = PA.PAGA_CREDI_ID
        WHERE PA.PAGA_NUMDOCPAGAMENTO LIKE likeKey
     )loop 
        pipe row(cls);
     end loop;
  END filterCLinetDocumentoPay;

  function filterCLinetGarrantia(clientGarrantia character varying) return FilterClientSimple PIPELINED 
  IS
     docGarNoAccent CHARACTER VARYING(4000) := PACK_LIB.NO_ACCENT('%'||clientGarrantia||'%');
  BEGIN
     for cls in (
        SELECT  DISTINCT CLS.*
            FROM VER_CLIENTE_SIMPLE CLS
               LEFT JOIN CERDITO CT ON CLS.NIF = CT.CREDI_DOS_NIF
               LEFT JOIN MVER_GARRANTIA_NOACCENT GA ON CT.CREDI_ID = GA.GARDOC_CREDI_ID
               LEFT JOIN MVER_DOCUMENT_NOACCENT DO ON CT.CREDI_ID = DO.DOCENTER_CREDI_ID
            WHERE DO."DOCENTER_DESC NOACCENT" LIKE docGarNoAccent
               OR GA."GARDOC_DESC NOACCENT" LIKE docGarNoAccent
     )loop 
        pipe row(cls);
     end loop;
  END filterCLinetGarrantia;

END PACK_FILTER_CLIENTE;