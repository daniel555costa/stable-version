create trigger TG_NEXT_LOGIN
	before insert
	on LOGIN
	for each row
begin  
   if inserting then 
      if :NEW."LOGIN_ID" is null then 
         select SEQ_LOGIN.nextval into :NEW."LOGIN_ID" from dual; 
      end if; 
   end if; 
end;
