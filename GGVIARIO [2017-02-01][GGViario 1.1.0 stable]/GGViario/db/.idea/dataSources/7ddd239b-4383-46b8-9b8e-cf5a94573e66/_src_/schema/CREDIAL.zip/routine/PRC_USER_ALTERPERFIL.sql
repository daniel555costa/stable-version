create PROCEDURE PRC_USER_ALTERPERFIL 
(
  idUserSuper IN VARCHAR2, -- O utilizador que esta a alterar(Administrador)
  idUserAlterar IN VARCHAR2, -- O itilizador que tera o perfil alterado
  idNewPerfilForUser NUMBER -- O novo perfil para o utilizador
) AS 
BEGIN
    -- Altrar o perfil do utilizador
    -- UPDATE USER PROFILE
    UPDATE T_USER U
       SET U.USER_TPREF_ID = idNewPerfilForUser
       WHERE U.USER_ID = idUserAlterar;
END PRC_USER_ALTERPERFIL;