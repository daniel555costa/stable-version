create TYPE           "TB_BANCOCHECK"                                          AS
TABLE OF TP_BANCOCHECK;