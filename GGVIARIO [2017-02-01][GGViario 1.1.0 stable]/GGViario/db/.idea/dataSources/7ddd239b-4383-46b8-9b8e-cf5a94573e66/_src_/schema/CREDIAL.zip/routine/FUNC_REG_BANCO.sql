create FUNCTION FUNC_REG_BANCO 
(
    idUser VARCHAR2,
    sigla VARCHAR2,
    nome VARCHAR2,
    idAgencia NUMBER
)RETURN VARCHAR2 IS
BEGIN
    INSERT INTO BANCO(BANCO_USER_ID, 
                      BANCO_SIGLA,
                      BANCO_NOME,
                      BANCO_AGE_ID)
                      VALUES(idUser,
                             sigla,
                             nome,
                             idAgencia);
    RETURN 'true';
    EXCEPTION WHEN OTHERS THEN RETURN 'Sigla ou nome do banco ja existe'; 
    
END;