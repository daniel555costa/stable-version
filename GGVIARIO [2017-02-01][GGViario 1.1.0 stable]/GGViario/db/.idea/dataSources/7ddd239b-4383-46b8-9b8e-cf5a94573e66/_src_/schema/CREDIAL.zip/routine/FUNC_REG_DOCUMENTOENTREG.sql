create FUNCTION         FUNC_REG_DOCUMENTOENTREG 
(
   userId NVARCHAR2,
   idTipoDocumento NUMBER,
   idCredito NUMBER,
   idAgencia NUMBER,
   designacao CHARACTER VARYING
)
RETURN VARCHAR2
IS
BEGIN
    INSERT INTO DOCUMENTREGUE (DOCENTR_USER_ID, 
                               DOCENTR_DOCUM_ID, 
                               DOCENTER_CREDI_ID,
                               DOCENTR_AGE_ID,
                               DOCENTER_DESC)
                               VALUES (userId, 
                                       idTipoDocumento, 
                                       idCredito,
                                       idAgencia,
                                       designacao);
                                       

    RETURN 'true';
END;