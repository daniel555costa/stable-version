create function randomSum (numberText character varying ) return number
    is
       sumAcumulator number := 0;
       len number :=  length(numberText);
       randomIndex number;
       numberIndexRandom NUMBER;
    BEGIN
       if len is null or  len = 0 then return null; end if;
       
       FOR i in 1..len
       LOOP
          randomIndex := TO_NUMBER(SUBSTR(SYS.DBMS_RANDOM.value(1, len+1), 1, 1));
          
          -- retira um par de numero a calhas
          numberIndexRandom := TO_NUMBER(SUBSTR(numberText, randomIndex, 2));
          sumAcumulator := sumAcumulator + numberIndexRandom;
       END LOOP;
       return sumAcumulator;
    END;