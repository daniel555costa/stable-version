create FUNCTION         FUNC_REG_PAGAMENTO 
(
  USER_ID VARCHAR2,
  NUMERO_DOCUMENTO_PAGAMENTO VARCHAR2, -- 
  DATA_DOCUMENTO_PAGAMENTO   DATE,
  ID_TIPO_PAGAMENTO          NUMBER,
  ID_CREDITO                 NUMBER,
  PERIODO                    NUMBER,
  DATA_SAQUE DATE,
  TAXA                       FLOAT,
  PRESTACAO                  NUMBER,
  REEMBOLSO                  FLOAT,
  DESCONTO                   FLOAT,
  VALOR_REAL                 FLOAT,
  CONTA                      VARCHAR2,
  DATA_EMBOLSO               DATE,
  ID_BANCO NUMBER,
  NUM_DOC_PAGAMENTO_REAL     FLOAT,
  DATA_PAGAMENTO_REAL        DATE,
  idAgencia NUMBER
)
  RETURN VARCHAR2
  IS
  BEGIN
    INSERT INTO PAGAMENTO ( PAGA_USER_ID, 
                            PAGA_NUMDOCPAGAMENTO, 
                            PAGA_DATADOCUEMNTOPAGAMENTO, 
                            PAGA_TIPOPAGA_ID, 
                            PAGA_CREDI_ID,
                            PAGA_PERIODO,
                            PAGA_DATASAQUE,
                            PAGA_TAXA,
                            PAGA_PRESTACAO, 
                            PAGA_REEMBOLSO, 
                            PAGA_DESCONTO,
                            PAGA_VALOREAL,
                            PAGA_CONTA, 
                            PAGA_DATAENDOSSADO,
                            PAGA_BANCO_ID,
                            PAGA_NUMDOCPAGAMENTOREAL,
                            PAGA_DATADOCPAGAMENTOREAL,
                            PAGA_AGE_ID)
                            VALUES (USER_ID,
                                    NUMERO_DOCUMENTO_PAGAMENTO,
                                    DATA_DOCUMENTO_PAGAMENTO,
                                    ID_TIPO_PAGAMENTO, 
                                    ID_CREDITO,
                                    PERIODO,
                                    DATA_SAQUE,
                                    TAXA ,
                                    PRESTACAO,
                                    REEMBOLSO,
                                    DESCONTO,
                                    VALOR_REAL,
                                    CONTA ,
                                    DATA_EMBOLSO,
                                    ID_BANCO,
                                    NUM_DOC_PAGAMENTO_REAL,
                                    DATA_PAGAMENTO_REAL,
                                    idAgencia
                                   );
    RETURN 'true';
  END;