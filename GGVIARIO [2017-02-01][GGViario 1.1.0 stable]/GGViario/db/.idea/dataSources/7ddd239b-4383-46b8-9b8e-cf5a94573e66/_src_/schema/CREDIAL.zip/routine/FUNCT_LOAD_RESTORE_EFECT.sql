create FUNCTION  FUNCT_LOAD_RESTORE_EFECT
  RETURN PACK_VIEW.FilterRestoreCredito PIPELINED
  IS
    rowEfect PACK_VIEW.RestoreCredito;
    reativeRow PACK_VIEW.RestoreCredito;
    lastCheque CHEQUEMPRESA%ROWTYPE;
    reative CHEQUEMPRESA%ROWTYPE;

    banco CHARACTER VARYING(100);
    agencia CHARACTER VARYING(100);
    iCount NUMBER;
  BEGIN

    SELECT COUNT(*) INTO iCount
    FROM (SELECT *
          FROM CHEQUEMPRESA CH
          ORDER BY  CH.CHEQ_DATAREG DESC) CHE
    WHERE ROWNUM <= 1;



    IF iCount > 0 THEN

      SELECT * INTO lastCheque
      FROM (SELECT *
              FROM CHEQUEMPRESA CH
              ORDER BY  CH.CHEQ_DATAREG DESC) CHE
      WHERE ROWNUM <= 1;

      IF lastCheque.CHEQ_TOTALDISTRIBUIDOS  = 0 THEN
        SELECT B.BANCO_NOME INTO banco
          FROM BANCO B
          WHERE B.BANCO_ID = lastCheque.CHEQ_BANCO_ID;

        SELECT AG.AGE_DESC INTO agencia
          FROM AGENCIA AG
          WHERE AG.AGE_ID = lastCheque.CHEQ_AGE_ID;

        rowEfect.ID := lastCheque.CHEQ_ID;
        rowEfect.OPR := -1;
        rowEfect.OPERATION := 'Remover';
        rowEfect.BANCO := banco;
        rowEfect.AGENCIA := agencia;
        rowEfect.INICIO := lastCheque.CHEQ_SEQUENCIAINICIO;
        rowEfect.FIM := lastCheque.CHEQ_SEQUENCIAFIM;

        PIPE ROW (rowEfect);

        SELECT COUNT(*) INTO iCount
          FROM (SELECT *
                  FROM CHEQUEMPRESA CH
                  WHERE CH.CHEQ_ID != lastCheque.CHEQ_ID
                    AND CH.CHEQ_BANCO_ID = lastCheque.CHEQ_BANCO_ID
                    AND CH.CHEQ_AGE_ID = lastCheque.CHEQ_AGE_ID
                  ORDER BY CH.CHEQ_DATAREG DESC);

        IF iCount > 0 THEN

          SELECT * INTO reative
            FROM (SELECT *
                    FROM CHEQUEMPRESA CH
                    WHERE CH.CHEQ_ID != lastCheque.CHEQ_ID
                          AND CH.CHEQ_BANCO_ID = lastCheque.CHEQ_BANCO_ID
                          AND CH.CHEQ_AGE_ID = lastCheque.CHEQ_AGE_ID
                    ORDER BY CH.CHEQ_DATAREG DESC)
            WHERE ROWNUM <= 1;

          IF reative.CHEQ_TOTALDISTRIBUIDOS < reative.CHEQ_TOTALDISTRIBUIDOS THEN

            SELECT B.BANCO_NOME INTO banco
              FROM BANCO B
              WHERE B.BANCO_ID = reative.CHEQ_BANCO_ID;

            SELECT AG.AGE_DESC INTO agencia
              FROM AGENCIA AG
              WHERE AG.AGE_ID = reative.CHEQ_AGE_ID;

            reativeRow.ID := lastCheque.CHEQ_ID;
            reativeRow.OPR := 1;
            reativeRow.OPERATION := 'Reativar';
            reativeRow.BANCO := banco;
            reativeRow.AGENCIA := agencia;
            reativeRow.INICIO := reative.CHEQ_SEQUENCIAINICIO;
            reativeRow.FIM := reative.CHEQ_SEQUENCIAFIM;
         
            PIPE ROW (reativeRow);
          END IF;

        END IF;

      END IF;

    END IF;

  END;