create FUNCTION  "FUNC_REG_CLIENTE" 
( USUARIO         VARCHAR2,
  NIF             VARCHAR2,
  NOME            VARCHAR2,
  APELIDO         VARCHAR2,
  ID_GENERO  NUMBER,
  DATA_NASCIMENTO DATE,
  idAgencia NUMBER
)
  RETURN VARCHAR2
  IS
    TT_NIF    NUMBER;
    RESP      VARCHAR2(2000);
    NDOSS     VARCHAR2(9) := PACK_REGRAS.PFUNC_GET_DOSSIER_NUMBER();
  BEGIN
    --VERIFICANDO A DUPLICALIDADE DO NIF
    SELECT COUNT(*)
      INTO TT_NIF
      FROM DOSSIERCLIENTE DOS
      WHERE DOS.DOS_NIF = NIF;
    IF TT_NIF != 0
    THEN
      RETURN 'NIF existente';
    END IF;

    -- REGISTRADO O CLIENTE
    INSERT INTO DOSSIERCLIENTE (DOS_NIF,
                                DOS_NUMDOS,
                                DOS_NOME,
                                DOS_APELIDO,
                                DOS_GEN_ID,
                                DOS_DATANASC,
                                DOS_USER_ID,
                                DOS_AGE_ID)
                                VALUES (NIF, 
                                        NDOSS,
                                        NOME,
                                        APELIDO,
                                        ID_GENERO,
                                        DATA_NASCIMENTO,
                                        USUARIO,
                                        idAgencia);
    RETURN 'true';
  END;