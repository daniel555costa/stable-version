create trigger TG_NEXT_OBJECT
	before insert
	on OBJECTO
	for each row
BEGIN
  IF inserting THEN
    IF :NEW."OBJ_ID" IS NULL THEN
      SELECT SEQ_OBJECTO.NEXTVAL 
        INTO :NEW."OBJ_ID"
        FROM dual;
    END IF;
  END IF;
END;
