create PROCEDURE PRC_APLICAR_MULTA 

  -- OS SIMULARVALORES >31 CORESPONDE A MESES
  -- OS SIMULARVALORES <= 30 CORREESPONDEM A SEMANAS
  -- UMA SEMANA CORESPONDE A 7 DIA E CORESPONDE A UM PERIODO
  -- DUAS SEMANAS CORESPONDE A 15 diferencaDatas 2 PERIODOS
  -- 3 SEMANS CORESPONDE A 21 diferencaDatas 3 PERIODOS
  -- 4 SEMANS CORESPONDE A 30 diferencaDatas 4 PERIODO
  -- OS SIMULARVALORES > 30 A MESES 31 CORESPINDE A 1 MES E NESTE CASO UM PERIODO
  -- 60 MESES 2 PERIODSO, 90  3 MESES 3 PERIODOS, 120 diferencaDatas 4 MESES 4 PERIODOS, ECT

  IS
    RESP                TB_SIMULACAO  := TB_SIMULACAO();
    POS                 NUMBER        := 0;
    NUM_PERIODO         INTEGER       := 0;
    NUM_SEMANAS         NUMBER        := 0;
    RESTO_DIVISAO       NUMBER        := 0;
    SIMULARVALOR_SEGURO BINARY_DOUBLE := 0;
    
    


    TAXA_INF            PACK_REGRAS.PTP_RESULT_TAXA;
    TAXA                PACK_REGRAS.PTP_RESULT_TAXA;
    
    

    -- VAR
    nAcumularPenalidade INTEGER       := 0;
    diferencaDatas      INTEGER       := 0;
    taxaSimula          BINARY_DOUBLE := 0;
    periodoSimula       INTEGER       := 0;
    capiatalSimula      BINARY_DOUBLE := 0;
  BEGIN

    -- CURSOR PARA PERCORER AS SELECOES DOS CREDITOS COM PENALIDADE DO INICIO ATE AO FIN
    FOR I IN (SELECT * FROM VER_SELECT_PENALIDADE) LOOP

      nAcumularPenalidade := I.CREDI_PENALIDADE;
      diferencaDatas :=  TRUNC((SYSDATE - TO_DATE(i.CREDI_DATAREG, 'DD-MM-YYYY'))||''); --obter o dia
      -- DBMS_OUTPUT.PUT_LINE(diferencaDatas);

      IF diferencaDatas < 30 THEN -- caso for semana 
        NUM_PERIODO := 1; -- SEMANA DE 7 diferencaDatas
        NUM_SEMANAS := 30;
      ELSE -- CASO DE MES
        NUM_SEMANAS := 30;
        NUM_PERIODO := TRUNC(diferencaDatas / NUM_SEMANAS);
        RESTO_DIVISAO := MOD(diferencaDatas, NUM_SEMANAS); -- obter o resto da divisao
      END IF;

      IF RESTO_DIVISAO >= 1 THEN
        NUM_PERIODO := NUM_PERIODO + 1;
      ELSE
        IF RESTO_DIVISAO = 0 THEN
          NUM_PERIODO := NUM_PERIODO;
        END IF;
      END IF;

      IF NUM_PERIODO >= 4 AND NUM_SEMANAS = 7 THEN
        NUM_PERIODO := 4;
      ELSE 
         IF NUM_PERIODO >= 2 AND NUM_SEMANAS = 30  THEN
          SIMULARVALOR_SEGURO := PACK_REGRAS.PFUNC_GET_SEGURO_ACTIVO(); --BUCAR O ACTUAL SEGURO ACTIVO
        END IF;
      END IF;

      --BUSCAR AS TAXAS SUPERIORES E INFERIORES
      TAXA_INF := PACK_REGRAS.PFUNC_GET_PERIODO_TAXA_INF(diferencaDatas, i.TAXA_TIPOCRED_ID);
      -- DBMS_OUTPUT.put_line('TAXA_INF.ID = ' || TAXA_INF.ID);
      -- DBMS_OUTPUT.put_line('TAXA_INF.VALOR = ' || TAXA_INF.VALOR);
      -- DBMS_OUTPUT.put_line('TAXA_INF.ESTADO = ' ||TAXA_INF.ESTADO);
      -- DBMS_OUTPUT.put_line('TAXA_INF.PERIODO = ' ||TAXA_INF.PERIODO);
      
      
      -- DBMS_OUTPUT.put_line('TAXA.ID = ' || TAXA.ID);
      -- DBMS_OUTPUT.put_line('TAXA.VALOR = ' ||TAXA.VALOR);
      -- DBMS_OUTPUT.put_line('TAXA.ESTADO = ' ||TAXA.ESTADO);
      -- DBMS_OUTPUT.put_line('TAXA.PERIODO = ' ||TAXA.PERIODO);
      


      TAXA := PACK_REGRAS.PFUNC_GET_PERIODO_TAXA(diferencaDatas, i.TAXA_TIPOCRED_ID);
      -- DBMS_OUTPUT.put_line('diferencaDatas  = '||diferencaDatas );
      

      IF TAXA.ID != -1 THEN -- QUANDO HOUVER TAXA SUPERIOR
        IF TAXA.VALOR >= 1 THEN
          taxaSimula := TAXA.VALOR;
          periodoSimula := NUM_PERIODO;
          capiatalSimula := i.CREDI_VALORCREDITO;


          DECLARE
            NTAEGSUP                      NUMBER := 0; -- 
            NTAEGINF                      NUMBER := 0;
            nDiaMais                      NUMBER := 0;
            NTAEGDIFERENCA                NUMBER := 0;
            XDIARIO                       NUMBER := 0;

            TAEG_SEM_DESCONTO_SIMULA      NUMBER := 0;
            TAEG_COM_DESCONTO_SIMULA      NUMBER := 0;
            DESCONTO_SIMULA               NUMBER := 0;
            DESCONTO_SIMULA_CORECAO_TOTAL NUMBER := 0;
            taegSimula                    NUMBER := 0;
            totalPagarSimula              NUMBER := 0;
            xPenalidadeEfectiva           NUMBER := 0;
          BEGIN

            -- X1 CALCULO DE TAEG SUPERIOR
            NTAEGSUP := i.CREDI_VALORCREDITO * (TAXA.VALOR / 100);
            
            

            -- X2 CALCULO DE TAEG INFERIOR
            NTAEGINF := i.CREDI_VALORCREDITO * (TAXA_INF.VALOR / 100);
            
            
           
            

            -- D1 - D2 INF diferencaDatas DO PERIODOP MENOS O PERIODO DA TAGE INFERIOR
            nDiaMais := diferencaDatas - TAXA_INF.PERIODO;
            -- DBMS_OUTPUT.PUT_LINE('nDiaMais = '|| nDiaMais);
            
            -- X2 - X1 DIFERENCA ENTRE A TAEG SUPERIRO E INFERIOR
            NTAEGDIFERENCA := NTAEGSUP - NTAEGINF;
            -- DBMS_OUTPUT.PUT_LINE('NTAEGDIFERENCA = '|| NTAEGDIFERENCA);
            -- DIARIO = (X1 - X2)/DLIMSUP - D2LIMINF

            IF ((TAXA.PERIODO - TAXA_INF.PERIODO) = 0) OR ((NTAEGSUP - NTAEGINF) = 0) THEN
              XDIARIO := 0;
            ELSE
              XDIARIO := ((NTAEGSUP - NTAEGINF) / (TAXA.PERIODO - TAXA_INF.PERIODO));
              -- DBMS_OUTPUT.PUT_LINE('NTAEGSUP = '|| NTAEGSUP);
              -- DBMS_OUTPUT.PUT_LINE('NTAEGINF = '|| NTAEGINF);
              -- DBMS_OUTPUT.PUT_LINE('TAXA.PERIODO = '|| TAXA.PERIODO);
              -- DBMS_OUTPUT.PUT_LINE('TAXA_INF.PERIODO = '|| TAXA_INF.PERIODO);
            END IF;
            
            
            TAEG_SEM_DESCONTO_SIMULA := (NTAEGINF + (XDIARIO * nDiaMais));
            -- DBMS_OUTPUT.PUT_LINE('TAGE SEM DESCONTO = '|| TAEG_SEM_DESCONTO_SIMULA);
            -- DBMS_OUTPUT.PUT_LINE('X DIARIO = '|| XDIARIO);
            -- DBMS_OUTPUT.PUT_LINE('nDiaMais = '|| nDiaMais);
            -- DBMS_OUTPUT.PUT_LINE('NTAEGINF = '|| NTAEGINF);
            taegSimula := TAEG_SEM_DESCONTO_SIMULA;
            totalPagarSimula := i.CREDI_VALORCREDITO + taegSimula + SIMULARVALOR_SEGURO;
            -- xPenalidadeEfectiva := totalPagarSimula - i.CERDI_TOTALAPAGAR;
            xPenalidadeEfectiva := totalPagarSimula - i.CREDI_VALORCREDITO;
            -- DBMS_OUTPUT.PUT_LINE('totalPagarSimula = '||totalPagarSimula);
            -- DBMS_OUTPUT.PUT_LINE('i.CERDI_TOTALAPAGAR = '||i.CERDI_TOTALAPAGAR);
            -- DBMS_OUTPUT.PUT_LINE('i.CREDI_VALORCREDITO= '||i.CREDI_VALORCREDITO  || ' | TAGE SIMU = '||taegSimula || ' | SIMULARVALOR = ' || SIMULARVALOR_SEGURO);
            
           
            -- aplicando a penalidade
            PACK_REGRAS.PPRC_UPD_PENALIDADE(xPenalidadeEfectiva, i.CREDI_ID, i.CREDI_DOS_NIF);
            -- DBMS_OUTPUT.PUT_LINE('xPenalidadeEfectiva = '||xPenalidadeEfectiva);
            -- DBMS_OUTPUT.PUT_LINE('NEW VALUE -- --- ');
          END;
        ELSE

          NULL;
        -- para escrever na entidade log
        -- RESP(1) := TP_SIMULACAO('RESULTADO', 0.0, 'CONTACTAR O ADMINISTRADOR PARA COLOCAR A TAXA QUE PERMITA SIMULAR ESSES NUMEROS DE diferencaDatas');

        END IF;
      ELSE
        NULL;
      -- enviara para a entidade do log
      -- RESP.EXTEND; RESP(1) := TP_SIMULACAO('RESULTADO', 0.0, 'CONTACTAR O ADMINISTRADOR PARA COLOCAR A TAXA QUE PERMITA SIMULAR ESSES NUMEROS DE diferencaDatas');
      END IF;
    END LOOP;
  END;