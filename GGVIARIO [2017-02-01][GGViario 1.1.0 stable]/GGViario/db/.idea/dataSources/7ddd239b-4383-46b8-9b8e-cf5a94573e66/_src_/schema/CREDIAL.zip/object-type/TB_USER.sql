create TYPE           "TB_USER"                                          AS
TABLE OF TP_USER;