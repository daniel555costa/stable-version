create TYPE           "TB_VER_TABLE"                                          AS
TABLE OF TP_VER_TABLE;