create FUNCTION PFUNC_GET_PERIODO_TAXA_INF
   (
      PERIODO NUMBER,
      CREDITO_REQ NUMBER
    )
    RETURN PACK_REGRAS.PTP_RESULT_TAXA
    IS
      RES PACK_REGRAS.PTP_RESULT_TAXA;
      tt NUMBER;
    BEGIN
    
       SELECT COUNT(*) INTO tt
        FROM (SELECT TA2.*
                  FROM TAXA TA2
                    INNER JOIN VER_TIPOCREDITO vt
                      ON vt.REALID = TA2.TAXA_TIPOCRED_ID
                  WHERE vt.REALID = CREDITO_REQ
                    AND TA2.TAXA_ESTADO = 1
                    AND TA2.TAXA_PERIODO <= PERIODO
                  ORDER BY TA2.TAXA_PERIODO DESC)
              WHERE ROWNUM <= 1;
     IF tt = 0 THEN
        FOR TA2 IN (SELECT *
                       FROM (SELECT *
                                FROM TAXA TA2
                                WHERE TA2.TAXA_TIPOCRED_ID = CREDITO_REQ
                                   AND TA2.TAXA_ESTADO = 1
                                ORDER BY TA2.TAXA_PERIODO ASC)
                        WHERE ROWNUM <= 1)
        LOOP
          RES.ID := TA2.TAXA_ID;
          RES.PERIODO := TA2.TAXA_PERIODO;
          RES.ESTADO := TA2.TAXA_ESTADO;
          RES.VALOR := TA2.TAXA_VALOR;
          
          RETURN RES;
        END LOOP;
        
     ELSE
         FOR TA2 IN (SELECT *
                      FROM (SELECT TA2.*
                                FROM TAXA TA2
                                  INNER JOIN VER_TIPOCREDITO vt
                                    ON vt.REALID = TA2.TAXA_TIPOCRED_ID
                                WHERE vt.REALID = CREDITO_REQ
                                  AND TA2.TAXA_ESTADO = 1
                                  AND TA2.TAXA_PERIODO <= PERIODO
                                ORDER BY TA2.TAXA_PERIODO DESC)
                            WHERE ROWNUM <= 1)
          LOOP
              RES.ID := TA2.TAXA_ID;
              RES.PERIODO := TA2.TAXA_PERIODO;
              RES.ESTADO := TA2.TAXA_ESTADO;
              RES.VALOR := TA2.TAXA_VALOR;
          END LOOP;
          RETURN RES;
     END IF;
     

    END;