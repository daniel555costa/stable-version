create TYPE           "TB_RANDOMCHECK"                                          AS
TABLE OF TP_RANDOMCHECK;