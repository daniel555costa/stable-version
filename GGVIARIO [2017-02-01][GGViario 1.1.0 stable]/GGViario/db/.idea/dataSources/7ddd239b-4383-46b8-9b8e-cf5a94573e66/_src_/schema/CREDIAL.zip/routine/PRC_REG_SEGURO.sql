create PROCEDURE "PRC_REG_SEGURO" 
(
  USER_ID VARCHAR2,
  VALOR   FLOAT,
  idAgencia NUMBER
)
  IS
  BEGIN
    -- DESATIVAR O ANTIGO SEGURO
    UPDATE SEGURO
      SET SEG_STATE = 0
      WHERE SEG_STATE = 1;

    -- CRAIR UM NOVO SEGURO
    INSERT INTO SEGURO (SEG_VALOR,
                        SEG_USER_ID)
                        VALUES (VALOR,
                                USER_ID);
  END;