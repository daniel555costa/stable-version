create TYPE BODY           "TP_BACKUP" AS

  /* Types Values
       DT - {Date, TIMESTAMP}
       TXT - {CHAR, VARCHAR, TEXT}
       NUM - {NUMBER, DOUBLE, FLOAT ...}
  */
  
  MEMBER FUNCTION getColumn RETURN VARCHAR2 IS
  BEGIN
     return SELF.columnName;
  END getColumn;

  -- Criar os valores para o sql
  MEMBER FUNCTION getValue RETURN VARCHAR2 IS
     treatValue VARCHAR2(4000);
     typeColumn VARCHAR2(5);
  BEGIN
    typeColumn := UPPER(SELF.typeColumn);
    treatValue := SELF.valueText;
    
    IF typeColumn = 'DT' THEN
       treatVAlue := PACK_LIB.BKDT(SELF.valueText);
    ELSIF  typeColumn = 'TXT' THEN 
       treatValue := PACK_LIB.BKTXT(SELF.valueText);
    ELSIF typeColumn = 'NUM' THEN
       treatVAlue := SELF.valueText;
    END IF;
    
    RETURN treatValue;
  END getValue;

  MEMBER FUNCTION getUpdate RETURN VARCHAR2 AS
  BEGIN
     RETURN SELF.columnName || ' = '|| getValue;
  END getUpdate;

END;