create trigger TG_POS_UPD_PAGAMENTO_UPDCREDIT
	after update
	on PAGAMENTO
	for each row
DECLARE 
   liquidado NUMBER(1) DEFAULT(CASE WHEN :NEW.PAGA_REEMBOLSO = :NEW.PAGA_PRESTACAO THEN 1 ELSE 0 END);
BEGIN
  --Quando for efectuado alguma alteracao no pagamento alterar tabem o credito corespondente
    -- Podendo aumentar o numero de prestacao paga e aumentando o tatal de prestacao a pagar
  UPDATE CERDITO c
     SET c.CERDI_NUMPRESTAFALTA = (CASE
                                      WHEN liquidado=1 AND :NEW.PAGA_ESTADO = 0 THEN c.CERDI_NUMPRESTAFALTA + 1
                                      ELSE c.CERDI_NUMPRESTAFALTA
                                   END),
          c.CERDI_VALORPAGO = c.CERDI_VALORPAGO - :OLD.PAGA_PRESTACAO + :NEW.PAGA_PRESTACAO
      WHERE c.CREDI_ID = :OLD.PAGA_CREDI_ID;
END;
