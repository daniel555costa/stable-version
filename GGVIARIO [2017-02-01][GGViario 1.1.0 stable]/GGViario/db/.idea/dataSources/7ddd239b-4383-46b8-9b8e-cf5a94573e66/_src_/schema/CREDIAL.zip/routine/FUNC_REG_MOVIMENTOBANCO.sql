create FUNCTION FUNC_REG_MOVIMENTOBANCO 
(
    userID NUMBER,
    idBanco NUMBER,
    debito BINARY_DOUBLE,
    credito BINARY_DOUBLE,
    libele VARCHAR,
    idAgencia NUMBER
)RETURN VARCHAR2 IS
   linhaBanco BANCO%ROWTYPE;
BEGIN

  SELECT *
        INTO linhaBanco
     FROM BANCO B
     WHERE B.BANCO_ID = idBanco;
  
  -- No momento de debito garantir que tenha saldo sufieciente no banco
  IF credito = 0 AND debito != 0 AND linhaBanco.BANCO_SALDO < debito  THEN 
     RETURN  'Nao existe saldo suficiente no banco';
  END IF;
     
  ---RETURN 'USER='||userID||'; BANCO='||idBanco||'; DEBITO='||debito||'; CRFEDITO='||credito||'; CHEQUE='||numeroCheque||'; NCREDITO='||numeroCredito;
   
     INSERT INTO BANCOMOVIEMNTO (BANCOMOV_DEBITO, 
                                  BANCOMOV_CERDITO, 
                                  BANCOMOV_LIBELE, 
                                  BANCOMOV_USER_ID, 
                                  BANCOMOV_BANCO_ID,
                                  BANCOMOV_AGE_ID)
                                  VALUES(debito,
                                         credito,
                                         libele,
                                         userID,
                                         idBanco,
                                         idAgencia);
   RETURN 'true';

END;