create trigger TG_NEXT_SALARIO
	before insert
	on SALARIO
	for each row
BEGIN
  IF inserting
  THEN
    IF :NEW."SAL_ID" IS NULL
    THEN
      SELECT SEQ_SALARIO.NEXTVAL
        INTO :NEW."SAL_ID"
        FROM dual;
    END IF;
  END IF;
END;
