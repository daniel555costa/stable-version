create FUNCTION FUNC_ANULAR_CREDITO 
(
   idUtilizador NUMBER,
   idAgencia NUMBER,
   numeroCredito NUMBER,
   nifCliente NUMBER
)RETURN VARCHAR2
IS
   tt NUMBER;
   ttPagamentoPago NUMBER;
   linhaCredito CERDITO%ROWTYPE;
BEGIN
   SELECT COUNT(*) INTO tt
      FROM CERDITO CR
      WHERE CR.CREDI_NUMCERDI = numeroCredito
        AND CR.CREDI_DOS_NIF = nifCliente;
   
   IF tt = 0 THEN RETURN 'NIF ou Numero de credito invalido'; END IF;
   
    SELECT * INTO linhaCredito
      FROM CERDITO CR
      WHERE CR.CREDI_NUMCERDI = numeroCredito
        AND CR.CREDI_DOS_NIF = nifCliente;
    
    -- Verificar a quantidade dos pagamento nesse credito que ja estao sendo reembolsados
    SELECT COUNT(*) INTO ttPagamentoPago
      FROM PAGAMENTO PAG
      WHERE PAG.PAGA_CREDI_ID = linhaCredito.CREDI_ID
        AND PAG.PAGA_PRESTACAO != 0;

    -- Garantir que somente creditos em que não tiveram nenhum reembislo seja reembolsados
    IF linhaCredito.CERDI_ESTADO = 1
        AND linhaCredito.CERDI_VALORPAGO = 0
        AND linhaCredito.CERDI_NUMPRESTAFALTA = 0
        AND ttPagamentoPago = 0
      THEN
        -- Desativar o critodo 
        UPDATE CERDITO O
          SET O.CERDI_ESTADO = 0
          WHERE O.CREDI_ID = linhaCredito.CREDI_ID;
          
          RETURN 'true';
    ELSE RETURN 'O atual estado do credito nao aceita a anulação';
    END IF;
END;