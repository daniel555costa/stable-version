create FUNCTION         FUNC_CONFIRMAR_REGCREDITO 
(
    idUser NUMBER,
    idBanco NUMBER,
    idCredito NUMBER,
    totalDocumetosEntrges NUMBER,
    totalGarantiaCredito NUMBER,
    idAgencia NUMBER
)
  RETURN VARCHAR2
IS
    linhaCredito CERDITO%ROWTYPE;
    ttDocumentoDb NUMBER;
    ttGarantiaDb NUMBER;
    ttPagamentoDB NUMBER;
    nomeBanco VARCHAR2(50);
    res VARCHAR2(50);
    
    message VARCHAR2(500);
    messageGarantia VARCHAR2(50);
    messagePagamento VARCHAR2(50);
    messageDocumento VARCHAR2(50);
    libele VARCHAR2(220);
    
BEGIN
    
  -- Carregar todas as informacoes do creditos
    SELECT
         c.* INTO linhaCredito
       FROM CERDITO c
       WHERE c.CREDI_ID = idCredito;

    
    -- ================ BUSCAR A QUANTIDADE DE Registros dos pagamentos, DOCUMENTSO e Garantias registradas ===============
    -- Buscara a quantiade de documento entrege
    SELECT 
        COUNT(*) INTO ttDocumentoDb
       FROM DOCUMENTREGUE d
       WHERE d.DOCENTER_CREDI_ID = idCredito;

    -- Buscar pela quantidade de pagamento registrado
    SELECT 
          COUNT(*) INTO ttPagamentoDB
        FROM PAGAMENTO p 
        WHERE p.PAGA_CREDI_ID = idCredito;

    -- Buscar pela quantidade de credito registrado
    SELECT 
        COUNT(*) INTO ttGarantiaDb
        FROM GARRANTIADOCREDITO g
        WHERE g.GARDOC_CREDI_ID = idCredito;

    -- Buscar pelo nome do banco para criar a menssagem
    SELECT
            b.BANCO_NOME INTO nomeBanco
          FROM BANCO b
            INNER JOIN CHEQUEMPRESA c ON b.BANCO_ID = c.CHEQ_BANCO_ID
          WHERE c.CHEQ_ID = linhaCredito.CREDI_CHEQ_ID;

    -- "O numero do dossier é:"+ getId.split(";")[1]+ " e Cheque a atribuir Numero: "+getSequenciaCheque()+" do Banco: "+bancoCredito.split(";")[1]) );
    
    
    -- Se a quantidade de pagamento registrado for igual a total do pagamento fornecido
       -- E a quantidade dos documentos e garantia encontrada for maior que zero e menor ou igual a quantidade fornecida 
         -- Nesse caso deve ser criada a messagem de sucesso e finalizar o credito
    IF ttPagamentoDB = linhaCredito.CERDI_NUMPRESTACOES 
        AND ttDocumentoDb BETWEEN 1 AND totalDocumetosEntrges 
        AND ttGarantiaDb BETWEEN 1 AND totalGarantiaCredito THEN

        -- Criara a movimetacao no banco
        libele := 'Pagamento do cheque nº'||linhaCredito.CREDI_NUMCHEQUE||' para o credito nº'|| linhaCredito.CREDI_NUMCERDI;
        res := FUNC_REG_MOVIMENTOBANCO(idUser,
                                       idBanco, 
                                       linhaCredito.CREDI_VALORCREDITO,
                                       0,
                                       libele,
                                       idAgencia);
                                       
        -- Criar messagem de sucesso
        message := 'O credito foi registrado com sucesso'
                   ||';Dossier nº'||linhaCredito.CREDI_NUMCERDI
                   ||';Cheque: '||linhaCredito.CREDI_NUMCHEQUE
                   ||';Banco: '||nomeBanco;

       messageGarantia :=(CASE
                             WHEN ttGarantiaDb != totalGarantiaCredito THEN 'Nem todas garantias registradas!'
                             ELSE  ''
                           END );

       messageDocumento :=(CASE
                             WHEN ttDocumentoDb != totalDocumetosEntrges THEN 'Nem todas documentos registrados!'
                             ELSE ''
                           END);
      message := message 
                ||(CASE
                     WHEN messageDocumento IS NOT NULL THEN 
                        nl||messageDocumento ELSE ''
                   END)
                ||(CASE
                      WHEN messageGarantia IS NOT NULL THEN 
                        nl||messageGarantia 
                      ELSE ''
                    END);
    
        
    ELSE
    -- Para o caso contrario deve ser disfeitas todas as alteracoes aplicadas
        messageGarantia :=(CASE
                             WHEN ttGarantiaDb = 0 THEN 'Falha ao registrar as garantias!' 
                             WHEN ttGarantiaDb != totalGarantiaCredito THEN 'Nem todas garantias registradas!'
                             ELSE  ''
                           END);

       messageDocumento :=(CASE 
                             WHEN ttDocumentoDb = 0 THEN 'Falha ao registar os documentos!'
                             WHEN ttDocumentoDb != totalDocumetosEntrges THEN 'Nem todas documentos registrados!'
                             ELSE  ''
                           END);
     
      messagePagamento := (CASE
                              WHEN ttPagamentoDB != linhaCredito.CERDI_NUMPRESTACOES THEN 'Falha ao registra as prestações!'
                              ELSE ''
                            END);

      message := 'Credito nao registrado'
                  ||(CASE WHEN messagePagamento IS NOT NULL THEN NL||messagePagamento ELSE '' END)
                  ||(CASE WHEN messageDocumento IS NOT NULL THEN NL||messageDocumento ELSE  '' END)
                  ||(CASE WHEN messageGarantia IS NOT NULL THEN NL||messageGarantia ELSE '' END);

      -- Removido por causa do numero de conta bancaria que agora e introdusido a mao
      -- Repor o salto virtual do banco
      /*UPDATE BANCO b
        SET b.BANCO_SALDOVIRTUAL = b.BANCO_SALDOVIRTUAL + linhaCredito.CREDI_VALORCREDITO
        WHERE b.BANCO_ID = idBanco;*/

      DELETE FROM GARRANTIADOCREDITO g
        WHERE g.GARDOC_CREDI_ID = idCredito;

      DELETE FROM PAGAMENTO p
        WHERE p.PAGA_CREDI_ID = idCredito;

      DELETE FROM DOCUMENTREGUE d
        WHERE d.DOCENTER_CREDI_ID = idCredito;

      DELETE FROM CERDITO c
        WHERE c.CREDI_ID = idCredito;

    END IF;



    RETURN message;
END;