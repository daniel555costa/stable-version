create PROCEDURE "PRC_REG_TRABALHOUSER" 
(
   USER_ID_REG VARCHAR2,
   USER_ID     VARCHAR2,
   DATA_INICIO DATE,
   DATA_FIM    DATE,
   idAgencia NUMBER
)
  IS
  BEGIN

    INSERT INTO TRABALHA (TRAB_USER_ID, 
                          TRAB_DTINI, 
                          TRAB_DTFIM)
                          VALUES (USER_ID,
                                  DATA_INICIO,
                                  DATA_FIM);
  END;