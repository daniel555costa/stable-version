create trigger TG_NEXT_LOCALIDADE
	before insert
	on LOCALIDADE
	for each row
BEGIN
  IF inserting
  THEN
    IF :NEW."LOCAL_ID" IS NULL
    THEN
      SELECT SEQ_LOCALIDADE.NEXTVAL
        INTO :NEW."LOCAL_ID"
        FROM dual;
    END IF;
  END IF;
END;
