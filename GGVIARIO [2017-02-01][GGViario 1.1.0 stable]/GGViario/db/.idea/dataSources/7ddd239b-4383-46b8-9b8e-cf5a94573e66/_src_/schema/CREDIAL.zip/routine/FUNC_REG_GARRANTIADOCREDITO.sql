create FUNCTION         FUNC_REG_GARRANTIADOCREDITO 
(
    USER_ID NUMBER,
    idTipoGarantia VARCHAR2,
    idCredito       VARCHAR2,
    idAgencia NUMBER,
    descricao CHARACTER VARYING
)
  RETURN VARCHAR
  IS
  BEGIN
    INSERT INTO GARRANTIADOCREDITO (GARDOC_CREDI_ID, 
                                    GARDOC_GARR_ID, 
                                    GARDOC_USER_ID,
                                    GARDOC_AGE_ID,
                                    GARDOC_DESC)
                                    VALUES (idCredito, 
                                            idTipoGarantia, 
                                            USER_ID,
                                            idAgencia,
                                            descricao);
    RETURN 'true';
  END;