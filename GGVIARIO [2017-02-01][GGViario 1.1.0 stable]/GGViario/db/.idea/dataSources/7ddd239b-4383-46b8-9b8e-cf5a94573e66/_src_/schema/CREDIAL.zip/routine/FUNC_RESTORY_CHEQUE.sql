create FUNCTION func_restory_cheque
  RETURN  CHARACTER VARYING
  IS
    vResult CHARACTER VARYING(100);
  BEGIN

    vResult := 'false;Nenhum cheque para restaurar!';

    FOR I IN (SELECT *
                FROM TABLE (FUNCT_LOAD_RESTORE_EFECT()))
    LOOP
      -- Para o cheque a receber -1
      IF I.OPR = -1 THEN
        UPDATE CHEQUEMPRESA
          SET CHEQ_ESTADO = -1
          WHERE CHEQ_ID = I.ID;

        vResult := 'true;Ultimo Cheque Elimindao';
      END IF;

      IF I.OPR = 1 THEN
        UPDATE  CHEQUEMPRESA
          SET CHEQ_ESTADO = 1
          WHERE CHEQ_ID = I.ID;

        vResult := 'true;Cheque restaurado';
      END IF;
    END LOOP;

    RETURN vResult;
  END;