create trigger TG_NEXT_PAGAMENT
	before insert
	on PAGAMENTO
	for each row
BEGIN
  IF inserting AND :NEW.PAGA_ID IS NULL THEN
    :NEW.PAGA_ID := SEQ_PAGAMENTO.NEXTVAL;
  END IF;
END;
