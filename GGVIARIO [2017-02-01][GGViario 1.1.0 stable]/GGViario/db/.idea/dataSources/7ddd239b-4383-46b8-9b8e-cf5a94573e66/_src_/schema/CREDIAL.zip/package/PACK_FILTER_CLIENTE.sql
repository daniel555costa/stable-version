create PACKAGE PACK_FILTER_CLIENTE AS 
      
   TYPE FilterClientSimple is table of VER_CLIENTE_SIMPLE%ROWTYPE;
   
   function filterClient(value character varying) return FilterClientSimple PIPELINED;
   
   function filterCLinetNif(clientNif character varying) return FilterClientSimple PIPELINED;
   
   function filterCLinetName(clientName character varying) return FilterClientSimple PIPELINED;
   
   function filterCLinetDocumentoPay(numDocumentoPagamento character varying) return FilterClientSimple PIPELINED;
   
   function filterCLinetGarrantia(clientGarrantia character varying) return FilterClientSimple PIPELINED;

END PACK_FILTER_CLIENTE;