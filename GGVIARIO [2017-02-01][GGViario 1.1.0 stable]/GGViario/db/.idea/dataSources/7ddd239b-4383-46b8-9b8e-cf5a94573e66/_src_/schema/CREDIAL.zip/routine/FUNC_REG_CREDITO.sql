create FUNCTION FUNC_REG_CREDITO 
 (
    USER_ID         VARCHAR2,
    NIF_CLIENTE     VARCHAR2,
    VALORCREDITO    BINARY_DOUBLE,
    TOTALPAGAR      BINARY_DOUBLE,
    NUMEROPRESTACAO NUMBER,
    DATA_INICIO     DATE,
    DATA_FIM        DATE,
    ID_DA_TAXA      NUMBER,
    NUMERO_DE_CHECK VARCHAR2,
    ID_FONTE        NUMBER, 
    ID_DO_CHECK     NUMBER,
    VALOR_DESCOTO   BINARY_DOUBLE,
    ID_TIPOPAGAMENTO  NUMBER,
    TAEG            BINARY_DOUBLE,
    idAgencia NUMBER
 )
  RETURN VARCHAR2
  IS
    idSeguro NUMBER;
    idCredito NUMBER;
    NUMEROCREDITO VARCHAR2(22) := FUNC_GENERATE_NUMCRIDITO(NIF_CLIENTE, NUMERO_DE_CHECK);
    tt NUMBER;

  BEGIN
    -- validar a disponibilidade do saldo no banco
    /*SELECT COUNT(*) INTO tt
      FROM CHEQUEMPRESA c
        INNER JOIN BANCO b1 ON c.CHEQ_BANCO_ID = b1.BANCO_ID
      WHERE b1.BANCO_SALDO >= VALORCREDITO
        AND c.CHEQ_ID = ID_DO_CHECK;
    */
    
     if NUMEROCREDITO IS NULL THEN
       RETURN '-1;O numero de cheque não cumpre os requisitos minimo cheque: '+NUMERO_DE_CHECK;
    end IF;
    
    SELECT COUNT(*) INTO tt
       FROM CERDITO CT
       WHERE CT.CREDI_CHEQ_ID = ID_DO_CHECK
          AND CT.CREDI_NUMCHEQUE = NUMERO_DE_CHECK;
    
    IF tt != 0 THEN RETURN '-1;O numero de cheque já esta sendo utilizado!'; END IF;
       
    SELECT s.SEG_ID
            INTO idSeguro
       FROM SEGURO s 
       WHERE s.SEG_STATE = 1
         AND ROWNUM = 1;

    /*-- Verificar se existe algum cheque valido para esse utilizador
    SELECT COUNT(*)
      INTO tt
      FROM REQUISICAOCHEQUE d
      WHERE d.REQCHEQ_CHEQ_ID = ID_DO_CHECK
        AND d.REQCHEQ_USER_ID = USER_ID
        AND (d.REQCHEQ_STATE = 1
        AND d.REQCHEQ_DTLAST >= (SYSDATE - INTERVAL '15' MINUTE));

    -- se o credito do cliente estiver invalidado enta nao aceitar
    IF tt = 0
    THEN
      RETURN '-1;O tempo limite do cheque aspirou!';
    END IF;*/


    /*-- VALIDADO OS CREDITOS ANTERIORES DO CLIENTE
    SELECT COUNT(*) 
      INTO TT
      FROM CERDITO
      WHERE CREDI_DOS_NIF = NIF_CLIENTE;*/

    INSERT INTO CERDITO (CREDI_DOS_NIF, 
                         CREDI_VALORCREDITO,
                         CERDI_TOTALAPAGAR,
                         CERDI_NUMPRESTACOES,
                         CREDI_DATAINI,
                         CREDI_FIM,
                         CREDI_NUMCERDI,
                         CERDI_USER_ID,
                         CREDI_TAXA_ID,
                         CREDI_NUMCHEQUE,
                         CREDI_FONTE_ID,
                         CREDI_CHEQ_ID,
                         CREDI_DESCONTO,
                         CREDI_SEGUR_ID,
                         CREDI_TIPOPAGA_ID,
                         CREDIT_TAEG,
                         CREDI_AGE_ID)
                         VALUES (NIF_CLIENTE,
                                 VALORCREDITO, 
                                 TOTALPAGAR,
                                 NUMEROPRESTACAO,
                                 DATA_INICIO,
                                 DATA_FIM,
                                 NUMEROCREDITO,
                                 USER_ID,
                                 ID_DA_TAXA,
                                 NUMERO_DE_CHECK,
                                 ID_FONTE,
                                 ID_DO_CHECK,
                                 VALOR_DESCOTO,
                                 idSeguro,
                                 ID_TIPOPAGAMENTO,
                                 TAEG,
                                 idAgencia)
                      RETURNING CREDI_ID INTO idCredito;

    RETURN idCredito||';'|| NUMEROCREDITO;
  END;