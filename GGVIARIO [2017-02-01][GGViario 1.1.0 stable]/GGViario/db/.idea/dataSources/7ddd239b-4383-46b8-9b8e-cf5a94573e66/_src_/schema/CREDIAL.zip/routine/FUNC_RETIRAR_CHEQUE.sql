create FUNCTION  FUNC_RETIRAR_CHEQUE 
(
    userId NUMBER,
    idBanco NUMBER,
    idAgencia NUMBER,
    valorRequisicao FLOAT
)
RETURN VARCHAR2
IS
   -- Toda a regra de retirar o cheque numa cadineta esta disponivel no pacote regras
   res PACK_REGRAS.PTP_RandomCheck := PACK_REGRAS.PFUNC_GET_CHEQUE_RANDOM(userId, idBanco, idAgencia, valorRequisicao);
   message VARCHAR2(1000);
BEGIN
  -- RETURN 'USER='||userId||'; AGENCIA = '||idAgencia|| '; BANCO=' || idBanco || ';VARLO ='|| valorRequisicao;
    message := (CASE
                  WHEN res.numSequencia = 'CHEQUE' THEN  'Nao existe cheques para banco!!'
                  WHEN res.numSequencia = 'SALDO' THEN 'Saldo insuficiente no banco!!'
                  ELSE ''
                END);
                
    -- Retornar a concatenacao do id do cheque e o seu numero
   RETURN res.idCheque||';'||res.numSequencia||';'||message;
END;