create FUNCTION FUNC_USER_FORCEPWD 
(
    idUserAdm VARCHAR2, -- o nif do adiministrador 
    idUserForce VARCHAR2 -- O id do utilizador que serra forcado a alterar a palavra pada
)RETURN VARCHAR2
IS
BEGIN
   UPDATE T_USER U
     SET U.USER_ACCESS = 2,
         U.USER_PWD = FUNC_MD5(U.USER_ID)
     WHERE U.USER_ID = idUserForce;
     
   RETURN 'true';
END;