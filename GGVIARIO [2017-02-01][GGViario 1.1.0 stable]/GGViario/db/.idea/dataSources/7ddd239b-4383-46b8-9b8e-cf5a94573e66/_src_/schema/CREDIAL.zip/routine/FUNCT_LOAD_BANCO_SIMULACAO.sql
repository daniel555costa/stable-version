create FUNCTION         FUNCT_LOAD_BANCO_SIMULACAO 
(
   idAgencia NUMBER,
   idUser NUMBER,
   valorNecessario FLOAT
)
RETURN PACK_VIEW.FilterBanco PIPELINED
IS 
BEGIN
    FOR I IN(SELECT vb.*
                  FROM VER_BANCO vb
                    INNER JOIN CHEQUEMPRESA c ON c.CHEQ_BANCO_ID = vb.ID
                    INNER JOIN AGENCIA a ON c.CHEQ_AGE_ID = a.AGE_ID
                    INNER JOIN TRABALHA  tr ON a.AGE_ID = tr.TRAB_AGE_ID
                  WHERE tr.TRAB_USER_ID = idUser
                    AND a.AGE_ID = idAgencia
                    AND tr.TRAB_ESTADO = 1
                    -- O valor do saldo virtual foi substituido para o valor do saldo porcausa do numero de cheque que sera completado a mao
                    AND vb.SALDOSF >= valorNecessario
                    AND c.CHEQ_ESTADO = 1) LOOP
       PIPE ROW(I);
    END LOOP;
END;