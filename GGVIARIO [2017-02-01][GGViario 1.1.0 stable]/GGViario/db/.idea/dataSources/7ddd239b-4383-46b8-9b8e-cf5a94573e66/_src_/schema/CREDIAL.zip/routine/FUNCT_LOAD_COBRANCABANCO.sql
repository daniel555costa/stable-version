create FUNCTION FUNCT_LOAD_COBRANCABANCO 
(
    idBancao NUMBER,
    dataInicio DATE,
    dataFim DATE,
    idAgencia NUMBER
)RETURN PACK_VIEW.FilterCobrancaBanco PIPELINED IS
BEGIN
   -- Gestao do banco 
     -- Carregar os movimentos de um banco em um intervalo do tempo
    
   FOR I IN(SELECT *
                FROM VER_COBRANCABANCO VC 
                WHERE TO_DATE(VC.DATA, 'DD-MM-YYYY') BETWEEN dataInicio AND dataFim
                   AND VC.ID = idBancao 
                   AND VC."ID AGENCIA"  = (CASE WHEN idAgencia IS NULL THEN VC."ID AGENCIA" ELSE idAgencia END)) LOOP
      PIPE ROW(I);
   END LOOP;
END;