create FUNCTION FUNC_GENERATE_NUMCRIDITO(clienteNIF VARCHAR2,
                                     numCheque  NVARCHAR2)
    RETURN VARCHAR2
    IS
       -- O codigo do credito devera ser gerado da seginte forma
       -- BBRTTTCCCCCC
       
       -- Onde os B correspondem ao codigo do banco
       -- R coresponde a um numero aleatorio
       -- T corresponde a um tempo aleaterio
       
       -- segunda visoa do codigo
       -- EEDDDDEEEEEE
       -- Onde o E sera um valor determidano pelo cheque nao importa quantas vezes for a tentaviva
       -- Onde o D sera um numero que sera alterado a cada tentativa
       
       -- randon e um numero retirado a calhar vai de 0 .. 9
       -- codBanco o codigo do banco retirado do cheque
       
       codCredito character varying(12);
       
       -- partes --
       codBancoParte CHARACTER VARYING (2);
       randomParte character varying(1);
       nifTimeParte CHARACTER VARYING(3);
       digitosChequeParte character varying(6);
       -- partes -- 
       
       
       dinamicParte character varying(4);
       codBancoAux CHARACTER VARYING(4);
       codBancoNumber  NUMBER;
       randomSub NUMBER;
       randomParteAux NUMBER;
       
       dia NUMBER;
       mes NUMBER;
       ano NUMBER;
       hora NUMBER;
       minuto NUMBER;
       segundo NUMBER;
       microSegundo NUMBER;
       
       timeParte NUMBER;
       sumNumberInNifClinetRandom NUMBER;
       nifTimeParteNumber NUMBER;
       
       
       
      numTentativasMaxima number := 9999;
      ttNumCreditosEncontrados NUMBER;
      
      creditoLen number :=length(numCheque); 
      
    BEGIN
      
      IF creditoLen IS NULL OR creditoLen <6 THEN 
         RETURN null;
      END IF;
      
      -- obter os qutros primeiros digitos do banco
      codBancoAux := SUBSTR(numCheque,1, 4);
      
      -- transformalos em numero
      codBancoNumber := TO_NUMBER(codBancoAux);
      
      -- Para os que o numero do codigo do banco for maior que sera processado os segunte
      WHILE 
         codBancoNumber > 99
      LOOP
         codBancoNumber := codBancoNumber - 100;
      END LOOP;
      
      -- codigo de banco feito
      codBancoParte := trim(to_char(codBancoNumber, '00'));
      
      -- utimos digitos do banco feitos
      digitosChequeParte := SUBSTR2(numCheque, -6);
      
      -- Tentativa de retirar um numero a calha 
      -- A quantidade de tentativa nao pode exeder a quantidade de tentativa maxima definida na variavel
      while
         codCredito IS NULL 
            AND numTentativasMaxima > 0 
      loop
         -- criar o rando
         randomParteAux := SYS.DBMS_RANDOM.value(0, 10);
         IF randomParteAux < 1 THEN
           randomParteAux := 0;
         END IF;
         randomParte := SUBSTR(randomParteAux, 1, 1);
         
         -- criar o somatorio da data
         dia := to_number(to_char(sysdate, 'DD'));
         mes := to_number(to_char(sysdate, 'MM'));
         ano := to_number(to_char(sysdate, 'YY'));
         hora := to_number(to_char(systimestamp, 'DD'));
         minuto := to_number(to_char(systimestamp, 'MI'));
         segundo := to_number(to_char(systimestamp, 'SS'));
         microSegundo := to_number(to_char(systimestamp, 'FF3'));
         
         timeParte := dia + mes + ano + hora + minuto + segundo + microSegundo;
         
         -- Somara os digitos do NIF do cliente de uma forma aleatoria
         sumNumberInNifClinetRandom := randomSum (clienteNIF);
         
         -- Soma o somatorio da data com o somatorio dos NIFs dos clientes
         nifTimeParteNumber := timeParte + sumNumberInNifClinetRandom;
         
         -- Quando a soma da data com o NIF exeder as tres casas de centena entao devera ser criado um randan para diminuir isso
         while
            nifTimeParteNumber >= 999 
         loop
            randomSub := to_number(to_char(SYS.DBMS_RANDOM.value(1, nifTimeParteNumber-1), '9999'));
            nifTimeParteNumber := nifTimeParteNumber - randomSub;
         end loop;
         
         nifTimeParte := trim(to_char(nifTimeParteNumber, '000'));
         dinamicParte := randomParte||nifTimeParteNumber;
         
         codCredito := codBancoParte||dinamicParte||digitosChequeParte;
         
         IF codCredito IS NULL THEN
            RETURN NULL; END IF;
            
         
         
         SELECT COUNT(*) INTO ttNumCreditosEncontrados
            FROM CERDITO CE
            WHERE CE.CREDI_NUMCERDI = codCredito;
            
         if ttNumCreditosEncontrados > 0 then
            codCredito := null;
         end if;
        
         numTentativasMaxima := numTentativasMaxima -1;
      end loop;
      
      
      RETURN codCredito;
    END;