create trigger TG_NEXT_TAXA
	before insert
	on TAXA
	for each row
BEGIN
  IF inserting
  THEN
    IF :NEW.TAXA_ID IS NULL
    THEN
      SELECT SEQ_TAXA.NEXTVAL
        INTO :NEW.TAXA_ID
        FROM dual;
    END IF;
  END IF;
END;
