create FUNCTION FUNC_REG_HISTORICOCLIENTE 
(
    USER_APP       VARCHAR2,
    NIF            VARCHAR2,
    MORADA         VARCHAR2,
    TELEFONE       VARCHAR2,
    TELEMOVEL      VARCHAR2,
    SERVICO        VARCHAR2,
    ID_ESTADO_CIVIL NUMBER,
    ID_LOCALIDADE   NUMBER,
    ID_PROFISSAO     NUMBER,
    ID_TRABALHO NUMBER,
    idAgencia NUMBER,
    mail CHARACTER VARYING
)
  RETURN VARCHAR2
  IS
    TT              NUMBER;
  BEGIN 

    -- INABILITAR OS HITORICOS ANTERIOR
    UPDATE HISTORICOCLIENTE
      SET HISDOS_ESTADO = 0
      WHERE HISDOS_DOS_NIF = NIF
      AND HISDOS_ESTADO = 1;

    -- CRINADO NOVO HISTORICO
    INSERT INTO HISTORICOCLIENTE (HISDOS_DOS_NIF, 
                                  HISDOS_MORADA, 
                                  HISDOS_FIXO,
                                  HISDOS_MOVEL,
                                  HISDOS_SERVICO,
                                  HISDOS_USER_ID,
                                  HISDOS_CIVIL_ID,
                                  HISDOS_LOCAL_ID,
                                  HISDOS_PROF_ID,
                                  HISDOS_TRAB_ID,
                                  HISDOS_AGE_ID,
                                  HISDOS_MAIL)
                                  VALUES (NIF,
                                          MORADA,
                                          TELEFONE,
                                          TELEMOVEL,
                                          SERVICO,
                                          USER_APP,
                                          ID_ESTADO_CIVIL,
                                          ID_LOCALIDADE,
                                          ID_PROFISSAO,
                                          ID_TRABALHO,
                                          idAgencia,
                                          mail);

    RETURN 'true';
  END;