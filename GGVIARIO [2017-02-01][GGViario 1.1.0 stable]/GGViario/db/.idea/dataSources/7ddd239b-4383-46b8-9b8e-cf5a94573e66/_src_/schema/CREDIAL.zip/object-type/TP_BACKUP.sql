create TYPE           "TP_BACKUP"                                          AS OBJECT 
(
    /* Types Values
       DT - {Date, TIMESTAMP}
       TXT - {CHAR, VARCHAR, TEXT}
       NUM - {NUMBER, DOUBLE, FLOAT ...}
    */
    columnName VARCHAR2(20),
    valueText VARCHAR2(4000),
    typeColumn VARCHAR2(5),
    
    MEMBER FUNCTION getColumn RETURN VARCHAR2,
    
    MEMBER FUNCTION getValue RETURN VARCHAR2,
    
    MEMBER FUNCTION getUpdate RETURN VARCHAR2
);