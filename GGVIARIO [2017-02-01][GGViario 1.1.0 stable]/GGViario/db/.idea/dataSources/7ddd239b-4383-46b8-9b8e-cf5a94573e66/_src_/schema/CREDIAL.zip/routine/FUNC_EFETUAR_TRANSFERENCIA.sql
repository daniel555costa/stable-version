create FUNCTION FUNC_EFETUAR_TRANSFERENCIA 
(
   idUser NUMBER,
   valorTransferir FLOAT,
   idBancoRetirar NUMBER, -- (SEND BANCO) Banco em que o dinheiro ira sair
   idBancoReceber NUMBER, -- (RECIVE BANCO) Banco em que ira receber o saldo
   descrincaoOpr VARCHAR2,
   idAgencia NUMBER
)RETURN VARCHAR2
IS
   linhaBano BANCO%ROWTYPE;
   resp VARCHAR2(100);
   transfer BOOLEAN;
BEGIN
   SELECT *
      INTO linhaBano
      FROM BANCO BN
      WHERE BN.BANCO_ID = idBancoRetirar;
  IF linhaBano.BANCO_SALDO < valorTransferir THEN RETURN 'Nao existe saldo suficiente no banco para transferencia';
  ELSE
     -- Retirar o saldo de um banco
     resp := FUNC_REG_MOVIMENTOBANCO(idUser, idBancoRetirar, valorTransferir, 0, descrincaoOpr, idAgencia);
     IF UPPER(resp) = UPPER('TRUE') THEN 
        -- Colocar o saldo em outro banco
        resp := FUNC_REG_MOVIMENTOBANCO(idUser, idBancoReceber,0, valorTransferir, descrincaoOpr, idAgencia);
     END IF;
     
     -- Se transferiu finalizar a operacao
     IF UPPER(resp) = UPPER('TRUE') THEN
        COMMIT;
        RETURN 'true';
     ELSE 
        -- caso cintrario voltar tuda  traz
        ROLLBACK;
        RETURN resp;
     END IF;
  END IF;
END;