create type           SYS_PLSQL_20600_39_1 as object ("TAXA" VARCHAR2(126),
"DIAS" NUMBER(5),
"DE" DATE,
"À" DATE,
"TIPO_CREDITO" NUMBER(6));